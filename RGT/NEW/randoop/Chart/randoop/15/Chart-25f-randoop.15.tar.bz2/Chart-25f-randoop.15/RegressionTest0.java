import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 1L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 0L, (float) (byte) -1, textAnchor4, (double) ' ', (float) '#', (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.magenta;
        java.awt.Stroke stroke6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 10, (float) 2, textAnchor4, (double) 10L, textAnchor6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke2, paint3, stroke4, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (-1.0d), "", textAnchor3, textAnchor4, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, (float) (short) 10, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-165) + "'", int3 == (-165));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleEdge.RIGHT", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Stroke stroke2 = null;
        try {
            valueMarker1.setStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int3 = java.awt.Color.HSBtoRGB((float) '4', (float) (short) -1, (float) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        try {
            org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font1, (java.awt.Paint) color3, rectangleEdge4, horizontalAlignment5, verticalAlignment6, rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 15, 0.05d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "RectangleEdge.RIGHT", "RectangleEdge.RIGHT", categoryDataset3, comparable4, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.color.ColorSpace colorSpace7 = null;
        float[] floatArray8 = new float[] {};
        try {
            float[] floatArray9 = color0.getComponents(colorSpace7, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean3 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) 0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            java.lang.String str6 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("", font1);
        java.awt.Paint paint3 = textFragment2.getPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            float float6 = textFragment2.calculateBaselineOffset(graphics2D4, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { (-1.0d) };
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] {};
        double[] doubleArray9 = new double[] { 1L, (byte) 10, '4', (byte) 10, ' ', 10L };
        double[] doubleArray16 = new double[] { 1L, (byte) 10, '4', (byte) 10, ' ', 10L };
        double[] doubleArray23 = new double[] { 1L, (byte) 10, '4', (byte) 10, ' ', 10L };
        double[][] doubleArray24 = new double[][] { doubleArray9, doubleArray16, doubleArray23 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray2, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        java.awt.Shape shape3 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis0, shape3, "ThreadContext", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getRGB();
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4194112) + "'", int1 == (-4194112));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4194112) + "'", int2 == (-4194112));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.awt.Image image19 = projectInfo17.getLogo();
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleEdge.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleEdge.RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-65281), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        textLine0.removeFragment(textFragment3);
        float float6 = textFragment3.getBaselineOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Shape shape0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        int int8 = color1.getGreen();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray14 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = color1.getRGBComponents(floatArray15);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = chartChangeEventType1.equals((java.lang.Object) rectangleEdge2);
        try {
            double double4 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) (short) 10, categoryLabelWidthType4, (float) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range1, lengthConstraintType2, 10.0d, range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        java.awt.Stroke stroke8 = null;
        try {
            valueMarker1.setStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str7 = rectangleEdge6.toString();
        try {
            java.util.List list8 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.RIGHT" + "'", str7.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 15, (double) 0.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("");
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle0.addChangeListener(titleChangeListener3);
        double double5 = textTitle0.getHeight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.getInfo();
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color15 = java.awt.Color.getColor("", (int) '4');
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint18 = categoryAxis17.getTickMarkPaint();
        try {
            org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem(attributedString0, "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", "hi!", "RectangleEdge.RIGHT", shape12, (java.awt.Paint) color15, stroke16, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.util.List list10 = projectInfo7.getContributors();
        java.util.List list11 = projectInfo7.getContributors();
        projectInfo7.addOptionalLibrary("RectangleEdge.RIGHT");
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart1, 0, (int) (byte) 10);
        chartProgressEvent4.setPercent(100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D(10.0d, 0.0d);
        boolean boolean5 = categoryLabelPositions1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("", (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", "", "hi!", shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", graphics2D1, (float) '#', (float) (short) 100, textAnchor4, (double) '#', (float) (short) -1, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleEdge.RIGHT");
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        double double2 = size2D0.width;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        int int5 = color3.getGreen();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 192 + "'", int5 == 192);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        valueMarker1.setValue(0.05d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 0.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker1.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets8.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockBorder4.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        java.awt.Color color3 = java.awt.Color.GRAY;
        boolean boolean4 = plotRenderingInfo1.equals((java.lang.Object) color3);
        java.awt.geom.Point2D point2D5 = null;
        try {
            int int6 = plotRenderingInfo1.getSubplotIndex(point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        float float19 = categoryPlot9.getBackgroundImageAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint22 = categoryAxis21.getTickMarkPaint();
        categoryAxis21.setUpperMargin(1.0d);
        java.lang.Object obj25 = categoryAxis21.clone();
        try {
            categoryPlot9.setDomainAxis((-4194112), categoryAxis21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        java.util.List list12 = textBlock6.getLines();
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = null;
        try {
            categoryPlot9.addDomainMarker(categoryMarker43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle5.getVerticalAlignment();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) (byte) 100);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean14 = range11.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint10.toRangeWidth(range11);
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle5.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) (-1));
        axisState0.cursorDown((double) (-4194112));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(192, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "RectangleEdge.RIGHT", "hi!");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        double double7 = range3.getCentralValue();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        float float19 = categoryPlot9.getBackgroundImageAlpha();
        java.awt.Paint paint20 = null;
        try {
            categoryPlot9.setRangeCrosshairPaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 15);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("HorizontalAlignment.CENTER", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection3 = categoryItemRendererState1.getEntityCollection();
        double double4 = categoryItemRendererState1.getBarWidth();
        double double5 = categoryItemRendererState1.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(entityCollection3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray18);
        org.jfree.data.Range range20 = statisticalBarRenderer0.findRangeBounds(categoryDataset19);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke24 = numberAxis23.getAxisLineStroke();
        try {
            statisticalBarRenderer0.setSeriesStroke((int) (byte) -1, stroke24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        java.lang.Comparable comparable10 = legendItemBlockContainer7.getSeriesKey();
        java.lang.Object obj11 = legendItemBlockContainer7.clone();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1.0d + "'", comparable10.equals(1.0d));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        double double3 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke2 = numberAxis1.getAxisLineStroke();
        double double3 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-165), 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        boolean boolean45 = categoryPlot9.isDomainZoomable();
        try {
            categoryPlot9.zoom((double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        int int9 = statisticalBarRenderer0.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        java.awt.Paint paint14 = statisticalBarRenderer0.getItemLabelPaint((int) '4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            legendItemBlockContainer7.setBounds(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        boolean boolean45 = categoryPlot9.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder46 = null;
        try {
            categoryPlot9.setRowRenderingOrder(sortOrder46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-2), (double) (-2), (double) 0.0f, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        double double10 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setFixedAutoRange((double) 0.0f);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis4.configure();
        org.jfree.data.RangeType rangeType6 = numberAxis4.getRangeType();
        java.awt.Paint paint7 = numberAxis4.getTickMarkPaint();
        try {
            java.lang.Object obj8 = blockContainer0.draw(graphics2D1, rectangle2D2, (java.lang.Object) numberAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.Object obj1 = size2D0.clone();
        size2D0.width = '#';
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray18);
        org.jfree.data.Range range20 = statisticalBarRenderer0.findRangeBounds(categoryDataset19);
        java.awt.Stroke stroke21 = null;
        try {
            statisticalBarRenderer0.setBaseOutlineStroke(stroke21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation((int) '#', axisLocation16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = null;
        try {
            categoryPlot9.setOrientation(plotOrientation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax((double) 10L);
        axisState0.cursorLeft(0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("HorizontalAlignment.CENTER", graphics2D1, (float) '4', (float) (short) 1, 0.5d, (float) (-1L), (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("java.awt.Color[r=255,g=0,b=255]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=255,g=0,b=255]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        numberAxis1.setLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets1.calculateBottomOutset(0.0d);
        java.awt.Color color5 = java.awt.Color.lightGray;
        boolean boolean6 = rectangleInsets1.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        int int13 = statisticalBarRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        projectInfo7.setVersion("ThreadContext");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        try {
            java.awt.GradientPaint gradientPaint3 = standardGradientPaintTransformer0.transform(gradientPaint1, shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.awt.Stroke stroke16 = null;
        try {
            statisticalBarRenderer0.setBaseOutlineStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.toString();
        java.util.List list20 = projectInfo7.getContributors();
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str19.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertNull(list20);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) (byte) 1, (double) (-4194112), (double) 100.0f, (double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100, (float) 10, (float) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.clone();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        try {
            categoryPlot9.mapDatasetToRangeAxis((-165), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-165), (double) (-165), 1, (java.lang.Comparable) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        numberAxis1.setUpperBound((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) rectangleEdge10);
        try {
            double double12 = numberAxis1.lengthToJava2D(0.0d, rectangle2D8, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        java.lang.Object obj10 = defaultDrawingSupplier8.clone();
        try {
            java.awt.Paint paint11 = defaultDrawingSupplier8.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = categoryPlot9.getDrawingSupplier();
        categoryPlot9.mapDatasetToRangeAxis(15, 100);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(drawingSupplier48);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("java.awt.Color[r=255,g=0,b=255]");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Paint paint6 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        java.awt.Paint paint12 = textFragment11.getPaint();
        boolean boolean13 = statisticalBarRenderer0.equals((java.lang.Object) textFragment11);
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textFragment11.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setAutoRangeMinimumSize(0.05d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        statisticalBarRenderer0.setPlot(categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot24.getDomainMarkers((int) (short) 1, layer26);
        categoryPlot24.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot24.setDomainAxisLocation(0, axisLocation31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot24.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot24.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean38 = statisticalBarRenderer36.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer36.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer36.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[][] doubleArray54 = new double[][] { doubleArray48, doubleArray49, doubleArray50, doubleArray51, doubleArray52, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray54);
        org.jfree.data.Range range56 = statisticalBarRenderer36.findRangeBounds(categoryDataset55);
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer36);
        categoryPlot10.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer36);
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis61.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis67, categoryItemRenderer68);
        org.jfree.chart.util.Layer layer71 = null;
        java.util.Collection collection72 = categoryPlot69.getDomainMarkers((int) (short) 1, layer71);
        categoryPlot69.setBackgroundImageAlignment((int) '#');
        categoryPlot69.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        try {
            statisticalBarRenderer36.drawDomainMarker(graphics2D59, categoryPlot69, categoryAxis77, categoryMarker78, rectangle2D79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNull(collection72);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        java.lang.String str6 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=192,g=0,b=192]" + "'", str6.equals("java.awt.Color[r=192,g=0,b=192]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        int int61 = chartProgressEvent5.getPercent();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 15 + "'", int61 == 15);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) categoryLabelPositions1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        java.awt.Paint paint12 = textFragment11.getPaint();
        boolean boolean13 = statisticalBarRenderer0.equals((java.lang.Object) textFragment11);
        java.lang.String str14 = textFragment11.getText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopOutset((double) 1);
        double double4 = rectangleInsets0.calculateTopOutset((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = valueMarker1.getLabelOffsetType();
        java.lang.Class class9 = null;
        try {
            java.util.EventListener[] eventListenerArray10 = valueMarker1.getListeners(class9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        categoryAxis0.setTickMarksVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        double double4 = numberAxis1.getLowerBound();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot16.getDomainMarkers((int) (short) 1, layer18);
        categoryPlot16.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot16.setDomainAxisLocation(0, axisLocation23);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot16.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot16.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean30 = statisticalBarRenderer28.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer28.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer28.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[][] doubleArray46 = new double[][] { doubleArray40, doubleArray41, doubleArray42, doubleArray43, doubleArray44, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray46);
        org.jfree.data.Range range48 = statisticalBarRenderer28.findRangeBounds(categoryDataset47);
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer28);
        categoryPlot16.setRangeCrosshairLockedOnData(false);
        categoryPlot16.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier55 = categoryPlot16.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot16);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace60 = numberAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot16, rectangle2D57, rectangleEdge58, axisSpace59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(drawingSupplier55);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color20 = color19.darker();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color19, jFreeChart21, (int) (short) 10, 0);
        chartProgressEvent24.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis29.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot37.getDomainMarkers((int) (short) 1, layer39);
        categoryPlot37.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot37.setDomainAxisLocation(0, axisLocation44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot37.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = categoryPlot37.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean51 = statisticalBarRenderer49.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer49.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer49.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray62 = new double[] {};
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[][] doubleArray67 = new double[][] { doubleArray61, doubleArray62, doubleArray63, doubleArray64, doubleArray65, doubleArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray67);
        org.jfree.data.Range range69 = statisticalBarRenderer49.findRangeBounds(categoryDataset68);
        categoryPlot37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer49);
        categoryPlot37.setRangeCrosshairLockedOnData(false);
        categoryPlot37.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier76 = categoryPlot37.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot37);
        java.lang.Object obj78 = jFreeChart77.getTextAntiAlias();
        chartProgressEvent24.setChart(jFreeChart77);
        org.jfree.chart.title.TextTitle textTitle80 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment81 = textTitle80.getVerticalAlignment();
        java.awt.Paint paint82 = textTitle80.getBackgroundPaint();
        jFreeChart77.addSubtitle((org.jfree.chart.title.Title) textTitle80);
        categoryPlot9.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart77);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(legendItemCollection46);
        org.junit.Assert.assertNull(categoryItemRenderer48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNull(range69);
        org.junit.Assert.assertNotNull(drawingSupplier76);
        org.junit.Assert.assertNull(obj78);
        org.junit.Assert.assertNotNull(verticalAlignment81);
        org.junit.Assert.assertNull(paint82);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[] doubleArray6 = new double[] { 10.0f, 10.0d, 0.0f, 10.0f };
        double[] doubleArray11 = new double[] { 10.0f, 10.0d, 0.0f, 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str3 = rectangleEdge2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str8 = rectangleEdge7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str13 = rectangleEdge12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions11.getLabelPosition(rectangleEdge12);
        double double15 = categoryLabelPosition14.getAngle();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition4, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.RIGHT" + "'", str8.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.RIGHT" + "'", str13.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.0d) + "'", double15 == (-0.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) categoryLabelPositions2);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", "TextBlockAnchor.TOP_RIGHT", "java.awt.Color[r=255,g=0,b=255]", "RectangleEdge.RIGHT");
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        textTitle0.setVerticalAlignment(verticalAlignment5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = color7.darker();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color7, jFreeChart9, (int) (short) 10, 0);
        chartProgressEvent12.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getDomainMarkers((int) (short) 1, layer27);
        categoryPlot25.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setDomainAxisLocation(0, axisLocation32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot25.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot25.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer37.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer37.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray49, doubleArray50, doubleArray51, doubleArray52, doubleArray53, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray55);
        org.jfree.data.Range range57 = statisticalBarRenderer37.findRangeBounds(categoryDataset56);
        categoryPlot25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer37);
        categoryPlot25.setRangeCrosshairLockedOnData(false);
        categoryPlot25.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = categoryPlot25.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot25);
        java.lang.Object obj66 = jFreeChart65.getTextAntiAlias();
        chartProgressEvent12.setChart(jFreeChart65);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = textTitle68.getVerticalAlignment();
        java.awt.Paint paint70 = textTitle68.getBackgroundPaint();
        jFreeChart65.addSubtitle((org.jfree.chart.title.Title) textTitle68);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart65);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent73 = null;
        try {
            jFreeChart65.plotChanged(plotChangeEvent73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(drawingSupplier64);
        org.junit.Assert.assertNull(obj66);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertNull(paint70);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        java.lang.Object obj10 = defaultDrawingSupplier8.clone();
        try {
            java.awt.Stroke stroke11 = defaultDrawingSupplier8.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.util.List list10 = projectInfo7.getContributors();
        java.util.List list11 = projectInfo7.getContributors();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.RIGHT", "RectangleEdge.RIGHT", "", "");
        basicProjectInfo16.setVersion("ThreadContext");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo16);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis3.configure();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3.setRange(range5, false, false);
        boolean boolean9 = labelBlock1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7, dataset8, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendItemBlockContainer10.getPadding();
        double double13 = rectangleInsets11.calculateLeftInset((double) (-2));
        categoryAxis0.setLabelInsets(rectangleInsets11);
        categoryAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getNegativeItemLabelPosition((int) ' ', 255);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Shape shape4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis6.configure();
        org.jfree.data.RangeType rangeType8 = numberAxis6.getRangeType();
        java.awt.Paint paint9 = numberAxis6.getTickMarkPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean12 = statisticalBarRenderer10.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer10.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer10.setDrawBarOutline(false);
        java.awt.Stroke stroke20 = statisticalBarRenderer10.lookupSeriesOutlineStroke((int) '#');
        java.awt.Paint paint21 = null;
        try {
            org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=0,b=255]", "ThreadContext", "ClassContext", "java.awt.Color[r=255,g=0,b=255]", shape4, paint9, stroke20, paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (-2));
        try {
            org.jfree.data.xy.XYDataset xYDataset6 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 2.0d, 0.0d, (-65281), (java.lang.Comparable) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        textTitle0.setVerticalAlignment(verticalAlignment5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color8 = color7.darker();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color7, jFreeChart9, (int) (short) 10, 0);
        chartProgressEvent12.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getDomainMarkers((int) (short) 1, layer27);
        categoryPlot25.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot25.setDomainAxisLocation(0, axisLocation32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot25.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot25.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer37.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer37.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[][] doubleArray55 = new double[][] { doubleArray49, doubleArray50, doubleArray51, doubleArray52, doubleArray53, doubleArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray55);
        org.jfree.data.Range range57 = statisticalBarRenderer37.findRangeBounds(categoryDataset56);
        categoryPlot25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer37);
        categoryPlot25.setRangeCrosshairLockedOnData(false);
        categoryPlot25.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier64 = categoryPlot25.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot25);
        java.lang.Object obj66 = jFreeChart65.getTextAntiAlias();
        chartProgressEvent12.setChart(jFreeChart65);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment69 = textTitle68.getVerticalAlignment();
        java.awt.Paint paint70 = textTitle68.getBackgroundPaint();
        jFreeChart65.addSubtitle((org.jfree.chart.title.Title) textTitle68);
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart65);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle();
        jFreeChart65.addSubtitle((org.jfree.chart.title.Title) textTitle73);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(drawingSupplier64);
        org.junit.Assert.assertNull(obj66);
        org.junit.Assert.assertNotNull(verticalAlignment69);
        org.junit.Assert.assertNull(paint70);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        categoryPlot9.setWeight((int) (short) 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopOutset((double) 1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = itemLabelPosition0.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition0.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("ThreadContext", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray18);
        org.jfree.data.Range range20 = statisticalBarRenderer0.findRangeBounds(categoryDataset19);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset19);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset19, 0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        int int26 = numberTickUnit25.getMinorTickCount();
        org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset23, (java.lang.Comparable) int26, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(pieDataset28);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        try {
            statisticalBarRenderer0.setSeriesVisibleInLegend((-2), (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
        boolean boolean3 = textAnchor0.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean14 = range11.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint10.toRangeWidth(range11);
        numberAxis1.setRange(range11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        numberAxis1.setTickLabelInsets(rectangleInsets17);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = rectangleConstraint0.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = rectangleConstraint0.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        double double4 = numberAxis1.getLowerMargin();
        double double5 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean3 = booleanList0.equals((java.lang.Object) 100.0d);
        booleanList0.setBoolean(2, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder(rectangleInsets53, (java.awt.Paint) color55);
        java.awt.Color color57 = color55.darker();
        try {
            jFreeChart50.setTextAntiAlias((java.lang.Object) color57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=134,g=134,b=0] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        double double18 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis22.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot30.getDomainMarkers((int) (short) 1, layer32);
        categoryPlot30.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot30.setDomainAxisLocation(0, axisLocation37);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot30.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot30.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean44 = statisticalBarRenderer42.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer42.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer42.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[][] doubleArray60 = new double[][] { doubleArray54, doubleArray55, doubleArray56, doubleArray57, doubleArray58, doubleArray59 };
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray60);
        org.jfree.data.Range range62 = statisticalBarRenderer42.findRangeBounds(categoryDataset61);
        categoryPlot30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer42);
        categoryPlot30.setRangeCrosshairLockedOnData(false);
        categoryPlot30.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer69 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean71 = statisticalBarRenderer69.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer69.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer69.setDrawBarOutline(false);
        int int78 = statisticalBarRenderer69.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator79 = null;
        statisticalBarRenderer69.setBaseToolTipGenerator(categoryToolTipGenerator79);
        categoryPlot30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer69);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint83 = categoryAxis82.getTickMarkPaint();
        categoryAxis82.setUpperMargin(1.0d);
        org.jfree.chart.plot.CategoryMarker categoryMarker86 = null;
        org.jfree.chart.util.Size2D size2D87 = new org.jfree.chart.util.Size2D();
        size2D87.height = (byte) 0;
        double double90 = size2D87.getHeight();
        double double91 = size2D87.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor94 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D95 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D87, 0.0d, (double) 0L, rectangleAnchor94);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D20, categoryPlot30, categoryAxis82, categoryMarker86, rectangle2D95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNull(itemLabelPosition19);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNull(categoryItemRenderer41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor94);
        org.junit.Assert.assertNotNull(rectangle2D95);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis15.setTickMarksVisible(true);
        java.awt.Font font21 = categoryAxis15.getLabelFont();
        int int22 = categoryPlot9.getDomainAxisIndex(categoryAxis15);
        java.lang.String str23 = categoryPlot9.getNoDataMessage();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "java.awt.Color[r=255,g=0,b=255]", "RectangleEdge.RIGHT", "RectangleEdge.RIGHT");
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray10);
        keyedObjects0.addObject((java.lang.Comparable) (-65281), (java.lang.Object) "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        org.jfree.chart.LegendItem legendItem14 = null;
        legendItemCollection13.add(legendItem14);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) "java.awt.Color[r=192,g=0,b=192]");
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        java.lang.Object obj5 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        numberAxis1.setTickLabelsVisible(false);
        numberAxis1.zoomRange((double) (byte) 10, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        categoryPlot9.setRangeGridlinesVisible(false);
        java.awt.Paint paint16 = categoryPlot9.getRangeGridlinePaint();
        try {
            categoryPlot9.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) 0);
        int int5 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener53 = null;
        try {
            jFreeChart50.removeChangeListener(chartChangeListener53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) 'a');
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean14 = textBlockAnchor8.equals((java.lang.Object) font13);
        java.awt.Shape shape18 = textBlock0.calculateBounds(graphics2D1, 10.0f, (float) 500, textBlockAnchor8, (float) (-2), (float) (byte) 1, (double) 10.0f);
        java.lang.String str19 = textBlockAnchor8.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str19.equals("TextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock6.getLineAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint14 = categoryAxis13.getTickMarkPaint();
        categoryAxis13.setUpperMargin(1.0d);
        java.lang.Object obj17 = categoryAxis13.clone();
        boolean boolean18 = horizontalAlignment12.equals((java.lang.Object) categoryAxis13);
        float float19 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis21.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getDomainMarkers((int) (short) 1, layer31);
        categoryPlot29.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot29.setDomainAxisLocation((int) '#', axisLocation36);
        categoryAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        numberAxis1.setLabelAngle((double) (byte) 0);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.lang.Object obj10 = null;
        int int11 = numberTickUnit8.compareTo(obj10);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.text.AttributedString attributedString0 = null;
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis7.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean18 = statisticalBarRenderer16.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer16.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke22 = statisticalBarRenderer16.getErrorIndicatorStroke();
        categoryPlot15.setDomainGridlineStroke(stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint5, stroke22);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = valueMarker24.getLabelOffset();
        org.jfree.chart.util.Size2D size2D26 = new org.jfree.chart.util.Size2D();
        size2D26.height = (byte) 0;
        double double29 = size2D26.getHeight();
        double double30 = size2D26.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D26, 0.0d, (double) 0L, rectangleAnchor33);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets25.createOutsetRectangle(rectangle2D34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke40 = numberAxis39.getAxisLineStroke();
        numberAxis37.setTickMarkStroke(stroke40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem(attributedString0, "", "NO_CHANGE", "HorizontalAlignment.CENTER", (java.awt.Shape) rectangle2D35, stroke40, (java.awt.Paint) color42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        java.awt.Paint paint12 = textFragment11.getPaint();
        boolean boolean13 = statisticalBarRenderer0.equals((java.lang.Object) textFragment11);
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] {};
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] {};
        java.awt.Shape shape20 = null;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] { shape20 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray15, paintArray16, strokeArray18, strokeArray19, shapeArray21);
        java.awt.Paint paint23 = defaultDrawingSupplier22.getNextFillPaint();
        statisticalBarRenderer0.setBasePaint(paint23, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.util.List list10 = projectInfo7.getContributors();
        java.awt.Image image14 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image14, "", "hi!", "hi!");
        projectInfo18.addOptionalLibrary("");
        java.awt.Image image24 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo28 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image24, "", "hi!", "hi!");
        projectInfo18.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo28);
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo18);
        java.awt.Image image31 = projectInfo7.getLogo();
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color6, true);
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(2, layer11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean16 = statisticalBarRenderer14.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer14.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer14.setBaseItemLabelPaint((java.awt.Paint) color20, true);
        try {
            categoryPlot9.setRenderer((-2), (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        int int2 = tickUnits0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (byte) -1);
        java.util.List list4 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis45.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis45.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        categoryPlot53.addChangeListener(plotChangeListener54);
        java.awt.Color color58 = java.awt.Color.getColor("", (int) '4');
        categoryPlot53.setNoDataMessagePaint((java.awt.Paint) color58);
        org.jfree.chart.util.Layer layer61 = null;
        java.util.Collection collection62 = categoryPlot53.getDomainMarkers((-2), layer61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint64 = categoryAxis63.getTickMarkPaint();
        boolean boolean65 = categoryAxis63.isTickMarksVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker66 = null;
        org.jfree.chart.util.Size2D size2D67 = new org.jfree.chart.util.Size2D();
        size2D67.height = (byte) 0;
        double double70 = size2D67.getHeight();
        double double71 = size2D67.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D75 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D67, 0.0d, (double) 0L, rectangleAnchor74);
        try {
            statisticalBarRenderer21.drawDomainMarker(graphics2D43, categoryPlot53, categoryAxis63, categoryMarker66, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot9.getRendererForDataset(categoryDataset23);
        int int26 = categoryPlot9.getDomainAxisCount();
        categoryPlot9.clearRangeAxes();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) (byte) -1);
        java.lang.Object obj5 = null;
        keyedObjects0.addObject((java.lang.Comparable) false, obj5);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean16 = statisticalBarRenderer14.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer14.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke20 = statisticalBarRenderer14.getErrorIndicatorStroke();
        categoryPlot13.setDomainGridlineStroke(stroke20);
        valueMarker1.setOutlineStroke(stroke20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.toString();
        java.lang.String str20 = projectInfo7.getInfo();
        projectInfo7.setLicenceName("RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str19.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Paint paint1 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Object) paint1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean5 = keyedObject2.equals((java.lang.Object) "hi!");
        java.lang.Comparable comparable6 = keyedObject2.getKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", comparable6.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        boolean boolean21 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker1.getLabelOffset();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = categoryPlot9.getDrawingSupplier();
        categoryPlot9.setBackgroundImageAlignment((int) (byte) 10);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(drawingSupplier48);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        java.awt.Paint paint2 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean20 = statisticalBarRenderer18.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke24 = statisticalBarRenderer18.getErrorIndicatorStroke();
        categoryPlot17.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint7, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker26.getLabelOffset();
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        size2D28.height = (byte) 0;
        double double31 = size2D28.getHeight();
        double double32 = size2D28.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) 0L, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str39 = rectangleEdge38.toString();
        boolean boolean41 = rectangleEdge38.equals((java.lang.Object) 15);
        double double42 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, (int) (short) 0, 0, rectangle2D36, rectangleEdge38);
        boolean boolean44 = categoryAnchor3.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.RIGHT" + "'", str39.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator21, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.Object obj3 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            labelBlock1.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        java.awt.Font font6 = null;
        java.awt.Paint paint7 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer10 = null;
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint7, (float) 1, (int) (byte) 10, textMeasurer10);
        boolean boolean12 = columnArrangement4.equals((java.lang.Object) (byte) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean15 = statisticalBarRenderer13.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer13.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer13.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[] doubleArray29 = new double[] {};
        double[] doubleArray30 = new double[] {};
        double[][] doubleArray31 = new double[][] { doubleArray25, doubleArray26, doubleArray27, doubleArray28, doubleArray29, doubleArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray31);
        org.jfree.data.Range range33 = statisticalBarRenderer13.findRangeBounds(categoryDataset32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset32);
        org.jfree.data.general.PieDataset pieDataset36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset32, 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer38 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.data.general.Dataset) categoryDataset32, (java.lang.Comparable) (-65281));
        java.awt.Image image42 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo46 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image42, "", "hi!", "hi!");
        projectInfo46.addOptionalLibrary("");
        java.awt.Image image52 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo56 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image52, "", "hi!", "hi!");
        projectInfo46.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo56);
        java.lang.String str58 = projectInfo46.toString();
        projectInfo46.setLicenceText("ThreadContext");
        projectInfo46.setVersion("java.awt.Color[r=255,g=0,b=255]");
        boolean boolean63 = columnArrangement4.equals((java.lang.Object) "java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNotNull(pieDataset36);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str58.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint10 = valueMarker9.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = textTitle11.getVerticalAlignment();
        java.awt.Paint paint13 = textTitle11.getBackgroundPaint();
        java.awt.Paint paint14 = textTitle11.getPaint();
        valueMarker9.setOutlinePaint(paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker9.getLabelOffset();
        double double18 = rectangleInsets16.calculateBottomOutset((double) (-1));
        legendItemBlockContainer7.setPadding(rectangleInsets16);
        double double20 = rectangleInsets16.getTop();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint22 = categoryAxis21.getTickMarkPaint();
        java.awt.Paint paint23 = categoryAxis21.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis30.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean41 = statisticalBarRenderer39.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = statisticalBarRenderer39.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke45 = statisticalBarRenderer39.getErrorIndicatorStroke();
        categoryPlot38.setDomainGridlineStroke(stroke45);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint28, stroke45);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = valueMarker47.getLabelOffset();
        org.jfree.chart.util.Size2D size2D49 = new org.jfree.chart.util.Size2D();
        size2D49.height = (byte) 0;
        double double52 = size2D49.getHeight();
        double double53 = size2D49.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D57 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D49, 0.0d, (double) 0L, rectangleAnchor56);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets48.createOutsetRectangle(rectangle2D57);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str60 = rectangleEdge59.toString();
        boolean boolean62 = rectangleEdge59.equals((java.lang.Object) 15);
        double double63 = categoryAxis21.getCategoryJava2DCoordinate(categoryAnchor24, (int) (short) 0, 0, rectangle2D57, rectangleEdge59);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets16.createInsetRectangle(rectangle2D57);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "RectangleEdge.RIGHT" + "'", str60.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        double double2 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.magenta;
        java.lang.String str3 = color2.toString();
        try {
            org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.RIGHT", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str3.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        boolean boolean8 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, dataset9, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendItemBlockContainer11.getPadding();
        textTitle0.setMargin(rectangleInsets12);
        java.awt.Font font15 = null;
        java.awt.Paint paint16 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (float) 1, (int) (byte) 10, textMeasurer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = null;
        textBlock20.draw(graphics2D21, (float) (short) 1, (float) (byte) 100, textBlockAnchor24);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textBlock20.getLineAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint28 = categoryAxis27.getTickMarkPaint();
        categoryAxis27.setUpperMargin(1.0d);
        java.lang.Object obj31 = categoryAxis27.clone();
        boolean boolean32 = horizontalAlignment26.equals((java.lang.Object) categoryAxis27);
        textTitle0.setHorizontalAlignment(horizontalAlignment26);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.lang.String str10 = numberTickUnit8.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[size=0]" + "'", str10.equals("[size=0]"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = lengthAdjustmentType0.equals(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getDomainMarkers((int) (short) 1, layer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot11.getAxisOffset();
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean20 = statisticalBarRenderer18.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getPositiveItemLabelPosition((int) (short) 1, 0);
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition23);
        java.awt.Paint paint26 = statisticalBarRenderer0.lookupSeriesPaint((-165));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions4);
        categoryAxis0.setLabel("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 1, 10.0d);
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        size2D3.height = (byte) 0;
        boolean boolean6 = meanAndStandardDeviation2.equals((java.lang.Object) size2D3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        java.awt.Color color3 = java.awt.Color.GRAY;
        boolean boolean4 = plotRenderingInfo1.equals((java.lang.Object) color3);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = plotRenderingInfo1.getSubplotInfo(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        java.awt.Paint paint13 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        try {
            java.lang.String str5 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint0.toRangeWidth(range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint5.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle2.setVerticalAlignment(verticalAlignment4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10, dataset11, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendItemBlockContainer13.getPadding();
        textTitle2.setMargin(rectangleInsets14);
        boolean boolean16 = size2D0.equals((java.lang.Object) textTitle2);
        double double17 = size2D0.width;
        java.lang.String str18 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str18.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color18 = java.awt.Color.getColor("", (int) '4');
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot13.getIndexOf(categoryItemRenderer20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str24 = rectangleEdge23.toString();
        boolean boolean26 = rectangleEdge23.equals((java.lang.Object) 15);
        boolean boolean27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = categoryAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D22, rectangleEdge23, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.RIGHT" + "'", str24.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        categoryPlot9.setDrawSharedDomainAxis(true);
        java.util.List list17 = categoryPlot9.getAnnotations();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVerticalTickLabels(true);
        double double7 = numberAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        boolean boolean18 = categoryPlot9.isOutlineVisible();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        double double20 = statisticalBarRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setUpperMargin(1.0d);
        java.lang.Object obj4 = categoryAxis0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9, dataset10, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint15 = valueMarker14.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        java.awt.Paint paint18 = textTitle16.getBackgroundPaint();
        java.awt.Paint paint19 = textTitle16.getPaint();
        valueMarker14.setOutlinePaint(paint19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker14.getLabelOffset();
        double double23 = rectangleInsets21.calculateBottomOutset((double) (-1));
        legendItemBlockContainer12.setPadding(rectangleInsets21);
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis28.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = statisticalBarRenderer37.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke43 = statisticalBarRenderer37.getErrorIndicatorStroke();
        categoryPlot36.setDomainGridlineStroke(stroke43);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint26, stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = valueMarker45.getLabelOffset();
        org.jfree.chart.util.Size2D size2D47 = new org.jfree.chart.util.Size2D();
        size2D47.height = (byte) 0;
        double double50 = size2D47.getHeight();
        double double51 = size2D47.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, 0.0d, (double) 0L, rectangleAnchor54);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets46.createOutsetRectangle(rectangle2D55);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str59 = lengthAdjustmentType58.toString();
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets21.createAdjustedRectangle(rectangle2D56, lengthAdjustmentType57, lengthAdjustmentType58);
        categoryAxis0.setLabelInsets(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertNotNull(lengthAdjustmentType58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "NO_CHANGE" + "'", str59.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot9.getRendererForDataset(categoryDataset23);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset23, true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray11 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray12 = color6.getComponents(floatArray11);
        int int13 = color6.getGreen();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray19 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray20 = color14.getComponents(floatArray19);
        float[] floatArray21 = color6.getRGBComponents(floatArray20);
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color6, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.toString();
        projectInfo7.setLicenceText("ThreadContext");
        projectInfo7.setName("ClassContext");
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str19.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        double double2 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setBase((double) (-165));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint10 = categoryAxis9.getTickMarkPaint();
        java.awt.Paint paint11 = categoryAxis9.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer27.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke33 = statisticalBarRenderer27.getErrorIndicatorStroke();
        categoryPlot26.setDomainGridlineStroke(stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint16, stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = valueMarker35.getLabelOffset();
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        size2D37.height = (byte) 0;
        double double40 = size2D37.getHeight();
        double double41 = size2D37.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 0.0d, (double) 0L, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets36.createOutsetRectangle(rectangle2D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str48 = rectangleEdge47.toString();
        boolean boolean50 = rectangleEdge47.equals((java.lang.Object) 15);
        double double51 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor12, (int) (short) 0, 0, rectangle2D45, rectangleEdge47);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D45, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        try {
            statisticalBarRenderer0.drawBackground(graphics2D6, categoryPlot7, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "RectangleEdge.RIGHT" + "'", str48.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(2.0d);
        java.lang.String str3 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot9.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 10, (double) (byte) 1, 1.0d, (double) 1.0f, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Paint paint21 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint23 = statisticalBarRenderer0.lookupSeriesOutlinePaint((int) (short) 10);
        java.awt.Stroke stroke24 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition25, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        categoryPlot9.setDrawSharedDomainAxis(true);
        categoryPlot9.setRangeCrosshairValue((double) (-1L), true);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis23.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot31.getDomainMarkers((int) (short) 1, layer33);
        categoryPlot31.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot31.setDomainAxisLocation(0, axisLocation38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot31.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot31.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean45 = statisticalBarRenderer43.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer43.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer43.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray55, doubleArray56, doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray61);
        org.jfree.data.Range range63 = statisticalBarRenderer43.findRangeBounds(categoryDataset62);
        categoryPlot31.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer43);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo68);
        boolean boolean70 = categoryPlot31.render(graphics2D65, rectangle2D66, 192, plotRenderingInfo69);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.lang.Object obj73 = plotRenderingInfo72.clone();
        plotRenderingInfo69.addSubplotInfo(plotRenderingInfo72);
        org.jfree.chart.util.Size2D size2D75 = new org.jfree.chart.util.Size2D();
        size2D75.height = (byte) 0;
        double double78 = size2D75.getHeight();
        double double79 = size2D75.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D83 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D75, 0.0d, (double) 0L, rectangleAnchor82);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor84 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D85 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D83, rectangleAnchor84);
        categoryPlot9.zoomRangeAxes((double) (byte) 10, (double) '#', plotRenderingInfo72, point2D85);
        java.awt.geom.Rectangle2D rectangle2D87 = plotRenderingInfo72.getDataArea();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(rectangleAnchor84);
        org.junit.Assert.assertNotNull(point2D85);
        org.junit.Assert.assertNotNull(rectangle2D87);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        categoryAxis0.clearCategoryLabelToolTips();
        double double25 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        try {
            statisticalBarRenderer0.setSeriesURLGenerator((int) (short) -1, categoryURLGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.util.List list10 = projectInfo7.getContributors();
        java.util.List list11 = projectInfo7.getContributors();
        java.lang.String str12 = projectInfo7.getVersion();
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        float float19 = categoryPlot9.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis21.setPositiveArrowVisible(false);
        numberAxis21.setTickMarkOutsideLength((float) 0);
        org.jfree.data.Range range26 = categoryPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        try {
            java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor11, 0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 0L, (float) '4');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        double double7 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation1);
        org.jfree.chart.LegendItem legendItem5 = statisticalBarRenderer0.getLegendItem(10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint3 = valueMarker2.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = textTitle4.getVerticalAlignment();
        java.awt.Paint paint6 = textTitle4.getBackgroundPaint();
        java.awt.Paint paint7 = textTitle4.getPaint();
        valueMarker2.setOutlinePaint(paint7);
        java.awt.Font font9 = valueMarker2.getLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray19 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray20 = color14.getComponents(floatArray19);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1L, 2.0d, (double) (short) 0, (double) (-1.0f), (java.awt.Paint) color14);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer25 = new org.jfree.chart.text.G2TextMeasurer(graphics2D24);
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_RIGHT", font9, (java.awt.Paint) color14, (float) 0L, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis12.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color25 = java.awt.Color.getColor("", (int) '4');
        categoryPlot20.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot20.getDomainMarkers((-2), layer28);
        java.awt.Paint paint30 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        size2D31.height = (byte) 0;
        double double34 = size2D31.getHeight();
        double double35 = size2D31.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 0.0d, (double) 0L, rectangleAnchor38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D10, categoryPlot20, rectangle2D39, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Shape shape9 = defaultDrawingSupplier8.getNextShape();
        java.awt.Paint paint10 = defaultDrawingSupplier8.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean4 = statisticalBarRenderer2.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer2.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke8 = statisticalBarRenderer2.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        categoryPlot18.setRangeGridlinesVisible(false);
        statisticalBarRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot18);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(500, (java.awt.Paint) color23);
        labelBlock1.setPaint((java.awt.Paint) color23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setUpperMargin(1.0d);
        double double4 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot13.getAxisOffset();
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[][] doubleArray26 = new double[][] { doubleArray20, doubleArray21, doubleArray22, doubleArray23, doubleArray24, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray26);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot13.getRendererForDataset(categoryDataset27);
        org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset27, (int) (short) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) strSet3, (org.jfree.data.general.Dataset) pieDataset31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(pieDataset31);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray14 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray15 = color9.getComponents(floatArray14);
        int int16 = color9.getGreen();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray22 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray23 = color17.getComponents(floatArray22);
        float[] floatArray24 = color9.getRGBComponents(floatArray23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.text.TextBlock textBlock31 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape39 = textBlock31.calculateBounds(graphics2D32, (float) 15, 0.0f, textBlockAnchor35, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color40 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape39, (java.awt.Paint) color40);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator43 = statisticalBarRenderer42.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke45 = statisticalBarRenderer44.getErrorIndicatorStroke();
        statisticalBarRenderer42.setBaseOutlineStroke(stroke45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem(attributedString0, "RectangleEdge.RIGHT", "NO_CHANGE", "hi!", true, shape5, true, paint7, false, (java.awt.Paint) color9, stroke25, true, shape39, stroke45, (java.awt.Paint) color47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke2 = numberAxis1.getAxisLineStroke();
        numberAxis1.setRangeAboutValue((double) (-2), (double) 'a');
        boolean boolean6 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        java.util.Iterator iterator14 = legendItemCollection13.iterator();
        int int15 = legendItemCollection13.getItemCount();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(iterator14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        java.awt.Paint paint63 = textTitle61.getBackgroundPaint();
        org.jfree.chart.event.TitleChangeListener titleChangeListener64 = null;
        textTitle61.removeChangeListener(titleChangeListener64);
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle61.setVerticalAlignment(verticalAlignment66);
        java.awt.Font font69 = null;
        java.awt.Paint paint70 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer73 = null;
        org.jfree.chart.text.TextBlock textBlock74 = org.jfree.chart.text.TextUtilities.createTextBlock("", font69, paint70, (float) 1, (int) (byte) 10, textMeasurer73);
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor78 = null;
        textBlock74.draw(graphics2D75, (float) (short) 1, (float) (byte) 100, textBlockAnchor78);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment80 = textBlock74.getLineAlignment();
        textTitle61.setTextAlignment(horizontalAlignment80);
        jFreeChart58.setTitle(textTitle61);
        jFreeChart58.setBackgroundImageAlpha((float) 500);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertNotNull(textBlock74);
        org.junit.Assert.assertNotNull(horizontalAlignment80);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeHeight(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        numberAxis1.setInverted(true);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        double double2 = statisticalBarRenderer0.getItemMargin();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean16 = statisticalBarRenderer14.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer14.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke20 = statisticalBarRenderer14.getErrorIndicatorStroke();
        categoryPlot13.setDomainGridlineStroke(stroke20);
        statisticalBarRenderer0.setSeriesOutlineStroke(0, stroke20, true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers((int) (short) 1, layer16);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot14.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer26.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = statisticalBarRenderer26.findRangeBounds(categoryDataset45);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        categoryPlot14.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj55 = jFreeChart54.getTextAntiAlias();
        titleChangeEvent3.setChart(jFreeChart54);
        int int57 = jFreeChart54.getBackgroundImageAlignment();
        try {
            org.jfree.chart.title.Title title59 = jFreeChart54.getSubtitle((-165));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(drawingSupplier53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) '#');
        boolean boolean12 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint5 = categoryAxis4.getTickMarkPaint();
        java.awt.Paint paint6 = categoryAxis4.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis13.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalBarRenderer22.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke28 = statisticalBarRenderer22.getErrorIndicatorStroke();
        categoryPlot21.setDomainGridlineStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint11, stroke28);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker30.getLabelOffset();
        org.jfree.chart.util.Size2D size2D32 = new org.jfree.chart.util.Size2D();
        size2D32.height = (byte) 0;
        double double35 = size2D32.getHeight();
        double double36 = size2D32.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 0.0d, (double) 0L, rectangleAnchor39);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets31.createOutsetRectangle(rectangle2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str43 = rectangleEdge42.toString();
        boolean boolean45 = rectangleEdge42.equals((java.lang.Object) 15);
        double double46 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor7, (int) (short) 0, 0, rectangle2D40, rectangleEdge42);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray52 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray53 = color47.getComponents(floatArray52);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("NO_CHANGE", "ThreadContext", "ClassContext", "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", (java.awt.Shape) rectangle2D40, (java.awt.Paint) color47);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleEdge.RIGHT" + "'", str43.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        int int14 = legendItemCollection13.getItemCount();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers((-2), layer17);
        java.awt.Paint paint19 = categoryPlot9.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot9.addDomainMarker((int) ' ', categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 1, 10.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10.0d + "'", number3.equals(10.0d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean3 = booleanList0.equals((java.lang.Object) 100.0d);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers((int) (short) 1, layer16);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot14.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer26.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = statisticalBarRenderer26.findRangeBounds(categoryDataset45);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        categoryPlot14.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj55 = jFreeChart54.getTextAntiAlias();
        java.awt.image.BufferedImage bufferedImage58 = jFreeChart54.createBufferedImage((int) (short) 10, (int) (short) 100);
        boolean boolean59 = booleanList0.equals((java.lang.Object) bufferedImage58);
        booleanList0.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(drawingSupplier53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertNotNull(bufferedImage58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.text.TextLine textLine3 = null;
        textBlock0.addLine(textLine3);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.TOP_RIGHT");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        double double5 = range1.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint6.getWidthConstraintType();
        java.awt.Paint paint9 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean22 = statisticalBarRenderer20.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = statisticalBarRenderer20.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke26 = statisticalBarRenderer20.getErrorIndicatorStroke();
        categoryPlot19.setDomainGridlineStroke(stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint9, stroke26);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker28.getLabelOffset();
        boolean boolean30 = lengthConstraintType7.equals((java.lang.Object) valueMarker28);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Size2D[width=0.0, height=0.0]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        java.lang.String str4 = labelBlock1.getURLText();
        labelBlock1.setToolTipText("hi!");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        java.lang.Boolean boolean20 = statisticalBarRenderer0.getSeriesItemLabelsVisible(15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        double double4 = labelBlock1.getContentXOffset();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean20 = statisticalBarRenderer18.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke24 = statisticalBarRenderer18.getErrorIndicatorStroke();
        categoryPlot17.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint7, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker26.getLabelOffset();
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        size2D28.height = (byte) 0;
        double double31 = size2D28.getHeight();
        double double32 = size2D28.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) 0L, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createOutsetRectangle(rectangle2D36);
        try {
            labelBlock1.draw(graphics2D5, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (byte) 0;
        double double3 = size2D0.getHeight();
        double double4 = size2D0.getHeight();
        size2D0.setHeight((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        double double9 = categoryItemRendererState8.getBarWidth();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getDomainMarkers((int) (short) 1, layer21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.lang.Object obj27 = plotRenderingInfo26.clone();
        java.awt.Color color28 = java.awt.Color.GRAY;
        boolean boolean29 = plotRenderingInfo26.equals((java.lang.Object) color28);
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot19.zoomDomainAxes((double) 2, 0.05d, plotRenderingInfo26, point2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo26.getDataArea();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis34.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        categoryPlot42.addChangeListener(plotChangeListener43);
        java.awt.Color color47 = java.awt.Color.getColor("", (int) '4');
        categoryPlot42.setNoDataMessagePaint((java.awt.Paint) color47);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis49.setLabelAngle(0.05d);
        categoryAxis49.configure();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean56 = statisticalBarRenderer54.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer54.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer54.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[] doubleArray71 = new double[] {};
        double[][] doubleArray72 = new double[][] { doubleArray66, doubleArray67, doubleArray68, doubleArray69, doubleArray70, doubleArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray72);
        org.jfree.data.Range range74 = statisticalBarRenderer54.findRangeBounds(categoryDataset73);
        java.lang.Number number75 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset73);
        try {
            statisticalBarRenderer0.drawItem(graphics2D6, categoryItemRendererState8, rectangle2D32, categoryPlot42, categoryAxis49, valueAxis53, categoryDataset73, 0, 500, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertNull(range74);
        org.junit.Assert.assertNull(number75);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = titleChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        titleChangeEvent3.setChart(jFreeChart5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("0.2", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        int int2 = plotRenderingInfo1.getSubplotCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis0.setTickMarksVisible(true);
        java.awt.Font font6 = categoryAxis0.getLabelFont();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 6.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        jFreeChart50.clearSubtitles();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setLabelAngle(0.0d);
        boolean boolean9 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "hi!");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray6 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray7 = color1.getComponents(floatArray6);
        int int8 = color1.getGreen();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray14 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = color1.getRGBComponents(floatArray15);
        try {
            org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        double double5 = range1.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint6.getWidthConstraintType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12, dataset13, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendItemBlockContainer15.getPadding();
        java.lang.Object obj17 = legendItemBlockContainer15.clone();
        boolean boolean18 = lengthConstraintType7.equals(obj17);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=0]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity46 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D37, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        java.lang.String str47 = categoryLabelEntity46.getShapeType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "rect" + "'", str47.equals("rect"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        org.jfree.data.general.Dataset dataset17 = legendItem14.getDataset();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(dataset17);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int20 = color19.getRGB();
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color19);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalBarRenderer22.getPositiveItemLabelPosition((int) (short) 1, 0);
        double double28 = statisticalBarRenderer22.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = statisticalBarRenderer22.getSeriesToolTipGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor33 = itemLabelPosition32.getItemLabelAnchor();
        statisticalBarRenderer22.setSeriesPositiveItemLabelPosition(0, itemLabelPosition32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis36.configure();
        org.jfree.data.RangeType rangeType38 = numberAxis36.getRangeType();
        boolean boolean39 = itemLabelPosition32.equals((java.lang.Object) rangeType38);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition32, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-4194112) + "'", int20 == (-4194112));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertNotNull(itemLabelAnchor33);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, 0.0d, (double) (-1.0f), (double) 255, (double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        try {
            numberAxis1.zoomRange((double) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) (short) 0);
        java.awt.Color color4 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        int int6 = color4.getRGB();
        keyedObjects0.addObject((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=255]", (java.lang.Object) int6);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-65281) + "'", int6 == (-65281));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        double double2 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setBase((double) (-165));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition5.getTextAnchor();
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        java.awt.Paint paint10 = defaultDrawingSupplier8.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "HorizontalAlignment.CENTER", "RectangleEdge.RIGHT", "Size2D[width=0.0, height=0.0]", "NO_CHANGE");
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVerticalTickLabels(true);
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        boolean boolean8 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers((int) (short) 1, layer16);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot14.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer26.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = statisticalBarRenderer26.findRangeBounds(categoryDataset45);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        categoryPlot14.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj55 = jFreeChart54.getTextAntiAlias();
        titleChangeEvent3.setChart(jFreeChart54);
        try {
            org.jfree.chart.title.Title title58 = jFreeChart54.getSubtitle(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(drawingSupplier53);
        org.junit.Assert.assertNull(obj55);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7, dataset8, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendItemBlockContainer10.getPadding();
        double double13 = rectangleInsets11.calculateLeftInset((double) (-2));
        categoryAxis0.setLabelInsets(rectangleInsets11);
        double double16 = rectangleInsets11.calculateTopInset((double) (byte) 100);
        double double17 = rectangleInsets11.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle2.setVerticalAlignment(verticalAlignment4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10, dataset11, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendItemBlockContainer13.getPadding();
        textTitle2.setMargin(rectangleInsets14);
        boolean boolean16 = size2D0.equals((java.lang.Object) textTitle2);
        double double17 = textTitle2.getContentXOffset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setAxisLineVisible(true);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Image image52 = null;
        jFreeChart50.setBackgroundImage(image52);
        java.awt.Paint paint54 = null;
        jFreeChart50.setBorderPaint(paint54);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot9.addDomainMarker(100, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray51, numberArray54, numberArray57, numberArray60, numberArray63, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray67);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset68, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot9.getRendererForDataset(categoryDataset68);
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset68);
        try {
            org.jfree.data.general.PieDataset pieDataset74 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset68, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 6.0d + "'", number72.equals(6.0d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("HorizontalAlignment.CENTER", graphics2D1, (float) 2, (float) 10L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        boolean boolean53 = jFreeChart50.isNotify();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot9.getDataset((-2));
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(categoryDataset47);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.RIGHT", "hi!");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.util.EventListener eventListener43 = null;
        boolean boolean44 = statisticalBarRenderer21.hasListener(eventListener43);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = statisticalBarRenderer21.getSeriesToolTipGenerator((int) (short) 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator46);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (short) 100, (java.lang.Number) 2);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 100 + "'", number3.equals((short) 100));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        java.awt.Paint paint19 = categoryPlot9.getRangeCrosshairPaint();
        categoryPlot9.setForegroundAlpha((float) 2);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        try {
            numberAxis1.setRangeWithMargins((double) 'a', (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, dataset9, (java.lang.Comparable) 1.0d);
        boolean boolean12 = labelBlock1.equals((java.lang.Object) 1.0d);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        labelBlock1.setPaint(paint13);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder52 = new org.jfree.chart.block.BlockBorder(1.0E-8d, (-0.0d), (double) (byte) 10, (double) 'a', (java.awt.Paint) color51);
        boolean boolean53 = plotOrientation46.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=192,g=0,b=192]", "ThreadContext", "Size2D[width=0.0, height=0.0]", "ClassContext");
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = categoryPlot9.getDrawingSupplier();
        org.jfree.chart.util.SortOrder sortOrder49 = categoryPlot9.getColumnRenderingOrder();
        categoryPlot9.setBackgroundAlpha(0.5f);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(drawingSupplier48);
        org.junit.Assert.assertNotNull(sortOrder49);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) '#');
        org.jfree.chart.text.TextBlock textBlock15 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape23 = textBlock15.calculateBounds(graphics2D16, (float) 15, 0.0f, textBlockAnchor19, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape23, (java.awt.Paint) color24);
        statisticalBarRenderer0.setBaseShape(shape23);
        java.awt.Paint paint29 = statisticalBarRenderer0.getItemPaint((int) '4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        int int21 = statisticalBarRenderer0.getColumnCount();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment25, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset29 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement28, dataset29, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint34 = valueMarker33.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = textTitle35.getVerticalAlignment();
        java.awt.Paint paint37 = textTitle35.getBackgroundPaint();
        java.awt.Paint paint38 = textTitle35.getPaint();
        valueMarker33.setOutlinePaint(paint38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = valueMarker33.getLabelOffset();
        double double42 = rectangleInsets40.calculateBottomOutset((double) (-1));
        legendItemBlockContainer31.setPadding(rectangleInsets40);
        java.awt.Paint paint45 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis47.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis47.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis53, categoryItemRenderer54);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer56 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean58 = statisticalBarRenderer56.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = statisticalBarRenderer56.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke62 = statisticalBarRenderer56.getErrorIndicatorStroke();
        categoryPlot55.setDomainGridlineStroke(stroke62);
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint45, stroke62);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = valueMarker64.getLabelOffset();
        org.jfree.chart.util.Size2D size2D66 = new org.jfree.chart.util.Size2D();
        size2D66.height = (byte) 0;
        double double69 = size2D66.getHeight();
        double double70 = size2D66.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D74 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D66, 0.0d, (double) 0L, rectangleAnchor73);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets65.createOutsetRectangle(rectangle2D74);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType76 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str78 = lengthAdjustmentType77.toString();
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets40.createAdjustedRectangle(rectangle2D75, lengthAdjustmentType76, lengthAdjustmentType77);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D22, categoryPlot23, rectangle2D75, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(lengthAdjustmentType76);
        org.junit.Assert.assertNotNull(lengthAdjustmentType77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "NO_CHANGE" + "'", str78.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D79);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((-4194112), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        float float14 = categoryPlot9.getForegroundAlpha();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.lang.Object obj50 = plotRenderingInfo49.clone();
        int int51 = plotRenderingInfo49.getSubplotCount();
        categoryPlot9.handleClick(0, 0, plotRenderingInfo49);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis54.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis54.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.util.Layer layer64 = null;
        java.util.Collection collection65 = categoryPlot62.getDomainMarkers((int) (short) 1, layer64);
        categoryPlot62.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot62.setDomainAxisLocation(0, axisLocation69);
        org.jfree.chart.LegendItemCollection legendItemCollection71 = categoryPlot62.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = categoryPlot62.getRenderer((-2));
        boolean boolean74 = plotRenderingInfo49.equals((java.lang.Object) (-2));
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNull(legendItemCollection71);
        org.junit.Assert.assertNull(categoryItemRenderer73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.configure();
        org.jfree.data.RangeType rangeType4 = numberAxis2.getRangeType();
        boolean boolean5 = rangeType0.equals((java.lang.Object) numberAxis2);
        java.lang.String str6 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RangeType.FULL" + "'", str6.equals("RangeType.FULL"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) 1);
        blockParams0.setTranslateX((double) 500);
        boolean boolean5 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean50 = statisticalBarRenderer48.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer48.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer48.setDrawBarOutline(false);
        int int57 = statisticalBarRenderer48.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        statisticalBarRenderer48.setBaseToolTipGenerator(categoryToolTipGenerator58);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer48);
        statisticalBarRenderer48.setSeriesItemLabelsVisible(192, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        int int9 = statisticalBarRenderer0.getColumnCount();
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        java.awt.Paint paint13 = statisticalBarRenderer0.getItemFillPaint((-65281), (int) (short) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(100, categoryURLGenerator15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.lang.Object obj2 = plotRenderingInfo1.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo4);
        org.jfree.chart.renderer.RendererState rendererState6 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo4);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabelAngle(0.05d);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis4.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
        int int7 = objectList0.indexOf((java.lang.Object) categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        try {
            java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.awt.Shape shape17 = legendItem14.getLine();
        org.jfree.data.general.Dataset dataset18 = legendItem14.getDataset();
        org.jfree.data.general.Dataset dataset19 = legendItem14.getDataset();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(dataset18);
        org.junit.Assert.assertNull(dataset19);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = categoryLabelPosition0.getCategoryAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(axisLocation14, false);
        int int17 = categoryPlot9.getDatasetCount();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        numberAxis1.setTickLabelsVisible(false);
        numberAxis1.zoomRange((double) (byte) 10, (double) '#');
        numberAxis1.setUpperBound((double) 1);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        int int21 = statisticalBarRenderer0.getColumnCount();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis24.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getDomainMarkers((int) (short) 1, layer34);
        categoryPlot32.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot32.setDomainAxisLocation(0, axisLocation39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot32.getFixedLegendItems();
        float float42 = categoryPlot32.getBackgroundImageAlpha();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = categoryPlot32.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis45.setPositiveArrowVisible(false);
        boolean boolean48 = numberAxis45.isAutoTickUnitSelection();
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        textTitle49.setID("");
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        size2D52.height = (byte) 0;
        double double55 = size2D52.getHeight();
        double double56 = size2D52.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, 0.0d, (double) 0L, rectangleAnchor59);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D62 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D60, rectangleAnchor61);
        textTitle49.setBounds(rectangle2D60);
        try {
            statisticalBarRenderer0.drawRangeGridline(graphics2D22, categoryPlot32, (org.jfree.chart.axis.ValueAxis) numberAxis45, rectangle2D60, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(legendItemCollection41);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.5f + "'", float42 == 0.5f);
        org.junit.Assert.assertNotNull(drawingSupplier43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge();
        java.lang.String str25 = categoryPlot13.getNoDataMessage();
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) (short) 0);
        java.awt.Color color4 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        int int6 = color4.getRGB();
        keyedObjects0.addObject((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=255]", (java.lang.Object) int6);
        try {
            keyedObjects0.removeValue(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-65281) + "'", int6 == (-65281));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("NO_CHANGE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis52.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.util.Layer layer62 = null;
        java.util.Collection collection63 = categoryPlot60.getDomainMarkers((int) (short) 1, layer62);
        categoryPlot60.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot60.setDomainAxisLocation(0, axisLocation67);
        org.jfree.chart.LegendItemCollection legendItemCollection69 = categoryPlot60.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot60.getRenderer((-2));
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.JFreeChart jFreeChart73 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        java.awt.RenderingHints renderingHints74 = jFreeChart73.getRenderingHints();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNull(legendItemCollection69);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertNotNull(renderingHints74);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (-1));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Image image52 = null;
        jFreeChart50.setBackgroundImage(image52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        java.awt.image.BufferedImage bufferedImage57 = jFreeChart50.createBufferedImage((int) (byte) 100, 15, chartRenderingInfo56);
        java.lang.Object obj58 = jFreeChart50.getTextAntiAlias();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent59 = null;
        try {
            jFreeChart50.titleChanged(titleChangeEvent59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(bufferedImage57);
        org.junit.Assert.assertNull(obj58);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight(2.0d);
        try {
            org.jfree.chart.util.Size2D size2D7 = labelBlock1.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot9.getRangeMarkers(layer12);
        categoryPlot9.setAnchorValue(0.05d);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis52.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.util.Layer layer62 = null;
        java.util.Collection collection63 = categoryPlot60.getDomainMarkers((int) (short) 1, layer62);
        categoryPlot60.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot60.setDomainAxisLocation(0, axisLocation67);
        org.jfree.chart.LegendItemCollection legendItemCollection69 = categoryPlot60.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot60.getRenderer((-2));
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot60);
        org.jfree.chart.util.SortOrder sortOrder73 = categoryPlot60.getRowRenderingOrder();
        categoryPlot60.clearAnnotations();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(collection63);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNull(legendItemCollection69);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertNotNull(sortOrder73);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 100, (float) 10, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers((-2), layer17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis21.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot29.getDomainMarkers((int) (short) 1, layer31);
        categoryPlot29.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot29.setDomainAxisLocation(0, axisLocation36);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot29.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot29.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean43 = statisticalBarRenderer41.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer41.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer41.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[][] doubleArray59 = new double[][] { doubleArray53, doubleArray54, doubleArray55, doubleArray56, doubleArray57, doubleArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray59);
        org.jfree.data.Range range61 = statisticalBarRenderer41.findRangeBounds(categoryDataset60);
        categoryPlot29.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer41);
        categoryPlot29.setRangeCrosshairLockedOnData(false);
        categoryPlot29.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier68 = categoryPlot29.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart69 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot29);
        java.lang.Object obj70 = jFreeChart69.getTextAntiAlias();
        java.awt.image.BufferedImage bufferedImage73 = jFreeChart69.createBufferedImage((int) (short) 10, (int) (short) 100);
        categoryPlot9.setBackgroundImage((java.awt.Image) bufferedImage73);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNull(legendItemCollection38);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertNotNull(drawingSupplier68);
        org.junit.Assert.assertNull(obj70);
        org.junit.Assert.assertNotNull(bufferedImage73);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[][] doubleArray22 = new double[][] { doubleArray16, doubleArray17, doubleArray18, doubleArray19, doubleArray20, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray22);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot9.getRendererForDataset(categoryDataset23);
        int int26 = categoryPlot9.getDomainAxisCount();
        java.awt.Paint paint27 = categoryPlot9.getNoDataMessagePaint();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Image image52 = null;
        jFreeChart50.setBackgroundImage(image52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        java.awt.image.BufferedImage bufferedImage57 = jFreeChart50.createBufferedImage((int) (byte) 100, 15, chartRenderingInfo56);
        java.lang.Object obj58 = jFreeChart50.getTextAntiAlias();
        java.awt.Image image59 = jFreeChart50.getBackgroundImage();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(bufferedImage57);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertNull(image59);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Size2D[width=0.0, height=0.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity46 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D37, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        categoryLabelEntity46.setURLText("HorizontalAlignment.CENTER");
        java.lang.String str49 = categoryLabelEntity46.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "CategoryLabelEntity: category=0, tooltip=Size2D[width=0.0, height=0.0], url=HorizontalAlignment.CENTER" + "'", str49.equals("CategoryLabelEntity: category=0, tooltip=Size2D[width=0.0, height=0.0], url=HorizontalAlignment.CENTER"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers((int) (short) 1, layer16);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot14.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer26.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = statisticalBarRenderer26.findRangeBounds(categoryDataset45);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        categoryPlot14.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj55 = jFreeChart54.getTextAntiAlias();
        titleChangeEvent3.setChart(jFreeChart54);
        try {
            java.awt.image.BufferedImage bufferedImage59 = jFreeChart54.createBufferedImage(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(drawingSupplier53);
        org.junit.Assert.assertNull(obj55);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        float float53 = jFreeChart50.getBackgroundImageAlpha();
        jFreeChart50.setAntiAlias(false);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle0.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, dataset9, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendItemBlockContainer11.getPadding();
        textTitle0.setMargin(rectangleInsets12);
        double double15 = rectangleInsets12.calculateLeftInset((double) 'a');
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        numberAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnits tickUnits6 = new org.jfree.chart.axis.TickUnits();
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        try {
            org.jfree.chart.axis.TickUnit tickUnit10 = tickUnits6.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setRangeGridlinesVisible(false);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot9.getRangeMarkers(layer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace14);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.lang.String str19 = projectInfo7.toString();
        java.lang.String str20 = projectInfo7.toString();
        projectInfo7.setName("TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str19.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str20.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        int int14 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot9.getFixedLegendItems();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(legendItemCollection15);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder(1.0E-8d, (-0.0d), (double) (byte) 10, (double) 'a', (java.awt.Paint) color47);
        statisticalBarRenderer21.setBaseItemLabelPaint((java.awt.Paint) color47, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean54 = statisticalBarRenderer52.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer52.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer52.setDrawBarOutline(false);
        statisticalBarRenderer52.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator65 = null;
        statisticalBarRenderer52.setBaseToolTipGenerator(categoryToolTipGenerator65, false);
        java.lang.Boolean boolean69 = statisticalBarRenderer52.getSeriesItemLabelsVisible(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition72 = statisticalBarRenderer52.getPositiveItemLabelPosition((-65281), 192);
        statisticalBarRenderer21.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition72);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(boolean69);
        org.junit.Assert.assertNotNull(itemLabelPosition72);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7, dataset8, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendItemBlockContainer10.getPadding();
        double double13 = rectangleInsets11.calculateLeftInset((double) (-2));
        categoryAxis0.setLabelInsets(rectangleInsets11);
        double double16 = rectangleInsets11.calculateBottomOutset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        double double4 = numberAxis1.getLowerBound();
        numberAxis1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        double double6 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) 'a', (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }
}

