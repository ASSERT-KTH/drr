import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle0.getPosition();
        java.awt.Font font3 = textTitle0.getFont();
        java.awt.Color color4 = java.awt.Color.magenta;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        boolean boolean11 = textTitle0.equals((java.lang.Object) rectangle2D7);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        double double4 = labelBlock1.getContentXOffset();
        java.lang.String str5 = labelBlock1.getURLText();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        labelBlock1.setPaint(paint6);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        textLine1.removeFragment(textFragment4);
        java.awt.Font font7 = textFragment4.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getDomainMarkers((int) (short) 1, layer19);
        categoryPlot17.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setDomainAxisLocation(0, axisLocation24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot17.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer29.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer29.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray47);
        org.jfree.data.Range range49 = statisticalBarRenderer29.findRangeBounds(categoryDataset48);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer29);
        categoryPlot17.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke53 = categoryPlot17.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("RectangleEdge.RIGHT", font7, (org.jfree.chart.plot.Plot) categoryPlot17, true);
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState();
        java.util.List list57 = axisState56.getTicks();
        jFreeChart55.setSubtitles(list57);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        double double60 = textTitle59.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame61 = textTitle59.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent62 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle59);
        java.lang.String str63 = textTitle59.getToolTipText();
        jFreeChart55.removeSubtitle((org.jfree.chart.title.Title) textTitle59);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = textTitle59.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame61);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity46 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D37, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        java.lang.String str47 = categoryLabelEntity46.getURLText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str47.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 500);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        try {
            statisticalBarRenderer0.setSeriesVisible((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getDomainMarkers((int) (short) 1, layer21);
        categoryPlot19.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(0, axisLocation26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot19.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean33 = statisticalBarRenderer31.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer31.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer31.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[][] doubleArray49 = new double[][] { doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray49);
        org.jfree.data.Range range51 = statisticalBarRenderer31.findRangeBounds(categoryDataset50);
        categoryPlot19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder58 = new org.jfree.chart.block.BlockBorder(1.0E-8d, (-0.0d), (double) (byte) 10, (double) 'a', (java.awt.Paint) color57);
        statisticalBarRenderer31.setBaseItemLabelPaint((java.awt.Paint) color57, true);
        java.awt.Paint paint62 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis64.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis64.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, valueAxis70, categoryItemRenderer71);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer73 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean75 = statisticalBarRenderer73.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition78 = statisticalBarRenderer73.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke79 = statisticalBarRenderer73.getErrorIndicatorStroke();
        categoryPlot72.setDomainGridlineStroke(stroke79);
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint62, stroke79);
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = valueMarker81.getLabelOffset();
        org.jfree.chart.util.Size2D size2D83 = new org.jfree.chart.util.Size2D();
        size2D83.height = (byte) 0;
        double double86 = size2D83.getHeight();
        double double87 = size2D83.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor90 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D91 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D83, 0.0d, (double) 0L, rectangleAnchor90);
        java.awt.geom.Rectangle2D rectangle2D92 = rectangleInsets82.createOutsetRectangle(rectangle2D91);
        statisticalBarRenderer31.setBaseShape((java.awt.Shape) rectangle2D91);
        boolean boolean94 = legendItemBlockContainer7.equals((java.lang.Object) rectangle2D91);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor90);
        org.junit.Assert.assertNotNull(rectangle2D91);
        org.junit.Assert.assertNotNull(rectangle2D92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Color color7 = java.awt.Color.magenta;
        java.lang.String str8 = color7.toString();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setID("");
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        size2D12.height = (byte) 0;
        double double15 = size2D12.getHeight();
        double double16 = size2D12.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, 0.0d, (double) 0L, rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        textTitle9.setBounds(rectangle2D20);
        boolean boolean24 = color7.equals((java.lang.Object) textTitle9);
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.text.TextBlock textBlock30 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor34 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape38 = textBlock30.calculateBounds(graphics2D31, (float) 15, 0.0f, textBlockAnchor34, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color39 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) 'a');
        java.awt.Shape shape43 = legendItem40.getLine();
        java.awt.Stroke stroke44 = legendItem40.getLineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color7, stroke44);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str8.equals("java.awt.Color[r=255,g=0,b=255]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor34);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = statisticalBarRenderer0.hasListener(eventListener6);
        java.awt.Paint paint10 = statisticalBarRenderer0.getItemLabelPaint(10, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot9.axisChanged(axisChangeEvent18);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        boolean boolean3 = booleanList0.equals((java.lang.Object) 100.0d);
        java.lang.Boolean boolean5 = booleanList0.getBoolean(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        double double6 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        boolean boolean7 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint8 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Paint paint1 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Object) paint1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = statisticalBarRenderer3.getGradientPaintTransformer();
        double double5 = statisticalBarRenderer3.getItemMargin();
        statisticalBarRenderer3.setBase((double) (-165));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis12.setPositiveArrowVisible(false);
        boolean boolean15 = numberAxis12.isTickMarksVisible();
        numberAxis12.setAutoTickUnitSelection(false, true);
        numberAxis12.setPositiveArrowVisible(false);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D();
        size2D21.height = (byte) 0;
        double double24 = size2D21.getHeight();
        double double25 = size2D21.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, 0.0d, (double) 0L, rectangleAnchor28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        statisticalBarRenderer3.drawRangeGridline(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, rectangle2D29, (double) 10L);
        keyedObject2.setObject((java.lang.Object) categoryPlot10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        numberAxis1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        statisticalBarRenderer0.setPlot(categoryPlot10);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer27.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke33 = statisticalBarRenderer27.getErrorIndicatorStroke();
        categoryPlot26.setDomainGridlineStroke(stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint16, stroke33);
        statisticalBarRenderer0.setSeriesPaint(100, paint16, false);
        java.awt.Color color39 = java.awt.Color.GRAY;
        statisticalBarRenderer0.setSeriesPaint(192, (java.awt.Paint) color39);
        java.lang.Object obj41 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean4 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean11 = categoryPlot9.removeAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis0.setCategoryMargin(1.0E-8d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean3 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) 0.0f);
        java.lang.Object obj4 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        numberAxis1.setInverted(true);
        boolean boolean9 = numberAxis1.isInverted();
        numberAxis1.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setLabelAngle(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment15, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset19 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement18, dataset19, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendItemBlockContainer21.getPadding();
        double double24 = rectangleInsets22.calculateLeftInset((double) (-2));
        categoryAxis11.setLabelInsets(rectangleInsets22);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint30 = categoryAxis29.getTickMarkPaint();
        java.awt.Paint paint31 = categoryAxis29.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint36 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis38.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis44, categoryItemRenderer45);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean49 = statisticalBarRenderer47.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = statisticalBarRenderer47.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke53 = statisticalBarRenderer47.getErrorIndicatorStroke();
        categoryPlot46.setDomainGridlineStroke(stroke53);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint36, stroke53);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = valueMarker55.getLabelOffset();
        org.jfree.chart.util.Size2D size2D57 = new org.jfree.chart.util.Size2D();
        size2D57.height = (byte) 0;
        double double60 = size2D57.getHeight();
        double double61 = size2D57.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor64 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D65 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D57, 0.0d, (double) 0L, rectangleAnchor64);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets56.createOutsetRectangle(rectangle2D65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str68 = rectangleEdge67.toString();
        boolean boolean70 = rectangleEdge67.equals((java.lang.Object) 15);
        double double71 = categoryAxis29.getCategoryJava2DCoordinate(categoryAnchor32, (int) (short) 0, 0, rectangle2D65, rectangleEdge67);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity74 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D65, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double76 = categoryAxis11.getCategoryStart((int) '4', 0, rectangle2D65, rectangleEdge75);
        numberAxis1.setUpArrow((java.awt.Shape) rectangle2D65);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(categoryAnchor32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor64);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "RectangleEdge.RIGHT" + "'", str68.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("", font28);
        java.awt.Paint paint30 = textFragment29.getPaint();
        boolean boolean31 = axisLocation26.equals((java.lang.Object) paint30);
        categoryPlot13.setRangeAxisLocation(axisLocation26, false);
        categoryPlot13.configureRangeAxes();
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "{0}");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.awt.Shape shape17 = legendItem14.getLine();
        org.jfree.data.general.Dataset dataset18 = legendItem14.getDataset();
        java.awt.Shape shape19 = legendItem14.getShape();
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", numberArray23);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset24, 2);
        legendItem14.setDataset((org.jfree.data.general.Dataset) categoryDataset24);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(dataset18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(pieDataset26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        boolean boolean2 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setBase(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray8 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray9 = color3.getComponents(floatArray8);
        int int10 = color3.getGreen();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        float[] floatArray16 = new float[] { 2, 0.0f, (-1), (short) 1 };
        float[] floatArray17 = color11.getComponents(floatArray16);
        float[] floatArray18 = color3.getRGBComponents(floatArray17);
        float[] floatArray19 = color0.getComponents(colorSpace2, floatArray18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis19.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot27.getDomainMarkers((int) (short) 1, layer29);
        boolean boolean31 = categoryPlot27.getDrawSharedDomainAxis();
        java.awt.Paint paint33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis35.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis35.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean46 = statisticalBarRenderer44.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = statisticalBarRenderer44.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke50 = statisticalBarRenderer44.getErrorIndicatorStroke();
        categoryPlot43.setDomainGridlineStroke(stroke50);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint33, stroke50);
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker52);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer56 = null;
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker55, layer56);
        java.awt.Stroke stroke58 = valueMarker55.getStroke();
        categoryPlot9.setDomainGridlineStroke(stroke58);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        boolean boolean11 = statisticalBarRenderer0.isSeriesItemLabelsVisible(1);
        org.jfree.chart.LegendItem legendItem14 = statisticalBarRenderer0.getLegendItem(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint17 = categoryAxis15.getLabelPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint17);
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape31 = textBlock23.calculateBounds(graphics2D24, (float) 15, 0.0f, textBlockAnchor27, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape31, (java.awt.Paint) color32);
        legendItem33.setSeriesIndex((int) 'a');
        java.awt.Shape shape36 = legendItem33.getShape();
        statisticalBarRenderer0.setBaseShape(shape36, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) categoryLabelPositions3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str8 = rectangleEdge7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions3, categoryLabelPosition9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition9);
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition9.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = categoryLabelPosition9.getCategoryAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.RIGHT" + "'", str8.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=192,g=0,b=192]", (int) (short) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.RIGHT", "RectangleEdge.RIGHT", "", "");
        java.lang.String str10 = basicProjectInfo9.getName();
        boolean boolean11 = textTitle0.equals((java.lang.Object) str10);
        textTitle0.setNotify(true);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.RIGHT" + "'", str10.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        boolean boolean11 = statisticalBarRenderer0.isSeriesItemLabelsVisible(1);
        boolean boolean12 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis15.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot23.getDomainMarkers((int) (short) 1, layer25);
        categoryPlot23.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot23.setDomainAxisLocation(0, axisLocation30);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot23.getFixedLegendItems();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot23.getRangeMarkers(0, layer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint38 = categoryAxis37.getTickMarkPaint();
        java.awt.Paint paint39 = categoryAxis37.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint44 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis46.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis46.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis52, categoryItemRenderer53);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer55 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean57 = statisticalBarRenderer55.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition60 = statisticalBarRenderer55.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke61 = statisticalBarRenderer55.getErrorIndicatorStroke();
        categoryPlot54.setDomainGridlineStroke(stroke61);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint44, stroke61);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = valueMarker63.getLabelOffset();
        org.jfree.chart.util.Size2D size2D65 = new org.jfree.chart.util.Size2D();
        size2D65.height = (byte) 0;
        double double68 = size2D65.getHeight();
        double double69 = size2D65.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D73 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D65, 0.0d, (double) 0L, rectangleAnchor72);
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets64.createOutsetRectangle(rectangle2D73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str76 = rectangleEdge75.toString();
        boolean boolean78 = rectangleEdge75.equals((java.lang.Object) 15);
        double double79 = categoryAxis37.getCategoryJava2DCoordinate(categoryAnchor40, (int) (short) 0, 0, rectangle2D73, rectangleEdge75);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity82 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D73, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        try {
            statisticalBarRenderer0.drawOutline(graphics2D13, categoryPlot23, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNull(legendItemCollection32);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "RectangleEdge.RIGHT" + "'", str76.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        categoryPlot13.setRangeCrosshairValue(10.0d, false);
        categoryPlot13.setRangeCrosshairValue((double) (-1.0f));
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot13);
        java.awt.Stroke stroke20 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getDomainMarkers((int) (short) 1, layer13);
        categoryPlot11.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setDomainAxisLocation(0, axisLocation18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot11.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot11.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean25 = statisticalBarRenderer23.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer23.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer23.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[][] doubleArray41 = new double[][] { doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray41);
        org.jfree.data.Range range43 = statisticalBarRenderer23.findRangeBounds(categoryDataset42);
        categoryPlot11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        categoryPlot11.setRangeCrosshairLockedOnData(false);
        categoryPlot11.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = categoryPlot11.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot11);
        java.lang.Object obj52 = jFreeChart51.getTextAntiAlias();
        java.awt.Image image53 = null;
        jFreeChart51.setBackgroundImage(image53);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = null;
        java.awt.image.BufferedImage bufferedImage58 = jFreeChart51.createBufferedImage((int) (byte) 100, 15, chartRenderingInfo57);
        boolean boolean59 = gradientPaintTransformType0.equals((java.lang.Object) bufferedImage58);
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions61 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean62 = textAnchor60.equals((java.lang.Object) categoryLabelPositions61);
        org.jfree.chart.text.TextAnchor textAnchor63 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions64 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean65 = textAnchor63.equals((java.lang.Object) categoryLabelPositions64);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions67 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str69 = rectangleEdge68.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition70 = categoryLabelPositions67.getLabelPosition(rectangleEdge68);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions71 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions64, categoryLabelPosition70);
        double double72 = categoryLabelPosition70.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions73 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions61, categoryLabelPosition70);
        boolean boolean74 = gradientPaintTransformType0.equals((java.lang.Object) categoryLabelPositions73);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(drawingSupplier50);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertNotNull(bufferedImage58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(categoryLabelPositions61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(textAnchor63);
        org.junit.Assert.assertNotNull(categoryLabelPositions64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "RectangleEdge.RIGHT" + "'", str69.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition70);
        org.junit.Assert.assertNotNull(categoryLabelPositions71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-0.0d) + "'", double72 == (-0.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        textTitle0.setText("ThreadContext");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 1, "RectangleEdge.RIGHT");
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.configure();
        org.jfree.data.RangeType rangeType16 = numberAxis14.getRangeType();
        java.awt.Paint paint17 = numberAxis14.getTickMarkPaint();
        numberAxis14.setVerticalTickLabels(true);
        boolean boolean20 = numberAxis14.isPositiveArrowVisible();
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) numberAxis14);
        categoryAxis1.setCategoryLabelPositionOffset(192);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        double double10 = rectangleInsets8.calculateLeftInset((double) (-2));
        double double12 = rectangleInsets8.calculateLeftInset((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        java.awt.Font font44 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment45, verticalAlignment46, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset50 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement49, dataset50, (java.lang.Comparable) 1.0d);
        java.awt.Font font54 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment55 = new org.jfree.chart.text.TextFragment("", font54);
        boolean boolean56 = columnArrangement49.equals((java.lang.Object) font54);
        categoryAxis1.setLabelFont(font54);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment59 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement62 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment58, verticalAlignment59, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset63 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer65 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement62, dataset63, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = legendItemBlockContainer65.getPadding();
        double double68 = rectangleInsets66.calculateLeftInset((double) (-2));
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder70 = new org.jfree.chart.block.BlockBorder(rectangleInsets66, (java.awt.Paint) color69);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer73 = new org.jfree.chart.text.G2TextMeasurer(graphics2D72);
        try {
            org.jfree.chart.text.TextBlock textBlock74 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=0, tooltip=Size2D[width=0.0, height=0.0], url=HorizontalAlignment.CENTER", font54, (java.awt.Paint) color69, (float) 255, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(color69);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        boolean boolean18 = statisticalBarRenderer0.isDrawBarOutline();
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("", font1);
        java.lang.String str3 = textFragment2.getText();
        float float4 = textFragment2.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) 1);
        boolean boolean3 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY((double) 1.0f);
        blockParams0.setTranslateX((double) 0.8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot9.getRangeMarkers(0, layer20);
        boolean boolean22 = categoryPlot9.isRangeCrosshairLockedOnData();
        int int23 = categoryPlot9.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis25, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType29 = rectangleInsets28.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, 0.0d, (double) 255, (double) (-165), 0.0d);
        categoryPlot9.setInsets(rectangleInsets34);
        java.awt.Paint[] paintArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray37 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray38 = new java.awt.Paint[] {};
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Shape shape42 = null;
        java.awt.Shape[] shapeArray43 = new java.awt.Shape[] { shape42 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier44 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray37, paintArray38, strokeArray40, strokeArray41, shapeArray43);
        java.awt.Shape shape45 = defaultDrawingSupplier44.getNextShape();
        categoryPlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier44);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shapeArray43);
        org.junit.Assert.assertNull(shape45);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        boolean boolean11 = statisticalBarRenderer0.isSeriesItemLabelsVisible(1);
        boolean boolean12 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = statisticalBarRenderer0.getItemLabelGenerator((-65281), (int) (byte) -1);
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) 'a');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, dataset9, (java.lang.Comparable) 1.0d);
        boolean boolean12 = labelBlock1.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = labelBlock1.getID();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        titleChangeEvent3.setType(chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent3.getChart();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        int int18 = categoryPlot9.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        double double2 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setBase((double) (-165));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis9.setPositiveArrowVisible(false);
        boolean boolean12 = numberAxis9.isTickMarksVisible();
        numberAxis9.setAutoTickUnitSelection(false, true);
        numberAxis9.setPositiveArrowVisible(false);
        org.jfree.chart.util.Size2D size2D18 = new org.jfree.chart.util.Size2D();
        size2D18.height = (byte) 0;
        double double21 = size2D18.getHeight();
        double double22 = size2D18.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, 0.0d, (double) 0L, rectangleAnchor25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        statisticalBarRenderer0.drawRangeGridline(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) numberAxis9, rectangle2D26, (double) 10L);
        numberAxis9.setRangeWithMargins(3.0d, (double) (short) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint0.toRangeWidth(range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis12.configure();
        org.jfree.data.RangeType rangeType14 = numberAxis12.getRangeType();
        java.awt.Font font15 = numberAxis12.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = numberAxis12.getLabelInsets();
        categoryPlot9.setAxisOffset(rectangleInsets16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color19 = color18.darker();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke3 = statisticalBarRenderer2.getErrorIndicatorStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = itemLabelPosition5.getItemLabelAnchor();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent48);
        boolean boolean50 = categoryPlot9.isSubplot();
        categoryPlot9.setNoDataMessage("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis3.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions4);
        double double6 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        java.awt.Font font44 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment45, verticalAlignment46, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset50 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement49, dataset50, (java.lang.Comparable) 1.0d);
        java.awt.Font font54 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment55 = new org.jfree.chart.text.TextFragment("", font54);
        boolean boolean56 = columnArrangement49.equals((java.lang.Object) font54);
        categoryAxis1.setLabelFont(font54);
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("TextBlockAnchor.TOP_RIGHT", font54);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesOutlinePaint((int) (short) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) (short) 1, categoryItemLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke2 = numberAxis1.getAxisLineStroke();
        numberAxis1.configure();
        try {
            numberAxis1.setRangeAboutValue((double) 192, (double) (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32832.5) <= upper (-32448.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        java.awt.Font font8 = valueMarker1.getLabelFont();
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(false);
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        textTitle0.setFont(font3);
        textTitle0.setHeight((double) 1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Paint paint21 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint23 = statisticalBarRenderer0.lookupSeriesOutlinePaint((int) (short) 10);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint27 = valueMarker26.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle28.getVerticalAlignment();
        java.awt.Paint paint30 = textTitle28.getBackgroundPaint();
        java.awt.Paint paint31 = textTitle28.getPaint();
        valueMarker26.setOutlinePaint(paint31);
        java.awt.Font font33 = valueMarker26.getLabelFont();
        float float34 = valueMarker26.getAlpha();
        java.awt.Paint paint35 = valueMarker26.getLabelPaint();
        java.awt.Stroke stroke36 = valueMarker26.getStroke();
        statisticalBarRenderer0.setSeriesStroke(10, stroke36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.8f + "'", float34 == 0.8f);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        java.lang.Comparable comparable10 = legendItemBlockContainer7.getSeriesKey();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color14);
        java.awt.Paint paint16 = blockBorder15.getPaint();
        legendItemBlockContainer7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        org.jfree.chart.block.Block block18 = null;
        legendItemBlockContainer7.add(block18);
        org.jfree.data.general.Dataset dataset20 = legendItemBlockContainer7.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1.0d + "'", comparable10.equals(1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(dataset20);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str7 = lengthAdjustmentType6.toString();
        java.lang.String str8 = lengthAdjustmentType6.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NO_CHANGE" + "'", str7.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NO_CHANGE" + "'", str8.equals("NO_CHANGE"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean4 = statisticalBarRenderer2.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer2.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = statisticalBarRenderer2.hasListener(eventListener8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getRotationAnchor();
        statisticalBarRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition10);
        barRenderer0.setSeriesPositiveItemLabelPosition(10, itemLabelPosition10, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        numberAxis1.setInverted(true);
        boolean boolean9 = numberAxis1.isInverted();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        numberAxis1.setAxisLineStroke(stroke10);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        java.lang.Comparable comparable10 = legendItemBlockContainer7.getSeriesKey();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color14);
        java.awt.Paint paint16 = blockBorder15.getPaint();
        legendItemBlockContainer7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        org.jfree.chart.block.Block block18 = null;
        legendItemBlockContainer7.add(block18);
        java.util.List list20 = legendItemBlockContainer7.getBlocks();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1.0d + "'", comparable10.equals(1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        java.awt.Shape shape14 = statisticalBarRenderer0.getSeriesShape((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        double double4 = numberAxis1.getLowerBound();
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        numberAxis1.setInverted(true);
        boolean boolean9 = numberAxis1.isInverted();
        org.jfree.data.Range range10 = null;
        try {
            numberAxis1.setRangeWithMargins(range10, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color11);
        numberAxis1.setTickLabelInsets(rectangleInsets9);
        double double15 = rectangleInsets9.extendHeight((double) (short) -1);
        double double16 = rectangleInsets9.getBottom();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot9.getRangeMarkers(0, layer20);
        boolean boolean22 = categoryPlot9.isRangeCrosshairLockedOnData();
        int int23 = categoryPlot9.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot9.getRangeAxis((-2));
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(valueAxis25);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) (short) 0);
        java.awt.Color color4 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        int int6 = color4.getRGB();
        keyedObjects0.addObject((java.lang.Comparable) "java.awt.Color[r=255,g=0,b=255]", (java.lang.Object) int6);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("NO_CHANGE");
        keyedObjects0.addObject((java.lang.Comparable) 100L, (java.lang.Object) "NO_CHANGE");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-65281) + "'", int6 == (-65281));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVerticalTickLabels(true);
        double double7 = numberAxis1.getLowerMargin();
        numberAxis1.setFixedDimension((double) (-2));
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.configure();
        org.jfree.data.RangeType rangeType16 = numberAxis14.getRangeType();
        categoryPlot9.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot9.getInsets();
        java.awt.Paint paint19 = categoryPlot9.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 10, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        boolean boolean11 = statisticalBarRenderer0.isSeriesItemLabelsVisible(1);
        org.jfree.chart.LegendItem legendItem14 = statisticalBarRenderer0.getLegendItem(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint17 = categoryAxis15.getLabelPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint17);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis21.configure();
        org.jfree.data.RangeType rangeType23 = numberAxis21.getRangeType();
        java.awt.Font font24 = numberAxis21.getLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (byte) 100, font24, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator27);
        boolean boolean30 = statisticalBarRenderer0.isSeriesItemLabelsVisible(3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rangeType23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.awt.Shape shape17 = legendItem14.getLine();
        java.awt.Paint paint18 = legendItem14.getLinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem14.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.lang.Object obj17 = plotRenderingInfo16.clone();
        java.awt.Color color18 = java.awt.Color.GRAY;
        boolean boolean19 = plotRenderingInfo16.equals((java.lang.Object) color18);
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 0.05d, plotRenderingInfo16, point2D20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment22, verticalAlignment23, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement26, dataset27, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint32 = valueMarker31.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = textTitle33.getVerticalAlignment();
        java.awt.Paint paint35 = textTitle33.getBackgroundPaint();
        java.awt.Paint paint36 = textTitle33.getPaint();
        valueMarker31.setOutlinePaint(paint36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = valueMarker31.getLabelOffset();
        double double40 = rectangleInsets38.calculateBottomOutset((double) (-1));
        legendItemBlockContainer29.setPadding(rectangleInsets38);
        java.awt.Paint paint43 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis45.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis45.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean56 = statisticalBarRenderer54.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = statisticalBarRenderer54.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke60 = statisticalBarRenderer54.getErrorIndicatorStroke();
        categoryPlot53.setDomainGridlineStroke(stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint43, stroke60);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = valueMarker62.getLabelOffset();
        org.jfree.chart.util.Size2D size2D64 = new org.jfree.chart.util.Size2D();
        size2D64.height = (byte) 0;
        double double67 = size2D64.getHeight();
        double double68 = size2D64.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D72 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D64, 0.0d, (double) 0L, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets63.createOutsetRectangle(rectangle2D72);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str76 = lengthAdjustmentType75.toString();
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets38.createAdjustedRectangle(rectangle2D73, lengthAdjustmentType74, lengthAdjustmentType75);
        plotRenderingInfo16.setPlotArea(rectangle2D73);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType74);
        org.junit.Assert.assertNotNull(lengthAdjustmentType75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "NO_CHANGE" + "'", str76.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D77);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        statisticalBarRenderer21.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        int int2 = numberTickUnit1.getMinorTickCount();
        java.lang.String str3 = numberTickUnit1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[size=0]" + "'", str3.equals("[size=0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setRangeAboutValue(0.0d, (double) 255);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis12.configure();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis12.setRange(range14, false, false);
        boolean boolean20 = range14.intersects((double) (-65281), 0.0d);
        numberAxis1.setRange(range14, true, false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        textLine0.draw(graphics2D1, 2.0f, (float) 15, textAnchor4, (float) (short) 0, (float) '4', (double) 192);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine();
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font11);
        java.awt.Paint paint13 = textFragment12.getPaint();
        textLine9.removeFragment(textFragment12);
        java.lang.String str15 = textFragment12.getText();
        textLine0.removeFragment(textFragment12);
        java.awt.Paint paint17 = textFragment12.getPaint();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("java.awt.Color[r=192,g=0,b=192]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=192,g=0,b=192], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot9.getRowRenderingOrder();
        java.awt.Color color15 = java.awt.Color.magenta;
        java.lang.String str16 = color15.toString();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setID("");
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        size2D20.height = (byte) 0;
        double double23 = size2D20.getHeight();
        double double24 = size2D20.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.0d, (double) 0L, rectangleAnchor27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor29);
        textTitle17.setBounds(rectangle2D28);
        boolean boolean32 = color15.equals((java.lang.Object) textTitle17);
        categoryPlot9.setOutlinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str16.equals("java.awt.Color[r=255,g=0,b=255]"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) (byte) 10);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.TOP_RIGHT");
        objectList0.set(0, (java.lang.Object) "TextBlockAnchor.TOP_RIGHT");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        java.awt.Paint paint63 = textTitle61.getBackgroundPaint();
        jFreeChart58.addSubtitle((org.jfree.chart.title.Title) textTitle61);
        org.jfree.chart.title.LegendTitle legendTitle65 = null;
        try {
            jFreeChart58.addLegend(legendTitle65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNull(paint63);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape9 = textBlock1.calculateBounds(graphics2D2, (float) 15, 0.0f, textBlockAnchor5, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean11 = textBlockAnchor5.equals((java.lang.Object) font10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis13.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot21.getRangeMarkers(2, layer23);
        categoryPlot21.setDrawSharedDomainAxis(false);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) categoryPlot21, true);
        java.awt.Stroke stroke29 = jFreeChart28.getBorderStroke();
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setTickMarkOutsideLength((float) 0);
        numberAxis1.setFixedDimension((double) 3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        java.util.Iterator iterator14 = legendItemCollection13.iterator();
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape31 = textBlock23.calculateBounds(graphics2D24, (float) 15, 0.0f, textBlockAnchor27, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape31, (java.awt.Paint) color32);
        legendItem33.setSeriesIndex((int) 'a');
        java.awt.Shape shape36 = legendItem33.getShape();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint39 = valueMarker38.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = textTitle40.getVerticalAlignment();
        java.awt.Paint paint42 = textTitle40.getBackgroundPaint();
        java.awt.Paint paint43 = textTitle40.getPaint();
        valueMarker38.setOutlinePaint(paint43);
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "ChartChangeEventType.GENERAL", "NO_CHANGE", "TextBlockAnchor.BOTTOM_CENTER", shape36, paint43);
        legendItemCollection13.add(legendItem45);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(iterator14);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        boolean boolean48 = categoryPlot9.render(graphics2D43, rectangle2D44, 192, plotRenderingInfo47);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        java.lang.Object obj51 = plotRenderingInfo50.clone();
        plotRenderingInfo47.addSubplotInfo(plotRenderingInfo50);
        boolean boolean54 = plotRenderingInfo50.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        java.awt.Stroke stroke4 = numberAxis3.getAxisLineStroke();
        numberAxis1.setTickMarkStroke(stroke4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = statisticalBarRenderer6.getGradientPaintTransformer();
        double double8 = statisticalBarRenderer6.getItemMargin();
        statisticalBarRenderer6.setBase((double) (-165));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer6.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis15.setPositiveArrowVisible(false);
        boolean boolean18 = numberAxis15.isTickMarksVisible();
        numberAxis15.setAutoTickUnitSelection(false, true);
        numberAxis15.setPositiveArrowVisible(false);
        org.jfree.chart.util.Size2D size2D24 = new org.jfree.chart.util.Size2D();
        size2D24.height = (byte) 0;
        double double27 = size2D24.getHeight();
        double double28 = size2D24.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, 0.0d, (double) 0L, rectangleAnchor31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        statisticalBarRenderer6.drawRangeGridline(graphics2D12, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis15, rectangle2D32, (double) 10L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, (java.awt.Shape) rectangle2D32, "0.2", "hi!");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (byte) 0;
        double double3 = size2D0.getHeight();
        double double4 = size2D0.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 0L, rectangleAnchor7);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D8, "", "hi!");
        java.lang.String str12 = tickLabelEntity11.getShapeType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "rect" + "'", str12.equals("rect"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        double double18 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition();
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax((double) 10L);
        axisState0.setMax(3.0d);
        axisState0.cursorLeft(1.0E-8d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray7 = new float[] { 1.0f, 255, 0.5f, (-165) };
        float[] floatArray8 = color0.getComponents(colorSpace2, floatArray7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        textLine1.removeFragment(textFragment4);
        java.awt.Font font7 = textFragment4.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getDomainMarkers((int) (short) 1, layer19);
        categoryPlot17.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setDomainAxisLocation(0, axisLocation24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot17.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer29.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer29.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray47);
        org.jfree.data.Range range49 = statisticalBarRenderer29.findRangeBounds(categoryDataset48);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer29);
        categoryPlot17.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke53 = categoryPlot17.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("RectangleEdge.RIGHT", font7, (org.jfree.chart.plot.Plot) categoryPlot17, true);
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState();
        java.util.List list57 = axisState56.getTicks();
        jFreeChart55.setSubtitles(list57);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        double double60 = textTitle59.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame61 = textTitle59.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent62 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle59);
        java.lang.String str63 = textTitle59.getToolTipText();
        jFreeChart55.removeSubtitle((org.jfree.chart.title.Title) textTitle59);
        jFreeChart55.setBackgroundImageAlignment((-65281));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame61);
        org.junit.Assert.assertNull(str63);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape16 = textBlock8.calculateBounds(graphics2D9, (float) 15, 0.0f, textBlockAnchor12, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Font font17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean18 = textBlockAnchor12.equals((java.lang.Object) font17);
        java.awt.Shape shape22 = textBlock4.calculateBounds(graphics2D5, 10.0f, (float) 500, textBlockAnchor12, (float) (-2), (float) (byte) 1, (double) 10.0f);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean25 = statisticalBarRenderer23.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer23.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer23.setDrawBarOutline(false);
        int int32 = statisticalBarRenderer23.getColumnCount();
        java.awt.Paint paint33 = statisticalBarRenderer23.getErrorIndicatorPaint();
        java.awt.Paint paint36 = statisticalBarRenderer23.getItemFillPaint((-65281), (int) (short) 0);
        java.awt.Stroke stroke39 = statisticalBarRenderer23.getItemOutlineStroke((int) (short) 1, 0);
        java.awt.Color color40 = java.awt.Color.DARK_GRAY;
        int int41 = color40.getAlpha();
        try {
            org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.GENERAL", "Size2D[width=0.0, height=0.0]", "", shape22, stroke39, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 255 + "'", int41 == 255);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Shape shape0 = null;
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray5, doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset12, true);
        java.lang.Comparable comparable15 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity17 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "[size=0]", categoryDataset12, comparable15, (java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        boolean boolean3 = numberTickUnit1.equals((java.lang.Object) 1.0d);
        java.lang.String str5 = numberTickUnit1.valueToString(0.2d);
        java.lang.String str6 = numberTickUnit1.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.2" + "'", str5.equals("0.2"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[size=0]" + "'", str6.equals("[size=0]"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder(1.0E-8d, (-0.0d), (double) (byte) 10, (double) 'a', (java.awt.Paint) color47);
        statisticalBarRenderer21.setBaseItemLabelPaint((java.awt.Paint) color47, true);
        java.awt.Paint paint52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis54.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis54.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer63 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean65 = statisticalBarRenderer63.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = statisticalBarRenderer63.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke69 = statisticalBarRenderer63.getErrorIndicatorStroke();
        categoryPlot62.setDomainGridlineStroke(stroke69);
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint52, stroke69);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = valueMarker71.getLabelOffset();
        org.jfree.chart.util.Size2D size2D73 = new org.jfree.chart.util.Size2D();
        size2D73.height = (byte) 0;
        double double76 = size2D73.getHeight();
        double double77 = size2D73.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D81 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D73, 0.0d, (double) 0L, rectangleAnchor80);
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets72.createOutsetRectangle(rectangle2D81);
        statisticalBarRenderer21.setBaseShape((java.awt.Shape) rectangle2D81);
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = statisticalBarRenderer21.getPlot();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(categoryPlot84);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = titleChangeEvent3.getType();
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10, dataset11, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint16 = valueMarker15.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle17.getVerticalAlignment();
        java.awt.Paint paint19 = textTitle17.getBackgroundPaint();
        java.awt.Paint paint20 = textTitle17.getPaint();
        valueMarker15.setOutlinePaint(paint20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker15.getLabelOffset();
        double double24 = rectangleInsets22.calculateBottomOutset((double) (-1));
        legendItemBlockContainer13.setPadding(rectangleInsets22);
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis29.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer38.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = statisticalBarRenderer38.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke44 = statisticalBarRenderer38.getErrorIndicatorStroke();
        categoryPlot37.setDomainGridlineStroke(stroke44);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint27, stroke44);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = valueMarker46.getLabelOffset();
        org.jfree.chart.util.Size2D size2D48 = new org.jfree.chart.util.Size2D();
        size2D48.height = (byte) 0;
        double double51 = size2D48.getHeight();
        double double52 = size2D48.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, 0.0d, (double) 0L, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets47.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str60 = lengthAdjustmentType59.toString();
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets22.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType58, lengthAdjustmentType59);
        boolean boolean62 = chartChangeEventType4.equals((java.lang.Object) rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(lengthAdjustmentType58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "NO_CHANGE" + "'", str60.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color11);
        numberAxis1.setTickLabelInsets(rectangleInsets9);
        try {
            numberAxis1.setRange(0.0d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        double double14 = categoryPlot9.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxis((int) (short) -1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1.0d, (java.lang.Number) (-1.0f));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) 0, 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(2.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedWidth((double) 1.0f);
        double double5 = rectangleConstraint0.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit(0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("CategoryLabelEntity: category=0, tooltip=Size2D[width=0.0, height=0.0], url=HorizontalAlignment.CENTER", "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", "NO_CHANGE", "NO_CHANGE", "java.awt.Color[r=192,g=0,b=192]");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(100.0d);
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources2 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean4 = jFreeChartResources2.containsKey("");
        java.util.Set<java.lang.String> strSet5 = jFreeChartResources2.keySet();
        int int6 = numberTickUnit1.compareTo((java.lang.Object) jFreeChartResources2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.lang.Object obj17 = plotRenderingInfo16.clone();
        java.awt.Color color18 = java.awt.Color.GRAY;
        boolean boolean19 = plotRenderingInfo16.equals((java.lang.Object) color18);
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 0.05d, plotRenderingInfo16, point2D20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint24 = categoryAxis23.getTickMarkPaint();
        java.awt.Paint paint25 = categoryAxis23.getLabelPaint();
        try {
            categoryPlot9.setDomainAxis((-2), categoryAxis23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = legendItemBlockContainer7.arrange(graphics2D10);
        org.jfree.chart.block.Arrangement arrangement12 = legendItemBlockContainer7.getArrangement();
        legendItemBlockContainer7.setToolTipText("java.awt.Color[r=255,g=0,b=255]");
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(arrangement12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str4 = rectangleEdge3.toString();
        java.lang.String str5 = rectangleEdge3.toString();
        axisState0.moveCursor((double) (-165), rectangleEdge3);
        axisState0.cursorUp(100.0d);
        axisState0.cursorLeft((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleEdge.RIGHT" + "'", str4.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.RIGHT" + "'", str5.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100L, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[][] doubleArray18 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray18);
        org.jfree.data.Range range20 = statisticalBarRenderer0.findRangeBounds(categoryDataset19);
        java.awt.Paint paint22 = statisticalBarRenderer0.getSeriesOutlinePaint(15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        boolean boolean2 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation1);
        java.awt.Color color3 = java.awt.Color.GRAY;
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9, true);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset9, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getDomainMarkers((int) (short) 1, layer13);
        categoryPlot11.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setDomainAxisLocation(0, axisLocation18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot11.getFixedLegendItems();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot11.getRangeMarkers(0, layer22);
        boolean boolean24 = categoryPlot11.isRangeCrosshairLockedOnData();
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot11);
        int int26 = statisticalBarRenderer0.getPassCount();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE7" + "'", str1.equals("ItemLabelAnchor.OUTSIDE7"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        try {
            java.awt.Paint paint10 = defaultDrawingSupplier8.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Object obj3 = defaultStatisticalCategoryDataset0.clone();
        try {
            java.lang.Number number6 = defaultStatisticalCategoryDataset0.getMeanValue(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(2, layer11);
        categoryPlot9.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis17.resizeRange(1.0E-8d);
        numberAxis17.setLabelToolTip("TextBlockAnchor.BOTTOM_CENTER");
        try {
            categoryPlot9.setRangeAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) numberAxis17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.05d, (double) 0.5f, (double) 10.0f, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Object obj0 = null;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image4, "", "hi!", "hi!");
        projectInfo8.addOptionalLibrary("");
        java.awt.Image image14 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image14, "", "hi!", "hi!");
        projectInfo8.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo18);
        java.lang.String str20 = projectInfo8.toString();
        java.lang.String str21 = projectInfo8.toString();
        java.lang.String str22 = projectInfo8.getVersion();
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) str22);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str20.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!" + "'", str21.equals("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.Object obj3 = labelBlock1.clone();
        labelBlock1.setWidth((double) (byte) 10);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setLabelAngle(0.05d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset15 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14, dataset15, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendItemBlockContainer17.getPadding();
        double double20 = rectangleInsets18.calculateLeftInset((double) (-2));
        categoryAxis7.setLabelInsets(rectangleInsets18);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint26 = categoryAxis25.getTickMarkPaint();
        java.awt.Paint paint27 = categoryAxis25.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis34.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean45 = statisticalBarRenderer43.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = statisticalBarRenderer43.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke49 = statisticalBarRenderer43.getErrorIndicatorStroke();
        categoryPlot42.setDomainGridlineStroke(stroke49);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint32, stroke49);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = valueMarker51.getLabelOffset();
        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D();
        size2D53.height = (byte) 0;
        double double56 = size2D53.getHeight();
        double double57 = size2D53.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D53, 0.0d, (double) 0L, rectangleAnchor60);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets52.createOutsetRectangle(rectangle2D61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str64 = rectangleEdge63.toString();
        boolean boolean66 = rectangleEdge63.equals((java.lang.Object) 15);
        double double67 = categoryAxis25.getCategoryJava2DCoordinate(categoryAnchor28, (int) (short) 0, 0, rectangle2D61, rectangleEdge63);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity70 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D61, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double72 = categoryAxis7.getCategoryStart((int) '4', 0, rectangle2D61, rectangleEdge71);
        java.lang.Object obj73 = null;
        try {
            java.lang.Object obj74 = labelBlock1.draw(graphics2D6, rectangle2D61, obj73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "RectangleEdge.RIGHT" + "'", str64.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot9.getRangeMarkers(0, layer20);
        boolean boolean22 = categoryPlot9.isRangeCrosshairLockedOnData();
        int int23 = categoryPlot9.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot9.setDomainAxis(0, categoryAxis25, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType29 = rectangleInsets28.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, 0.0d, (double) 255, (double) (-165), 0.0d);
        categoryPlot9.setInsets(rectangleInsets34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis37.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = categoryPlot45.getDomainMarkers((int) (short) 1, layer47);
        boolean boolean49 = categoryPlot45.getDrawSharedDomainAxis();
        java.awt.Paint paint51 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis53.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis53.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean64 = statisticalBarRenderer62.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = statisticalBarRenderer62.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke68 = statisticalBarRenderer62.getErrorIndicatorStroke();
        categoryPlot61.setDomainGridlineStroke(stroke68);
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint51, stroke68);
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker70);
        java.awt.Stroke stroke72 = categoryPlot45.getRangeGridlineStroke();
        java.awt.Stroke stroke73 = categoryPlot45.getDomainGridlineStroke();
        categoryPlot9.setOutlineStroke(stroke73);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Shape shape19 = statisticalBarRenderer0.getBaseShape();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer4.getPositiveItemLabelPosition((int) (short) 1, 0);
        double double10 = statisticalBarRenderer4.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = statisticalBarRenderer4.getSeriesToolTipGenerator(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = itemLabelPosition14.getItemLabelAnchor();
        statisticalBarRenderer4.setSeriesPositiveItemLabelPosition(0, itemLabelPosition14);
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition14.getRotationAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = org.jfree.chart.text.TextUtilities.drawAlignedString("[size=0]", graphics2D1, (float) (short) 1, (float) (short) 0, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ClassContext", "ChartChangeEventType.GENERAL", "hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", "NO_CHANGE");
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.configure();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis2.setRange(range4, false, false);
        boolean boolean10 = range4.intersects((double) (-65281), 0.0d);
        java.lang.String str11 = range4.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,1.0]" + "'", str11.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = categoryPlot9.getDrawingSupplier();
        org.jfree.chart.util.SortOrder sortOrder49 = categoryPlot9.getColumnRenderingOrder();
        java.lang.Object obj50 = categoryPlot9.clone();
        java.util.List list51 = categoryPlot9.getAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryPlot9.getAxisOffset();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(drawingSupplier48);
        org.junit.Assert.assertNotNull(sortOrder49);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Paint paint1 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Object) paint1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean5 = keyedObject2.equals((java.lang.Object) "hi!");
        java.lang.Object obj6 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot9.getAxisOffset();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot9.getDomainMarkers((int) (short) -1, layer15);
        java.awt.Image image17 = categoryPlot9.getBackgroundImage();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) horizontalAlignment1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image13, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo17);
        projectInfo7.addOptionalLibrary("ThreadContext");
        java.util.List list21 = projectInfo7.getContributors();
        org.junit.Assert.assertNull(list21);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.RIGHT", "RectangleEdge.RIGHT", "", "");
        basicProjectInfo4.setVersion("ThreadContext");
        java.lang.String str7 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.RIGHT" + "'", str7.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = (byte) 0;
        double double3 = size2D0.getHeight();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, true);
        java.lang.Object obj7 = defaultStatisticalCategoryDataset4.clone();
        boolean boolean8 = size2D0.equals(obj7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.util.Size2D size2D1 = new org.jfree.chart.util.Size2D();
        double double2 = size2D1.width;
        boolean boolean4 = size2D1.equals((java.lang.Object) (-65281));
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) "java.awt.Color[r=192,g=0,b=192]", (java.lang.Object) size2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        double double5 = numberAxis1.getLabelAngle();
        java.lang.String str6 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ThreadContext" + "'", str6.equals("ThreadContext"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation2 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Font font4 = numberAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis1.getLabelInsets();
        org.jfree.chart.plot.Plot plot6 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        double double2 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setBase((double) (-165));
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        java.awt.Font font11 = categoryAxis5.getLabelFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font11);
        org.jfree.chart.LegendItem legendItem15 = statisticalBarRenderer0.getLegendItem(15, 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(legendItem15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0L, (java.lang.Object) (short) 100);
        boolean boolean4 = keyedObject2.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        statisticalBarRenderer0.setPlot(categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis16.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot24.getDomainMarkers((int) (short) 1, layer26);
        categoryPlot24.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot24.setDomainAxisLocation(0, axisLocation31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot24.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot24.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean38 = statisticalBarRenderer36.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer36.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer36.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[][] doubleArray54 = new double[][] { doubleArray48, doubleArray49, doubleArray50, doubleArray51, doubleArray52, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray54);
        org.jfree.data.Range range56 = statisticalBarRenderer36.findRangeBounds(categoryDataset55);
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer36);
        categoryPlot10.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer36);
        java.awt.Font font61 = statisticalBarRenderer36.getItemLabelFont((int) 'a', (-2));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertNotNull(font61);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        float float53 = jFreeChart50.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean56 = statisticalBarRenderer54.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = statisticalBarRenderer54.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke60 = statisticalBarRenderer54.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = null;
        statisticalBarRenderer54.setBaseItemLabelGenerator(categoryItemLabelGenerator61, false);
        boolean boolean65 = statisticalBarRenderer54.isSeriesItemLabelsVisible(1);
        org.jfree.chart.LegendItem legendItem68 = statisticalBarRenderer54.getLegendItem(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint70 = categoryAxis69.getTickMarkPaint();
        java.awt.Paint paint71 = categoryAxis69.getLabelPaint();
        statisticalBarRenderer54.setBaseFillPaint(paint71);
        jFreeChart50.setBackgroundPaint(paint71);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(legendItem68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 10, (double) '#', 1.0E-8d, (double) (byte) -1);
        double double6 = rectangleInsets4.trimHeight((double) 10L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0E-8d) + "'", double6 == (-1.0E-8d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        java.awt.Font font8 = valueMarker1.getLabelFont();
        float float9 = valueMarker1.getAlpha();
        java.awt.Paint paint10 = valueMarker1.getLabelPaint();
        java.awt.Stroke stroke11 = valueMarker1.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis13.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis26.configure();
        org.jfree.data.RangeType rangeType28 = numberAxis26.getRangeType();
        categoryPlot21.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis26);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryPlot21.getInsets();
        categoryPlot21.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryPlot21.getInsets();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setRangeCrosshairValue(10.0d, false);
        categoryPlot9.setRangeCrosshairValue((double) (-1.0f));
        categoryPlot9.setRangeGridlinesVisible(true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.Number number0 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(number0, (java.lang.Number) 1.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 3, "TextBlockAnchor.TOP_RIGHT", textAnchor3, textAnchor5, 0.0d);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent48);
        boolean boolean50 = categoryPlot9.isSubplot();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis52.configure();
        org.jfree.data.RangeType rangeType54 = numberAxis52.getRangeType();
        java.awt.Paint paint55 = numberAxis52.getTickMarkPaint();
        numberAxis52.setVerticalTickLabels(true);
        double double58 = numberAxis52.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis60.configure();
        org.jfree.data.RangeType rangeType62 = numberAxis60.getRangeType();
        org.jfree.chart.plot.Plot plot63 = numberAxis60.getPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = numberAxis60.getTickUnit();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { numberAxis52, numberAxis60 };
        categoryPlot9.setRangeAxes(valueAxisArray65);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rangeType54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(rangeType62);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertNotNull(numberTickUnit64);
        org.junit.Assert.assertNotNull(valueAxisArray65);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        java.awt.Paint paint11 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        textLine0.removeFragment(textFragment3);
        java.lang.String str6 = textFragment3.getText();
        java.awt.Font font7 = textFragment3.getFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ChartChangeEventType.GENERAL", 3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean50 = statisticalBarRenderer48.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer48.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer48.setDrawBarOutline(false);
        int int57 = statisticalBarRenderer48.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        statisticalBarRenderer48.setBaseToolTipGenerator(categoryToolTipGenerator58);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer48);
        try {
            statisticalBarRenderer48.setSeriesItemLabelsVisible((int) (byte) -1, (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer1.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke7 = statisticalBarRenderer1.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        categoryPlot17.setRangeGridlinesVisible(false);
        statisticalBarRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = statisticalBarRenderer1.getItemLabelGenerator(100, (int) (byte) 100);
        boolean boolean24 = gradientPaintTransformType0.equals((java.lang.Object) categoryItemLabelGenerator23);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        java.awt.Paint paint63 = textTitle61.getBackgroundPaint();
        jFreeChart58.addSubtitle((org.jfree.chart.title.Title) textTitle61);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean67 = statisticalBarRenderer65.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition70 = statisticalBarRenderer65.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke71 = statisticalBarRenderer65.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator72 = null;
        statisticalBarRenderer65.setBaseItemLabelGenerator(categoryItemLabelGenerator72, false);
        boolean boolean76 = statisticalBarRenderer65.isSeriesItemLabelsVisible(1);
        org.jfree.chart.LegendItem legendItem79 = statisticalBarRenderer65.getLegendItem(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint81 = categoryAxis80.getTickMarkPaint();
        java.awt.Paint paint82 = categoryAxis80.getLabelPaint();
        statisticalBarRenderer65.setBaseFillPaint(paint82);
        jFreeChart58.setBorderPaint(paint82);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(legendItem79);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=0, tooltip=Size2D[width=0.0, height=0.0], url=HorizontalAlignment.CENTER");
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        statisticalBarRenderer0.setSeriesOutlinePaint(15, (java.awt.Paint) color21);
        java.awt.Paint paint25 = statisticalBarRenderer0.getItemOutlinePaint(15, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color6, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("", font28);
        java.awt.Paint paint30 = textFragment29.getPaint();
        boolean boolean31 = axisLocation26.equals((java.lang.Object) paint30);
        categoryPlot13.setRangeAxisLocation(axisLocation26, false);
        int int34 = categoryPlot13.getRangeAxisCount();
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setAutoRangeMinimumSize((double) 10);
        numberAxis1.resizeRange((double) (byte) 1, (double) (byte) 100);
        numberAxis1.setTickMarkOutsideLength((float) (byte) 100);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.RIGHT", "hi!", doubleArray10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset12);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset12);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range0.intersects((double) 100, (double) 100.0f);
        double double4 = range0.getCentralValue();
        double double5 = range0.getUpperBound();
        boolean boolean8 = range0.intersects((double) 2.0f, 1.0E-8d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 2);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getDomainMarkers((int) (short) 1, layer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot11.getAxisOffset();
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot11);
        boolean boolean18 = statisticalBarRenderer0.isSeriesVisibleInLegend((int) '#');
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray51, numberArray54, numberArray57, numberArray60, numberArray63, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray67);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset68, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot9.getRendererForDataset(categoryDataset68);
        org.jfree.chart.plot.Plot plot72 = categoryPlot9.getRootPlot();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertNotNull(plot72);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        boolean boolean13 = categoryPlot9.getDrawSharedDomainAxis();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = statisticalBarRenderer26.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke32 = statisticalBarRenderer26.getErrorIndicatorStroke();
        categoryPlot25.setDomainGridlineStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint15, stroke32);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        org.jfree.chart.util.Layer layer38 = null;
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker37, layer38);
        java.awt.Stroke stroke40 = valueMarker37.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor41 = valueMarker37.getLabelTextAnchor();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(textAnchor41);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot9.getDataset((int) (short) 0);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNull(categoryDataset48);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str1 = rectangleEdge0.toString();
        boolean boolean3 = rectangleEdge0.equals((java.lang.Object) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.RIGHT" + "'", str1.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle2.setVerticalAlignment(verticalAlignment4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10, dataset11, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendItemBlockContainer13.getPadding();
        textTitle2.setMargin(rectangleInsets14);
        boolean boolean16 = size2D0.equals((java.lang.Object) textTitle2);
        textTitle2.setID("NO_CHANGE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        float float19 = categoryPlot9.getBackgroundImageAlpha();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot9.getDrawingSupplier();
        org.jfree.chart.util.SortOrder sortOrder21 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot9.setRowRenderingOrder(sortOrder21);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(sortOrder21);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = statisticalBarRenderer0.getBaseURLGenerator();
        java.awt.Paint paint21 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        int int8 = chartProgressEvent5.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getURLText();
        java.lang.Object obj3 = labelBlock1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8, dataset9, (java.lang.Comparable) 1.0d);
        boolean boolean12 = labelBlock1.equals((java.lang.Object) 1.0d);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis15.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot23.getDomainMarkers((int) (short) 1, layer25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.lang.Object obj31 = plotRenderingInfo30.clone();
        java.awt.Color color32 = java.awt.Color.GRAY;
        boolean boolean33 = plotRenderingInfo30.equals((java.lang.Object) color32);
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot23.zoomDomainAxes((double) 2, 0.05d, plotRenderingInfo30, point2D34);
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo30.getDataArea();
        try {
            labelBlock1.draw(graphics2D13, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(1.0d, range1);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.configure();
        org.jfree.data.RangeType rangeType16 = numberAxis14.getRangeType();
        categoryPlot9.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot9.getInsets();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = textTitle19.getVerticalAlignment();
        java.awt.Paint paint21 = textTitle19.getBackgroundPaint();
        java.awt.Paint paint22 = textTitle19.getPaint();
        categoryPlot9.setRangeCrosshairPaint(paint22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = categoryPlot9.getRangeAxisIndex(valueAxis24);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        double double16 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        try {
            statisticalBarRenderer0.setSeriesItemLabelGenerator((-165), categoryItemLabelGenerator18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot9.getRangeMarkers(0, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot9.getDomainAxisLocation((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis26.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot34.getDomainMarkers((int) (short) 1, layer36);
        categoryPlot34.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot34.setDomainAxisLocation(0, axisLocation41);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = categoryPlot34.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot34.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean48 = statisticalBarRenderer46.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer46.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer46.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[] doubleArray62 = new double[] {};
        double[] doubleArray63 = new double[] {};
        double[][] doubleArray64 = new double[][] { doubleArray58, doubleArray59, doubleArray60, doubleArray61, doubleArray62, doubleArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray64);
        org.jfree.data.Range range66 = statisticalBarRenderer46.findRangeBounds(categoryDataset65);
        categoryPlot34.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer46);
        categoryPlot34.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke70 = categoryPlot34.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = categoryPlot34.getOrientation();
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray79 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray85 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray88 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray91 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray92 = new java.lang.Number[][] { numberArray76, numberArray79, numberArray82, numberArray85, numberArray88, numberArray91 };
        org.jfree.data.category.CategoryDataset categoryDataset93 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray92);
        org.jfree.data.Range range95 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset93, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer96 = categoryPlot34.getRendererForDataset(categoryDataset93);
        categoryPlot9.setDataset((int) (byte) 10, categoryDataset93);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(legendItemCollection43);
        org.junit.Assert.assertNull(categoryItemRenderer45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNull(range66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray85);
        org.junit.Assert.assertNotNull(numberArray88);
        org.junit.Assert.assertNotNull(numberArray91);
        org.junit.Assert.assertNotNull(numberArray92);
        org.junit.Assert.assertNotNull(categoryDataset93);
        org.junit.Assert.assertNotNull(range95);
        org.junit.Assert.assertNull(categoryItemRenderer96);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean26 = textAnchor24.equals((java.lang.Object) categoryLabelPositions25);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions25);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) false);
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) 1);
        double double3 = blockParams0.getTranslateX();
        double double4 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        textLine1.removeFragment(textFragment4);
        java.awt.Font font7 = textFragment4.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot17.getDomainMarkers((int) (short) 1, layer19);
        categoryPlot17.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot17.setDomainAxisLocation(0, axisLocation24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot17.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer29.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer29.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[][] doubleArray47 = new double[][] { doubleArray41, doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray47);
        org.jfree.data.Range range49 = statisticalBarRenderer29.findRangeBounds(categoryDataset48);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer29);
        categoryPlot17.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke53 = categoryPlot17.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart("RectangleEdge.RIGHT", font7, (org.jfree.chart.plot.Plot) categoryPlot17, true);
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState();
        java.util.List list57 = axisState56.getTicks();
        jFreeChart55.setSubtitles(list57);
        java.awt.Image image59 = jFreeChart55.getBackgroundImage();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNull(image59);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers((-2), layer17);
        categoryPlot9.setForegroundAlpha((float) (byte) 0);
        java.awt.Color color21 = java.awt.Color.magenta;
        java.lang.String str22 = color21.toString();
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str22.equals("java.awt.Color[r=255,g=0,b=255]"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        java.awt.Font font8 = valueMarker1.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setID("");
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        size2D4.height = (byte) 0;
        double double7 = size2D4.getHeight();
        double double8 = size2D4.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D4, 0.0d, (double) 0L, rectangleAnchor11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D14 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D12, rectangleAnchor13);
        textTitle1.setBounds(rectangle2D12);
        boolean boolean16 = borderArrangement0.equals((java.lang.Object) textTitle1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.awt.Font font3 = labelBlock1.getFont();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        categoryPlot16.setRangeCrosshairValue(1.0d, true);
        categoryPlot16.mapDatasetToDomainAxis(0, 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        int int9 = statisticalBarRenderer0.getColumnCount();
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.util.Size2D size2D12 = new org.jfree.chart.util.Size2D();
        size2D12.height = (byte) 0;
        double double15 = size2D12.getHeight();
        double double16 = size2D12.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, 0.0d, (double) 0L, rectangleAnchor19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        statisticalBarRenderer0.setSeriesShape((int) (short) 10, (java.awt.Shape) rectangle2D20, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = statisticalBarRenderer0.getURLGenerator(255, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 15, (double) (byte) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        boolean boolean13 = categoryPlot9.getDrawSharedDomainAxis();
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis17.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = statisticalBarRenderer26.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke32 = statisticalBarRenderer26.getErrorIndicatorStroke();
        categoryPlot25.setDomainGridlineStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint15, stroke32);
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        java.awt.Stroke stroke36 = categoryPlot9.getRangeGridlineStroke();
        java.awt.Stroke stroke37 = categoryPlot9.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot9.getDomainAxis();
        java.awt.Stroke stroke39 = categoryPlot9.getDomainGridlineStroke();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(categoryAxis38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, (float) 15, 0.0f, textBlockAnchor4, (float) '4', (float) (byte) 10, (double) (byte) -1);
        org.jfree.chart.text.TextLine textLine9 = textBlock0.getLastLine();
        org.jfree.chart.text.TextLine textLine10 = textBlock0.getLastLine();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock0.calculateDimensions(graphics2D11);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(textLine9);
        org.junit.Assert.assertNull(textLine10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        java.lang.Object obj9 = legendItemBlockContainer7.clone();
        java.lang.Comparable comparable10 = legendItemBlockContainer7.getSeriesKey();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color14);
        java.awt.Paint paint16 = blockBorder15.getPaint();
        legendItemBlockContainer7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color19 = color18.darker();
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color18, jFreeChart20, (int) (short) 10, 0);
        chartProgressEvent23.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis28.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot36.getDomainMarkers((int) (short) 1, layer38);
        categoryPlot36.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setDomainAxisLocation(0, axisLocation43);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = categoryPlot36.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot36.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean50 = statisticalBarRenderer48.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer48.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer48.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[] doubleArray62 = new double[] {};
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[][] doubleArray66 = new double[][] { doubleArray60, doubleArray61, doubleArray62, doubleArray63, doubleArray64, doubleArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray66);
        org.jfree.data.Range range68 = statisticalBarRenderer48.findRangeBounds(categoryDataset67);
        categoryPlot36.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer48);
        categoryPlot36.setRangeCrosshairLockedOnData(false);
        categoryPlot36.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier75 = categoryPlot36.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart76 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot36);
        java.lang.Object obj77 = jFreeChart76.getTextAntiAlias();
        chartProgressEvent23.setChart(jFreeChart76);
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment80 = textTitle79.getVerticalAlignment();
        java.awt.Paint paint81 = textTitle79.getBackgroundPaint();
        jFreeChart76.addSubtitle((org.jfree.chart.title.Title) textTitle79);
        java.lang.Object obj83 = textTitle79.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint85 = categoryAxis84.getTickMarkPaint();
        categoryAxis84.setUpperMargin(1.0d);
        java.lang.Object obj88 = categoryAxis84.clone();
        legendItemBlockContainer7.add((org.jfree.chart.block.Block) textTitle79, obj88);
        textTitle79.setHeight(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 1.0d + "'", comparable10.equals(1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNull(legendItemCollection45);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertNotNull(drawingSupplier75);
        org.junit.Assert.assertNull(obj77);
        org.junit.Assert.assertNotNull(verticalAlignment80);
        org.junit.Assert.assertNull(paint81);
        org.junit.Assert.assertNotNull(obj83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(obj88);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) categoryLabelPositions1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean5 = textAnchor3.equals((java.lang.Object) categoryLabelPositions4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str9 = rectangleEdge8.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions4, categoryLabelPosition10);
        double double12 = categoryLabelPosition10.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition10);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean16 = textAnchor14.equals((java.lang.Object) categoryLabelPositions15);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str20 = rectangleEdge19.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = categoryLabelPositions18.getLabelPosition(rectangleEdge19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions15, categoryLabelPosition21);
        double double23 = categoryLabelPosition21.getAngle();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = categoryLabelPosition21.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = categoryLabelPosition21.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape35 = textBlock27.calculateBounds(graphics2D28, (float) 15, 0.0f, textBlockAnchor31, (float) '4', (float) (byte) 10, (double) (byte) -1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape35, rectangleAnchor36, 0.05d, 0.0d);
        org.jfree.chart.text.TextBlock textBlock40 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape48 = textBlock40.calculateBounds(graphics2D41, (float) 15, 0.0f, textBlockAnchor44, (float) '4', (float) (byte) 10, (double) (byte) -1);
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions52 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean53 = textAnchor51.equals((java.lang.Object) categoryLabelPositions52);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions55 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str57 = rectangleEdge56.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition58 = categoryLabelPositions55.getLabelPosition(rectangleEdge56);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions59 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions52, categoryLabelPosition58);
        double double60 = categoryLabelPosition58.getAngle();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType61 = categoryLabelPosition58.getWidthType();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition63 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor36, textBlockAnchor44, textAnchor49, (double) (-1L), categoryLabelWidthType61, 0.0f);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions64 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition10, categoryLabelPosition21, categoryLabelPosition26, categoryLabelPosition63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.RIGHT" + "'", str9.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.0d) + "'", double12 == (-0.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleEdge.RIGHT" + "'", str20.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition21);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-0.0d) + "'", double23 == (-0.0d));
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(categoryLabelPositions52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "RectangleEdge.RIGHT" + "'", str57.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition58);
        org.junit.Assert.assertNotNull(categoryLabelPositions59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-0.0d) + "'", double60 == (-0.0d));
        org.junit.Assert.assertNotNull(categoryLabelWidthType61);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range10.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint9.toRangeWidth(range10);
        org.jfree.chart.util.Size2D size2D15 = legendItemBlockContainer7.arrange(graphics2D8, rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint9.toUnconstrainedWidth();
        double double17 = rectangleConstraint9.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint9.toFixedHeight((double) 100L);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str2 = labelBlock1.getToolTipText();
        java.lang.Object obj3 = labelBlock1.clone();
        labelBlock1.setWidth((double) (byte) 10);
        labelBlock1.setToolTipText("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj3);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean7 = range4.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint3.toRangeWidth(range4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean12 = textAnchor10.equals((java.lang.Object) categoryLabelPositions11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str16 = rectangleEdge15.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions14.getLabelPosition(rectangleEdge15);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions11, categoryLabelPosition17);
        boolean boolean19 = horizontalAlignment9.equals((java.lang.Object) categoryLabelPositions18);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) range4, (java.lang.Object) boolean19);
        numberAxis1.setDefaultAutoRange(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleEdge.RIGHT" + "'", str16.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
        boolean boolean4 = org.jfree.chart.util.ShapeUtilities.equal(shape1, shape3);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 1.0f, shape3, "Size2D[width=0.0, height=0.0]", "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        boolean boolean13 = categoryPlot9.getDrawSharedDomainAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot9.getRangeAxisForDataset((int) (byte) 100);
        java.util.List list16 = categoryPlot9.getAnnotations();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean22 = statisticalBarRenderer20.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer20.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer20.setDrawBarOutline(false);
        statisticalBarRenderer20.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator34 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean36 = standardCategorySeriesLabelGenerator34.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer20.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator34);
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot9.getLegendItems();
        categoryPlot9.setRangeGridlinesVisible(false);
        java.awt.Paint paint16 = categoryPlot9.getRangeGridlinePaint();
        categoryPlot9.mapDatasetToDomainAxis((int) 'a', (-65281));
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        double double18 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = statisticalBarRenderer0.getPlot();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = statisticalBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNull(categoryURLGenerator20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.awt.Shape shape17 = legendItem14.getLine();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape17, "ChartChangeEventType.GENERAL", "Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesOutlinePaint((int) (short) -1);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine();
        textBlock6.addLine(textLine12);
        org.jfree.chart.text.TextLine textLine14 = textBlock6.getLastLine();
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textLine14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        size2D0.setWidth((double) 3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean50 = statisticalBarRenderer48.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer48.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer48.setDrawBarOutline(false);
        int int57 = statisticalBarRenderer48.getColumnCount();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator58 = null;
        statisticalBarRenderer48.setBaseToolTipGenerator(categoryToolTipGenerator58);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer48);
        java.awt.Stroke stroke61 = statisticalBarRenderer48.getErrorIndicatorStroke();
        org.jfree.chart.text.TextBlock textBlock63 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor67 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape71 = textBlock63.calculateBounds(graphics2D64, (float) 15, 0.0f, textBlockAnchor67, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Font font72 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean73 = textBlockAnchor67.equals((java.lang.Object) font72);
        statisticalBarRenderer48.setSeriesItemLabelFont(2, font72, true);
        java.lang.Boolean boolean77 = statisticalBarRenderer48.getSeriesItemLabelsVisible((int) (short) 100);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(textBlockAnchor67);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(boolean77);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 3.0d, (java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Number number8 = defaultStatisticalCategoryDataset0.getValue(comparable6, (java.lang.Comparable) numberTickUnit7);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        textTitle1.setPadding((double) (short) 1, 1.0E-8d, (double) '#', 2.0d);
        org.jfree.chart.block.BlockFrame blockFrame7 = textTitle1.getFrame();
        org.junit.Assert.assertNotNull(blockFrame7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        boolean boolean48 = categoryPlot9.render(graphics2D43, rectangle2D44, 192, plotRenderingInfo47);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState49 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo47);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getDomainMarkers((int) (short) 1, layer16);
        categoryPlot14.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot14.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer26.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer26.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = statisticalBarRenderer26.findRangeBounds(categoryDataset45);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        categoryPlot14.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier53 = categoryPlot14.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj55 = jFreeChart54.getTextAntiAlias();
        titleChangeEvent3.setChart(jFreeChart54);
        int int57 = jFreeChart54.getBackgroundImageAlignment();
        jFreeChart54.setAntiAlias(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(drawingSupplier53);
        org.junit.Assert.assertNull(obj55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        numberAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnits tickUnits6 = new org.jfree.chart.axis.TickUnits();
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        boolean boolean11 = numberTickUnit9.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = numberTickUnit9.valueToString(0.2d);
        try {
            org.jfree.chart.axis.TickUnit tickUnit14 = tickUnits6.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.2" + "'", str13.equals("0.2"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11, numberArray14, numberArray17, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset22, (double) (byte) 10);
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean29 = range26.intersects((double) 100, (double) 100.0f);
        double double30 = range26.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range26);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType32 = rectangleConstraint31.getWidthConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis35.configure();
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis35.setRange(range37, false, false);
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean45 = range42.intersects((double) 100, (double) 100.0f);
        double double46 = range42.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range42);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType48 = rectangleConstraint47.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((double) 500, range24, lengthConstraintType32, (double) (byte) 10, range37, lengthConstraintType48);
        java.lang.String str50 = lengthConstraintType32.toString();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.5d + "'", double30 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType32);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.5d + "'", double46 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "LengthConstraintType.FIXED" + "'", str50.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        size2D0.setHeight((double) ' ');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        boolean boolean6 = size2D0.equals((java.lang.Object) categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        java.awt.Paint paint2 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean20 = statisticalBarRenderer18.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke24 = statisticalBarRenderer18.getErrorIndicatorStroke();
        categoryPlot17.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint7, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker26.getLabelOffset();
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        size2D28.height = (byte) 0;
        double double31 = size2D28.getHeight();
        double double32 = size2D28.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) 0L, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str39 = rectangleEdge38.toString();
        boolean boolean41 = rectangleEdge38.equals((java.lang.Object) 15);
        double double42 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, (int) (short) 0, 0, rectangle2D36, rectangleEdge38);
        java.awt.Font font43 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setLabelURL("");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.RIGHT" + "'", str39.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, 0.0d, (double) 255, (double) (-165), 0.0d);
        double double8 = rectangleInsets6.calculateRightOutset((double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        java.awt.Paint paint63 = textTitle61.getBackgroundPaint();
        jFreeChart58.addSubtitle((org.jfree.chart.title.Title) textTitle61);
        java.awt.Paint paint65 = jFreeChart58.getBorderPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock6.getLineAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint14 = categoryAxis13.getTickMarkPaint();
        categoryAxis13.setUpperMargin(1.0d);
        java.lang.Object obj17 = categoryAxis13.clone();
        boolean boolean18 = horizontalAlignment12.equals((java.lang.Object) categoryAxis13);
        float float19 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        boolean boolean20 = categoryAxis13.isTickMarksVisible();
        java.awt.Font font22 = categoryAxis13.getTickLabelFont((java.lang.Comparable) 0.8f);
        categoryAxis13.setLowerMargin((double) 2.0f);
        double double25 = categoryAxis13.getUpperMargin();
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Paint paint4 = textFragment3.getPaint();
        textLine0.removeFragment(textFragment3);
        org.jfree.chart.text.TextFragment textFragment6 = textLine0.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment7 = textLine0.getLastTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(textFragment6);
        org.junit.Assert.assertNull(textFragment7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        java.awt.Stroke stroke11 = numberAxis1.getTickMarkStroke();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState();
        java.util.List list14 = axisState13.getTicks();
        axisState13.cursorRight((double) 'a');
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment17, verticalAlignment18, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement21, dataset22, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint27 = valueMarker26.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle28.getVerticalAlignment();
        java.awt.Paint paint30 = textTitle28.getBackgroundPaint();
        java.awt.Paint paint31 = textTitle28.getPaint();
        valueMarker26.setOutlinePaint(paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = valueMarker26.getLabelOffset();
        double double35 = rectangleInsets33.calculateBottomOutset((double) (-1));
        legendItemBlockContainer24.setPadding(rectangleInsets33);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis40.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis46, categoryItemRenderer47);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean51 = statisticalBarRenderer49.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = statisticalBarRenderer49.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke55 = statisticalBarRenderer49.getErrorIndicatorStroke();
        categoryPlot48.setDomainGridlineStroke(stroke55);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint38, stroke55);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = valueMarker57.getLabelOffset();
        org.jfree.chart.util.Size2D size2D59 = new org.jfree.chart.util.Size2D();
        size2D59.height = (byte) 0;
        double double62 = size2D59.getHeight();
        double double63 = size2D59.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D67 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 0.0d, (double) 0L, rectangleAnchor66);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets58.createOutsetRectangle(rectangle2D67);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType69 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str71 = lengthAdjustmentType70.toString();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets33.createAdjustedRectangle(rectangle2D68, lengthAdjustmentType69, lengthAdjustmentType70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list74 = numberAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D72, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(lengthAdjustmentType69);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "NO_CHANGE" + "'", str71.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setUpperMargin(1.0d);
        categoryAxis0.setCategoryMargin((double) 192);
        java.awt.Paint paint6 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker1.getLabelOffset();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        valueMarker1.setLabelFont(font9);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint13 = valueMarker12.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle14.getVerticalAlignment();
        java.awt.Paint paint16 = textTitle14.getBackgroundPaint();
        java.awt.Paint paint17 = textTitle14.getPaint();
        valueMarker12.setOutlinePaint(paint17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = valueMarker12.getLabelOffset();
        java.awt.Font font20 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        valueMarker12.setLabelFont(font20);
        valueMarker1.setLabelFont(font20);
        java.lang.String str23 = valueMarker1.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor24 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint2 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint8 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke25 = statisticalBarRenderer19.getErrorIndicatorStroke();
        categoryPlot18.setDomainGridlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint8, stroke25);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = valueMarker27.getLabelOffset();
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = (byte) 0;
        double double32 = size2D29.getHeight();
        double double33 = size2D29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, (double) 0L, rectangleAnchor36);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str40 = rectangleEdge39.toString();
        boolean boolean42 = rectangleEdge39.equals((java.lang.Object) 15);
        double double43 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (short) 0, 0, rectangle2D37, rectangleEdge39);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity46 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D37, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        java.awt.Shape shape47 = categoryLabelEntity46.getArea();
        java.lang.String str48 = categoryLabelEntity46.getToolTipText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleEdge.RIGHT" + "'", str40.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str48.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        categoryPlot9.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier48 = categoryPlot9.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis50 = categoryPlot9.getRangeAxis((-2));
        categoryPlot9.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(drawingSupplier48);
        org.junit.Assert.assertNull(valueAxis50);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint4 = categoryAxis3.getTickMarkPaint();
        categoryAxis3.setUpperMargin(1.0d);
        categoryAxis3.setCategoryMargin((double) 192);
        boolean boolean9 = keyedObjects0.equals((java.lang.Object) 192);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.axis.AxisState axisState61 = new org.jfree.chart.axis.AxisState();
        java.util.List list62 = axisState61.getTicks();
        axisState61.cursorRight((double) 'a');
        org.jfree.chart.axis.AxisState axisState65 = new org.jfree.chart.axis.AxisState();
        java.util.List list66 = axisState65.getTicks();
        axisState61.setTicks(list66);
        jFreeChart58.setSubtitles(list66);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(list66);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = statisticalBarRenderer0.getItemLabelGenerator(100, (int) (byte) 100);
        java.awt.Stroke stroke24 = statisticalBarRenderer0.getSeriesStroke(2);
        java.awt.Paint paint25 = statisticalBarRenderer0.getBasePaint();
        java.awt.Paint paint27 = statisticalBarRenderer0.getSeriesItemLabelPaint((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(2, layer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle14.getVerticalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        textTitle14.setVerticalAlignment(verticalAlignment16);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle18.getVerticalAlignment();
        textTitle14.setVerticalAlignment(verticalAlignment19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color22 = color21.darker();
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color21, jFreeChart23, (int) (short) 10, 0);
        chartProgressEvent26.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis31.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot39.getDomainMarkers((int) (short) 1, layer41);
        categoryPlot39.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot39.setDomainAxisLocation(0, axisLocation46);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot39.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot39.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean53 = statisticalBarRenderer51.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer51.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer51.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray64 = new double[] {};
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[][] doubleArray69 = new double[][] { doubleArray63, doubleArray64, doubleArray65, doubleArray66, doubleArray67, doubleArray68 };
        org.jfree.data.category.CategoryDataset categoryDataset70 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray69);
        org.jfree.data.Range range71 = statisticalBarRenderer51.findRangeBounds(categoryDataset70);
        categoryPlot39.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer51);
        categoryPlot39.setRangeCrosshairLockedOnData(false);
        categoryPlot39.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier78 = categoryPlot39.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart79 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot39);
        java.lang.Object obj80 = jFreeChart79.getTextAntiAlias();
        chartProgressEvent26.setChart(jFreeChart79);
        org.jfree.chart.title.TextTitle textTitle82 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment83 = textTitle82.getVerticalAlignment();
        java.awt.Paint paint84 = textTitle82.getBackgroundPaint();
        jFreeChart79.addSubtitle((org.jfree.chart.title.Title) textTitle82);
        textTitle14.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart79);
        plotChangeEvent13.setChart(jFreeChart79);
        org.jfree.chart.event.ChartChangeListener chartChangeListener88 = null;
        try {
            jFreeChart79.addChangeListener(chartChangeListener88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(legendItemCollection48);
        org.junit.Assert.assertNull(categoryItemRenderer50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(categoryDataset70);
        org.junit.Assert.assertNull(range71);
        org.junit.Assert.assertNotNull(drawingSupplier78);
        org.junit.Assert.assertNull(obj80);
        org.junit.Assert.assertNotNull(verticalAlignment83);
        org.junit.Assert.assertNull(paint84);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.lang.Object obj9 = defaultDrawingSupplier8.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setNotify(false);
        org.jfree.chart.block.BlockFrame blockFrame3 = textTitle0.getFrame();
        org.junit.Assert.assertNotNull(blockFrame3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Object obj0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color1, jFreeChart3, (int) (short) 10, 0);
        chartProgressEvent6.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getDomainMarkers((int) (short) 1, layer21);
        categoryPlot19.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(0, axisLocation26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot19.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean33 = statisticalBarRenderer31.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer31.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer31.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[][] doubleArray49 = new double[][] { doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray49);
        org.jfree.data.Range range51 = statisticalBarRenderer31.findRangeBounds(categoryDataset50);
        categoryPlot19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        categoryPlot19.setRangeCrosshairLockedOnData(false);
        categoryPlot19.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = categoryPlot19.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart59 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot19);
        java.lang.Object obj60 = jFreeChart59.getTextAntiAlias();
        chartProgressEvent6.setChart(jFreeChart59);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(drawingSupplier58);
        org.junit.Assert.assertNull(obj60);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        numberAxis1.setTickMarksVisible(true);
        numberAxis1.setInverted(true);
        boolean boolean9 = numberAxis1.isInverted();
        numberAxis1.setLowerBound((double) 1);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        float float53 = jFreeChart50.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType55 = rectangleInsets54.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets(unitType55, 0.0d, (double) 255, (double) (-165), 0.0d);
        jFreeChart50.setPadding(rectangleInsets60);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.5f + "'", float53 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(unitType55);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.lang.String str17 = legendItem14.getDescription();
        java.lang.String str18 = legendItem14.getToolTipText();
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[] doubleArray23 = new double[] {};
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[][] doubleArray27 = new double[][] { doubleArray21, doubleArray22, doubleArray23, doubleArray24, doubleArray25, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray27);
        legendItem14.setDataset((org.jfree.data.general.Dataset) categoryDataset28);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[size=0]" + "'", str18.equals("[size=0]"));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        boolean boolean20 = statisticalBarRenderer0.getBaseSeriesVisible();
        int int21 = statisticalBarRenderer0.getColumnCount();
        java.awt.Color color22 = java.awt.Color.red;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color22, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot9.setRangeAxisLocation(axisLocation11);
        boolean boolean13 = categoryPlot9.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis3.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean14 = statisticalBarRenderer12.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalBarRenderer12.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke18 = statisticalBarRenderer12.getErrorIndicatorStroke();
        categoryPlot11.setDomainGridlineStroke(stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint1, stroke18);
        valueMarker20.setValue((double) 2.0f);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("", font25);
        java.awt.Paint paint27 = textFragment26.getPaint();
        textLine23.removeFragment(textFragment26);
        java.awt.Font font29 = textFragment26.getFont();
        valueMarker20.setLabelFont(font29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        java.awt.Shape shape17 = legendItem14.getLine();
        java.awt.Paint paint18 = legendItem14.getLinePaint();
        java.awt.Paint paint19 = legendItem14.getOutlinePaint();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = rendererState2.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_RIGHT");
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        statisticalBarRenderer0.setPlot(categoryPlot10);
        categoryPlot10.setNoDataMessage("");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextPaint();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        categoryPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge();
        categoryPlot13.clearAnnotations();
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) 1);
        blockParams0.setTranslateX((double) 500);
        blockParams0.setTranslateY((double) 10.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        statisticalBarRenderer0.setPlot(categoryPlot10);
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer27.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke33 = statisticalBarRenderer27.getErrorIndicatorStroke();
        categoryPlot26.setDomainGridlineStroke(stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint16, stroke33);
        statisticalBarRenderer0.setSeriesPaint(100, paint16, false);
        java.awt.Color color39 = java.awt.Color.GRAY;
        statisticalBarRenderer0.setSeriesPaint(192, (java.awt.Paint) color39);
        java.lang.Boolean boolean42 = statisticalBarRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean44 = statisticalBarRenderer0.equals((java.lang.Object) lengthAdjustmentType43);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(lengthAdjustmentType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis8.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setRangeGridlinesVisible(false);
        statisticalBarRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color21);
        boolean boolean23 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Paint paint24 = statisticalBarRenderer0.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        boolean boolean3 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) 'a');
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) '#');
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint2 = valueMarker1.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = textTitle3.getVerticalAlignment();
        java.awt.Paint paint5 = textTitle3.getBackgroundPaint();
        java.awt.Paint paint6 = textTitle3.getPaint();
        valueMarker1.setOutlinePaint(paint6);
        java.awt.Font font8 = valueMarker1.getLabelFont();
        float float9 = valueMarker1.getAlpha();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset15 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14, dataset15, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint20 = valueMarker19.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle21.getVerticalAlignment();
        java.awt.Paint paint23 = textTitle21.getBackgroundPaint();
        java.awt.Paint paint24 = textTitle21.getPaint();
        valueMarker19.setOutlinePaint(paint24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker19.getLabelOffset();
        double double28 = rectangleInsets26.calculateBottomOutset((double) (-1));
        legendItemBlockContainer17.setPadding(rectangleInsets26);
        java.awt.Paint paint31 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis33.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean44 = statisticalBarRenderer42.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer42.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke48 = statisticalBarRenderer42.getErrorIndicatorStroke();
        categoryPlot41.setDomainGridlineStroke(stroke48);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint31, stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = valueMarker50.getLabelOffset();
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        size2D52.height = (byte) 0;
        double double55 = size2D52.getHeight();
        double double56 = size2D52.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D60 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, 0.0d, (double) 0L, rectangleAnchor59);
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets51.createOutsetRectangle(rectangle2D60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str64 = lengthAdjustmentType63.toString();
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets26.createAdjustedRectangle(rectangle2D61, lengthAdjustmentType62, lengthAdjustmentType63);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "NO_CHANGE" + "'", str64.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D65);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[0.0,1.0]", graphics2D1, (float) '4', (float) 3, 0.0d, (float) 100L, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(2, layer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        categoryPlot9.mapDatasetToRangeAxis(0, (int) (byte) 100);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke6 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7, false);
        boolean boolean11 = statisticalBarRenderer0.isSeriesItemLabelsVisible(1);
        org.jfree.chart.LegendItem legendItem14 = statisticalBarRenderer0.getLegendItem(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint16 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint17 = categoryAxis15.getLabelPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint17);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis23.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot31.getDomainMarkers((int) (short) 1, layer33);
        categoryPlot31.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis37.setTickMarksVisible(true);
        java.awt.Font font43 = categoryAxis37.getLabelFont();
        int int44 = categoryPlot31.getDomainAxisIndex(categoryAxis37);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        try {
            statisticalBarRenderer0.drawOutline(graphics2D21, categoryPlot31, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, (int) (short) 10, 0);
        chartProgressEvent5.setPercent(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getDomainMarkers((int) (short) 1, layer20);
        categoryPlot18.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(0, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot18.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer30.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[][] doubleArray48 = new double[][] { doubleArray42, doubleArray43, doubleArray44, doubleArray45, doubleArray46, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray48);
        org.jfree.data.Range range50 = statisticalBarRenderer30.findRangeBounds(categoryDataset49);
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        categoryPlot18.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = categoryPlot18.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot18);
        java.lang.Object obj59 = jFreeChart58.getTextAntiAlias();
        chartProgressEvent5.setChart(jFreeChart58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = textTitle61.getVerticalAlignment();
        java.awt.Paint paint63 = textTitle61.getBackgroundPaint();
        jFreeChart58.addSubtitle((org.jfree.chart.title.Title) textTitle61);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = textTitle66.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = textTitle66.getPosition();
        try {
            jFreeChart58.addSubtitle(192, (org.jfree.chart.title.Title) textTitle66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(drawingSupplier57);
        org.junit.Assert.assertNull(obj59);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "", "hi!", "hi!");
        projectInfo7.addOptionalLibrary("");
        java.util.List list10 = projectInfo7.getContributors();
        java.awt.Image image14 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo18 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image14, "", "hi!", "hi!");
        projectInfo18.addOptionalLibrary("");
        java.awt.Image image24 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo28 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image24, "", "hi!", "hi!");
        projectInfo18.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo28);
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo18);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis33.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot41.getDomainMarkers((int) (short) 1, layer43);
        categoryPlot41.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot41.setDomainAxisLocation(0, axisLocation48);
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot41.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot41.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean55 = statisticalBarRenderer53.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer53.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer53.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray65 = new double[] {};
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray68 = new double[] {};
        double[] doubleArray69 = new double[] {};
        double[] doubleArray70 = new double[] {};
        double[][] doubleArray71 = new double[][] { doubleArray65, doubleArray66, doubleArray67, doubleArray68, doubleArray69, doubleArray70 };
        org.jfree.data.category.CategoryDataset categoryDataset72 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray71);
        org.jfree.data.Range range73 = statisticalBarRenderer53.findRangeBounds(categoryDataset72);
        categoryPlot41.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer53);
        categoryPlot41.setRangeCrosshairLockedOnData(false);
        categoryPlot41.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier80 = categoryPlot41.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart81 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot41);
        java.lang.Object obj82 = jFreeChart81.getTextAntiAlias();
        java.awt.Image image83 = null;
        jFreeChart81.setBackgroundImage(image83);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo87 = null;
        java.awt.image.BufferedImage bufferedImage88 = jFreeChart81.createBufferedImage((int) (byte) 100, 15, chartRenderingInfo87);
        projectInfo18.setLogo((java.awt.Image) bufferedImage88);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(legendItemCollection50);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(categoryDataset72);
        org.junit.Assert.assertNull(range73);
        org.junit.Assert.assertNotNull(drawingSupplier80);
        org.junit.Assert.assertNull(obj82);
        org.junit.Assert.assertNotNull(bufferedImage88);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setFixedAutoRange(10.0d);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer1.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer1.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[] doubleArray17 = new double[] {};
        double[] doubleArray18 = new double[] {};
        double[][] doubleArray19 = new double[][] { doubleArray13, doubleArray14, doubleArray15, doubleArray16, doubleArray17, doubleArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray19);
        org.jfree.data.Range range21 = statisticalBarRenderer1.findRangeBounds(categoryDataset20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset20);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset20, 0);
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 2.0d, (org.jfree.data.KeyedValues) pieDataset24);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset24);
        org.jfree.data.general.PieDataset pieDataset29 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset24, (java.lang.Comparable) (-1L), (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(pieDataset29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color16 = color15.darker();
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color15, jFreeChart17, (int) (short) 10, 0);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        double double23 = textTitle22.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle22.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        titleChangeEvent25.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = titleChangeEvent25.getType();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        double double30 = textTitle29.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame31 = textTitle29.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent32 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle29);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        titleChangeEvent32.setType(chartChangeEventType33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = titleChangeEvent32.getType();
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        double double37 = textTitle36.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame38 = textTitle36.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent39 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle36);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis42.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis42.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis48, categoryItemRenderer49);
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = categoryPlot50.getDomainMarkers((int) (short) 1, layer52);
        categoryPlot50.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot50.setDomainAxisLocation(0, axisLocation57);
        org.jfree.chart.LegendItemCollection legendItemCollection59 = categoryPlot50.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = categoryPlot50.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean64 = statisticalBarRenderer62.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer62.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer62.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray74 = new double[] {};
        double[] doubleArray75 = new double[] {};
        double[] doubleArray76 = new double[] {};
        double[] doubleArray77 = new double[] {};
        double[] doubleArray78 = new double[] {};
        double[] doubleArray79 = new double[] {};
        double[][] doubleArray80 = new double[][] { doubleArray74, doubleArray75, doubleArray76, doubleArray77, doubleArray78, doubleArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray80);
        org.jfree.data.Range range82 = statisticalBarRenderer62.findRangeBounds(categoryDataset81);
        categoryPlot50.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer62);
        categoryPlot50.setRangeCrosshairLockedOnData(false);
        categoryPlot50.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier89 = categoryPlot50.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart90 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot50);
        java.lang.Object obj91 = jFreeChart90.getTextAntiAlias();
        titleChangeEvent39.setChart(jFreeChart90);
        titleChangeEvent32.setChart(jFreeChart90);
        titleChangeEvent25.setChart(jFreeChart90);
        boolean boolean95 = legendGraphic21.equals((java.lang.Object) titleChangeEvent25);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNull(chartChangeEventType28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame31);
        org.junit.Assert.assertNull(chartChangeEventType35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame38);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNull(legendItemCollection59);
        org.junit.Assert.assertNull(categoryItemRenderer61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
        org.junit.Assert.assertNull(range82);
        org.junit.Assert.assertNotNull(drawingSupplier89);
        org.junit.Assert.assertNull(obj91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        double double18 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = statisticalBarRenderer0.getPlot();
        java.awt.Stroke stroke21 = statisticalBarRenderer0.getSeriesStroke((int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis23.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot31.getDomainMarkers((int) (short) 1, layer33);
        categoryPlot31.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot31.setDomainAxisLocation(0, axisLocation38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot31.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot31.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean45 = statisticalBarRenderer43.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer43.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer43.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray55, doubleArray56, doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray61);
        org.jfree.data.Range range63 = statisticalBarRenderer43.findRangeBounds(categoryDataset62);
        categoryPlot31.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer43);
        categoryPlot31.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke67 = categoryPlot31.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation68 = categoryPlot31.getOrientation();
        java.lang.Number[] numberArray73 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray79 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray82 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray85 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray88 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray89 = new java.lang.Number[][] { numberArray73, numberArray76, numberArray79, numberArray82, numberArray85, numberArray88 };
        org.jfree.data.category.CategoryDataset categoryDataset90 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray89);
        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset90, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer93 = categoryPlot31.getRendererForDataset(categoryDataset90);
        org.jfree.data.Range range94 = statisticalBarRenderer0.findRangeBounds(categoryDataset90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(plotOrientation68);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(numberArray85);
        org.junit.Assert.assertNotNull(numberArray88);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(categoryDataset90);
        org.junit.Assert.assertNotNull(range92);
        org.junit.Assert.assertNull(categoryItemRenderer93);
        org.junit.Assert.assertNotNull(range94);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Image image52 = null;
        jFreeChart50.setBackgroundImage(image52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        java.awt.image.BufferedImage bufferedImage57 = jFreeChart50.createBufferedImage((int) (byte) 100, 15, chartRenderingInfo56);
        java.lang.Object obj58 = jFreeChart50.clone();
        java.awt.Color color59 = java.awt.Color.BLACK;
        jFreeChart50.setBorderPaint((java.awt.Paint) color59);
        int int61 = jFreeChart50.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(bufferedImage57);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 15 + "'", int61 == 15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 1, "RectangleEdge.RIGHT");
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.configure();
        org.jfree.data.RangeType rangeType16 = numberAxis14.getRangeType();
        java.awt.Paint paint17 = numberAxis14.getTickMarkPaint();
        numberAxis14.setVerticalTickLabels(true);
        boolean boolean20 = numberAxis14.isPositiveArrowVisible();
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) numberAxis14);
        categoryAxis1.setCategoryLabelPositionOffset(3);
        org.junit.Assert.assertNotNull(rangeType16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 2, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle0.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        titleChangeEvent3.setType(chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = titleChangeEvent3.getType();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        double double8 = textTitle7.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame9 = textTitle7.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis13.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot21.getDomainMarkers((int) (short) 1, layer23);
        categoryPlot21.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot21.setDomainAxisLocation(0, axisLocation28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot21.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean35 = statisticalBarRenderer33.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer33.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer33.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[] doubleArray50 = new double[] {};
        double[][] doubleArray51 = new double[][] { doubleArray45, doubleArray46, doubleArray47, doubleArray48, doubleArray49, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray51);
        org.jfree.data.Range range53 = statisticalBarRenderer33.findRangeBounds(categoryDataset52);
        categoryPlot21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer33);
        categoryPlot21.setRangeCrosshairLockedOnData(false);
        categoryPlot21.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier60 = categoryPlot21.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot21);
        java.lang.Object obj62 = jFreeChart61.getTextAntiAlias();
        titleChangeEvent10.setChart(jFreeChart61);
        titleChangeEvent3.setChart(jFreeChart61);
        java.awt.Font font66 = null;
        java.awt.Paint paint67 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer70 = null;
        org.jfree.chart.text.TextBlock textBlock71 = org.jfree.chart.text.TextUtilities.createTextBlock("", font66, paint67, (float) 1, (int) (byte) 10, textMeasurer70);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor75 = null;
        textBlock71.draw(graphics2D72, (float) (short) 1, (float) (byte) 100, textBlockAnchor75);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment77 = textBlock71.getLineAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint79 = categoryAxis78.getTickMarkPaint();
        categoryAxis78.setUpperMargin(1.0d);
        java.lang.Object obj82 = categoryAxis78.clone();
        boolean boolean83 = horizontalAlignment77.equals((java.lang.Object) categoryAxis78);
        java.awt.Stroke stroke84 = categoryAxis78.getTickMarkStroke();
        jFreeChart61.setBorderStroke(stroke84);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame9);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(drawingSupplier60);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertNotNull(textBlock71);
        org.junit.Assert.assertNotNull(horizontalAlignment77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        java.awt.Paint paint2 = categoryAxis0.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean20 = statisticalBarRenderer18.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke24 = statisticalBarRenderer18.getErrorIndicatorStroke();
        categoryPlot17.setDomainGridlineStroke(stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint7, stroke24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker26.getLabelOffset();
        org.jfree.chart.util.Size2D size2D28 = new org.jfree.chart.util.Size2D();
        size2D28.height = (byte) 0;
        double double31 = size2D28.getHeight();
        double double32 = size2D28.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D28, 0.0d, (double) 0L, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets27.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str39 = rectangleEdge38.toString();
        boolean boolean41 = rectangleEdge38.equals((java.lang.Object) 15);
        double double42 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, (int) (short) 0, 0, rectangle2D36, rectangleEdge38);
        boolean boolean43 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.RIGHT" + "'", str39.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean4 = numberAxis1.isTickMarksVisible();
        numberAxis1.setUpperBound((double) 10L);
        numberAxis1.setUpperMargin((double) 2);
        boolean boolean9 = numberAxis1.isNegativeArrowVisible();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis12.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot20.getDomainMarkers((int) (short) 1, layer22);
        categoryPlot20.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setDomainAxisLocation(0, axisLocation27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot20.getRangeMarkers(0, layer31);
        boolean boolean33 = categoryPlot20.isRangeCrosshairLockedOnData();
        int int34 = categoryPlot20.getWeight();
        categoryPlot20.setRangeCrosshairVisible(false);
        java.awt.Paint paint38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis40.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis46, categoryItemRenderer47);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean51 = statisticalBarRenderer49.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = statisticalBarRenderer49.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke55 = statisticalBarRenderer49.getErrorIndicatorStroke();
        categoryPlot48.setDomainGridlineStroke(stroke55);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint38, stroke55);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = valueMarker57.getLabelOffset();
        org.jfree.chart.util.Size2D size2D59 = new org.jfree.chart.util.Size2D();
        size2D59.height = (byte) 0;
        double double62 = size2D59.getHeight();
        double double63 = size2D59.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D67 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D59, 0.0d, (double) 0L, rectangleAnchor66);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets58.createOutsetRectangle(rectangle2D67);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = new org.jfree.chart.axis.AxisSpace();
        double double71 = axisSpace70.getRight();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace72 = numberAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D68, rectangleEdge69, axisSpace70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(legendItemCollection29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers((-2), layer17);
        categoryPlot9.setForegroundAlpha((float) (byte) 0);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str24 = labelBlock23.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis26.configure();
        org.jfree.data.RangeType rangeType28 = numberAxis26.getRangeType();
        java.awt.Font font29 = numberAxis26.getLabelFont();
        labelBlock23.setFont(font29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis32.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = categoryPlot40.getRangeMarkers(2, layer42);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=0,b=255]", font29, (org.jfree.chart.plot.Plot) categoryPlot40, true);
        categoryPlot9.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart45);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(collection43);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint10 = categoryAxis9.getTickMarkPaint();
        java.awt.Paint paint11 = categoryAxis9.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean29 = statisticalBarRenderer27.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke33 = statisticalBarRenderer27.getErrorIndicatorStroke();
        categoryPlot26.setDomainGridlineStroke(stroke33);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint16, stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = valueMarker35.getLabelOffset();
        org.jfree.chart.util.Size2D size2D37 = new org.jfree.chart.util.Size2D();
        size2D37.height = (byte) 0;
        double double40 = size2D37.getHeight();
        double double41 = size2D37.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, 0.0d, (double) 0L, rectangleAnchor44);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets36.createOutsetRectangle(rectangle2D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str48 = rectangleEdge47.toString();
        boolean boolean50 = rectangleEdge47.equals((java.lang.Object) 15);
        double double51 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor12, (int) (short) 0, 0, rectangle2D45, rectangleEdge47);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity54 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0L, (java.awt.Shape) rectangle2D45, "Size2D[width=0.0, height=0.0]", "TextBlockAnchor.TOP_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D45, rectangleEdge55);
        org.jfree.chart.axis.AxisState axisState57 = new org.jfree.chart.axis.AxisState();
        double double58 = axisState57.getMax();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str61 = rectangleEdge60.toString();
        java.lang.String str62 = rectangleEdge60.toString();
        axisState57.moveCursor((double) (-165), rectangleEdge60);
        double double64 = categoryAxis0.getCategoryEnd(255, (int) (byte) 0, rectangle2D45, rectangleEdge60);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "RectangleEdge.RIGHT" + "'", str48.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleEdge.RIGHT" + "'", str61.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "RectangleEdge.RIGHT" + "'", str62.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color3.getRGB();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4145152) + "'", int6 == (-4145152));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getHorizontalAlignment();
        java.lang.String str6 = horizontalAlignment5.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        boolean boolean8 = horizontalAlignment5.equals((java.lang.Object) textBlockAnchor7);
        textTitle0.setHorizontalAlignment(horizontalAlignment5);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.CENTER" + "'", str6.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot9.notifyListeners(plotChangeEvent19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot9.getLegendItems();
        java.util.Iterator iterator22 = legendItemCollection21.iterator();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(iterator22);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color11);
        numberAxis1.setTickLabelInsets(rectangleInsets9);
        org.jfree.chart.plot.Plot plot14 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        double double5 = numberAxis1.getLabelAngle();
        numberAxis1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.5d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        java.awt.Paint paint15 = categoryPlot9.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot9.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getDomainMarkers((int) (short) 1, layer28);
        categoryPlot26.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setDomainAxisLocation(0, axisLocation33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot26.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot26.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer38.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer38.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer38.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray51 = new double[] {};
        double[] doubleArray52 = new double[] {};
        double[] doubleArray53 = new double[] {};
        double[] doubleArray54 = new double[] {};
        double[] doubleArray55 = new double[] {};
        double[][] doubleArray56 = new double[][] { doubleArray50, doubleArray51, doubleArray52, doubleArray53, doubleArray54, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray56);
        org.jfree.data.Range range58 = statisticalBarRenderer38.findRangeBounds(categoryDataset57);
        categoryPlot26.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer38);
        categoryPlot26.setRangeCrosshairLockedOnData(false);
        categoryPlot26.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier65 = categoryPlot26.getDrawingSupplier();
        org.jfree.chart.util.SortOrder sortOrder66 = categoryPlot26.getColumnRenderingOrder();
        boolean boolean67 = datasetRenderingOrder16.equals((java.lang.Object) categoryPlot26);
        java.lang.String str68 = datasetRenderingOrder16.toString();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertNotNull(drawingSupplier65);
        org.junit.Assert.assertNotNull(sortOrder66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str68.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        java.lang.String str2 = textTitle1.getURLText();
        java.awt.Paint paint3 = textTitle1.getPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.configure();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis2.setRange(range4, false, false);
        boolean boolean8 = numberAxis2.isVerticalTickLabels();
        boolean boolean9 = itemLabelAnchor0.equals((java.lang.Object) numberAxis2);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis2.setNumberFormatOverride(numberFormat10);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.lang.String str2 = unitType1.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) 100, (double) 10, (double) (-4194112), 10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle5.getVerticalAlignment();
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, (java.lang.Object) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        double double2 = textTitle1.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        textTitle1.setURLText("ClassContext");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Paint paint1 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Object) paint1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        keyedObject2.setObject((java.lang.Object) color6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5, dataset6, (java.lang.Comparable) 1.0d);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        boolean boolean12 = columnArrangement5.equals((java.lang.Object) font10);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font10);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        java.awt.Stroke[] strokeArray5 = new java.awt.Stroke[] {};
        java.awt.Shape shape6 = null;
        java.awt.Shape[] shapeArray7 = new java.awt.Shape[] { shape6 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray4, strokeArray5, shapeArray7);
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextFillPaint();
        java.lang.Object obj10 = defaultDrawingSupplier8.clone();
        java.awt.Shape shape11 = defaultDrawingSupplier8.getNextShape();
        java.awt.Paint paint12 = defaultDrawingSupplier8.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setTickMarkOutsideLength((float) 0);
        org.jfree.data.RangeType rangeType6 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis8.configure();
        org.jfree.data.RangeType rangeType10 = numberAxis8.getRangeType();
        boolean boolean11 = rangeType6.equals((java.lang.Object) numberAxis8);
        numberAxis1.setRangeType(rangeType6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        boolean boolean16 = numberTickUnit14.equals((java.lang.Object) 1.0d);
        java.lang.String str18 = numberTickUnit14.valueToString(0.2d);
        numberAxis1.setTickUnit(numberTickUnit14, true, true);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(rangeType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0.2" + "'", str18.equals("0.2"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint0.toRangeWidth(range1);
        double double6 = range1.getLength();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        statisticalBarRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) false);
        java.awt.Paint paint21 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "NO_CHANGE", "HorizontalAlignment.CENTER", image3, "Range[0.0,1.0]", "", "RectangleEdge.RIGHT");
        java.lang.String str8 = projectInfo7.toString();
        java.lang.String str9 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Size2D[width=0.0, height=0.0] version NO_CHANGE.\nRange[0.0,1.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:HorizontalAlignment.CENTER\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Size2D[width=0.0, height=0.0]:None\nSize2D[width=0.0, height=0.0] LICENCE TERMS:\nRectangleEdge.RIGHT" + "'", str8.equals("Size2D[width=0.0, height=0.0] version NO_CHANGE.\nRange[0.0,1.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:HorizontalAlignment.CENTER\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Size2D[width=0.0, height=0.0]:None\nSize2D[width=0.0, height=0.0] LICENCE TERMS:\nRectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.RIGHT" + "'", str9.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 3.0d, (java.lang.Comparable) 1.0f);
        defaultStatisticalCategoryDataset0.add((double) 15, (double) (byte) -1, (java.lang.Comparable) 0.0d, (java.lang.Comparable) "ClassContext");
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultStatisticalCategoryDataset0.getGroup();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 15.0d + "'", number11.equals(15.0d));
        org.junit.Assert.assertNotNull(datasetGroup12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean17 = statisticalBarRenderer15.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalBarRenderer15.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke21 = statisticalBarRenderer15.getErrorIndicatorStroke();
        categoryPlot14.setDomainGridlineStroke(stroke21);
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint4, stroke21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker23.getLabelOffset();
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D();
        size2D25.height = (byte) 0;
        double double28 = size2D25.getHeight();
        double double29 = size2D25.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 0.0d, (double) 0L, rectangleAnchor32);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets24.createOutsetRectangle(rectangle2D33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = textTitle35.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = textTitle35.getPosition();
        java.awt.Font font38 = textTitle35.getFont();
        java.lang.Object obj39 = textTitle0.draw(graphics2D2, rectangle2D33, (java.lang.Object) textTitle35);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNull(obj39);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Stroke stroke3 = strokeList0.getStroke((-165));
        strokeList0.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean6 = strokeList0.equals((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 1, (double) (short) -1);
        flowArrangement4.clear();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) flowArrangement4, jFreeChart6, 255, (int) (short) 10);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        double double12 = textTitle11.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame13 = textTitle11.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        titleChangeEvent14.setType(chartChangeEventType15);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = titleChangeEvent14.getType();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        double double19 = textTitle18.getContentXOffset();
        org.jfree.chart.block.BlockFrame blockFrame20 = textTitle18.getFrame();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent21 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle18);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis24.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getDomainMarkers((int) (short) 1, layer34);
        categoryPlot32.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot32.setDomainAxisLocation(0, axisLocation39);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot32.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot32.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean46 = statisticalBarRenderer44.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer44.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer44.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[] doubleArray61 = new double[] {};
        double[][] doubleArray62 = new double[][] { doubleArray56, doubleArray57, doubleArray58, doubleArray59, doubleArray60, doubleArray61 };
        org.jfree.data.category.CategoryDataset categoryDataset63 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray62);
        org.jfree.data.Range range64 = statisticalBarRenderer44.findRangeBounds(categoryDataset63);
        categoryPlot32.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer44);
        categoryPlot32.setRangeCrosshairLockedOnData(false);
        categoryPlot32.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier71 = categoryPlot32.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart72 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot32);
        java.lang.Object obj73 = jFreeChart72.getTextAntiAlias();
        titleChangeEvent21.setChart(jFreeChart72);
        titleChangeEvent14.setChart(jFreeChart72);
        boolean boolean76 = flowArrangement4.equals((java.lang.Object) titleChangeEvent14);
        flowArrangement4.clear();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame20);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNull(legendItemCollection41);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(categoryDataset63);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(drawingSupplier71);
        org.junit.Assert.assertNull(obj73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray51, numberArray54, numberArray57, numberArray60, numberArray63, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray67);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset68, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot9.getRendererForDataset(categoryDataset68);
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset68);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 1.0d + "'", number72.equals(1.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset5, (java.lang.Comparable) 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendItemBlockContainer7.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, 0.0d, 1.0d);
        java.awt.Font font15 = null;
        java.awt.Paint paint16 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (float) 1, (int) (byte) 10, textMeasurer19);
        boolean boolean21 = columnArrangement13.equals((java.lang.Object) (byte) 10);
        legendItemBlockContainer7.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement13);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        textLine23.draw(graphics2D24, 2.0f, (float) 15, textAnchor27, (float) (short) 0, (float) '4', (double) 192);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine();
        java.awt.Font font34 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("", font34);
        java.awt.Paint paint36 = textFragment35.getPaint();
        textLine32.removeFragment(textFragment35);
        java.lang.String str38 = textFragment35.getText();
        textLine23.removeFragment(textFragment35);
        boolean boolean40 = columnArrangement13.equals((java.lang.Object) textLine23);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        boolean boolean12 = categoryPlot9.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (-165), (-1.0E-8d), (double) (short) 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint20 = categoryAxis19.getTickMarkPaint();
        java.awt.Paint paint21 = categoryAxis19.getLabelPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis28.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = statisticalBarRenderer37.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke43 = statisticalBarRenderer37.getErrorIndicatorStroke();
        categoryPlot36.setDomainGridlineStroke(stroke43);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint26, stroke43);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = valueMarker45.getLabelOffset();
        org.jfree.chart.util.Size2D size2D47 = new org.jfree.chart.util.Size2D();
        size2D47.height = (byte) 0;
        double double50 = size2D47.getHeight();
        double double51 = size2D47.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D55 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, 0.0d, (double) 0L, rectangleAnchor54);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets46.createOutsetRectangle(rectangle2D55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str58 = rectangleEdge57.toString();
        boolean boolean60 = rectangleEdge57.equals((java.lang.Object) 15);
        double double61 = categoryAxis19.getCategoryJava2DCoordinate(categoryAnchor22, (int) (short) 0, 0, rectangle2D55, rectangleEdge57);
        java.awt.Font font62 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement67 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment63, verticalAlignment64, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset68 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer70 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement67, dataset68, (java.lang.Comparable) 1.0d);
        java.awt.Font font72 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment73 = new org.jfree.chart.text.TextFragment("", font72);
        boolean boolean74 = columnArrangement67.equals((java.lang.Object) font72);
        categoryAxis19.setLabelFont(font72);
        int int76 = categoryPlot9.getDomainAxisIndex(categoryAxis19);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "RectangleEdge.RIGHT" + "'", str58.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        java.awt.Paint paint12 = textFragment11.getPaint();
        boolean boolean13 = statisticalBarRenderer0.equals((java.lang.Object) textFragment11);
        java.awt.Paint paint14 = null;
        try {
            statisticalBarRenderer0.setBaseItemLabelPaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color14 = java.awt.Color.getColor("", (int) '4');
        categoryPlot9.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot9.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        categoryPlot9.setBackgroundAlpha((float) (short) 100);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(legendItemCollection18);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine();
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font14);
        java.awt.Paint paint16 = textFragment15.getPaint();
        textLine12.removeFragment(textFragment15);
        org.jfree.chart.text.TextFragment textFragment18 = textLine12.getFirstTextFragment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        textLine12.draw(graphics2D19, 0.0f, (float) ' ', textAnchor22, (float) (-65281), (float) (-1), 100.0d);
        textBlock6.addLine(textLine12);
        java.awt.Font font29 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("", font29);
        textLine12.removeFragment(textFragment30);
        org.jfree.chart.text.TextFragment textFragment32 = textLine12.getLastTextFragment();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.Size2D size2D34 = textLine12.calculateDimensions(graphics2D33);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(textFragment18);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(textFragment32);
        org.junit.Assert.assertNotNull(size2D34);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getDomainMarkers((int) (short) 1, layer11);
        categoryPlot9.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(0, axisLocation16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean23 = statisticalBarRenderer21.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer21.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer21.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[][] doubleArray39 = new double[][] { doubleArray33, doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray39);
        org.jfree.data.Range range41 = statisticalBarRenderer21.findRangeBounds(categoryDataset40);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke45 = categoryPlot9.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = categoryPlot9.getOrientation();
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { 1, (-4194112) };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray51, numberArray54, numberArray57, numberArray60, numberArray63, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "HorizontalAlignment.CENTER", numberArray67);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset68, (double) (byte) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot9.getRendererForDataset(categoryDataset68);
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset68);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset68);
        double double74 = range73.getLength();
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNull(categoryItemRenderer71);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 6.0d + "'", number72.equals(6.0d));
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 4194113.0d + "'", double74 == 4194113.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = textTitle0.getVerticalAlignment();
        java.awt.Paint paint2 = textTitle0.getBackgroundPaint();
        java.lang.Object obj3 = textTitle0.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        legendItem14.setSeriesIndex((int) 'a');
        legendItem14.setDatasetIndex((-165));
        boolean boolean19 = legendItem14.isLineVisible();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) 1, (int) (byte) 10, textMeasurer5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = null;
        textBlock6.draw(graphics2D7, (float) (short) 1, (float) (byte) 100, textBlockAnchor10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine();
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font14);
        java.awt.Paint paint16 = textFragment15.getPaint();
        textLine12.removeFragment(textFragment15);
        org.jfree.chart.text.TextFragment textFragment18 = textLine12.getFirstTextFragment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        textLine12.draw(graphics2D19, 0.0f, (float) ' ', textAnchor22, (float) (-65281), (float) (-1), 100.0d);
        textBlock6.addLine(textLine12);
        java.awt.Font font29 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("", font29);
        textLine12.removeFragment(textFragment30);
        java.awt.Graphics2D graphics2D32 = null;
        try {
            org.jfree.chart.util.Size2D size2D33 = textFragment30.calculateDimensions(graphics2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(textFragment18);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint1 = categoryAxis0.getTickMarkPaint();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        java.awt.Paint paint8 = textFragment7.getPaint();
        textLine4.removeFragment(textFragment7);
        java.awt.Font font10 = textFragment7.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis12.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot20.getDomainMarkers((int) (short) 1, layer22);
        categoryPlot20.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setDomainAxisLocation(0, axisLocation27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot20.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean34 = statisticalBarRenderer32.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer32.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer32.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray45 = new double[] {};
        double[] doubleArray46 = new double[] {};
        double[] doubleArray47 = new double[] {};
        double[] doubleArray48 = new double[] {};
        double[] doubleArray49 = new double[] {};
        double[][] doubleArray50 = new double[][] { doubleArray44, doubleArray45, doubleArray46, doubleArray47, doubleArray48, doubleArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray50);
        org.jfree.data.Range range52 = statisticalBarRenderer32.findRangeBounds(categoryDataset51);
        categoryPlot20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer32);
        categoryPlot20.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke56 = categoryPlot20.getRangeGridlineStroke();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart("RectangleEdge.RIGHT", font10, (org.jfree.chart.plot.Plot) categoryPlot20, true);
        categoryAxis0.setTickLabelFont(font10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNull(legendItemCollection29);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.05d);
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        categoryAxis0.setLabelInsets(rectangleInsets5);
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        java.lang.Object obj2 = datasetGroup0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str10 = labelBlock9.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis12.configure();
        org.jfree.data.RangeType rangeType14 = numberAxis12.getRangeType();
        java.awt.Font font15 = numberAxis12.getLabelFont();
        labelBlock9.setFont(font15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers(2, layer28);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=0,b=255]", font15, (org.jfree.chart.plot.Plot) categoryPlot26, true);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D6, categoryPlot26, rectangle2D32, (double) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rangeType14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.String str3 = labelBlock2.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis5.configure();
        org.jfree.data.RangeType rangeType7 = numberAxis5.getRangeType();
        java.awt.Font font8 = numberAxis5.getLabelFont();
        labelBlock2.setFont(font8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleEdge11, (java.lang.Object) paint12);
        java.awt.Color color14 = java.awt.Color.magenta;
        java.lang.String str15 = color14.toString();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setID("");
        org.jfree.chart.util.Size2D size2D19 = new org.jfree.chart.util.Size2D();
        size2D19.height = (byte) 0;
        double double22 = size2D19.getHeight();
        double double23 = size2D19.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D19, 0.0d, (double) 0L, rectangleAnchor26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor28);
        textTitle16.setBounds(rectangle2D27);
        boolean boolean31 = color14.equals((java.lang.Object) textTitle16);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        textTitle32.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle32.getHorizontalAlignment();
        java.lang.String str36 = horizontalAlignment35.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        boolean boolean38 = horizontalAlignment35.equals((java.lang.Object) textBlockAnchor37);
        textTitle16.setHorizontalAlignment(horizontalAlignment35);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis42.configure();
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis42.setRange(range44, false, false);
        boolean boolean48 = numberAxis42.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1.0E-8d, (java.lang.Object) rectangleInsets50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder53 = new org.jfree.chart.block.BlockBorder(rectangleInsets50, (java.awt.Paint) color52);
        numberAxis42.setTickLabelInsets(rectangleInsets50);
        double double55 = rectangleInsets50.getTop();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=0,b=255]", font8, paint10, rectangleEdge11, horizontalAlignment35, verticalAlignment40, rectangleInsets50);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=0,b=255]" + "'", str15.equals("java.awt.Color[r=255,g=0,b=255]"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "HorizontalAlignment.CENTER" + "'", str36.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.data.Range range4 = numberAxis1.getRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.expand(range4, (double) (short) 0, (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) categoryLabelPositions3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str8 = rectangleEdge7.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions6.getLabelPosition(rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions3, categoryLabelPosition9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = categoryLabelPosition9.getCategoryAnchor();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor11, (double) 10, (double) (byte) 100);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.RIGHT" + "'", str8.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        boolean boolean16 = standardCategorySeriesLabelGenerator14.equals((java.lang.Object) 0.0f);
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        double double18 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint22 = statisticalBarRenderer0.getItemPaint(0, 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape12 = textBlock4.calculateBounds(graphics2D5, (float) 15, 0.0f, textBlockAnchor8, (float) '4', (float) (byte) 10, (double) (byte) -1);
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!", "", "[size=0]", "Size2D[width=0.0, height=0.0]", shape12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = legendItem14.getOutlinePaint();
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = statisticalBarRenderer0.hasListener(eventListener6);
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        java.awt.Paint paint10 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.5d, (double) (short) 100, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis5.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot13.getDomainMarkers((int) (short) 1, layer15);
        categoryPlot13.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(0, axisLocation20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getFixedLegendItems();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation26 = axisLocation25.getOpposite();
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("", font28);
        java.awt.Paint paint30 = textFragment29.getPaint();
        boolean boolean31 = axisLocation26.equals((java.lang.Object) paint30);
        categoryPlot13.setRangeAxisLocation(axisLocation26, false);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis35.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis35.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis41, categoryItemRenderer42);
        boolean boolean44 = categoryPlot43.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot43.setRangeAxisLocation(axisLocation45);
        categoryPlot13.setRangeAxisLocation(axisLocation45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation49 = axisLocation48.getOpposite();
        java.awt.Font font51 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment52 = new org.jfree.chart.text.TextFragment("", font51);
        java.awt.Paint paint53 = textFragment52.getPaint();
        boolean boolean54 = axisLocation49.equals((java.lang.Object) paint53);
        categoryPlot13.setRangeAxisLocation(axisLocation49, true);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle0.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, 0.0d, 1.0d);
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10, dataset11, (java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 0L);
        java.awt.Paint paint16 = valueMarker15.getOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle17.getVerticalAlignment();
        java.awt.Paint paint19 = textTitle17.getBackgroundPaint();
        java.awt.Paint paint20 = textTitle17.getPaint();
        valueMarker15.setOutlinePaint(paint20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker15.getLabelOffset();
        double double24 = rectangleInsets22.calculateBottomOutset((double) (-1));
        legendItemBlockContainer13.setPadding(rectangleInsets22);
        java.awt.Paint paint27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis29.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer38.equals((java.lang.Object) 100.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = statisticalBarRenderer38.getPositiveItemLabelPosition((int) (short) 1, 0);
        java.awt.Stroke stroke44 = statisticalBarRenderer38.getErrorIndicatorStroke();
        categoryPlot37.setDomainGridlineStroke(stroke44);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 100L, paint27, stroke44);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = valueMarker46.getLabelOffset();
        org.jfree.chart.util.Size2D size2D48 = new org.jfree.chart.util.Size2D();
        size2D48.height = (byte) 0;
        double double51 = size2D48.getHeight();
        double double52 = size2D48.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D48, 0.0d, (double) 0L, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets47.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str60 = lengthAdjustmentType59.toString();
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets22.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType58, lengthAdjustmentType59);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        java.lang.String str64 = rectangleEdge62.toString();
        java.lang.Object obj65 = textTitle0.draw(graphics2D5, rectangle2D57, (java.lang.Object) str64);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(lengthAdjustmentType58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "NO_CHANGE" + "'", str60.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "RectangleEdge.TOP" + "'", str64.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNull(obj65);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        numberAxis1.resizeRange((double) 100);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis11.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getDomainMarkers((int) (short) 1, layer21);
        categoryPlot19.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(0, axisLocation26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot19.getFixedLegendItems();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot19.getRangeMarkers(0, layer30);
        boolean boolean32 = categoryPlot19.isRangeCrosshairLockedOnData();
        statisticalBarRenderer8.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot19);
        boolean boolean34 = numberAxis1.equals((java.lang.Object) statisticalBarRenderer8);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[] doubleArray44 = new double[] {};
        double[][] doubleArray45 = new double[][] { doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleEdge.RIGHT", "hi!", doubleArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset47);
        org.jfree.data.Range range49 = statisticalBarRenderer8.findRangeBounds(categoryDataset47);
        java.awt.Stroke stroke51 = statisticalBarRenderer8.getSeriesStroke((-1));
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(stroke51);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d);
        numberAxis1.setTickUnit(numberTickUnit8);
        java.awt.Shape shape10 = numberAxis1.getRightArrow();
        java.awt.Stroke stroke11 = numberAxis1.getTickMarkStroke();
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi! version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean9 = range6.intersects((double) 100, (double) 100.0f);
        double double10 = range6.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range6);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D13 = textTitle1.arrange(graphics2D4, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        textLine1.removeFragment(textFragment4);
        java.awt.Font font7 = textFragment4.getFont();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("NO_CHANGE", font7);
        float float9 = textFragment8.getBaselineOffset();
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textFragment8.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot4 = numberAxis1.getPlot();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        numberAxis1.setLabelAngle(0.0d);
        java.awt.Font font10 = null;
        java.awt.Paint paint11 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint11, (float) 1, (int) (byte) 10, textMeasurer14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = null;
        textBlock15.draw(graphics2D16, (float) (short) 1, (float) (byte) 100, textBlockAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textBlock15.getLineAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint23 = categoryAxis22.getTickMarkPaint();
        categoryAxis22.setUpperMargin(1.0d);
        java.lang.Object obj26 = categoryAxis22.clone();
        boolean boolean27 = horizontalAlignment21.equals((java.lang.Object) categoryAxis22);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        numberAxis1.setTickMarkStroke(stroke28);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setNegativeArrowVisible(true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = statisticalBarRenderer4.getGradientPaintTransformer();
        boolean boolean7 = statisticalBarRenderer4.isSeriesItemLabelsVisible((int) 'a');
        keyedObjects0.setObject((java.lang.Comparable) (-1L), (java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 500, "");
        categoryAxis2.setTickMarksVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getDomainMarkers((int) (short) 1, layer12);
        categoryPlot10.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(0, axisLocation17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRenderer((-2));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer22.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "ThreadContext", doubleArray40);
        org.jfree.data.Range range42 = statisticalBarRenderer22.findRangeBounds(categoryDataset41);
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        categoryPlot10.setAnchorValue((double) (short) 10, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = categoryPlot10.getDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("Size2D[width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) categoryPlot10);
        java.lang.Object obj51 = jFreeChart50.getTextAntiAlias();
        java.awt.Paint paint52 = jFreeChart50.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle53 = jFreeChart50.getTitle();
        org.jfree.chart.event.ChartProgressListener chartProgressListener54 = null;
        jFreeChart50.removeProgressListener(chartProgressListener54);
        org.jfree.chart.event.ChartChangeListener chartChangeListener56 = null;
        try {
            jFreeChart50.addChangeListener(chartChangeListener56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(textTitle53);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        numberAxis1.setTickLabelsVisible(false);
        boolean boolean6 = numberAxis1.isVisible();
        boolean boolean7 = numberAxis1.getAutoRangeIncludesZero();
        double double8 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-8d + "'", double8 == 1.0E-8d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects((double) 100, (double) 100.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint0.toRangeWidth(range1);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint5.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.configure();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range3, false, false);
        boolean boolean7 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setRangeAboutValue(0.0d, (double) 255);
        numberAxis1.setAutoRangeMinimumSize((double) 1.0f, false);
        numberAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.equals((java.lang.Object) 100.0d);
        statisticalBarRenderer0.setSeriesVisible((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setSeriesCreateEntities(100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.lang.Boolean boolean17 = statisticalBarRenderer0.getSeriesItemLabelsVisible(100);
        boolean boolean18 = statisticalBarRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }
}

