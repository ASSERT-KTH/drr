import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        long long5 = day3.getLastMillisecond();
        int int6 = day3.getDayOfMonth();
        long long7 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries9.setMaximumItemCount(0);
        java.util.List list12 = timeSeries9.getItems();
        boolean boolean13 = day3.equals((java.lang.Object) list12);
        long long14 = day3.getLastMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day3.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2958102L + "'", long7 == 2958102L);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 253370966399999L + "'", long14 == 253370966399999L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int39 = fixedMillisecond37.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("ClassContext");
        int int42 = fixedMillisecond37.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date43 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        java.util.Date date45 = year44.getStart();
        long long46 = year44.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 28799999L);
        int int49 = year44.getYear();
        java.util.Calendar calendar50 = null;
        try {
            long long51 = year44.getFirstMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-31507200000L) + "'", long46 == (-31507200000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries17.createCopy(8, 2147483647);
        boolean boolean41 = timeSeries17.isEmpty();
        timeSeries17.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        java.lang.Number number9 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-11L) + "'", number9.equals((-11L)));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str9 = day8.toString();
        long long10 = day8.getLastMillisecond();
        int int11 = day8.getDayOfMonth();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        int int17 = month14.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getLastMillisecond(calendar22);
        boolean boolean25 = fixedMillisecond19.equals((java.lang.Object) (byte) 10);
        boolean boolean26 = month14.equals((java.lang.Object) fixedMillisecond19);
        boolean boolean27 = day8.equals((java.lang.Object) boolean26);
        int int28 = fixedMillisecond1.compareTo((java.lang.Object) day8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day8.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2-January-9999" + "'", str9.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 253370966399999L + "'", long10 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62198899200000L) + "'", long15 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        int int18 = year8.compareTo((java.lang.Object) "ClassContext");
        long long19 = year8.getLastMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, year8);
        long long21 = month20.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62102865600001L) + "'", long21 == (-62102865600001L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone19);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass11);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray28 = seriesException27.getSuppressed();
        seriesException24.addSuppressed((java.lang.Throwable) seriesException27);
        java.lang.Throwable[] throwableArray30 = seriesException27.getSuppressed();
        java.lang.Class<?> wildcardClass31 = throwableArray30.getClass();
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass31);
        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass31);
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-October-9999", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(uRL32);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNull(uRL34);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month2.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 2147483647, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        java.lang.Object obj9 = null;
        boolean boolean10 = day7.equals(obj9);
        int int11 = day7.getYear();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate26 = serialDate18.getEndOfCurrentMonth(serialDate23);
        boolean boolean27 = day7.equals((java.lang.Object) serialDate26);
        int int28 = spreadsheetDate3.compare(serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        java.lang.String str35 = serialDate34.toString();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate43 = serialDate34.getEndOfCurrentMonth(serialDate40);
        boolean boolean44 = spreadsheetDate3.isOnOrAfter(serialDate40);
        int int45 = spreadsheetDate3.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9999 + "'", int11 == 9999);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-2958125) + "'", int28 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2-January-9999" + "'", str35.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray11 = seriesException8.getSuppressed();
        java.lang.Class<?> wildcardClass12 = throwableArray11.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        java.util.Date date18 = month15.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass12);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January -1", (java.lang.Class) wildcardClass12);
        java.lang.ClassLoader classLoader24 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int31 = month29.compareTo((java.lang.Object) 2);
        java.util.Date date32 = month29.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        long long34 = year33.getLastMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 1, year33);
        java.lang.Class<?> wildcardClass36 = month35.getClass();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int41 = month39.compareTo((java.lang.Object) 2);
        java.util.Date date42 = month39.getStart();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=9]", (java.lang.Class) wildcardClass36);
        java.lang.Object obj47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass36);
        java.net.URL uRL48 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNotNull(classLoader24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62167363200001L) + "'", long34 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNull(inputStream46);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNull(uRL48);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 9 + "'", obj4.equals(9));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond7.getFirstMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond7.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate7.getPreviousDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        java.lang.Object obj57 = null;
        boolean boolean58 = day55.equals(obj57);
        int int59 = day55.getYear();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate71 = day70.getSerialDate();
        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate74 = serialDate66.getEndOfCurrentMonth(serialDate71);
        boolean boolean75 = day55.equals((java.lang.Object) serialDate74);
        int int76 = spreadsheetDate51.compare(serialDate74);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.lang.String str78 = spreadsheetDate51.toString();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
        org.jfree.data.time.SerialDate serialDate85 = serialDate83.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate90 = day89.getSerialDate();
        org.jfree.data.time.SerialDate serialDate92 = serialDate90.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate93 = serialDate85.getEndOfCurrentMonth(serialDate90);
        java.lang.String str94 = serialDate93.toString();
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate93);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(serialDate93);
        boolean boolean97 = spreadsheetDate51.isOnOrAfter(serialDate93);
        int int98 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int99 = spreadsheetDate51.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9999 + "'", int59 == 9999);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-2958125) + "'", int76 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "5-January-1900" + "'", str78.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "31-January-9999" + "'", str94.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 5 + "'", int99 == 5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        try {
            java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) class9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setNotify(true);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
        boolean boolean27 = fixedMillisecond21.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond21.getMiddleMillisecond(calendar28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int33 = month32.getMonth();
        boolean boolean34 = fixedMillisecond21.equals((java.lang.Object) month32);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = serialDate15.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate25 = serialDate20.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(2, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = serialDate7.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate35 = serialDate25.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(2, serialDate25);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.String str9 = year7.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        long long17 = fixedMillisecond11.getMiddleMillisecond();
        long long18 = fixedMillisecond11.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray17 = seriesException16.getSuppressed();
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray20 = seriesException19.getSuppressed();
        seriesException16.addSuppressed((java.lang.Throwable) seriesException19);
        seriesException11.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable[] throwableArray23 = seriesException11.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.lang.Comparable comparable17 = timeSeries1.getKey();
        java.lang.Object obj18 = timeSeries1.clone();
        long long19 = timeSeries1.getMaximumItemAge();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((-2958125));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1900 + "'", comparable17.equals(1900));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        int int11 = year6.compareTo((java.lang.Object) 7);
        long long12 = year6.getSerialIndex();
        int int13 = year6.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        try {
            java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) month2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        int int8 = month2.getMonth();
        int int9 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        spreadsheetDate1.setDescription("Sunday");
        int int59 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
        org.jfree.data.time.SerialDate serialDate67 = serialDate65.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate72 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate75 = serialDate67.getEndOfCurrentMonth(serialDate72);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addMonths(9, serialDate72);
        serialDate76.setDescription("31-January-9999");
        org.jfree.data.time.SerialDate serialDate80 = serialDate76.getNearestDayOfWeek((int) (byte) 1);
        boolean boolean81 = spreadsheetDate1.isOnOrBefore(serialDate80);
        int int82 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1900 + "'", int82 == 1900);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        int int12 = year8.compareTo((java.lang.Object) class11);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray19 = seriesException18.getSuppressed();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        seriesException18.addSuppressed((java.lang.Throwable) seriesException21);
        java.lang.Throwable[] throwableArray24 = seriesException21.getSuppressed();
        java.lang.Class<?> wildcardClass25 = throwableArray24.getClass();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int30 = month28.compareTo((java.lang.Object) 2);
        java.util.Date date31 = month28.getStart();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone33);
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass25);
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray39 = seriesException38.getSuppressed();
        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray42 = seriesException41.getSuppressed();
        seriesException38.addSuppressed((java.lang.Throwable) seriesException41);
        java.lang.Throwable[] throwableArray44 = seriesException41.getSuppressed();
        java.lang.Class<?> wildcardClass45 = throwableArray44.getClass();
        java.net.URL uRL46 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass45);
        java.lang.Object obj47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass25, (java.lang.Class) wildcardClass45);
        java.lang.ClassLoader classLoader48 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass45);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year8, "", "ThreadContext", (java.lang.Class) wildcardClass45);
        try {
            timeSeries49.delete(2958465, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(uRL46);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(classLoader48);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = serialDate9.getEndOfCurrentMonth(serialDate14);
        java.lang.String str18 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
        serialDate19.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate23 = serialDate19.getPreviousDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate41 = serialDate33.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(9, serialDate38);
        java.lang.String str43 = serialDate38.toString();
        boolean boolean44 = spreadsheetDate25.isBefore(serialDate38);
        boolean boolean46 = spreadsheetDate1.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate25, (-460));
        spreadsheetDate1.setDescription("2019");
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2-January-9999" + "'", str43.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) (-62167363200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Date date19 = year7.getStart();
        try {
            org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        boolean boolean11 = day3.equals((java.lang.Object) regularTimePeriod10);
        long long12 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 253370880000000L + "'", long12 == 253370880000000L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        long long17 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        boolean boolean23 = fixedMillisecond11.equals((java.lang.Object) int22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        int int11 = day6.getDayOfMonth();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        timeSeries1.setRangeDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 4);
//        long long17 = day13.getLastMillisecond();
//        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
//        seriesException20.addSuppressed((java.lang.Throwable) seriesException23);
//        java.lang.Throwable[] throwableArray26 = seriesException23.getSuppressed();
//        java.lang.Class<?> wildcardClass27 = throwableArray26.getClass();
//        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray30 = seriesException29.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray33 = seriesException32.getSuppressed();
//        seriesException29.addSuppressed((java.lang.Throwable) seriesException32);
//        java.lang.Throwable[] throwableArray35 = seriesException32.getSuppressed();
//        java.lang.Class<?> wildcardClass36 = throwableArray35.getClass();
//        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass27, (java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, (java.lang.Class) wildcardClass27);
//        java.util.Collection collection39 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        timeSeries41.setDomainDescription("");
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
//        boolean boolean47 = timeSeries41.equals((java.lang.Object) month46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.next();
//        java.util.Date date49 = month46.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
//        java.lang.String str54 = day53.toString();
//        long long55 = day53.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) month46, (org.jfree.data.time.RegularTimePeriod) day53);
//        timeSeries56.setMaximumItemCount(9);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(obj37);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2-January-9999" + "'", str54.equals("2-January-9999"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 253370966399999L + "'", long55 == 253370966399999L);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        try {
            timeSeries1.delete(1969, (-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate5.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1969, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2-January-9999" + "'", str6.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        java.lang.Object obj5 = null;
        boolean boolean6 = timeSeries1.equals(obj5);
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.clear();
        timeSeries1.setMaximumItemAge((long) (short) 100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year8.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray23 = seriesException22.getSuppressed();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray26 = seriesException25.getSuppressed();
        seriesException22.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.Throwable[] throwableArray28 = seriesException25.getSuppressed();
        java.lang.Class<?> wildcardClass29 = throwableArray28.getClass();
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray32 = seriesException31.getSuppressed();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray35 = seriesException34.getSuppressed();
        seriesException31.addSuppressed((java.lang.Throwable) seriesException34);
        java.lang.Throwable[] throwableArray37 = seriesException34.getSuppressed();
        java.lang.Class<?> wildcardClass38 = throwableArray37.getClass();
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass29, (java.lang.Class) wildcardClass38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass38);
        try {
            timeSeries41.update(8, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(inputStream40);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date30 = fixedMillisecond24.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        java.util.Date date32 = year31.getStart();
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray11 = seriesException8.getSuppressed();
        java.lang.Class<?> wildcardClass12 = throwableArray11.getClass();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        seriesException14.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = seriesException17.getSuppressed();
        java.lang.Class<?> wildcardClass21 = throwableArray20.getClass();
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "2-January-9999", "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int28 = month26.compareTo((java.lang.Object) 2);
        int int29 = month26.getMonth();
        try {
            timeSeries23.update((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 28799999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int19 = month17.compareTo((java.lang.Object) 2);
        java.util.Date date20 = month17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, year21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int27 = fixedMillisecond25.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("ClassContext");
        int int30 = fixedMillisecond25.compareTo((java.lang.Object) "ClassContext");
        int int31 = year21.compareTo((java.lang.Object) "ClassContext");
        long long32 = year21.getLastMillisecond();
        boolean boolean33 = month13.equals((java.lang.Object) year21);
        boolean boolean34 = year8.equals((java.lang.Object) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year8.previous();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(12, year8);
        try {
            org.jfree.data.time.Year year37 = month36.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62167363200001L) + "'", long22 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(regularTimePeriod35);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = year7.getSerialIndex();
        long long11 = year7.getSerialIndex();
        java.lang.String str12 = year7.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray17 = seriesException16.getSuppressed();
        seriesException13.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable[] throwableArray19 = seriesException16.getSuppressed();
        java.lang.Class<?> wildcardClass20 = throwableArray19.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass20);
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class24 = null;
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass20, class24);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(inputStream22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 3);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        timeSeries17.setRangeDescription("ThreadContext");
        java.lang.String str21 = timeSeries17.getRangeDescription();
        timeSeries17.clear();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int24 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        int int25 = year23.getYear();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int32 = month30.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) (-1));
        java.lang.String str35 = timeSeries27.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond37.getLastMillisecond(calendar40);
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.util.Date date43 = fixedMillisecond37.getTime();
        boolean boolean44 = year23.equals((java.lang.Object) fixedMillisecond37);
        boolean boolean45 = timeSeriesDataItem15.equals((java.lang.Object) fixedMillisecond37);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ThreadContext" + "'", str21.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        long long11 = year8.getSerialIndex();
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(3, year8);
        long long14 = month13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62099107200000L) + "'", long14 == (-62099107200000L));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate17 = serialDate12.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(2, serialDate17);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate34 = serialDate26.getEndOfCurrentMonth(serialDate31);
        java.lang.String str35 = serialDate26.getDescription();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        org.jfree.data.time.SerialDate serialDate37 = serialDate17.getEndOfCurrentMonth(serialDate26);
        serialDate37.setDescription("Second");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        java.util.List list4 = timeSeries1.getItems();
        try {
            java.lang.Number number6 = timeSeries1.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        timeSeries12.setMaximumItemCount(0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        java.lang.String str34 = serialDate33.toString();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate42 = serialDate33.getEndOfCurrentMonth(serialDate39);
        boolean boolean43 = spreadsheetDate2.isOnOrAfter(serialDate39);
        int int44 = spreadsheetDate2.getMonth();
        int int45 = spreadsheetDate2.getMonth();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2-January-9999" + "'", str34.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str21 = day20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        java.lang.Number number23 = null;
        timeSeries1.add(regularTimePeriod22, number23);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2-January-9999" + "'", str21.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = month9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25L + "'", long10 == 25L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        int int19 = year18.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year18);
        java.lang.String str21 = seriesChangeEvent20.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=2]"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        int int8 = month5.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean12 = fixedMillisecond10.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) (byte) 10);
        boolean boolean17 = month5.equals((java.lang.Object) fixedMillisecond10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getFirstMillisecond(calendar18);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener21);
        try {
            timeSeries1.setMaximumItemAge((long) (-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62198899200000L) + "'", long6 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "hi!", "January -1", class13);
        timeSeries14.setRangeDescription("Oct");
        timeSeries14.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int24 = month22.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int35 = fixedMillisecond33.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("ClassContext");
        int int38 = fixedMillisecond33.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date39 = fixedMillisecond33.getTime();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, 0.0d);
        boolean boolean43 = day0.equals((java.lang.Object) year40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January -1" + "'", str7.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        java.lang.Object obj24 = timeSeries23.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate27);
        java.lang.String str31 = serialDate30.toString();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
        long long33 = day32.getSerialIndex();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (-1898));
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        java.lang.String str50 = month47.toString();
        long long51 = month47.getSerialIndex();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        java.lang.Object obj57 = null;
        boolean boolean58 = day55.equals(obj57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int65 = month63.compareTo((java.lang.Object) 2);
        java.util.Date date66 = month63.getStart();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        long long68 = year67.getLastMillisecond();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month((int) (short) 1, year67);
        long long70 = year67.getSerialIndex();
        long long71 = year67.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year67, (double) (short) 1);
        try {
            timeSeries1.add(timeSeriesDataItem73);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-9999" + "'", str31.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2958131L + "'", long33 == 2958131L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62198899200000L) + "'", long48 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "January -1" + "'", str50.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-11L) + "'", long51 == (-11L));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62167363200001L) + "'", long68 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2L + "'", long70 == 2L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2L + "'", long71 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setNotify(true);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        boolean boolean20 = timeSeries1.getNotify();
        java.lang.Class<?> wildcardClass21 = timeSeries1.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.String str9 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        timeSeriesDataItem8.setValue((java.lang.Number) 253373385600000L);
        timeSeriesDataItem8.setValue((java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.lang.Comparable comparable17 = timeSeries1.getKey();
        java.lang.Object obj18 = timeSeries1.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries1.addChangeListener(seriesChangeListener19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1900 + "'", comparable17.equals(1900));
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((int) '#', (int) '4');
        java.util.List list35 = timeSeries34.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries38 = timeSeries34.createCopy((int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year7.previous();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year7.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date17 = fixedMillisecond11.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond11.next();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) 0);
        java.lang.String str10 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str10.equals("Wed Dec 31 15:59:59 PST 1969"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = null;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate18 = serialDate9.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((-572), serialDate18);
        try {
            boolean boolean21 = spreadsheetDate1.isInRange(serialDate3, serialDate18, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2-January-9999" + "'", str10.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int29 = month27.compareTo((java.lang.Object) 2);
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, year31);
        long long34 = year31.getSerialIndex();
        long long35 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) (short) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year31.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.clear();
        timeSeries1.setMaximumItemAge((long) (short) 100);
        long long23 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        long long4 = month2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62101526400001L) + "'", long4 == (-62101526400001L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        java.lang.String str20 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        try {
            java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        int int8 = day3.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8);
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9999 + "'", int8 == 9999);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 2, (-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-2958125), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond7.getFirstMillisecond(calendar15);
        long long17 = fixedMillisecond7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = serialDate13.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(2, serialDate18);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate35 = serialDate27.getEndOfCurrentMonth(serialDate32);
        java.lang.String str36 = serialDate27.getDescription();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(3, serialDate27);
        org.jfree.data.time.SerialDate serialDate38 = serialDate18.getEndOfCurrentMonth(serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str31 = month30.toString();
        int int32 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, number37);
        java.lang.Object obj39 = timeSeriesDataItem38.clone();
        timeSeries10.add(timeSeriesDataItem38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int47 = month45.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1));
        java.lang.String str50 = timeSeries42.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean54 = fixedMillisecond52.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond52.getLastMillisecond(calendar55);
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries42.addChangeListener(seriesChangeListener58);
        java.lang.Comparable comparable60 = timeSeries42.getKey();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries10.addAndOrUpdate(timeSeries42);
        timeSeries10.setMaximumItemCount(100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "January -1" + "'", str31.equals("January -1"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 1900 + "'", comparable60.equals(1900));
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        int int8 = month5.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean12 = fixedMillisecond10.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) (byte) 10);
        boolean boolean17 = month5.equals((java.lang.Object) fixedMillisecond10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getFirstMillisecond(calendar18);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        long long30 = fixedMillisecond24.getLastMillisecond();
        java.util.Date date31 = fixedMillisecond24.getTime();
        long long32 = fixedMillisecond24.getLastMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62198899200000L) + "'", long6 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1561964399999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        int int5 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str27 = day26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
        java.lang.Number number29 = null;
        timeSeries7.add(regularTimePeriod28, number29);
        timeSeries7.setNotify(false);
        java.lang.String str33 = timeSeries7.getDescription();
        boolean boolean34 = month2.equals((java.lang.Object) str33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2-January-9999" + "'", str27.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemAge((long) 1900);
        java.lang.Object obj5 = timeSeries1.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("ClassContext");
        int int12 = fixedMillisecond7.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-11L));
        timeSeriesDataItem14.setValue((java.lang.Number) 100.0f);
        try {
            timeSeries1.add(timeSeriesDataItem14);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        java.lang.String str6 = month2.toString();
        try {
            org.jfree.data.time.Year year7 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January -1" + "'", str6.equals("January -1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        spreadsheetDate1.setDescription("Sunday");
        int int59 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
        java.lang.String str65 = serialDate64.toString();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate70 = day69.getSerialDate();
        org.jfree.data.time.SerialDate serialDate72 = serialDate70.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate73 = serialDate64.getEndOfCurrentMonth(serialDate70);
        int int74 = spreadsheetDate1.compare(serialDate70);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2-January-9999" + "'", str65.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-2958096) + "'", int74 == (-2958096));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        serialDate18.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate22 = serialDate18.getPreviousDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate22);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        long long23 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond15.getMiddleMillisecond(calendar24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-2958096));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int26 = month24.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) (-1));
        java.lang.String str29 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond31.getLastMillisecond(calendar34);
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        long long38 = month37.getLastMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) month37);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month37, (double) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        java.lang.Class class6 = null;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1561964399999L);
        java.lang.Class class18 = timeSeries1.getTimePeriodClass();
        boolean boolean19 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = null;
        try {
            timeSeries1.add(timeSeriesDataItem21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray11 = seriesException8.getSuppressed();
        java.lang.Class<?> wildcardClass12 = throwableArray11.getClass();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        seriesException14.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = seriesException17.getSuppressed();
        java.lang.Class<?> wildcardClass21 = throwableArray20.getClass();
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4, (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(inputStream23);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            year7.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        int int4 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray23 = seriesException22.getSuppressed();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray26 = seriesException25.getSuppressed();
        seriesException22.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.Throwable[] throwableArray28 = seriesException25.getSuppressed();
        java.lang.Class<?> wildcardClass29 = throwableArray28.getClass();
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray32 = seriesException31.getSuppressed();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray35 = seriesException34.getSuppressed();
        seriesException31.addSuppressed((java.lang.Throwable) seriesException34);
        java.lang.Throwable[] throwableArray37 = seriesException34.getSuppressed();
        java.lang.Class<?> wildcardClass38 = throwableArray37.getClass();
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass29, (java.lang.Class) wildcardClass38);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int48 = month46.compareTo((java.lang.Object) 2);
        java.util.Date date49 = month46.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        long long51 = year50.getLastMillisecond();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (short) 1, year50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int56 = fixedMillisecond54.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException58 = new org.jfree.data.general.SeriesException("ClassContext");
        int int59 = fixedMillisecond54.compareTo((java.lang.Object) "ClassContext");
        int int60 = year50.compareTo((java.lang.Object) "ClassContext");
        long long61 = year50.getLastMillisecond();
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(1, year50);
        int int63 = month62.getYearValue();
        try {
            timeSeries41.add((org.jfree.data.time.RegularTimePeriod) month62, (double) (-62101526400001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of [Ljava.lang.Throwable;.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(inputStream40);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-62167363200001L) + "'", long51 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-62167363200001L) + "'", long61 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("ClassContext");
        int int8 = fixedMillisecond3.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date9 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date9);
        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond12);
        java.lang.String str14 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate7);
        org.jfree.data.time.SerialDate serialDate19 = serialDate7.getPreviousDayOfWeek(1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        try {
            timeSeries1.update((-2958125), (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.util.Date date0 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int7 = month5.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (double) (-1));
        java.lang.String str10 = timeSeries2.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getLastMillisecond(calendar15);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.util.Date date18 = fixedMillisecond12.getTime();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray23 = seriesException22.getSuppressed();
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray26 = seriesException25.getSuppressed();
        seriesException22.addSuppressed((java.lang.Throwable) seriesException25);
        java.lang.Throwable[] throwableArray28 = seriesException25.getSuppressed();
        java.lang.Class<?> wildcardClass29 = throwableArray28.getClass();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int34 = month32.compareTo((java.lang.Object) 2);
        java.util.Date date35 = month32.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone37);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass29);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray43 = seriesException42.getSuppressed();
        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray46 = seriesException45.getSuppressed();
        seriesException42.addSuppressed((java.lang.Throwable) seriesException45);
        java.lang.Throwable[] throwableArray48 = seriesException45.getSuppressed();
        java.lang.Class<?> wildcardClass49 = throwableArray48.getClass();
        java.net.URL uRL50 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass49);
        java.lang.Object obj51 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass29, (java.lang.Class) wildcardClass49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int55 = fixedMillisecond53.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException57 = new org.jfree.data.general.SeriesException("ClassContext");
        int int58 = fixedMillisecond53.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date59 = fixedMillisecond53.getTime();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date59, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date18, timeZone61);
        try {
            org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date0, timeZone61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(uRL39);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(uRL50);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int9 = month7.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, (double) (-1));
        timeSeries4.removeAgedItems(false);
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int21 = month19.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (double) (-1));
        timeSeries16.removeAgedItems(false);
        timeSeries16.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection29 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries16.removeAgedItems(253373385600000L, false);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries1.addAndOrUpdate(timeSeries16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.addChangeListener(seriesChangeListener34);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        java.lang.Object obj57 = null;
        boolean boolean58 = day55.equals(obj57);
        int int59 = day55.getYear();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate71 = day70.getSerialDate();
        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate74 = serialDate66.getEndOfCurrentMonth(serialDate71);
        boolean boolean75 = day55.equals((java.lang.Object) serialDate74);
        int int76 = spreadsheetDate51.compare(serialDate74);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.lang.String str78 = spreadsheetDate51.toString();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
        org.jfree.data.time.SerialDate serialDate85 = serialDate83.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate90 = day89.getSerialDate();
        org.jfree.data.time.SerialDate serialDate92 = serialDate90.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate93 = serialDate85.getEndOfCurrentMonth(serialDate90);
        java.lang.String str94 = serialDate93.toString();
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate93);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(serialDate93);
        boolean boolean97 = spreadsheetDate51.isOnOrAfter(serialDate93);
        int int98 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int99 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9999 + "'", int59 == 9999);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-2958125) + "'", int76 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "5-January-1900" + "'", str78.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "31-January-9999" + "'", str94.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1900 + "'", int99 == 1900);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setNotify(true);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        int int57 = spreadsheetDate1.getYYYY();
        java.util.Date date58 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
        org.junit.Assert.assertNotNull(date58);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        int int19 = year18.getYear();
        java.lang.String str20 = year18.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2" + "'", str20.equals("2"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = serialDate9.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(9, serialDate14);
        java.lang.String str19 = serialDate14.toString();
        boolean boolean20 = spreadsheetDate1.isBefore(serialDate14);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate34 = serialDate25.getEndOfCurrentMonth(serialDate31);
        boolean boolean35 = spreadsheetDate1.isBefore(serialDate25);
        int int36 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2-January-9999" + "'", str19.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-9999" + "'", str26.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        int int11 = day6.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate12 = day6.getSerialDate();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class6 = timeSeries5.getTimePeriodClass();
        timeSeries5.setRangeDescription("ThreadContext");
        java.lang.String str9 = timeSeries5.getRangeDescription();
        timeSeries5.clear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str13 = year11.toString();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(5, year11);
        int int15 = year11.getYear();
        timeSeries1.setKey((java.lang.Comparable) int15);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ThreadContext" + "'", str9.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.Calendar calendar9 = null;
        try {
            year7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "July" + "'", str1.equals("July"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate14.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        long long17 = day16.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-January-9999" + "'", str15.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2958131L + "'", long17 == 2958131L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        seriesException23.addSuppressed((java.lang.Throwable) seriesException26);
        java.lang.Throwable[] throwableArray29 = seriesException26.getSuppressed();
        java.lang.Class<?> wildcardClass30 = throwableArray29.getClass();
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass30);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int36 = fixedMillisecond34.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("ClassContext");
        int int39 = fixedMillisecond34.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date40 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date40, timeZone42);
        java.lang.ClassLoader classLoader44 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(uRL31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(classLoader44);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str5 = day4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        java.lang.Object obj7 = null;
        boolean boolean8 = day4.equals(obj7);
        int int9 = day4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(12, serialDate10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        int int18 = year8.compareTo((java.lang.Object) "ClassContext");
        long long19 = year8.getLastMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, year8);
        long long21 = year8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2L + "'", long21 == 2L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        long long12 = day11.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-14400001L) + "'", long12 == (-14400001L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("ClassContext");
        int int8 = fixedMillisecond3.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date9 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date9);
        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond12.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(8, 2958465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray19 = seriesException18.getSuppressed();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        seriesException18.addSuppressed((java.lang.Throwable) seriesException21);
        seriesException11.addSuppressed((java.lang.Throwable) seriesException21);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        boolean boolean26 = fixedMillisecond1.equals((java.lang.Object) seriesException11);
        long long27 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int64 = month62.compareTo((java.lang.Object) 2);
        java.util.Date date65 = month62.getStart();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
        long long67 = year66.getLastMillisecond();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 1, year66);
        java.lang.Class<?> wildcardClass69 = month68.getClass();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int74 = month72.compareTo((java.lang.Object) 2);
        java.util.Date date75 = month72.getStart();
        java.util.TimeZone timeZone76 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date75, timeZone76);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate32, "7-January-9999", "2", (java.lang.Class) wildcardClass69);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62167363200001L) + "'", long67 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(regularTimePeriod77);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        java.util.Date date9 = month6.getEnd();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=January -1]", (java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(classLoader13);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Date date3 = regularTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (short) 10, (-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.util.Collection collection27 = org.jfree.chart.util.ObjectUtilities.deepClone(collection26);
        java.util.Collection collection28 = org.jfree.chart.util.ObjectUtilities.deepClone(collection26);
        java.util.Collection collection29 = org.jfree.chart.util.ObjectUtilities.deepClone(collection26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-2958125));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-2958125) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int29 = month27.compareTo((java.lang.Object) 2);
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, year31);
        long long34 = year31.getSerialIndex();
        long long35 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) (short) 1);
        try {
            timeSeries1.delete(5, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month12.getMonth();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) month12);
        long long15 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int19 = month17.compareTo((java.lang.Object) 2);
        java.util.Date date20 = month17.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 1, year21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int27 = fixedMillisecond25.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("ClassContext");
        int int30 = fixedMillisecond25.compareTo((java.lang.Object) "ClassContext");
        int int31 = year21.compareTo((java.lang.Object) "ClassContext");
        long long32 = year21.getLastMillisecond();
        boolean boolean33 = month13.equals((java.lang.Object) year21);
        boolean boolean34 = year8.equals((java.lang.Object) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year8.previous();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(12, year8);
        long long37 = month36.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62167363200001L) + "'", long22 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 36L + "'", long37 == 36L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 0.0f);
        int int6 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        seriesException12.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.Throwable[] throwableArray18 = seriesException15.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass19);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass19);
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(inputStream21);
        org.junit.Assert.assertNotNull(classLoader22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.clear();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int25 = month23.compareTo((java.lang.Object) 2);
        java.util.Date date26 = month23.getStart();
        long long27 = month23.getSerialIndex();
        int int28 = month23.getMonth();
        long long29 = month23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month23.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-11L) + "'", long27 == (-11L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-11L) + "'", long29 == (-11L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        java.lang.String str38 = day3.toString();
        java.lang.Object obj39 = null;
        int int40 = day3.compareTo(obj39);
        java.lang.Class class41 = null;
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int46 = month44.compareTo((java.lang.Object) 2);
        java.util.Date date47 = month44.getStart();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date47, timeZone48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date47);
        int int51 = day3.compareTo((java.lang.Object) date47);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2-January-9999" + "'", str38.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
        java.lang.Object obj54 = null;
        boolean boolean55 = day52.equals(obj54);
        int int56 = day52.getYear();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate61 = day60.getSerialDate();
        org.jfree.data.time.SerialDate serialDate63 = serialDate61.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate68 = day67.getSerialDate();
        org.jfree.data.time.SerialDate serialDate70 = serialDate68.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate71 = serialDate63.getEndOfCurrentMonth(serialDate68);
        boolean boolean72 = day52.equals((java.lang.Object) serialDate71);
        boolean boolean73 = spreadsheetDate2.isOnOrBefore(serialDate71);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9999 + "'", int56 == 9999);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        timeSeries55.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        timeSeries57.setRangeDescription("ThreadContext");
        java.lang.String str61 = timeSeries57.getRangeDescription();
        timeSeries57.clear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int64 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str65 = year63.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str67 = timeSeries37.getDomainDescription();
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int72 = day71.getYear();
        java.lang.Number number73 = null;
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day71, number73, false);
        timeSeries37.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ThreadContext" + "'", str61.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 9999 + "'", int72 == 9999);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate27);
        java.lang.String str31 = serialDate30.toString();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
        long long33 = day32.getSerialIndex();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (-1898));
        java.util.Calendar calendar36 = null;
        try {
            long long37 = day32.getFirstMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-9999" + "'", str31.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2958131L + "'", long33 == 2958131L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        int int9 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        long long17 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long21 = month20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
        int int23 = month20.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond25.getLastMillisecond(calendar28);
        boolean boolean31 = fixedMillisecond25.equals((java.lang.Object) (byte) 10);
        boolean boolean32 = month20.equals((java.lang.Object) fixedMillisecond25);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond25.getFirstMillisecond(calendar33);
        long long35 = fixedMillisecond25.getLastMillisecond();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond25.getMiddleMillisecond(calendar36);
        boolean boolean38 = fixedMillisecond11.equals((java.lang.Object) long37);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62198899200000L) + "'", long21 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone19);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass11);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Time", (java.lang.Class) wildcardClass11);
        java.lang.Class class24 = null;
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray30 = seriesException29.getSuppressed();
        seriesException26.addSuppressed((java.lang.Throwable) seriesException29);
        java.lang.Throwable[] throwableArray32 = seriesException29.getSuppressed();
        java.lang.Class<?> wildcardClass33 = throwableArray32.getClass();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int38 = month36.compareTo((java.lang.Object) 2);
        java.util.Date date39 = month36.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone41);
        java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January -1", class24, (java.lang.Class) wildcardClass33);
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass11, class24);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNull(obj44);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getLastMillisecond();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62101526400001L) + "'", long6 == (-62101526400001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        try {
            timeSeries1.setMaximumItemAge((-62198899200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        seriesException23.addSuppressed((java.lang.Throwable) seriesException26);
        java.lang.Throwable[] throwableArray29 = seriesException26.getSuppressed();
        java.lang.Class<?> wildcardClass30 = throwableArray29.getClass();
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass30);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int36 = fixedMillisecond34.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("ClassContext");
        int int39 = fixedMillisecond34.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date40 = fixedMillisecond34.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date40, timeZone42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int47 = fixedMillisecond45.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("ClassContext");
        int int50 = fixedMillisecond45.compareTo((java.lang.Object) "ClassContext");
        long long51 = fixedMillisecond45.getLastMillisecond();
        java.util.Date date52 = fixedMillisecond45.getTime();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date40, timeZone53);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(uRL31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, (-460), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, number6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "2", (java.lang.Object) regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        java.lang.String str5 = day3.toString();
        long long6 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 253370880000000L + "'", long6 == 253370880000000L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1898) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, year15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("ClassContext");
        int int24 = fixedMillisecond19.compareTo((java.lang.Object) "ClassContext");
        int int25 = year15.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(1900);
        int int28 = year15.compareTo((java.lang.Object) year27);
        boolean boolean29 = year6.equals((java.lang.Object) int28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str33 = month32.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month32, "hi!", "January -1", class39);
        boolean boolean42 = month32.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int47 = fixedMillisecond45.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("ClassContext");
        int int50 = fixedMillisecond45.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date51 = fixedMillisecond45.getTime();
        java.lang.Number number52 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        int int53 = year6.compareTo((java.lang.Object) number52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62167363200001L) + "'", long16 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1898) + "'", int28 == (-1898));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "January -1" + "'", str33.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        java.lang.String str12 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int7 = month5.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (double) (-1));
        timeSeries2.removeAgedItems(false);
        java.lang.Class class12 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int19 = month17.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) (-1));
        timeSeries14.removeAgedItems(false);
        timeSeries14.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection27 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.removeAgedItems(true);
        java.lang.String str30 = timeSeries14.getDescription();
        java.lang.Class class31 = timeSeries14.getTimePeriodClass();
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(uRL32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int29 = month27.compareTo((java.lang.Object) 2);
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, year31);
        long long34 = year31.getSerialIndex();
        long long35 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) (short) 1);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = year31.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        timeSeries1.setRangeDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 4);
//        long long17 = day13.getLastMillisecond();
//        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
//        seriesException20.addSuppressed((java.lang.Throwable) seriesException23);
//        java.lang.Throwable[] throwableArray26 = seriesException23.getSuppressed();
//        java.lang.Class<?> wildcardClass27 = throwableArray26.getClass();
//        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray30 = seriesException29.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray33 = seriesException32.getSuppressed();
//        seriesException29.addSuppressed((java.lang.Throwable) seriesException32);
//        java.lang.Throwable[] throwableArray35 = seriesException32.getSuppressed();
//        java.lang.Class<?> wildcardClass36 = throwableArray35.getClass();
//        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass27, (java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, (java.lang.Class) wildcardClass27);
//        java.util.Collection collection39 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(obj37);
//        org.junit.Assert.assertNotNull(collection39);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int9 = year7.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) (-1));
        java.lang.String str19 = timeSeries11.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date27 = fixedMillisecond21.getTime();
        boolean boolean28 = year7.equals((java.lang.Object) fixedMillisecond21);
        long long29 = fixedMillisecond21.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str31 = month30.toString();
        int int32 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, number37);
        java.lang.Object obj39 = timeSeriesDataItem38.clone();
        timeSeries10.add(timeSeriesDataItem38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int47 = month45.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1));
        java.lang.String str50 = timeSeries42.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean54 = fixedMillisecond52.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond52.getLastMillisecond(calendar55);
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries42.addChangeListener(seriesChangeListener58);
        java.lang.Comparable comparable60 = timeSeries42.getKey();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries10.addAndOrUpdate(timeSeries42);
        timeSeries61.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "January -1" + "'", str31.equals("January -1"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Time" + "'", str50.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + 1900 + "'", comparable60.equals(1900));
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Date date19 = year7.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year21.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        java.util.Date date15 = month11.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("ClassContext");
        int int23 = fixedMillisecond18.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date24 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        int int29 = year25.compareTo((java.lang.Object) class28);
        org.jfree.data.general.SeriesException seriesException35 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray36 = seriesException35.getSuppressed();
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray39 = seriesException38.getSuppressed();
        seriesException35.addSuppressed((java.lang.Throwable) seriesException38);
        java.lang.Throwable[] throwableArray41 = seriesException38.getSuppressed();
        java.lang.Class<?> wildcardClass42 = throwableArray41.getClass();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int47 = month45.compareTo((java.lang.Object) 2);
        java.util.Date date48 = month45.getStart();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone50);
        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass42);
        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray56 = seriesException55.getSuppressed();
        org.jfree.data.general.SeriesException seriesException58 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray59 = seriesException58.getSuppressed();
        seriesException55.addSuppressed((java.lang.Throwable) seriesException58);
        java.lang.Throwable[] throwableArray61 = seriesException58.getSuppressed();
        java.lang.Class<?> wildcardClass62 = throwableArray61.getClass();
        java.net.URL uRL63 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass62);
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass42, (java.lang.Class) wildcardClass62);
        java.lang.ClassLoader classLoader65 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass62);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year25, "", "ThreadContext", (java.lang.Class) wildcardClass62);
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int72 = month70.compareTo((java.lang.Object) 2);
        java.util.Date date73 = month70.getStart();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        long long75 = year74.getLastMillisecond();
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month((int) (short) 1, year74);
        java.lang.Class<?> wildcardClass77 = month76.getClass();
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int82 = month80.compareTo((java.lang.Object) 2);
        java.util.Date date83 = month80.getStart();
        java.util.TimeZone timeZone84 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date83, timeZone84);
        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int89 = fixedMillisecond87.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException91 = new org.jfree.data.general.SeriesException("ClassContext");
        int int92 = fixedMillisecond87.compareTo((java.lang.Object) "ClassContext");
        long long93 = fixedMillisecond87.getLastMillisecond();
        java.util.Date date94 = fixedMillisecond87.getTime();
        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date94, timeZone95);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date83, timeZone95);
        org.jfree.data.time.Month month98 = new org.jfree.data.time.Month(date15, timeZone95);
        org.jfree.data.time.Year year99 = new org.jfree.data.time.Year(date6, timeZone95);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(uRL52);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNull(uRL63);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertNotNull(classLoader65);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62167363200001L) + "'", long75 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + (-1L) + "'", long93 == (-1L));
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertNotNull(timeZone95);
        org.junit.Assert.assertNull(regularTimePeriod97);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate2.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        java.lang.String str34 = serialDate33.toString();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate42 = serialDate33.getEndOfCurrentMonth(serialDate39);
        boolean boolean43 = spreadsheetDate2.isOnOrAfter(serialDate39);
        int int44 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate67 = serialDate59.getEndOfCurrentMonth(serialDate64);
        org.jfree.data.time.SerialDate serialDate69 = serialDate64.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(2, serialDate69);
        org.jfree.data.time.SerialDate serialDate71 = serialDate51.getEndOfCurrentMonth(serialDate69);
        boolean boolean72 = spreadsheetDate2.isBefore(serialDate71);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2-January-9999" + "'", str34.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getLastMillisecond();
        long long7 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62101526400001L) + "'", long6 == (-62101526400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-11L) + "'", long7 == (-11L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        java.lang.String str24 = timeSeries23.getDescription();
        java.util.List list25 = timeSeries23.getItems();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-920));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-683) + "'", int1 == (-683));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate4);
        java.util.Calendar calendar15 = null;
        try {
            day14.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate14.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate14);
        java.lang.String str18 = serialDate14.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-January-9999" + "'", str15.equals("31-January-9999"));
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        long long5 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62198899200000L) + "'", long5 == (-62198899200000L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries7.setNotify(true);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        long long26 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        timeSeries28.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int34 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener35);
        java.util.Collection collection37 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        java.lang.String str38 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        long long8 = month7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62101526400001L) + "'", long8 == (-62101526400001L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.String str9 = year7.toString();
        long long10 = year7.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(1, 1969);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int29 = month27.compareTo((java.lang.Object) 2);
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, year31);
        long long34 = year31.getSerialIndex();
        long long35 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) (short) 1);
        java.lang.String[] strArray38 = org.jfree.data.time.SerialDate.getMonths();
        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) strArray38);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "hi!", "January -1", class17);
        timeSeries18.setRangeDescription("Oct");
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int28 = month26.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean34 = fixedMillisecond32.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
        timeSeries37.setRangeDescription("ThreadContext");
        java.lang.String str41 = timeSeries37.getRangeDescription();
        java.util.List list42 = timeSeries37.getItems();
        java.util.Collection collection43 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries1.addAndOrUpdate(timeSeries35);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -1" + "'", str11.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ThreadContext" + "'", str41.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(collection43);
        org.junit.Assert.assertNotNull(timeSeries44);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) '#');
        long long12 = fixedMillisecond9.getSerialIndex();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getLastMillisecond(calendar13);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2019, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        int int14 = day10.getYear();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate29 = serialDate21.getEndOfCurrentMonth(serialDate26);
        boolean boolean30 = day10.equals((java.lang.Object) serialDate29);
        int int31 = spreadsheetDate6.compare(serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate32);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate40);
        boolean boolean46 = spreadsheetDate1.isInRange(serialDate32, serialDate44, (int) (byte) 100);
        int int47 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9999 + "'", int14 == 9999);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-2958125) + "'", int31 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        boolean boolean32 = month12.equals((java.lang.Object) year20);
        boolean boolean33 = year7.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year7.previous();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year7.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        timeSeries1.setMaximumItemCount((int) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getLastMillisecond(calendar15);
        boolean boolean18 = fixedMillisecond12.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond12.getMiddleMillisecond(calendar19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int24 = month23.getMonth();
        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) month23);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = year7.getSerialIndex();
        long long11 = year7.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        java.lang.Class class23 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int30 = month28.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) (-1));
        timeSeries25.removeAgedItems(false);
        timeSeries25.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection38 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries25.removeAgedItems(true);
        boolean boolean41 = year7.equals((java.lang.Object) timeSeries25);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167363200001L) + "'", long11 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = serialDate15.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate25 = serialDate20.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(2, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = serialDate7.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((int) '#', (int) '4');
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries12.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray3 = seriesException2.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        seriesException2.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray8 = seriesException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = throwableArray8.getClass();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int14 = month12.compareTo((java.lang.Object) 2);
        java.util.Date date15 = month12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone17);
        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertNotNull(classLoader20);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str31 = month30.toString();
        int int32 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, number37);
        java.lang.Object obj39 = timeSeriesDataItem38.clone();
        timeSeries10.add(timeSeriesDataItem38);
        boolean boolean41 = timeSeries10.getNotify();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "January -1" + "'", str31.equals("January -1"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.setRangeDescription("ThreadContext");
        java.lang.String str6 = timeSeries2.getRangeDescription();
        timeSeries2.clear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.String str10 = year8.toString();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(5, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ThreadContext" + "'", str6.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year7.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, year18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("ClassContext");
        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "ClassContext");
        int int28 = year18.compareTo((java.lang.Object) "ClassContext");
        long long29 = year18.getLastMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(1, year18);
        int int31 = month30.getYearValue();
        boolean boolean32 = timeSeries1.equals((java.lang.Object) int31);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62167363200001L) + "'", long29 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, number14);
        timeSeries1.add(timeSeriesDataItem15, false);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate35 = serialDate27.getEndOfCurrentMonth(serialDate32);
        java.lang.String str36 = serialDate27.getDescription();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(3, serialDate27);
        serialDate37.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate41 = serialDate37.getPreviousDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate59 = serialDate51.getEndOfCurrentMonth(serialDate56);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(9, serialDate56);
        java.lang.String str61 = serialDate56.toString();
        boolean boolean62 = spreadsheetDate43.isBefore(serialDate56);
        boolean boolean64 = spreadsheetDate19.isInRange(serialDate37, (org.jfree.data.time.SerialDate) spreadsheetDate43, (-460));
        int int65 = timeSeriesDataItem15.compareTo((java.lang.Object) serialDate37);
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2-January-9999" + "'", str61.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        java.util.List list4 = timeSeries1.getItems();
        java.util.List list5 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1L + "'", obj2.equals(1L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1L + "'", obj3.equals(1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2019, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.util.Calendar calendar4 = null;
        try {
            day3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        timeSeries57.setRangeDescription("ThreadContext");
        java.lang.String str61 = timeSeries57.getRangeDescription();
        timeSeries57.clear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int64 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str65 = year63.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year63);
        int int67 = timeSeries37.getMaximumItemCount();
        java.util.List list68 = timeSeries37.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ThreadContext" + "'", str61.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2147483647 + "'", int67 == 2147483647);
        org.junit.Assert.assertNotNull(list68);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.ClassLoader classLoader20 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass10);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader20);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(classLoader20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        int int38 = day3.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9, (int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries17.createCopy(8, 2147483647);
        boolean boolean41 = timeSeries17.isEmpty();
        timeSeries17.removeAgedItems((long) 2958465, false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone19);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass11);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Time", (java.lang.Class) wildcardClass11);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        timeSeries57.setRangeDescription("ThreadContext");
        java.lang.String str61 = timeSeries57.getRangeDescription();
        timeSeries57.clear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int64 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str65 = year63.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str67 = timeSeries37.getDomainDescription();
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int72 = day71.getYear();
        java.lang.Number number73 = null;
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day71, number73, false);
        org.jfree.data.time.SerialDate serialDate76 = day71.getSerialDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ThreadContext" + "'", str61.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 9999 + "'", int72 == 9999);
        org.junit.Assert.assertNotNull(serialDate76);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        timeSeriesDataItem8.setValue((java.lang.Number) 253373385600000L);
        timeSeriesDataItem8.setValue((java.lang.Number) (-11L));
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str16 = month15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class22 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "hi!", "January -1", class22);
        boolean boolean24 = timeSeries23.isEmpty();
        int int25 = timeSeriesDataItem8.compareTo((java.lang.Object) boolean24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "January -1" + "'", str16.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem4.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        boolean boolean20 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getSerialIndex();
        long long8 = year6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        java.lang.String str34 = serialDate33.toString();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate42 = serialDate33.getEndOfCurrentMonth(serialDate39);
        boolean boolean43 = spreadsheetDate2.isOnOrAfter(serialDate39);
        int int44 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate50 = day49.getSerialDate();
        org.jfree.data.time.SerialDate serialDate52 = serialDate50.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate60 = serialDate52.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate60);
        boolean boolean62 = spreadsheetDate2.isOnOrBefore(serialDate61);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2-January-9999" + "'", str34.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        int int19 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        timeSeries22.setRangeDescription("ThreadContext");
        java.lang.String str26 = timeSeries22.getRangeDescription();
        timeSeries22.clear();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        int int29 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        java.lang.String str30 = year28.toString();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(5, year28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-2958096));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ThreadContext" + "'", str26.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem33);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        boolean boolean4 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
        int int8 = month5.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean12 = fixedMillisecond10.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
        boolean boolean16 = fixedMillisecond10.equals((java.lang.Object) (byte) 10);
        boolean boolean17 = month5.equals((java.lang.Object) fixedMillisecond10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getFirstMillisecond(calendar18);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener21);
        timeSeries1.setDomainDescription("31-January-9999");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62198899200000L) + "'", long6 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        long long11 = day6.getSerialIndex();
        int int12 = day6.getMonth();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2958102L + "'", long11 == 2958102L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        int int19 = year18.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year18);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str9 = day8.toString();
        long long10 = day8.getLastMillisecond();
        int int11 = day8.getDayOfMonth();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        int int17 = month14.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getLastMillisecond(calendar22);
        boolean boolean25 = fixedMillisecond19.equals((java.lang.Object) (byte) 10);
        boolean boolean26 = month14.equals((java.lang.Object) fixedMillisecond19);
        boolean boolean27 = day8.equals((java.lang.Object) boolean26);
        int int28 = fixedMillisecond1.compareTo((java.lang.Object) day8);
        long long29 = day8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2-January-9999" + "'", str9.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 253370966399999L + "'", long10 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62198899200000L) + "'", long15 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2958102L + "'", long29 == 2958102L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str21 = day20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        java.lang.Number number23 = null;
        timeSeries1.add(regularTimePeriod22, number23);
        timeSeries1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries1.removeChangeListener(seriesChangeListener27);
        try {
            timeSeries1.update((int) ' ', (java.lang.Number) (-2958096));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2-January-9999" + "'", str21.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            day3.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries17.createCopy(8, 2147483647);
        int int41 = timeSeries17.getItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        int int19 = year7.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str8 = day7.toString();
        long long9 = day7.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day7);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.createCopy(1900, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2-January-9999" + "'", str8.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 253370966399999L + "'", long9 == 253370966399999L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int11 = day10.getYear();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10);
        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) day10);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9999 + "'", int11 == 9999);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) (byte) 10);
        int int12 = year7.compareTo((java.lang.Object) 7);
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((-920), year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, (int) (short) 100, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        boolean boolean7 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate24 = serialDate16.getEndOfCurrentMonth(serialDate21);
        java.lang.String str25 = serialDate16.getDescription();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        java.lang.String str27 = serialDate26.toString();
        boolean boolean28 = month6.equals((java.lang.Object) serialDate26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1-April-9999" + "'", str27.equals("1-April-9999"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 4);
//        long long8 = day4.getLastMillisecond();
//        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
//        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
//        java.lang.Throwable[] throwableArray17 = seriesException14.getSuppressed();
//        java.lang.Class<?> wildcardClass18 = throwableArray17.getClass();
//        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
//        seriesException20.addSuppressed((java.lang.Throwable) seriesException23);
//        java.lang.Throwable[] throwableArray26 = seriesException23.getSuppressed();
//        java.lang.Class<?> wildcardClass27 = throwableArray26.getClass();
//        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass27);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, (java.lang.Class) wildcardClass18);
//        java.lang.ClassLoader classLoader30 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
//        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", (java.lang.Class) wildcardClass18);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertNotNull(throwableArray17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(obj28);
//        org.junit.Assert.assertNotNull(classLoader30);
//        org.junit.Assert.assertNull(obj31);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(9999, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "hi!", "January -1", class20);
        timeSeries21.setRangeDescription("Oct");
        timeSeries21.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        timeSeries26.setRangeDescription("ThreadContext");
        java.lang.String str30 = timeSeries26.getRangeDescription();
        timeSeries26.clear();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        int int33 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        int int34 = year32.getYear();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int41 = month39.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (double) (-1));
        java.lang.String str44 = timeSeries36.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean48 = fixedMillisecond46.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond46.getLastMillisecond(calendar49);
        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.util.Date date52 = fixedMillisecond46.getTime();
        boolean boolean53 = year32.equals((java.lang.Object) fixedMillisecond46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) year32);
        long long55 = year32.getSerialIndex();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ThreadContext" + "'", str30.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int29 = spreadsheetDate2.toSerial();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate45 = day44.getSerialDate();
        org.jfree.data.time.SerialDate serialDate47 = serialDate45.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate48 = serialDate40.getEndOfCurrentMonth(serialDate45);
        java.lang.String str49 = serialDate40.getDescription();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(3, serialDate40);
        serialDate50.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate54 = serialDate50.getPreviousDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate69 = day68.getSerialDate();
        org.jfree.data.time.SerialDate serialDate71 = serialDate69.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate72 = serialDate64.getEndOfCurrentMonth(serialDate69);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addMonths(9, serialDate69);
        java.lang.String str74 = serialDate69.toString();
        boolean boolean75 = spreadsheetDate56.isBefore(serialDate69);
        boolean boolean77 = spreadsheetDate32.isInRange(serialDate50, (org.jfree.data.time.SerialDate) spreadsheetDate56, (-460));
        boolean boolean78 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "2-January-9999" + "'", str74.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean11 = timeSeries10.isEmpty();
        timeSeries10.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        java.lang.String str38 = day3.toString();
        java.lang.String str39 = day3.toString();
        int int40 = day3.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2-January-9999" + "'", str38.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2-January-9999" + "'", str39.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        java.lang.Object obj7 = null;
        boolean boolean8 = day5.equals(obj7);
        int int9 = day5.getYear();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate24 = serialDate16.getEndOfCurrentMonth(serialDate21);
        boolean boolean25 = day5.equals((java.lang.Object) serialDate24);
        int int26 = spreadsheetDate1.compare(serialDate24);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int26, "org.jfree.data.general.SeriesChangeEvent[source=9]", "Sunday", class29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = null;
        try {
            timeSeries30.add(timeSeriesDataItem31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9999 + "'", int9 == 9999);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-2958125) + "'", int26 == (-2958125));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        long long8 = month6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62101526400001L) + "'", long8 == (-62101526400001L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.String str8 = seriesException4.toString();
        java.lang.Throwable[] throwableArray9 = seriesException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        int int11 = timeSeries1.getItemCount();
        boolean boolean12 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) '#');
//        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("ClassContext");
//        int int13 = fixedMillisecond8.compareTo((java.lang.Object) "ClassContext");
//        long long14 = fixedMillisecond8.getLastMillisecond();
//        java.util.Date date15 = fixedMillisecond8.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond8.next();
//        timeSeries1.delete(regularTimePeriod16);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries1.getTimePeriod(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        java.lang.String str38 = day3.toString();
        java.lang.String str39 = day3.toString();
        int int40 = day3.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2-January-9999" + "'", str38.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2-January-9999" + "'", str39.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        java.lang.Class<?> wildcardClass13 = throwableArray12.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone21);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass13);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January -1", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-11L), "13-June-2019", "December", (java.lang.Class) wildcardClass13);
        timeSeries25.setMaximumItemAge((long) 2019);
        try {
            timeSeries25.delete((-2958125), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2958125");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNull(uRL24);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.SerialDate serialDate48 = day46.getSerialDate();
        int int49 = fixedMillisecond24.compareTo((java.lang.Object) day46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(7, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "July" + "'", str2.equals("July"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate15);
        serialDate16.setDescription("Time");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        int int9 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("ClassContext");
        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem20, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        long long8 = month2.getSerialIndex();
        java.lang.String str9 = month2.toString();
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-11L) + "'", long8 == (-11L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "January -1" + "'", str9.equals("January -1"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str9 = day8.toString();
        long long10 = day8.getLastMillisecond();
        int int11 = day8.getDayOfMonth();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        int int17 = month14.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getLastMillisecond(calendar22);
        boolean boolean25 = fixedMillisecond19.equals((java.lang.Object) (byte) 10);
        boolean boolean26 = month14.equals((java.lang.Object) fixedMillisecond19);
        boolean boolean27 = day8.equals((java.lang.Object) boolean26);
        int int28 = fixedMillisecond1.compareTo((java.lang.Object) day8);
        long long29 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2-January-9999" + "'", str9.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 253370966399999L + "'", long10 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62198899200000L) + "'", long15 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int9 = month7.compareTo((java.lang.Object) 2);
        java.util.Date date10 = month7.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, year11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        int int21 = year11.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1900);
        int int24 = year11.compareTo((java.lang.Object) year23);
        boolean boolean25 = month2.equals((java.lang.Object) year23);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = month2.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62167363200001L) + "'", long12 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1898) + "'", int24 == (-1898));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        try {
            java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) str29);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.lang.Comparable comparable17 = timeSeries1.getKey();
        java.lang.Object obj18 = timeSeries1.clone();
        long long19 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str24 = day23.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str27 = timeSeries26.getDescription();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int32 = day31.getYear();
        java.lang.Number number33 = null;
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day31, number33, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        long long54 = month53.getLastMillisecond();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries26.addAndOrUpdate(timeSeries37);
        boolean boolean57 = day23.equals((java.lang.Object) timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries37.createCopy(8, 2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = fixedMillisecond62.next();
        java.util.Calendar calendar64 = null;
        long long65 = fixedMillisecond62.getFirstMillisecond(calendar64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1));
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-2958125));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 1900 + "'", comparable17.equals(1900));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9999 + "'", int32 == 9999);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1561964399999L + "'", long54 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 4L + "'", long65 == 4L);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        java.lang.Class<?> wildcardClass13 = throwableArray12.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone21);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass13);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January -1", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-11L), "13-June-2019", "December", (java.lang.Class) wildcardClass13);
        timeSeries25.setMaximumItemAge((long) 2019);
        try {
            timeSeries25.update((int) (byte) 1, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNull(uRL24);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        long long7 = month3.getLastMillisecond();
        java.util.Date date8 = month3.getEnd();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        seriesException12.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.Throwable[] throwableArray18 = seriesException15.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        seriesException21.addSuppressed((java.lang.Throwable) seriesException24);
        java.lang.Throwable[] throwableArray27 = seriesException24.getSuppressed();
        java.lang.Class<?> wildcardClass28 = throwableArray27.getClass();
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass28);
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass28);
        int int31 = month3.compareTo((java.lang.Object) wildcardClass28);
        java.io.InputStream inputStream32 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("1-April-9999", (java.lang.Class) wildcardClass28);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62101526400001L) + "'", long7 == (-62101526400001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(inputStream30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(inputStream32);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        int int3 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("ClassContext");
        int int10 = fixedMillisecond5.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        java.lang.Number number14 = timeSeriesDataItem12.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem12.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem12, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-11L) + "'", number14.equals((-11L)));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Date date9 = year8.getStart();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray17 = seriesException16.getSuppressed();
        seriesException13.addSuppressed((java.lang.Throwable) seriesException16);
        java.lang.Throwable[] throwableArray19 = seriesException16.getSuppressed();
        java.lang.Class<?> wildcardClass20 = throwableArray19.getClass();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int25 = month23.compareTo((java.lang.Object) 2);
        java.util.Date date26 = month23.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone28);
        java.net.URL uRL30 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass20);
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray34 = seriesException33.getSuppressed();
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray37 = seriesException36.getSuppressed();
        seriesException33.addSuppressed((java.lang.Throwable) seriesException36);
        java.lang.Throwable[] throwableArray39 = seriesException36.getSuppressed();
        java.lang.Class<?> wildcardClass40 = throwableArray39.getClass();
        java.net.URL uRL41 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass40);
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass20, (java.lang.Class) wildcardClass40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int46 = fixedMillisecond44.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException48 = new org.jfree.data.general.SeriesException("ClassContext");
        int int49 = fixedMillisecond44.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date50 = fixedMillisecond44.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date50, timeZone52);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date9, timeZone52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(uRL30);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(uRL41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries17.setDomainDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean23 = timeSeries17.equals((java.lang.Object) month22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        java.util.Date date25 = month22.getEnd();
        long long26 = month22.getFirstMillisecond();
        long long27 = month22.getSerialIndex();
        java.util.Date date28 = month22.getStart();
        java.lang.Number number29 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62198899200000L) + "'", long26 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-11L) + "'", long27 == (-11L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1.0d) + "'", number29.equals((-1.0d)));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray3 = seriesException2.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        seriesException2.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray8 = seriesException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = throwableArray8.getClass();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int14 = month12.compareTo((java.lang.Object) 2);
        java.util.Date date15 = month12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15);
        int int20 = year19.getYear();
        try {
            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((-683), year19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        int int49 = spreadsheetDate2.toSerial();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
        java.lang.Object obj63 = null;
        boolean boolean64 = day61.equals(obj63);
        int int65 = day61.getYear();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate70 = day69.getSerialDate();
        org.jfree.data.time.SerialDate serialDate72 = serialDate70.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate77 = day76.getSerialDate();
        org.jfree.data.time.SerialDate serialDate79 = serialDate77.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate80 = serialDate72.getEndOfCurrentMonth(serialDate77);
        boolean boolean81 = day61.equals((java.lang.Object) serialDate80);
        int int82 = spreadsheetDate57.compare(serialDate80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        int int84 = spreadsheetDate57.toSerial();
        boolean boolean86 = spreadsheetDate2.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate57, (-572));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9999 + "'", int65 == 9999);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-2958125) + "'", int82 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("ClassContext");
        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        boolean boolean18 = day3.equals((java.lang.Object) timeSeriesDataItem16);
        java.lang.Number number19 = timeSeriesDataItem16.getValue();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray30 = seriesException29.getSuppressed();
        seriesException26.addSuppressed((java.lang.Throwable) seriesException29);
        java.lang.Throwable[] throwableArray32 = seriesException29.getSuppressed();
        java.lang.Class<?> wildcardClass33 = throwableArray32.getClass();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int38 = month36.compareTo((java.lang.Object) 2);
        java.util.Date date39 = month36.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone41);
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass33);
        java.net.URL uRL44 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January -1", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-11L), "13-June-2019", "December", (java.lang.Class) wildcardClass33);
        timeSeries45.setMaximumItemAge((long) 2019);
        java.lang.Class class48 = timeSeries45.getTimePeriodClass();
        int int49 = timeSeriesDataItem16.compareTo((java.lang.Object) timeSeries45);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-11L) + "'", number19.equals((-11L)));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(uRL43);
        org.junit.Assert.assertNull(uRL44);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("ClassContext");
        int int22 = fixedMillisecond17.compareTo((java.lang.Object) "ClassContext");
        int int23 = year13.compareTo((java.lang.Object) "ClassContext");
        int int24 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62167363200001L) + "'", long14 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setMaximumItemCount(0);
        timeSeries1.removeAgedItems(2019L, false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(1, year20);
        java.lang.Number number33 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = serialDate9.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(9, serialDate14);
        serialDate18.setDescription("31-January-9999");
        org.jfree.data.time.SerialDate serialDate22 = serialDate18.getNearestDayOfWeek((int) (byte) 1);
        boolean boolean23 = timeSeries1.equals((java.lang.Object) (byte) 1);
        timeSeries1.setDescription("");
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date29 = spreadsheetDate2.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int33 = fixedMillisecond31.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException35 = new org.jfree.data.general.SeriesException("ClassContext");
        int int36 = fixedMillisecond31.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem38.getPeriod();
        int int41 = timeSeriesDataItem38.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        boolean boolean47 = timeSeriesDataItem38.equals((java.lang.Object) serialDate46);
        int int48 = spreadsheetDate2.compare(serialDate46);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-2958096) + "'", int48 == (-2958096));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries2.setMaximumItemCount(0);
        java.lang.Class<?> wildcardClass5 = timeSeries2.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3, (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries7.setNotify(true);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        long long26 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        timeSeries28.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int34 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener35);
        java.util.Collection collection37 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries7.setDomainDescription("");
        java.lang.String str40 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getYear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate22 = serialDate14.getEndOfCurrentMonth(serialDate19);
        boolean boolean23 = day3.equals((java.lang.Object) serialDate22);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int33 = month31.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (double) (-1));
        timeSeries28.removeAgedItems(false);
        java.lang.Class class38 = timeSeries28.getTimePeriodClass();
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "January -1", "", class38);
        java.lang.String str41 = serialDate22.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-January-9999" + "'", str41.equals("31-January-9999"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        boolean boolean32 = month12.equals((java.lang.Object) year20);
        boolean boolean33 = year7.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year7.previous();
        int int35 = year7.getYear();
        java.lang.String str36 = year7.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2" + "'", str36.equals("2"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str21 = day20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        java.lang.Number number23 = null;
        timeSeries1.add(regularTimePeriod22, number23);
        timeSeries1.setNotify(false);
        java.lang.String str27 = timeSeries1.getDescription();
        timeSeries1.removeAgedItems((long) (-683), false);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int37 = month35.compareTo((java.lang.Object) 2);
        java.util.Date date38 = month35.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, year39);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int50 = month48.compareTo((java.lang.Object) 2);
        java.util.Date date51 = month48.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        long long53 = year52.getLastMillisecond();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, year52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int58 = fixedMillisecond56.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException60 = new org.jfree.data.general.SeriesException("ClassContext");
        int int61 = fixedMillisecond56.compareTo((java.lang.Object) "ClassContext");
        int int62 = year52.compareTo((java.lang.Object) "ClassContext");
        long long63 = year52.getLastMillisecond();
        boolean boolean64 = month44.equals((java.lang.Object) year52);
        boolean boolean65 = year39.equals((java.lang.Object) month44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year39.previous();
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(12, year39);
        java.lang.Number number68 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year39);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2-January-9999" + "'", str21.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62167363200001L) + "'", long40 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62167363200001L) + "'", long53 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-62167363200001L) + "'", long63 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNull(number68);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries7.setNotify(true);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        java.lang.Object obj31 = null;
        boolean boolean32 = day29.equals(obj31);
        int int33 = day29.getYear();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate45 = day44.getSerialDate();
        org.jfree.data.time.SerialDate serialDate47 = serialDate45.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate48 = serialDate40.getEndOfCurrentMonth(serialDate45);
        boolean boolean49 = day29.equals((java.lang.Object) serialDate48);
        int int50 = day29.getMonth();
        java.lang.Number number51 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day29);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9999 + "'", int33 == 9999);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year7.previous();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year7.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(9, serialDate13);
        java.lang.String str18 = serialDate13.toString();
        serialDate13.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(0, serialDate13);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-9999" + "'", str18.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1900 + "'", comparable5.equals(1900));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        timeSeries10.setNotify(true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 0.0f);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Saturday" + "'", str1.equals("Saturday"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getLastMillisecond();
        java.util.Date date7 = month2.getEnd();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.Throwable[] throwableArray17 = seriesException14.getSuppressed();
        java.lang.Class<?> wildcardClass18 = throwableArray17.getClass();
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
        seriesException20.addSuppressed((java.lang.Throwable) seriesException23);
        java.lang.Throwable[] throwableArray26 = seriesException23.getSuppressed();
        java.lang.Class<?> wildcardClass27 = throwableArray26.getClass();
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass27);
        java.io.InputStream inputStream29 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass27);
        int int30 = month2.compareTo((java.lang.Object) wildcardClass27);
        int int31 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62101526400001L) + "'", long6 == (-62101526400001L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(inputStream29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Date date9 = year8.getStart();
        long long10 = year8.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year8.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        java.lang.Class<?> wildcardClass13 = throwableArray12.getClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone21);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass13);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January -1", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-11L), "13-June-2019", "December", (java.lang.Class) wildcardClass13);
        timeSeries25.setMaximumItemAge((long) 2019);
        java.lang.Comparable comparable28 = timeSeries25.getKey();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-11L) + "'", comparable28.equals((-11L)));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str53 = day52.toString();
        long long54 = day52.getLastMillisecond();
        int int55 = day52.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate56 = day52.getSerialDate();
        boolean boolean57 = spreadsheetDate2.isAfter(serialDate56);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2-January-9999" + "'", str53.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 253370966399999L + "'", long54 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        int int12 = year8.compareTo((java.lang.Object) class11);
        long long13 = year8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setMaximumItemCount((int) (short) 100);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond16.getMiddleMillisecond(calendar21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy(regularTimePeriod14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        java.lang.String str7 = fixedMillisecond1.toString();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str7.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        try {
            timeSeries1.add(regularTimePeriod10, (double) 0L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        boolean boolean14 = timeSeries13.isEmpty();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.next();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "hi!", "January -1", class24);
        timeSeries25.setRangeDescription("Oct");
        timeSeries25.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int35 = month33.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean41 = fixedMillisecond39.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int46 = fixedMillisecond44.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException48 = new org.jfree.data.general.SeriesException("ClassContext");
        int int49 = fixedMillisecond44.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date50 = fixedMillisecond44.getTime();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, 0.0d);
        java.lang.Number number54 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) year51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January -1" + "'", str18.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNull(number54);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        java.util.Date date9 = month6.getEnd();
        long long10 = month6.getFirstMillisecond();
        long long11 = month6.getSerialIndex();
        int int12 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62198899200000L) + "'", long10 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-11L) + "'", long11 == (-11L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int29 = month27.compareTo((java.lang.Object) 2);
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, year31);
        long long34 = year31.getSerialIndex();
        long long35 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (double) (short) 1);
        long long38 = year31.getSerialIndex();
        java.util.Calendar calendar39 = null;
        try {
            long long40 = year31.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62167363200001L) + "'", long32 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2L + "'", long38 == 2L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Date date15 = fixedMillisecond7.getTime();
        java.util.Date date16 = fixedMillisecond7.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        long long7 = month3.getLastMillisecond();
        java.util.Date date8 = month3.getEnd();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        seriesException12.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.Throwable[] throwableArray18 = seriesException15.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        seriesException21.addSuppressed((java.lang.Throwable) seriesException24);
        java.lang.Throwable[] throwableArray27 = seriesException24.getSuppressed();
        java.lang.Class<?> wildcardClass28 = throwableArray27.getClass();
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass19, (java.lang.Class) wildcardClass28);
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass28);
        int int31 = month3.compareTo((java.lang.Object) wildcardClass28);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Second", (java.lang.Class) wildcardClass28);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62101526400001L) + "'", long7 == (-62101526400001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(inputStream30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("2-October-9999", (java.lang.Class) wildcardClass10);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        java.lang.Object obj13 = seriesChangeEvent11.getSource();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent11);
        java.lang.String str15 = seriesChangeEvent11.toString();
        java.lang.Object obj16 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + 1L + "'", obj12.equals(1L));
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + 1L + "'", obj13.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + 1L + "'", obj16.equals(1L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("ClassContext");
        int int7 = fixedMillisecond2.compareTo((java.lang.Object) "ClassContext");
        long long8 = fixedMillisecond2.getLastMillisecond();
        java.util.Date date9 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date0, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "hi!", "January -1", class17);
        int int19 = month7.compareTo((java.lang.Object) class17);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        seriesException21.addSuppressed((java.lang.Throwable) seriesException24);
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray29 = seriesException28.getSuppressed();
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray32 = seriesException31.getSuppressed();
        seriesException28.addSuppressed((java.lang.Throwable) seriesException31);
        seriesException21.addSuppressed((java.lang.Throwable) seriesException31);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray37 = seriesException36.getSuppressed();
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray40 = seriesException39.getSuppressed();
        seriesException36.addSuppressed((java.lang.Throwable) seriesException39);
        seriesException31.addSuppressed((java.lang.Throwable) seriesException36);
        java.lang.Throwable[] throwableArray43 = seriesException36.getSuppressed();
        int int44 = month7.compareTo((java.lang.Object) seriesException36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -1" + "'", str11.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("ClassContext");
        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        boolean boolean18 = day3.equals((java.lang.Object) timeSeriesDataItem16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        java.lang.Object obj27 = null;
        boolean boolean28 = day25.equals(obj27);
        int int29 = day25.getYear();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        boolean boolean45 = day25.equals((java.lang.Object) serialDate44);
        int int46 = spreadsheetDate21.compare(serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
        java.lang.String str53 = serialDate52.toString();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate58 = day57.getSerialDate();
        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate61 = serialDate52.getEndOfCurrentMonth(serialDate58);
        boolean boolean62 = spreadsheetDate21.isOnOrAfter(serialDate58);
        int int63 = timeSeriesDataItem16.compareTo((java.lang.Object) spreadsheetDate21);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9999 + "'", int29 == 9999);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-2958125) + "'", int46 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2-January-9999" + "'", str53.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62198899200000L) + "'", long7 == (-62198899200000L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.setMaximumItemCount((int) (short) 100);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        int int14 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray19 = seriesException18.getSuppressed();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        seriesException18.addSuppressed((java.lang.Throwable) seriesException21);
        seriesException11.addSuppressed((java.lang.Throwable) seriesException21);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException11);
        boolean boolean26 = fixedMillisecond1.equals((java.lang.Object) seriesException11);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond1.getMiddleMillisecond(calendar27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        timeSeries1.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.lang.String str27 = timeSeries13.getDescription();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int32 = day31.getMonth();
        java.lang.Number number33 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day31);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries13.createCopy((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries17.createCopy(8, 2147483647);
        boolean boolean41 = timeSeries17.isEmpty();
        java.util.Collection collection42 = timeSeries17.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date14);
        long long20 = fixedMillisecond19.getSerialIndex();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62198899200000L) + "'", long20 == (-62198899200000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getLastMillisecond();
        int int7 = month2.getYearValue();
        long long8 = month2.getSerialIndex();
        long long9 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62101526400001L) + "'", long6 == (-62101526400001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-11L) + "'", long8 == (-11L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-11L) + "'", long9 == (-11L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        long long8 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2958102L + "'", long8 == 2958102L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        int int9 = timeSeries1.getItemCount();
        java.lang.Object obj10 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, number14);
        timeSeries1.add(timeSeriesDataItem15, false);
        java.util.List list18 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        timeSeries29.setRangeDescription("ThreadContext");
        java.lang.String str33 = timeSeries29.getRangeDescription();
        java.util.List list34 = timeSeries29.getItems();
        java.util.Collection collection35 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries27.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ThreadContext" + "'", str33.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str13 = day12.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str16 = timeSeries15.getDescription();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int21 = day20.getYear();
        java.lang.Number number22 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day20, number22, false);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int31 = month29.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month29, (double) (-1));
        java.lang.String str34 = timeSeries26.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond36.getLastMillisecond(calendar39);
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        long long43 = month42.getLastMillisecond();
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries15.addAndOrUpdate(timeSeries26);
        boolean boolean46 = day12.equals((java.lang.Object) timeSeries26);
        java.lang.String str47 = day12.toString();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int51 = month50.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month50.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries53 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day12, regularTimePeriod52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2-January-9999" + "'", str13.equals("2-January-9999"));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9999 + "'", int21 == 9999);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2-January-9999" + "'", str47.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNull(regularTimePeriod52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        org.jfree.data.time.SerialDate serialDate58 = serialDate32.getFollowingDayOfWeek(4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate58);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Oct");
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timeSeries1.getDescription();
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("ClassContext");
        int int11 = fixedMillisecond6.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) (-11L));
        timeSeriesDataItem13.setValue((java.lang.Number) 253373385600000L);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        boolean boolean19 = timeSeriesDataItem13.equals((java.lang.Object) seriesException17);
        try {
            timeSeries1.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        timeSeriesDataItem8.setValue((java.lang.Number) 253373385600000L);
        java.lang.Object obj11 = timeSeriesDataItem8.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        java.lang.Object obj12 = null;
        boolean boolean13 = day10.equals(obj12);
        int int14 = day10.getYear();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate29 = serialDate21.getEndOfCurrentMonth(serialDate26);
        boolean boolean30 = day10.equals((java.lang.Object) serialDate29);
        int int31 = spreadsheetDate6.compare(serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate32);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate40);
        boolean boolean46 = spreadsheetDate1.isInRange(serialDate32, serialDate44, (int) (byte) 100);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate51 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate58 = day57.getSerialDate();
        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate61 = serialDate53.getEndOfCurrentMonth(serialDate58);
        java.lang.String str62 = serialDate61.toString();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate61);
        boolean boolean64 = spreadsheetDate1.isBefore(serialDate61);
        try {
            org.jfree.data.time.SerialDate serialDate66 = serialDate61.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9999 + "'", int14 == 9999);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-2958125) + "'", int31 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31-January-9999" + "'", str62.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62150212800001L) + "'", long4 == (-62150212800001L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.lang.String str9 = year8.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.setMaximumItemAge((long) 11);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.setMaximumItemCount((int) (short) 10);
        boolean boolean29 = timeSeries13.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int7 = month5.compareTo((java.lang.Object) 2);
        java.util.Date date8 = month5.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, year9);
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        java.util.Date date18 = month15.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=9]", (java.lang.Class) wildcardClass12);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray28 = seriesException27.getSuppressed();
        seriesException24.addSuppressed((java.lang.Throwable) seriesException27);
        java.lang.Throwable[] throwableArray30 = seriesException27.getSuppressed();
        java.lang.Class<?> wildcardClass31 = throwableArray30.getClass();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int36 = month34.compareTo((java.lang.Object) 2);
        java.util.Date date37 = month34.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date37);
        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray46 = seriesException45.getSuppressed();
        org.jfree.data.general.SeriesException seriesException48 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray49 = seriesException48.getSuppressed();
        seriesException45.addSuppressed((java.lang.Throwable) seriesException48);
        java.lang.Throwable[] throwableArray51 = seriesException48.getSuppressed();
        java.lang.Class<?> wildcardClass52 = throwableArray51.getClass();
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray55 = seriesException54.getSuppressed();
        org.jfree.data.general.SeriesException seriesException57 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray58 = seriesException57.getSuppressed();
        seriesException54.addSuppressed((java.lang.Throwable) seriesException57);
        java.lang.Throwable[] throwableArray60 = seriesException57.getSuppressed();
        java.lang.Class<?> wildcardClass61 = throwableArray60.getClass();
        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass52, (java.lang.Class) wildcardClass61);
        java.io.InputStream inputStream63 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass61);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date37, (java.lang.Class) wildcardClass61);
        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass61);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167363200001L) + "'", long10 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNull(inputStream22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertNull(inputStream63);
        org.junit.Assert.assertNull(obj65);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        long long24 = month11.getFirstMillisecond();
        long long25 = month11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) 253370966399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62198899200000L) + "'", long24 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62198899200000L) + "'", long25 == (-62198899200000L));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries2.setMaximumItemCount(0);
        java.lang.Class<?> wildcardClass5 = timeSeries2.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("ClassContext");
        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date20 = fixedMillisecond14.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        int int25 = year21.compareTo((java.lang.Object) class24);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray32 = seriesException31.getSuppressed();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray35 = seriesException34.getSuppressed();
        seriesException31.addSuppressed((java.lang.Throwable) seriesException34);
        java.lang.Throwable[] throwableArray37 = seriesException34.getSuppressed();
        java.lang.Class<?> wildcardClass38 = throwableArray37.getClass();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int43 = month41.compareTo((java.lang.Object) 2);
        java.util.Date date44 = month41.getStart();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone46);
        java.net.URL uRL48 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass38);
        org.jfree.data.general.SeriesException seriesException51 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray52 = seriesException51.getSuppressed();
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray55 = seriesException54.getSuppressed();
        seriesException51.addSuppressed((java.lang.Throwable) seriesException54);
        java.lang.Throwable[] throwableArray57 = seriesException54.getSuppressed();
        java.lang.Class<?> wildcardClass58 = throwableArray57.getClass();
        java.net.URL uRL59 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass58);
        java.lang.Object obj60 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass38, (java.lang.Class) wildcardClass58);
        java.lang.ClassLoader classLoader61 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass58);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21, "", "ThreadContext", (java.lang.Class) wildcardClass58);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int68 = month66.compareTo((java.lang.Object) 2);
        java.util.Date date69 = month66.getStart();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date69);
        long long71 = year70.getLastMillisecond();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (short) 1, year70);
        java.lang.Class<?> wildcardClass73 = month72.getClass();
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int78 = month76.compareTo((java.lang.Object) 2);
        java.util.Date date79 = month76.getStart();
        java.util.TimeZone timeZone80 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date79, timeZone80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int85 = fixedMillisecond83.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException87 = new org.jfree.data.general.SeriesException("ClassContext");
        int int88 = fixedMillisecond83.compareTo((java.lang.Object) "ClassContext");
        long long89 = fixedMillisecond83.getLastMillisecond();
        java.util.Date date90 = fixedMillisecond83.getTime();
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date90, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date79, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone91);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(uRL48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNull(uRL59);
        org.junit.Assert.assertNull(obj60);
        org.junit.Assert.assertNotNull(classLoader61);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-62167363200001L) + "'", long71 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-1L) + "'", long89 == (-1L));
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        timeSeries14.setRangeDescription("ThreadContext");
        java.lang.String str18 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int25 = month23.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) (-1));
        java.lang.String str28 = timeSeries20.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean32 = fixedMillisecond30.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond30.getLastMillisecond(calendar33);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        timeSeries20.setNotify(true);
        java.util.Collection collection38 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        long long39 = timeSeries20.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
        timeSeries41.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int47 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener48);
        java.util.Collection collection50 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries41);
        timeSeries20.setDomainDescription("");
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        java.lang.Object obj58 = null;
        boolean boolean59 = day56.equals(obj58);
        int int60 = day56.getYear();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
        org.jfree.data.time.SerialDate serialDate67 = serialDate65.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate72 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate75 = serialDate67.getEndOfCurrentMonth(serialDate72);
        boolean boolean76 = day56.equals((java.lang.Object) serialDate75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (java.lang.Number) (-62167363200001L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int82 = fixedMillisecond80.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException84 = new org.jfree.data.general.SeriesException("ClassContext");
        int int85 = fixedMillisecond80.compareTo((java.lang.Object) "ClassContext");
        long long86 = fixedMillisecond80.getLastMillisecond();
        java.util.Date date87 = fixedMillisecond80.getTime();
        long long88 = fixedMillisecond80.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) day56, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ThreadContext" + "'", str18.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9999 + "'", int60 == 9999);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-1L) + "'", long86 == (-1L));
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-1L) + "'", long88 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries89);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) -1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        timeSeriesDataItem8.setValue((java.lang.Number) 253373385600000L);
        timeSeriesDataItem8.setValue((java.lang.Number) (-11L));
        java.lang.Number number13 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-11L) + "'", number13.equals((-11L)));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        java.lang.Object obj7 = null;
        boolean boolean8 = day5.equals(obj7);
        int int9 = day5.getYear();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate24 = serialDate16.getEndOfCurrentMonth(serialDate21);
        boolean boolean25 = day5.equals((java.lang.Object) serialDate24);
        int int26 = spreadsheetDate1.compare(serialDate24);
        int int27 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate36.getDescription();
        java.lang.String str46 = serialDate36.getDescription();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate51 = day50.getSerialDate();
        java.lang.String str52 = serialDate51.toString();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate60 = serialDate51.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = serialDate36.getEndOfCurrentMonth(serialDate60);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate67 = day66.getSerialDate();
        org.jfree.data.time.SerialDate serialDate69 = serialDate67.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate74 = day73.getSerialDate();
        org.jfree.data.time.SerialDate serialDate76 = serialDate74.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate77 = serialDate69.getEndOfCurrentMonth(serialDate74);
        java.lang.String str78 = serialDate69.getDescription();
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addMonths(3, serialDate69);
        serialDate79.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate83 = serialDate79.getPreviousDayOfWeek(3);
        boolean boolean84 = spreadsheetDate29.isInRange(serialDate60, serialDate79);
        boolean boolean85 = spreadsheetDate1.isOn(serialDate79);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9999 + "'", int9 == 9999);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-2958125) + "'", int26 == (-2958125));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2-January-9999" + "'", str52.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        int int11 = year6.compareTo((java.lang.Object) 7);
        long long12 = year6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int19 = month17.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) (-1));
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long25 = month24.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.previous();
        java.lang.String str27 = month24.toString();
        long long28 = month24.getSerialIndex();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        java.lang.Object obj34 = null;
        boolean boolean35 = day32.equals(obj34);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month24, (org.jfree.data.time.RegularTimePeriod) day32);
        int int37 = year6.compareTo((java.lang.Object) day32);
        long long38 = year6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62198899200000L) + "'", long25 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "January -1" + "'", str27.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-11L) + "'", long28 == (-11L));
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62167363200001L) + "'", long38 == (-62167363200001L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        timeSeries1.setMaximumItemCount((int) '#');
        timeSeries1.removeAgedItems((long) (byte) 0, false);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        java.lang.Object obj7 = null;
        boolean boolean8 = day5.equals(obj7);
        int int9 = day5.getYear();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate24 = serialDate16.getEndOfCurrentMonth(serialDate21);
        boolean boolean25 = day5.equals((java.lang.Object) serialDate24);
        int int26 = spreadsheetDate1.compare(serialDate24);
        int int27 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate43 = serialDate35.getEndOfCurrentMonth(serialDate40);
        org.jfree.data.time.SerialDate serialDate45 = serialDate40.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(2, serialDate45);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate52.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate59 = day58.getSerialDate();
        org.jfree.data.time.SerialDate serialDate61 = serialDate59.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate62 = serialDate54.getEndOfCurrentMonth(serialDate59);
        java.lang.String str63 = serialDate54.getDescription();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addMonths(3, serialDate54);
        org.jfree.data.time.SerialDate serialDate65 = serialDate45.getEndOfCurrentMonth(serialDate54);
        int int66 = spreadsheetDate1.compare(serialDate54);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9999 + "'", int9 == 9999);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-2958125) + "'", int26 == (-2958125));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-2958095) + "'", int66 == (-2958095));
    }
}

