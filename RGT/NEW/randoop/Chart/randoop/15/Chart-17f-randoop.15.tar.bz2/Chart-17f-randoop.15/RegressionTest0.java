import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("2-January-9999", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException8);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        try {
            timeSeries1.update(9, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(9, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond4.getLastMillisecond(calendar7);
        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) (byte) 10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 100.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, (int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            int int4 = timeSeries1.getIndex(regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 2, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(9, serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate18 = serialDate12.getPreviousDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.lang.String str5 = month2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January -1" + "'", str5.equals("January -1"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (-11L));
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        try {
            org.jfree.data.time.Year year7 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("ClassContext");
        int int13 = fixedMillisecond8.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        try {
            java.lang.Number number8 = timeSeries1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("ClassContext");
        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        boolean boolean18 = day3.equals((java.lang.Object) timeSeriesDataItem16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day3.next();
        java.lang.Object obj20 = null;
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) regularTimePeriod19, obj20);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            timeSeries1.add(regularTimePeriod14, (double) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month2.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(9, serialDate12);
        serialDate16.setDescription("31-January-9999");
        java.lang.String str19 = serialDate16.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2-October-9999" + "'", str19.equals("2-October-9999"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate4.getFollowingDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        try {
            org.jfree.data.time.Year year6 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        try {
            java.lang.Number number6 = timeSeries1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-11L));
        try {
            timeSeries1.add(timeSeriesDataItem19, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, 1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 5, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        int int3 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date6, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(uRL4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int8 = month6.compareTo((java.lang.Object) 2);
        java.util.Date date9 = month6.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, year10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("ClassContext");
        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "ClassContext");
        int int20 = year10.compareTo((java.lang.Object) "ClassContext");
        long long21 = year10.getLastMillisecond();
        boolean boolean22 = month2.equals((java.lang.Object) year10);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = year10.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167363200001L) + "'", long11 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Oct");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str7.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        try {
            org.jfree.data.time.Year year15 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getLastMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond7.getLastMillisecond(calendar15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        int int18 = year8.compareTo((java.lang.Object) "ClassContext");
        long long19 = year8.getLastMillisecond();
        try {
            org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1900, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        int int18 = year8.compareTo((java.lang.Object) "ClassContext");
        long long19 = year8.getLastMillisecond();
        java.util.Date date20 = year8.getStart();
        try {
            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(2019, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray3 = seriesException2.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        seriesException2.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray8 = seriesException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = throwableArray8.getClass();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int14 = month12.compareTo((java.lang.Object) 2);
        java.util.Date date15 = month12.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone17);
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("2-January-9999", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(inputStream19);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = year7.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        java.util.Date date43 = month40.getStart();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        long long45 = year44.getLastMillisecond();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62167363200001L) + "'", long45 == (-62167363200001L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.String str15 = seriesException11.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        try {
            java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        int int2 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Comparable comparable9 = null;
        try {
            timeSeries1.setKey(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(9, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.addChangeListener(seriesChangeListener32);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries31.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = year7.getSerialIndex();
        long long11 = year7.getSerialIndex();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-January-9999");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass10);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        long long5 = day3.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            day3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1));
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month13, (double) 12);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int11 = timeSeriesDataItem8.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = timeSeriesDataItem8.equals((java.lang.Object) serialDate16);
        timeSeriesDataItem8.setValue((java.lang.Number) 1561964399999L);
        java.lang.Number number20 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1561964399999L + "'", number20.equals(1561964399999L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        int int11 = day6.getMonth();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int30 = fixedMillisecond28.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("ClassContext");
        int int33 = fixedMillisecond28.compareTo((java.lang.Object) "ClassContext");
        long long34 = fixedMillisecond28.getLastMillisecond();
        java.util.Date date35 = fixedMillisecond28.getTime();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond28.getMiddleMillisecond(calendar36);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate15);
        java.lang.String str17 = serialDate16.getDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        timeSeries13.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        try {
            timeSeries17.delete(10, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        java.lang.Object obj13 = seriesChangeEvent11.getSource();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) seriesChangeEvent11);
        long long15 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + 1L + "'", obj12.equals(1L));
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + 1L + "'", obj13.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=9]");
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        int int6 = month3.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond8.getLastMillisecond(calendar11);
        boolean boolean14 = fixedMillisecond8.equals((java.lang.Object) (byte) 10);
        boolean boolean15 = month3.equals((java.lang.Object) fixedMillisecond8);
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "ClassContext", (java.lang.Object) boolean15);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62198899200000L) + "'", long4 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int11 = fixedMillisecond9.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("ClassContext");
        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        int int19 = timeSeriesDataItem16.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        boolean boolean25 = timeSeriesDataItem16.equals((java.lang.Object) serialDate24);
        timeSeriesDataItem16.setValue((java.lang.Number) 1561964399999L);
        try {
            timeSeries1.add(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January -1" + "'", str6.equals("January -1"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        timeSeriesDataItem9.setValue((java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate5.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((-1898), serialDate5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2-January-9999" + "'", str6.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        java.util.Date date15 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        java.lang.Number number10 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 10 + "'", number10.equals((byte) 10));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month12.getMonth();
        boolean boolean14 = fixedMillisecond1.equals((java.lang.Object) month12);
        java.util.Calendar calendar15 = null;
        fixedMillisecond1.peg(calendar15);
        long long17 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            int int12 = timeSeries1.getIndex(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int11 = timeSeriesDataItem8.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = timeSeriesDataItem8.equals((java.lang.Object) serialDate16);
        timeSeriesDataItem8.setValue((java.lang.Number) 1561964399999L);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        seriesException21.addSuppressed((java.lang.Throwable) seriesException24);
        java.lang.Throwable[] throwableArray27 = seriesException24.getSuppressed();
        java.lang.Class<?> wildcardClass28 = throwableArray27.getClass();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int33 = month31.compareTo((java.lang.Object) 2);
        java.util.Date date34 = month31.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34);
        int int39 = year38.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year38);
        int int41 = timeSeriesDataItem8.compareTo((java.lang.Object) year38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long8 = month7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        int int10 = month7.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getLastMillisecond(calendar15);
        boolean boolean18 = fixedMillisecond12.equals((java.lang.Object) (byte) 10);
        boolean boolean19 = month7.equals((java.lang.Object) fixedMillisecond12);
        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month7);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62198899200000L) + "'", long8 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        long long8 = month2.getSerialIndex();
        try {
            org.jfree.data.time.Year year9 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-11L) + "'", long8 == (-11L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = serialDate13.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(2, serialDate18);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate35 = serialDate27.getEndOfCurrentMonth(serialDate32);
        java.lang.String str36 = serialDate27.getDescription();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(3, serialDate27);
        org.jfree.data.time.SerialDate serialDate38 = serialDate18.getEndOfCurrentMonth(serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, serialDate38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2019);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.setRangeDescription("ThreadContext");
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.clear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries11.getTimePeriod(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 29, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ThreadContext" + "'", str15.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate6.getDescription();
        java.lang.String str16 = serialDate6.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate18 = serialDate6.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries12.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int22 = fixedMillisecond20.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("ClassContext");
        int int25 = fixedMillisecond20.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem27.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        long long5 = day3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.removeAgedItems(1L, false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNotNull(class2);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getLastMillisecond();
//        long long8 = day3.getSerialIndex();
//        int int9 = day3.getMonth();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        java.lang.String str17 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate15.toString();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-January-9999" + "'", str16.equals("31-January-9999"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        boolean boolean32 = month12.equals((java.lang.Object) year20);
        boolean boolean33 = year7.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year7.previous();
        java.util.Calendar calendar35 = null;
        try {
            year7.peg(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.Date date8 = fixedMillisecond6.getEnd();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        long long20 = day18.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-January-9999" + "'", str17.equals("31-January-9999"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 253373385600000L + "'", long20 == 253373385600000L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.removeAgedItems((long) 2019, true);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        int int5 = day3.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.String str8 = fixedMillisecond6.toString();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str8.equals("Wed Dec 31 15:59:59 PST 1969"));
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getLastMillisecond();
//        long long8 = day3.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day3.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        int int17 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        java.lang.Object obj7 = null;
        int int8 = timeSeriesDataItem5.compareTo(obj7);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate17 = serialDate12.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(2, serialDate17);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate34 = serialDate26.getEndOfCurrentMonth(serialDate31);
        java.lang.String str35 = serialDate26.getDescription();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        org.jfree.data.time.SerialDate serialDate37 = serialDate17.getEndOfCurrentMonth(serialDate26);
        java.lang.String str38 = serialDate37.getDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate22 = serialDate14.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.SerialDate serialDate24 = serialDate19.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(2, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = serialDate6.getEndOfCurrentMonth(serialDate24);
        try {
            org.jfree.data.time.SerialDate serialDate28 = serialDate26.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 9 + "'", obj2.equals(9));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 9 + "'", obj3.equals(9));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long17 = month16.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (double) 0.0f);
        try {
            timeSeries13.add(timeSeriesDataItem19, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62198899200000L) + "'", long17 == (-62198899200000L));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day3.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        try {
            timeSeries37.update(1, (java.lang.Number) (-1898));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(inputStream21);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("April");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62167363200001L) + "'", long14 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        long long5 = day3.getLastMillisecond();
        int int6 = day3.getDayOfMonth();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        int int12 = month9.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond14.getLastMillisecond(calendar17);
        boolean boolean20 = fixedMillisecond14.equals((java.lang.Object) (byte) 10);
        boolean boolean21 = month9.equals((java.lang.Object) fixedMillisecond14);
        boolean boolean22 = day3.equals((java.lang.Object) boolean21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day3.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62198899200000L) + "'", long10 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date17 = fixedMillisecond11.getTime();
        long long18 = fixedMillisecond11.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setNotify(true);
        timeSeries1.setDomainDescription("Sunday");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            java.lang.Number number12 = timeSeries1.getValue(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(11, 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (-1898), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        int int8 = month2.getMonth();
        int int9 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray8 = seriesException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-460));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-572) + "'", int1 == (-572));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        java.util.Calendar calendar24 = null;
        try {
            day19.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        java.lang.String str17 = serialDate7.getDescription();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        java.lang.String str23 = serialDate22.toString();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate28 = day27.getSerialDate();
        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate31 = serialDate22.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = serialDate7.getEndOfCurrentMonth(serialDate31);
        try {
            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears((int) '#', serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-9999" + "'", str23.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("January -1");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ERROR : Relative To String");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate6.getDescription();
        java.lang.String str16 = serialDate6.getDescription();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = serialDate21.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = serialDate6.getEndOfCurrentMonth(serialDate30);
        try {
            org.jfree.data.time.SerialDate serialDate33 = serialDate6.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2-January-9999" + "'", str22.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        try {
            java.lang.Number number11 = timeSeries1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate23 = serialDate15.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate25 = serialDate20.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(2, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = serialDate7.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate35 = serialDate25.getEndOfCurrentMonth(serialDate32);
        try {
            org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
//        java.lang.String str9 = day3.toString();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate17 = serialDate12.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(2, serialDate17);
        java.lang.String str19 = serialDate17.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "7-January-9999" + "'", str19.equals("7-January-9999"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate13 = serialDate4.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate4);
        java.lang.String str15 = day14.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2-January-9999" + "'", str15.equals("2-January-9999"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        long long5 = day3.getLastMillisecond();
        int int6 = day3.getDayOfMonth();
        long long7 = day3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2958102L + "'", long7 == 2958102L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 9);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=9]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.List list8 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate15.toString();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(8, serialDate15);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-January-9999" + "'", str16.equals("31-January-9999"));
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        java.lang.Class class6 = null;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1561964399999L);
        java.lang.Class class18 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries1.update(regularTimePeriod19, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        java.lang.Number number57 = null;
        try {
            timeSeries37.update((int) (byte) 100, number57);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-460), 2958465, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        java.lang.String str7 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        java.lang.String str5 = day3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.previous();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (-1.0d), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries1.delete(regularTimePeriod6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        java.lang.String str5 = day3.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-9999" + "'", str5.equals("2-January-9999"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 3);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        int int23 = day19.getDayOfMonth();
        long long24 = day19.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 2958102L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2-January-9999 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 253370880000000L + "'", long24 == 253370880000000L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate14.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        long long17 = day16.getSerialIndex();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day16.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-January-9999" + "'", str15.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2958131L + "'", long17 == 2958131L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        boolean boolean32 = month12.equals((java.lang.Object) year20);
        boolean boolean33 = year7.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year7.previous();
        long long35 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62167363200001L) + "'", long35 == (-62167363200001L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long10 = year7.getSerialIndex();
        long long11 = year7.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            year7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167363200001L) + "'", long11 == (-62167363200001L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        java.util.Collection collection20 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
        org.junit.Assert.assertNotNull(collection20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(5);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        int int11 = timeSeriesDataItem8.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        boolean boolean17 = timeSeriesDataItem8.equals((java.lang.Object) serialDate16);
        java.lang.String str18 = serialDate16.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-9999" + "'", str18.equals("2-January-9999"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (byte) 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        try {
            java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone(collection9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "January -1", (java.lang.Object) serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate18 = serialDate12.getPreviousDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        java.lang.String str11 = day10.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("ClassContext");
        int int7 = fixedMillisecond2.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date8 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        int int13 = year9.compareTo((java.lang.Object) class12);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray20 = seriesException19.getSuppressed();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray23 = seriesException22.getSuppressed();
        seriesException19.addSuppressed((java.lang.Throwable) seriesException22);
        java.lang.Throwable[] throwableArray25 = seriesException22.getSuppressed();
        java.lang.Class<?> wildcardClass26 = throwableArray25.getClass();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int31 = month29.compareTo((java.lang.Object) 2);
        java.util.Date date32 = month29.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone34);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass26);
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray40 = seriesException39.getSuppressed();
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray43 = seriesException42.getSuppressed();
        seriesException39.addSuppressed((java.lang.Throwable) seriesException42);
        java.lang.Throwable[] throwableArray45 = seriesException42.getSuppressed();
        java.lang.Class<?> wildcardClass46 = throwableArray45.getClass();
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass46);
        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass26, (java.lang.Class) wildcardClass46);
        java.lang.ClassLoader classLoader49 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year9, "", "ThreadContext", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int56 = month54.compareTo((java.lang.Object) 2);
        java.util.Date date57 = month54.getStart();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        long long59 = year58.getLastMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 1, year58);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int66 = month64.compareTo((java.lang.Object) 2);
        java.util.Date date67 = month64.getStart();
        java.util.TimeZone timeZone68 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date67, timeZone68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int73 = fixedMillisecond71.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException75 = new org.jfree.data.general.SeriesException("ClassContext");
        int int76 = fixedMillisecond71.compareTo((java.lang.Object) "ClassContext");
        long long77 = fixedMillisecond71.getLastMillisecond();
        java.util.Date date78 = fixedMillisecond71.getTime();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date67, timeZone79);
        try {
            org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date0, timeZone79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNotNull(classLoader49);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62167363200001L) + "'", long59 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass10);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray18 = seriesException17.getSuppressed();
        seriesException14.addSuppressed((java.lang.Throwable) seriesException17);
        java.lang.Throwable[] throwableArray20 = seriesException17.getSuppressed();
        java.lang.Class<?> wildcardClass21 = throwableArray20.getClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int26 = month24.compareTo((java.lang.Object) 2);
        java.util.Date date27 = month24.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date27, timeZone29);
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass21);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(uRL31);
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        long long23 = fixedMillisecond15.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.String str8 = seriesException4.toString();
        java.lang.String str9 = seriesException4.toString();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException11.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.setRangeDescription("ThreadContext");
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.clear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries11);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str24 = day23.toString();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str27 = timeSeries26.getDescription();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int32 = day31.getYear();
        java.lang.Number number33 = null;
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day31, number33, false);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        long long54 = month53.getLastMillisecond();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) month53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries26.addAndOrUpdate(timeSeries37);
        boolean boolean57 = day23.equals((java.lang.Object) timeSeries37);
        java.lang.String str58 = day23.toString();
        long long59 = day23.getLastMillisecond();
        try {
            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ThreadContext" + "'", str15.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9999 + "'", int32 == 9999);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1561964399999L + "'", long54 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2-January-9999" + "'", str58.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 253370966399999L + "'", long59 == 253370966399999L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("April");
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int9 = year7.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) (-1));
        java.lang.String str19 = timeSeries11.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date27 = fixedMillisecond21.getTime();
        boolean boolean28 = year7.equals((java.lang.Object) fixedMillisecond21);
        long long29 = fixedMillisecond21.getFirstMillisecond();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        try {
            timeSeries1.add(regularTimePeriod23, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries5.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) '#');
//        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("ClassContext");
//        int int13 = fixedMillisecond8.compareTo((java.lang.Object) "ClassContext");
//        long long14 = fixedMillisecond8.getLastMillisecond();
//        java.util.Date date15 = fixedMillisecond8.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond8.next();
//        timeSeries1.delete(regularTimePeriod16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        int int21 = fixedMillisecond19.compareTo((java.lang.Object) '#');
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("ClassContext");
//        int int24 = fixedMillisecond19.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (-11L));
//        timeSeriesDataItem26.setValue((java.lang.Number) 253373385600000L);
//        try {
//            timeSeries1.add(timeSeriesDataItem26, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1L + "'", obj2.equals(1L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1L + "'", obj3.equals(1L));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1L + "'", obj4.equals(1L));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 1L + "'", obj5.equals(1L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, number4);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        java.lang.String str15 = serialDate14.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = day17.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-January-9999" + "'", str15.equals("31-January-9999"));
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        timeSeries57.setRangeDescription("ThreadContext");
        java.lang.String str61 = timeSeries57.getRangeDescription();
        timeSeries57.clear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int64 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str65 = year63.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year63);
        timeSeries37.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ThreadContext" + "'", str61.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int13 = month11.compareTo((java.lang.Object) 2);
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        int int19 = year18.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year18);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year18.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 15:59:59 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str31 = month30.toString();
        int int32 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) month30);
        try {
            java.lang.Number number34 = timeSeries10.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "January -1" + "'", str31.equals("January -1"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.lang.Object obj5 = null;
        boolean boolean6 = day3.equals(obj5);
        int int7 = day3.getYear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate22 = serialDate14.getEndOfCurrentMonth(serialDate19);
        boolean boolean23 = day3.equals((java.lang.Object) serialDate22);
        int int24 = day3.getMonth();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int24);
        java.lang.String str26 = timeSeries25.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, year20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("ClassContext");
        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "ClassContext");
        int int30 = year20.compareTo((java.lang.Object) "ClassContext");
        long long31 = year20.getLastMillisecond();
        boolean boolean32 = month12.equals((java.lang.Object) year20);
        boolean boolean33 = year7.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month12.previous();
        long long35 = month12.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62167363200001L) + "'", long31 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62198899200000L) + "'", long35 == (-62198899200000L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.util.List list6 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Date date19 = year7.getStart();
        java.util.TimeZone timeZone20 = null;
        try {
            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19, timeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("ClassContext");
        int int26 = fixedMillisecond21.compareTo((java.lang.Object) "ClassContext");
        long long27 = fixedMillisecond21.getLastMillisecond();
        java.util.Date date28 = fixedMillisecond21.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond21.next();
        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond21);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-January-9999" + "'", str17.equals("31-January-9999"));
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        try {
            java.lang.String str8 = regularTimePeriod7.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        timeSeries1.clear();
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy(1900, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.String str8 = seriesException4.toString();
        java.lang.String str9 = seriesException4.toString();
        java.lang.String str10 = seriesException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Class class2 = null;
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Class<?> wildcardClass11 = throwableArray10.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January -1", class2, (java.lang.Class) wildcardClass11);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(uRL22);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("ClassContext");
        int int7 = fixedMillisecond2.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date8 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        int int13 = year9.compareTo((java.lang.Object) class12);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray20 = seriesException19.getSuppressed();
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray23 = seriesException22.getSuppressed();
        seriesException19.addSuppressed((java.lang.Throwable) seriesException22);
        java.lang.Throwable[] throwableArray25 = seriesException22.getSuppressed();
        java.lang.Class<?> wildcardClass26 = throwableArray25.getClass();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int31 = month29.compareTo((java.lang.Object) 2);
        java.util.Date date32 = month29.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone34);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass26);
        org.jfree.data.general.SeriesException seriesException39 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray40 = seriesException39.getSuppressed();
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray43 = seriesException42.getSuppressed();
        seriesException39.addSuppressed((java.lang.Throwable) seriesException42);
        java.lang.Throwable[] throwableArray45 = seriesException42.getSuppressed();
        java.lang.Class<?> wildcardClass46 = throwableArray45.getClass();
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass46);
        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass26, (java.lang.Class) wildcardClass46);
        java.lang.ClassLoader classLoader49 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year9, "", "ThreadContext", (java.lang.Class) wildcardClass46);
        java.io.InputStream inputStream51 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Oct", (java.lang.Class) wildcardClass46);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNotNull(classLoader49);
        org.junit.Assert.assertNull(inputStream51);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int4 = day3.getYear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9999 + "'", int4 == 9999);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        serialDate6.setDescription("ERROR : Relative To String");
        java.lang.String str9 = serialDate6.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1-January-9999" + "'", str9.equals("1-January-9999"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("October");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        long long5 = day3.getLastMillisecond();
        int int6 = day3.getDayOfMonth();
        long long7 = day3.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 253370966399999L + "'", long5 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2958102L + "'", long7 == 2958102L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December" + "'", str2.equals("December"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62198899200000L) + "'", long10 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day3, (double) 4);
//        long long7 = day3.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
//        long long9 = day3.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        java.lang.String str14 = month11.toString();
        long long15 = month11.getSerialIndex();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        java.lang.Object obj21 = null;
        boolean boolean22 = day19.equals(obj21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int27 = fixedMillisecond25.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("ClassContext");
        int int30 = fixedMillisecond25.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
        int int35 = timeSeriesDataItem32.compareTo((java.lang.Object) (-62167363200001L));
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate40 = day39.getSerialDate();
        boolean boolean41 = timeSeriesDataItem32.equals((java.lang.Object) serialDate40);
        timeSeriesDataItem32.setValue((java.lang.Number) 1561964399999L);
        try {
            timeSeries1.add(timeSeriesDataItem32, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62198899200000L) + "'", long12 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "January -1" + "'", str14.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-11L) + "'", long15 == (-11L));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        java.lang.Comparable comparable19 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener20);
        try {
            timeSeries1.delete(5, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 1900 + "'", comparable19.equals(1900));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day8.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 0.0f);
        timeSeriesDataItem5.setValue((java.lang.Number) (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "January -1");
        java.lang.String str12 = seriesChangeEvent11.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=January -1]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=January -1]"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int12 = fixedMillisecond10.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("ClassContext");
        int int15 = fixedMillisecond10.compareTo((java.lang.Object) "ClassContext");
        long long16 = fixedMillisecond10.getLastMillisecond();
        java.util.Date date17 = fixedMillisecond10.getTime();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getMiddleMillisecond(calendar18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int26 = month24.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) (-1));
        java.lang.String str29 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond31.getLastMillisecond(calendar34);
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        boolean boolean37 = fixedMillisecond10.equals((java.lang.Object) timeSeries21);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str41 = month40.toString();
        long long42 = month40.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (byte) 1);
        boolean boolean45 = fixedMillisecond6.equals((java.lang.Object) month40);
        java.lang.Number number46 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number46);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "January -1" + "'", str41.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62101526400001L) + "'", long42 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=January -1]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int7 = month5.compareTo((java.lang.Object) 2);
        java.util.Date date8 = month5.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, year9);
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        java.util.Date date18 = month15.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.lang.Class class21 = null;
        java.lang.Object obj22 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass12, class21);
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("31-January-9999", class21);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62167363200001L) + "'", long10 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(inputStream23);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        boolean boolean14 = month2.equals((java.lang.Object) 100.0d);
        java.lang.String str15 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January -1" + "'", str15.equals("January -1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        int int11 = year6.compareTo((java.lang.Object) 7);
        long long12 = year6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62167363200001L) + "'", long12 == (-62167363200001L));
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.lang.String str4 = serialDate3.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.addChangeListener(seriesChangeListener32);
        java.lang.String str34 = timeSeries31.getDescription();
        timeSeries31.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries31.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate7.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, 29, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        boolean boolean14 = month2.equals((java.lang.Object) 100.0d);
        try {
            org.jfree.data.time.Year year15 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("October");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str7 = timeSeries6.getDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int12 = day11.getYear();
        java.lang.Number number13 = null;
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, number13, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int22 = month20.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1));
        java.lang.String str25 = timeSeries17.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond27.getLastMillisecond(calendar30);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getLastMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries6.addAndOrUpdate(timeSeries17);
        boolean boolean37 = day3.equals((java.lang.Object) timeSeries17);
        java.lang.String str38 = day3.toString();
        int int39 = day3.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1561964399999L + "'", long34 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2-January-9999" + "'", str38.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        timeSeries4.setRangeDescription("ThreadContext");
        java.lang.String str8 = timeSeries4.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1));
        java.lang.String str18 = timeSeries10.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean22 = fixedMillisecond20.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond20.getLastMillisecond(calendar23);
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        timeSeries10.setNotify(true);
        java.util.Collection collection28 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        long long29 = timeSeries10.getMaximumItemAge();
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) long29);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ThreadContext" + "'", str8.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1, 5, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = serialDate9.getEndOfCurrentMonth(serialDate14);
        java.lang.String str18 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
        serialDate19.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate23 = serialDate19.getPreviousDayOfWeek(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate41 = serialDate33.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(9, serialDate38);
        java.lang.String str43 = serialDate38.toString();
        boolean boolean44 = spreadsheetDate25.isBefore(serialDate38);
        boolean boolean46 = spreadsheetDate1.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate25, (-460));
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate52 = day51.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate52.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate59 = day58.getSerialDate();
        org.jfree.data.time.SerialDate serialDate61 = serialDate59.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate62 = serialDate54.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.SerialDate serialDate64 = serialDate59.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(2, serialDate64);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate71 = day70.getSerialDate();
        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate78 = day77.getSerialDate();
        org.jfree.data.time.SerialDate serialDate80 = serialDate78.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate81 = serialDate73.getEndOfCurrentMonth(serialDate78);
        java.lang.String str82 = serialDate73.getDescription();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addMonths(3, serialDate73);
        org.jfree.data.time.SerialDate serialDate84 = serialDate64.getEndOfCurrentMonth(serialDate73);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate91 = day90.getSerialDate();
        org.jfree.data.time.SerialDate serialDate93 = serialDate91.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate91);
        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate91);
        boolean boolean97 = spreadsheetDate25.isInRange(serialDate64, serialDate95, (-1));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2-January-9999" + "'", str43.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        java.util.Date date17 = fixedMillisecond11.getTime();
        java.lang.String str18 = fixedMillisecond11.toString();
        long long19 = fixedMillisecond11.getFirstMillisecond();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond11.getMiddleMillisecond(calendar20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str18.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("ThreadContext");
        java.lang.String str19 = timeSeries15.getRangeDescription();
        timeSeries15.clear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        int int23 = year21.getYear();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int30 = month28.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) (-1));
        java.lang.String str33 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getLastMillisecond(calendar38);
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date41 = fixedMillisecond35.getTime();
        boolean boolean42 = year21.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        long long44 = year21.getSerialIndex();
        int int46 = year21.compareTo((java.lang.Object) "13-June-2019");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int9 = year7.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) (-1));
        java.lang.String str19 = timeSeries11.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date27 = fixedMillisecond21.getTime();
        boolean boolean28 = year7.equals((java.lang.Object) fixedMillisecond21);
        java.lang.String str29 = year7.toString();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year7.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        java.lang.String str32 = timeSeries12.getDomainDescription();
        java.util.Collection collection33 = timeSeries12.getTimePeriods();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertNotNull(collection33);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("1-January-9999");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        serialDate18.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate27);
        org.jfree.data.time.SerialDate serialDate32 = serialDate18.getEndOfCurrentMonth(serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-62198899200000L));
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        timeSeries1.setMaximumItemCount(0);
        long long5 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2-January-9999");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str4 = day3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        java.lang.Object obj6 = null;
        boolean boolean7 = day3.equals(obj6);
        long long8 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2-January-9999" + "'", str4.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 253370880000000L + "'", long8 == 253370880000000L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("ClassContext");
        int int26 = fixedMillisecond21.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (-11L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeriesDataItem28.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate(regularTimePeriod29, (double) 4L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNotNull(inputStream21);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.removeAgedItems(253373385600000L, false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries13.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(9, serialDate12);
        serialDate16.setDescription("31-January-9999");
        org.jfree.data.time.SerialDate serialDate20 = serialDate16.getNearestDayOfWeek((int) (byte) 1);
        serialDate20.setDescription("October");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str9 = day8.toString();
        long long10 = day8.getLastMillisecond();
        int int11 = day8.getDayOfMonth();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        int int17 = month14.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getLastMillisecond(calendar22);
        boolean boolean25 = fixedMillisecond19.equals((java.lang.Object) (byte) 10);
        boolean boolean26 = month14.equals((java.lang.Object) fixedMillisecond19);
        boolean boolean27 = day8.equals((java.lang.Object) boolean26);
        int int28 = fixedMillisecond1.compareTo((java.lang.Object) day8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2-January-9999" + "'", str9.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 253370966399999L + "'", long10 == 253370966399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62198899200000L) + "'", long15 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        timeSeries1.setMaximumItemCount(10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries1.removeChangeListener(seriesChangeListener21);
        java.lang.String str23 = timeSeries1.getDomainDescription();
        boolean boolean24 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1898));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-920) + "'", int1 == (-920));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day10.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate16 = serialDate11.getFollowingDayOfWeek(5);
        java.lang.String str17 = serialDate16.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=9]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries7.setNotify(true);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        java.lang.Number number27 = null;
        try {
            timeSeries7.update((int) (short) 100, number27);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        timeSeries1.setDomainDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        long long6 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("ClassContext");
        int int13 = fixedMillisecond8.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-11L));
        timeSeriesDataItem15.setValue((java.lang.Number) 253373385600000L);
        try {
            timeSeries1.add(timeSeriesDataItem15, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        boolean boolean7 = timeSeries1.equals((java.lang.Object) month6);
        java.util.Calendar calendar8 = null;
        try {
            month6.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("ClassContext");
        int int5 = timeSeries1.getItemCount();
        java.lang.Class class6 = null;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int11 = month9.compareTo((java.lang.Object) 2);
        java.util.Date date12 = month9.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1561964399999L);
        java.lang.Class class18 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        boolean boolean28 = fixedMillisecond22.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond22.getMiddleMillisecond(calendar29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int34 = month33.getMonth();
        boolean boolean35 = fixedMillisecond22.equals((java.lang.Object) month33);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.removeAgedItems(true);
        java.lang.String str29 = timeSeries13.getDescription();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        long long35 = day33.getSerialIndex();
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 1900, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2-January-9999 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2958102L + "'", long35 == 2958102L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate17 = serialDate9.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(9, serialDate14);
        java.lang.String str19 = serialDate14.toString();
        boolean boolean20 = spreadsheetDate1.isBefore(serialDate14);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int22 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2-January-9999" + "'", str19.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            timeSeries7.update((int) (byte) 0, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4L + "'", long4 == 4L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4L + "'", long5 == 4L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int18 = month16.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) (-1));
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems((long) (short) -1, false);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries13.removeAgedItems(253373385600000L, false);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str32 = timeSeries31.getDescription();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long36 = month35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.previous();
        int int38 = month35.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean42 = fixedMillisecond40.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond40.getLastMillisecond(calendar43);
        boolean boolean46 = fixedMillisecond40.equals((java.lang.Object) (byte) 10);
        boolean boolean47 = month35.equals((java.lang.Object) fixedMillisecond40);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond40.getFirstMillisecond(calendar48);
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 4L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62198899200000L) + "'", long36 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((-2958125), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        long long23 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond15.getLastMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond15.getTime();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        long long18 = year7.getLastMillisecond();
        java.util.Date date19 = year7.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167363200001L) + "'", long18 == (-62167363200001L));
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int8 = month6.compareTo((java.lang.Object) 2);
        java.util.Date date9 = month6.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, year10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("ClassContext");
        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "ClassContext");
        int int20 = year10.compareTo((java.lang.Object) "ClassContext");
        long long21 = year10.getLastMillisecond();
        boolean boolean22 = month2.equals((java.lang.Object) year10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year10.next();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167363200001L) + "'", long11 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("ClassContext");
        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date21 = fixedMillisecond15.getTime();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
        timeSeries13.setKey((java.lang.Comparable) fixedMillisecond24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        java.lang.String str18 = serialDate8.getDescription();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        java.lang.String str24 = serialDate23.toString();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate32 = serialDate23.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = serialDate8.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate49 = serialDate41.getEndOfCurrentMonth(serialDate46);
        java.lang.String str50 = serialDate41.getDescription();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(3, serialDate41);
        serialDate51.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate55 = serialDate51.getPreviousDayOfWeek(3);
        boolean boolean56 = spreadsheetDate1.isInRange(serialDate32, serialDate51);
        spreadsheetDate1.setDescription("Sunday");
        int int59 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
        org.jfree.data.time.SerialDate serialDate67 = serialDate65.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate72 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate75 = serialDate67.getEndOfCurrentMonth(serialDate72);
        java.lang.String str76 = serialDate67.getDescription();
        java.lang.String str77 = serialDate67.getDescription();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addDays(0, serialDate67);
        boolean boolean79 = spreadsheetDate1.isOnOrBefore(serialDate78);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-9999" + "'", str24.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        boolean boolean12 = month2.equals((java.lang.Object) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        long long8 = year7.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, year7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int13 = fixedMillisecond11.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("ClassContext");
        int int16 = fixedMillisecond11.compareTo((java.lang.Object) "ClassContext");
        int int17 = year7.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year7.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int28 = month26.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1));
        timeSeries23.removeAgedItems(false);
        java.lang.Class class33 = timeSeries23.getTimePeriodClass();
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", class33);
        try {
            org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18, "Wed Dec 31 15:59:59 PST 1969", "org.jfree.data.general.SeriesChangeEvent[source=1]", class33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62167363200001L) + "'", long8 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNull(uRL34);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        seriesException12.addSuppressed((java.lang.Throwable) seriesException15);
        java.lang.Throwable[] throwableArray18 = seriesException15.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass19);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("2-October-9999", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(uRL21);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        timeSeries1.setDescription("ClassContext");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) '#');
//        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("ClassContext");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "ClassContext");
//        long long19 = fixedMillisecond13.getLastMillisecond();
//        java.util.Date date20 = fixedMillisecond13.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond13.next();
//        timeSeries6.delete(regularTimePeriod21);
//        java.util.Collection collection23 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        java.util.Collection collection24 = org.jfree.chart.util.ObjectUtilities.deepClone(collection23);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(collection24);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str8 = day7.toString();
        long long9 = day7.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day7);
        java.util.Calendar calendar11 = null;
        try {
            day7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2-January-9999" + "'", str8.equals("2-January-9999"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 253370966399999L + "'", long9 == 253370966399999L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getSerialIndex();
        java.lang.String str6 = day3.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2958102L + "'", long5 == 2958102L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2-January-9999" + "'", str6.equals("2-January-9999"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setMaximumItemAge((long) 12);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("ClassContext");
        int int17 = fixedMillisecond12.compareTo((java.lang.Object) "ClassContext");
        int int18 = year8.compareTo((java.lang.Object) "ClassContext");
        long long19 = year8.getLastMillisecond();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(1, year8);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year8.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200001L) + "'", long19 == (-62167363200001L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        boolean boolean13 = fixedMillisecond7.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = month2.equals((java.lang.Object) fixedMillisecond7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond7.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str12 = timeSeries11.getDescription();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int17 = day16.getYear();
        java.lang.Number number18 = null;
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day16, number18, false);
        int int21 = day16.getDayOfMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day16, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2-January-9999 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9999 + "'", int17 == 9999);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1900 + "'", comparable14.equals(1900));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int12 = month10.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1));
        java.lang.String str15 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean19 = fixedMillisecond17.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getLastMillisecond(calendar20);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries7.setNotify(true);
        java.util.Collection collection25 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        long long26 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int32 = month30.compareTo((java.lang.Object) 2);
        java.util.Date date33 = month30.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getLastMillisecond();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, year34);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int45 = month43.compareTo((java.lang.Object) 2);
        java.util.Date date46 = month43.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        long long48 = year47.getLastMillisecond();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 1, year47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int53 = fixedMillisecond51.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("ClassContext");
        int int56 = fixedMillisecond51.compareTo((java.lang.Object) "ClassContext");
        int int57 = year47.compareTo((java.lang.Object) "ClassContext");
        long long58 = year47.getLastMillisecond();
        boolean boolean59 = month39.equals((java.lang.Object) year47);
        boolean boolean60 = year34.equals((java.lang.Object) month39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month39.previous();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries7.addOrUpdate(regularTimePeriod61, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62167363200001L) + "'", long35 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62167363200001L) + "'", long48 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62167363200001L) + "'", long58 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(regularTimePeriod61);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate11.getPreviousDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int39 = fixedMillisecond37.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException41 = new org.jfree.data.general.SeriesException("ClassContext");
        int int42 = fixedMillisecond37.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date43 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        java.util.Date date45 = year44.getStart();
        long long46 = year44.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 28799999L);
        java.util.Calendar calendar49 = null;
        try {
            year44.peg(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-31507200000L) + "'", long46 == (-31507200000L));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int3 = month2.getMonth();
        java.lang.Object obj4 = null;
        boolean boolean5 = month2.equals(obj4);
        int int7 = month2.compareTo((java.lang.Object) 2958131L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
//        int int7 = month5.compareTo((java.lang.Object) 2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month5, (double) (-1));
//        timeSeries2.removeAgedItems(false);
//        java.lang.Class class12 = timeSeries2.getTimePeriodClass();
//        boolean boolean13 = fixedMillisecond0.equals((java.lang.Object) timeSeries2);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 4);
//        long long21 = day17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.previous();
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 2958465, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 13-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        int int7 = month2.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-11L) + "'", long6 == (-11L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int9 = year7.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (double) (-1));
        java.lang.String str19 = timeSeries11.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.Date date27 = fixedMillisecond21.getTime();
        boolean boolean28 = year7.equals((java.lang.Object) fixedMillisecond21);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year7.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("7-January-9999");
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate27);
        java.lang.String str31 = serialDate30.toString();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
        long long33 = day32.getSerialIndex();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (-1898));
        long long36 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-9999" + "'", str31.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2958131L + "'", long33 == 2958131L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setMaximumItemCount(0);
        java.util.List list4 = timeSeries1.getItems();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        timeSeries1.removeAgedItems(false);
        timeSeries1.removeAgedItems((long) (short) -1, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate27);
        java.lang.String str31 = serialDate30.toString();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate30);
        long long33 = day32.getSerialIndex();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (-1898));
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        java.lang.String str50 = month47.toString();
        long long51 = month47.getSerialIndex();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        java.lang.Object obj57 = null;
        boolean boolean58 = day55.equals(obj57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) month47, (org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int65 = month63.compareTo((java.lang.Object) 2);
        java.util.Date date66 = month63.getStart();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        long long68 = year67.getLastMillisecond();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month((int) (short) 1, year67);
        long long70 = year67.getSerialIndex();
        long long71 = year67.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year67, (double) (short) 1);
        try {
            timeSeries1.add(timeSeriesDataItem73, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-January-9999" + "'", str31.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2958131L + "'", long33 == 2958131L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62198899200000L) + "'", long48 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "January -1" + "'", str50.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-11L) + "'", long51 == (-11L));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62167363200001L) + "'", long68 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2L + "'", long70 == 2L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2L + "'", long71 == 2L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        timeSeries1.setDomainDescription("");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        int int5 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        int int10 = day6.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate25 = serialDate17.getEndOfCurrentMonth(serialDate22);
        boolean boolean26 = day6.equals((java.lang.Object) serialDate25);
        int int27 = spreadsheetDate2.compare(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str29 = spreadsheetDate2.toString();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate44 = serialDate36.getEndOfCurrentMonth(serialDate41);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        boolean boolean48 = spreadsheetDate2.isOnOrAfter(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate56 = day55.getSerialDate();
        java.lang.Object obj57 = null;
        boolean boolean58 = day55.equals(obj57);
        int int59 = day55.getYear();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate64 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate71 = day70.getSerialDate();
        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate74 = serialDate66.getEndOfCurrentMonth(serialDate71);
        boolean boolean75 = day55.equals((java.lang.Object) serialDate74);
        int int76 = spreadsheetDate51.compare(serialDate74);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        java.lang.String str78 = spreadsheetDate51.toString();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate83 = day82.getSerialDate();
        org.jfree.data.time.SerialDate serialDate85 = serialDate83.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate90 = day89.getSerialDate();
        org.jfree.data.time.SerialDate serialDate92 = serialDate90.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate93 = serialDate85.getEndOfCurrentMonth(serialDate90);
        java.lang.String str94 = serialDate93.toString();
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate93);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(serialDate93);
        boolean boolean97 = spreadsheetDate51.isOnOrAfter(serialDate93);
        int int98 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int99 = spreadsheetDate51.getYYYY();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9999 + "'", int10 == 9999);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2958125) + "'", int27 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5-January-1900" + "'", str29.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "31-January-9999" + "'", str45.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9999 + "'", int59 == 9999);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-2958125) + "'", int76 == (-2958125));
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "5-January-1900" + "'", str78.equals("5-January-1900"));
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "31-January-9999" + "'", str94.equals("31-January-9999"));
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1900 + "'", int99 == 1900);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) (byte) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.setRangeDescription("ThreadContext");
        java.lang.String str15 = timeSeries11.getRangeDescription();
        timeSeries11.clear();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries11);
        long long20 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ThreadContext" + "'", str15.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray15 = seriesException11.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Sunday");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        long long7 = year6.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (byte) 10);
        int int11 = year6.compareTo((java.lang.Object) 7);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200001L) + "'", long7 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray19 = seriesException18.getSuppressed();
        seriesException15.addSuppressed((java.lang.Throwable) seriesException18);
        java.lang.Throwable[] throwableArray21 = seriesException18.getSuppressed();
        java.lang.Class<?> wildcardClass22 = throwableArray21.getClass();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int27 = month25.compareTo((java.lang.Object) 2);
        java.util.Date date28 = month25.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date28);
        int int33 = year32.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        java.util.Date date7 = month4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getLastMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 1, year8);
        java.lang.Class<?> wildcardClass11 = month10.getClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int16 = month14.compareTo((java.lang.Object) 2);
        java.util.Date date17 = month14.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int25 = month23.compareTo((java.lang.Object) 2);
        java.util.Date date26 = month23.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, year27);
        java.lang.Class<?> wildcardClass30 = month29.getClass();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int35 = month33.compareTo((java.lang.Object) 2);
        java.util.Date date36 = month33.getStart();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
        java.lang.Object obj39 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62167363200001L) + "'", long9 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62167363200001L) + "'", long28 == (-62167363200001L));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(obj39);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-11L));
        timeSeriesDataItem8.setValue((java.lang.Number) 253373385600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem8.getPeriod();
        java.util.Calendar calendar12 = null;
        long long13 = regularTimePeriod11.getMiddleMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        timeSeries1.setRangeDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 4);
//        long long17 = day13.getLastMillisecond();
//        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
//        seriesException20.addSuppressed((java.lang.Throwable) seriesException23);
//        java.lang.Throwable[] throwableArray26 = seriesException23.getSuppressed();
//        java.lang.Class<?> wildcardClass27 = throwableArray26.getClass();
//        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray30 = seriesException29.getSuppressed();
//        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray33 = seriesException32.getSuppressed();
//        seriesException29.addSuppressed((java.lang.Throwable) seriesException32);
//        java.lang.Throwable[] throwableArray35 = seriesException32.getSuppressed();
//        java.lang.Class<?> wildcardClass36 = throwableArray35.getClass();
//        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass27, (java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, (java.lang.Class) wildcardClass27);
//        java.util.Collection collection39 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        timeSeries1.removeAgedItems((long) 8, true);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(throwableArray21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(throwableArray30);
//        org.junit.Assert.assertNotNull(throwableArray33);
//        org.junit.Assert.assertNotNull(throwableArray35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(obj37);
//        org.junit.Assert.assertNotNull(collection39);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        java.lang.String str11 = day6.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2-January-9999" + "'", str11.equals("2-January-9999"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.util.Collection collection2 = timeSeries1.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.addChangeListener(seriesChangeListener3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection2);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        boolean boolean28 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str32 = month31.toString();
        long long33 = month31.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int42 = month40.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month40, (double) (-1));
        java.lang.String str45 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
        timeSeries37.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries12.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        timeSeries57.setRangeDescription("ThreadContext");
        java.lang.String str61 = timeSeries57.getRangeDescription();
        timeSeries57.clear();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        int int64 = timeSeries57.getIndex((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str65 = year63.toString();
        timeSeries37.delete((org.jfree.data.time.RegularTimePeriod) year63);
        java.lang.String str67 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int71 = fixedMillisecond69.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException73 = new org.jfree.data.general.SeriesException("ClassContext");
        int int74 = fixedMillisecond69.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date75 = fixedMillisecond69.getTime();
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond69.getMiddleMillisecond(calendar76);
        try {
            timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "January -1" + "'", str32.equals("January -1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62101526400001L) + "'", long33 == (-62101526400001L));
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ThreadContext" + "'", str61.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
        timeSeries29.setRangeDescription("ThreadContext");
        java.lang.String str33 = timeSeries29.getRangeDescription();
        java.util.List list34 = timeSeries29.getItems();
        java.util.Collection collection35 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries27.setRangeDescription("January -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ThreadContext" + "'", str33.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "hi!", "January -1", class17);
        int int19 = month7.compareTo((java.lang.Object) class17);
        java.util.Calendar calendar20 = null;
        try {
            month7.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January -1" + "'", str11.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        serialDate18.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate22 = serialDate18.getPreviousDayOfWeek(3);
        try {
            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-2958125));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate15 = serialDate7.getEndOfCurrentMonth(serialDate12);
        java.lang.String str16 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        serialDate17.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate21 = serialDate17.getPreviousDayOfWeek(3);
        serialDate17.setDescription("April");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int20 = month18.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long31 = month30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.previous();
        int int33 = month30.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getLastMillisecond(calendar38);
        boolean boolean41 = fixedMillisecond35.equals((java.lang.Object) (byte) 10);
        boolean boolean42 = month30.equals((java.lang.Object) fixedMillisecond35);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond35.getFirstMillisecond(calendar43);
        long long45 = fixedMillisecond35.getLastMillisecond();
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond35.getMiddleMillisecond(calendar46);
        try {
            timeSeries27.setKey((java.lang.Comparable) calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62198899200000L) + "'", long31 == (-62198899200000L));
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        java.lang.String str21 = day20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
        java.lang.Number number23 = null;
        timeSeries1.add(regularTimePeriod22, number23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2-January-9999" + "'", str21.equals("2-January-9999"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray11 = seriesException10.getSuppressed();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        seriesException10.addSuppressed((java.lang.Throwable) seriesException13);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str18 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        java.lang.String str9 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries1.addChangeListener(seriesChangeListener17);
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int6 = month4.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month4, (double) (-1));
        try {
            org.jfree.data.time.Year year9 = month4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.util.Date date6 = month3.getStart();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 0.0f);
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62198899200000L) + "'", long3 == (-62198899200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62101526400001L) + "'", long6 == (-62101526400001L));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Sunday");
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "Sunday" + "'", obj2.equals("Sunday"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("ClassContext");
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) "ClassContext");
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek(6);
        org.jfree.data.time.SerialDate serialDate16 = serialDate8.getEndOfCurrentMonth(serialDate13);
        java.lang.String str17 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        seriesException9.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.Throwable[] throwableArray15 = seriesException12.getSuppressed();
        java.lang.Class<?> wildcardClass16 = throwableArray15.getClass();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int21 = month19.compareTo((java.lang.Object) 2);
        java.util.Date date22 = month19.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date22, timeZone24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date22);
        int int27 = year26.getYear();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year26, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str16 = timeSeries15.getDescription();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int21 = day20.getYear();
        java.lang.Number number22 = null;
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day20, number22, false);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries15.getNextTimePeriod();
        java.lang.Number number28 = timeSeries10.getValue(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9999 + "'", int21 == 9999);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(number28);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-460), (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        timeSeries1.setDescription("ClassContext");
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) '#');
//        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("ClassContext");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "ClassContext");
//        long long19 = fixedMillisecond13.getLastMillisecond();
//        java.util.Date date20 = fixedMillisecond13.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond13.next();
//        timeSeries6.delete(regularTimePeriod21);
//        java.util.Collection collection23 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
//        timeSeries6.setNotify(false);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(collection23);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("ThreadContext");
        timeSeries1.setMaximumItemAge(253370966399999L);
        timeSeries1.setDomainDescription("January -1");
        timeSeries1.setMaximumItemCount((int) '#');
        boolean boolean11 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        java.lang.Throwable[] throwableArray9 = seriesException6.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int15 = month13.compareTo((java.lang.Object) 2);
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2-January-9999", (java.lang.Class) wildcardClass10);
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray27 = seriesException26.getSuppressed();
        seriesException23.addSuppressed((java.lang.Throwable) seriesException26);
        java.lang.Throwable[] throwableArray29 = seriesException26.getSuppressed();
        java.lang.Class<?> wildcardClass30 = throwableArray29.getClass();
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass30);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass30);
        java.lang.ClassLoader classLoader33 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader33);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(uRL31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(classLoader33);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-572));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-January-9999");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(2, (int) (byte) 1, 9999);
        int int7 = day6.getYear();
        java.lang.Number number8 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day6, number8, false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int17 = month15.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1));
        java.lang.String str20 = timeSeries12.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.addChangeListener(seriesChangeListener32);
        java.lang.String str34 = timeSeries31.getDescription();
        timeSeries31.setDomainDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries31.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int8 = month6.compareTo((java.lang.Object) 2);
        java.util.Date date9 = month6.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, year10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) '#');
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("ClassContext");
        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "ClassContext");
        int int20 = year10.compareTo((java.lang.Object) "ClassContext");
        long long21 = year10.getLastMillisecond();
        boolean boolean22 = month2.equals((java.lang.Object) year10);
        java.util.Calendar calendar23 = null;
        try {
            month2.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167363200001L) + "'", long11 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167363200001L) + "'", long21 == (-62167363200001L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "January -1", class9);
        timeSeries10.setRangeDescription("Oct");
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        timeSeries15.setRangeDescription("ThreadContext");
        java.lang.String str19 = timeSeries15.getRangeDescription();
        timeSeries15.clear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        int int22 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        int int23 = year21.getYear();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) -1);
        int int30 = month28.compareTo((java.lang.Object) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) (-1));
        java.lang.String str33 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 1.0f);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond35.getLastMillisecond(calendar38);
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        java.util.Date date41 = fixedMillisecond35.getTime();
        boolean boolean42 = year21.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        long long44 = year21.getSerialIndex();
        long long45 = year21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January -1" + "'", str3.equals("January -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("April", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

