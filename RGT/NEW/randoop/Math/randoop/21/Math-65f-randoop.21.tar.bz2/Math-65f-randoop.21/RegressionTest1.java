import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Throwable throwable0 = null;
        java.lang.RuntimeException runtimeException1 = org.apache.commons.math.MathRuntimeException.createInternalError(throwable0);
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) runtimeException1);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.BigMatrix bigMatrix20 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix21 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(bigMatrix20);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealVector realVector63 = blockRealMatrix16.getColumnVector(0);
        double double64 = blockRealMatrix16.getNorm();
        try {
            blockRealMatrix16.addToEntry((int) (byte) 0, (int) ' ', 145.14131045295133d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (0, 32) in a 3x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 291.0d + "'", double64 == 291.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.exception.Localizable localizable5 = null;
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray22 = new double[][] { doubleArray11, doubleArray16, doubleArray21 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray22);
        double[] doubleArray29 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix23.setRow(0, doubleArray29);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray29);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 100.0f, realMatrix31, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable5, objArray34);
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray42);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException44 = new org.apache.commons.math.linear.InvalidMatrixException(localizable38, objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException35, 0.0d, "hi!", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException((double) 'a', "hi!", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((double) 100.0f, "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", objArray42);
        java.util.NoSuchElementException noSuchElementException48 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("{0}", objArray42);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arithmeticException43);
        org.junit.Assert.assertNotNull(noSuchElementException48);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "org.apache.commons.math.linear.InvalidMatrixException: ", "hi!", "{0}", "hi!" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix6 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray2 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, objArray7);
        java.lang.IllegalStateException illegalStateException10 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(illegalStateException10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix25.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix25.walkInRowOrder(realMatrixChangingVisitor29, 6, 100, (int) (byte) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double[] doubleArray2 = new double[] { 0.0f, 10.0d };
        double[] doubleArray5 = new double[] { 0.0f, 10.0d };
        double[] doubleArray8 = new double[] { 0.0f, 10.0d };
        double[] doubleArray11 = new double[] { 0.0f, 10.0d };
        double[] doubleArray14 = new double[] { 0.0f, 10.0d };
        double[] doubleArray17 = new double[] { 0.0f, 10.0d };
        double[][] doubleArray18 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        int int20 = array2DRowRealMatrix19.getRowDimension();
        try {
            array2DRowRealMatrix19.setEntry(10, (int) (short) -1, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (10, -1) in a 6x2 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker1 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker1);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '4');
        levenbergMarquardtOptimizer0.setQRRankingThreshold(10.0d);
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Object[] objArray1 = null;
        java.lang.ArithmeticException arithmeticException2 = org.apache.commons.math.MathRuntimeException.createArithmeticException("{0}", objArray1);
        org.junit.Assert.assertNotNull(arithmeticException2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        double double42 = blockRealMatrix16.getNorm();
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray57 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray58 = new double[][] { doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray64 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray75 = new double[][] { doubleArray64, doubleArray69, doubleArray74 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray75);
        double[] doubleArray82 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix76.setRow(0, doubleArray82);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = blockRealMatrix59.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix76.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix87 = blockRealMatrix76.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix16.subtract(blockRealMatrix76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix16.scalarAdd((double) 1000);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 291.0d + "'", double42 == 291.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(blockRealMatrix84);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(realMatrix87);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
        org.junit.Assert.assertNotNull(blockRealMatrix90);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[][] doubleArray28 = array2DRowRealMatrix27.getDataRef();
        try {
            array2DRowRealMatrix27.setEntry(97, (int) (short) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 0) in a 3x1 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException6 = new org.apache.commons.math.linear.InvalidMatrixException(localizable0, objArray4);
        java.lang.Object[] objArray7 = invalidMatrixException6.getArguments();
        org.apache.commons.math.exception.Localizable localizable9 = null;
        org.apache.commons.math.exception.Localizable localizable10 = null;
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray27 = new double[][] { doubleArray16, doubleArray21, doubleArray26 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray27);
        double[] doubleArray34 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix28.setRow(0, doubleArray34);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray34);
        java.lang.Object[] objArray39 = new java.lang.Object[] { 100.0f, realMatrix36, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable10, objArray39);
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray57 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray58 = new double[][] { doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray65 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix59.setRow(0, doubleArray65);
        double[] doubleArray71 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray76 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray81 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray82 = new double[][] { doubleArray71, doubleArray76, doubleArray81 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix83 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray82);
        double[] doubleArray89 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix83.setRow(0, doubleArray89);
        org.apache.commons.math.linear.RealMatrix realMatrix91 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray89);
        java.lang.Object[] objArray92 = new java.lang.Object[] { localizable10, (byte) 0, (short) 1, 0, doubleArray89 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException93 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) invalidMatrixException6, 0.0d, localizable9, objArray92);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException93);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arithmeticException5);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(realMatrix91);
        org.junit.Assert.assertNotNull(objArray92);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        java.lang.String str62 = blockRealMatrix16.toString();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor63 = null;
        try {
            double double64 = blockRealMatrix16.walkInColumnOrder(realMatrixChangingVisitor63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str62.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        double[] doubleArray30 = new double[] { ' ' };
        double[] doubleArray32 = new double[] { ' ' };
        double[] doubleArray34 = new double[] { ' ' };
        double[] doubleArray36 = new double[] { ' ' };
        double[] doubleArray38 = new double[] { ' ' };
        double[][] doubleArray39 = new double[][] { doubleArray30, doubleArray32, doubleArray34, doubleArray36, doubleArray38 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        double double42 = array2DRowRealMatrix41.getNorm();
        int int43 = array2DRowRealMatrix41.getColumnDimension();
        int int44 = array2DRowRealMatrix41.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix41);
        double double46 = array2DRowRealMatrix45.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 160.0d + "'", double42 == 160.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double[] doubleArray5 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray10, doubleArray15 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        java.lang.IllegalStateException illegalStateException18 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray29 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray34 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray35 = new double[][] { doubleArray24, doubleArray29, doubleArray34 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray35);
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray46 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray51 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray52 = new double[][] { doubleArray41, doubleArray46, doubleArray51 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray52);
        double[] doubleArray58 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray63 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray68 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray69 = new double[][] { doubleArray58, doubleArray63, doubleArray68 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray69);
        double[] doubleArray76 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix70.setRow(0, doubleArray76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = blockRealMatrix53.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix70);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix80 = blockRealMatrix70.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix36, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix70);
        org.apache.commons.math.linear.RealMatrix realMatrix83 = blockRealMatrix36.scalarMultiply(160.0d);
        boolean boolean84 = blockRealMatrix36.isSquare();
        java.lang.String str85 = blockRealMatrix36.toString();
        double double86 = blockRealMatrix36.getFrobeniusNorm();
        double double87 = blockRealMatrix36.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix19.subtract(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(illegalStateException18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(blockRealMatrix78);
        org.junit.Assert.assertNotNull(blockRealMatrix80);
        org.junit.Assert.assertNotNull(realMatrix83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str85.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 176.91523393987302d + "'", double86 == 176.91523393987302d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 291.0d + "'", double87 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = blockRealMatrix16.scalarMultiply(160.0d);
        boolean boolean64 = blockRealMatrix16.isSquare();
        java.lang.String str65 = blockRealMatrix16.toString();
        double double66 = blockRealMatrix16.getFrobeniusNorm();
        double[] doubleArray68 = new double[] { ' ' };
        double[] doubleArray70 = new double[] { ' ' };
        double[] doubleArray72 = new double[] { ' ' };
        double[] doubleArray74 = new double[] { ' ' };
        double[] doubleArray76 = new double[] { ' ' };
        double[][] doubleArray77 = new double[][] { doubleArray68, doubleArray70, doubleArray72, doubleArray74, doubleArray76 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray77, true);
        double[] doubleArray81 = new double[] { ' ' };
        double[] doubleArray83 = new double[] { ' ' };
        double[] doubleArray85 = new double[] { ' ' };
        double[] doubleArray87 = new double[] { ' ' };
        double[] doubleArray89 = new double[] { ' ' };
        double[][] doubleArray90 = new double[][] { doubleArray81, doubleArray83, doubleArray85, doubleArray87, doubleArray89 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix92 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray90, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix93 = array2DRowRealMatrix79.subtract(array2DRowRealMatrix92);
        int int94 = array2DRowRealMatrix92.getColumnDimension();
        int int95 = array2DRowRealMatrix92.getRowDimension();
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix96 = blockRealMatrix16.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix92);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str65.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 176.91523393987302d + "'", double66 == 176.91523393987302d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 5 + "'", int95 == 5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        double[][] doubleArray46 = blockRealMatrix45.getData();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor47 = null;
        try {
            double double48 = blockRealMatrix45.walkInOptimizedOrder(realMatrixChangingVisitor47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = blockRealMatrix16.scalarMultiply(160.0d);
        boolean boolean64 = blockRealMatrix16.isSquare();
        java.lang.String str65 = blockRealMatrix16.toString();
        double double66 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix68 = blockRealMatrix16.scalarAdd((double) 97);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str65.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 176.91523393987302d + "'", double66 == 176.91523393987302d);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix25.walkInOptimizedOrder(realMatrixChangingVisitor29, 5, (int) '#', (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 5 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String[] strArray4 = new java.lang.String[] { "", "hi!", "matrix is singular", "org.apache.commons.math.optimization.OptimizationException: matrix is singular" };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix5 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker1 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker1);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '4');
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker5 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker5);
        levenbergMarquardtOptimizer0.setCostRelativeTolerance((double) 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[][] doubleArray25 = blockRealMatrix16.getData();
        double[] doubleArray30 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray35 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray40 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray41 = new double[][] { doubleArray30, doubleArray35, doubleArray40 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray41);
        double double43 = blockRealMatrix42.getNorm();
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix42, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix16.subtract(blockRealMatrix42);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor47 = null;
        try {
            double double48 = blockRealMatrix42.walkInOptimizedOrder(realMatrixChangingVisitor47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 291.0d + "'", double43 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Throwable throwable0 = null;
        java.lang.RuntimeException runtimeException1 = org.apache.commons.math.MathRuntimeException.createInternalError(throwable0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray19 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray20 = new double[][] { doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix21.setRow(0, doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0f, realMatrix29, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable3, objArray32);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException41 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException33, 0.0d, "hi!", objArray40);
        org.apache.commons.math.exception.Localizable localizable44 = functionEvaluationException43.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable46 = null;
        double[] doubleArray51 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray56 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray61 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray62 = new double[][] { doubleArray51, doubleArray56, doubleArray61 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix63 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray62);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException64 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable46, (java.lang.Object[]) doubleArray62);
        java.text.ParseException parseException65 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable44, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.exception.Localizable localizable66 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException71 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray70);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException(localizable66, objArray70);
        java.lang.IllegalArgumentException illegalArgumentException73 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable44, objArray70);
        runtimeException1.addSuppressed((java.lang.Throwable) illegalArgumentException73);
        org.junit.Assert.assertNotNull(runtimeException1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(arithmeticException41);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(parseException65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(arithmeticException71);
        org.junit.Assert.assertNotNull(illegalArgumentException73);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.linear.RealMatrix realMatrix2 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix((int) 'a', 1000);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        try {
            blockRealMatrix16.setEntry(0, (int) '#', (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (0, 35) in a 3x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = blockRealMatrix33.transpose();
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        double[] doubleArray66 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray71 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray76 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray77 = new double[][] { doubleArray66, doubleArray71, doubleArray76 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray77);
        double[] doubleArray84 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix78.setRow(0, doubleArray84);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix61.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix78);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix78.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix89 = blockRealMatrix78.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
        org.junit.Assert.assertNotNull(realMatrix89);
        org.junit.Assert.assertNotNull(blockRealMatrix90);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[] doubleArray11 = new double[] { ' ' };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable1, (java.lang.Object[]) doubleArray12);
        java.lang.Throwable[] throwableArray16 = functionEvaluationException15.getSuppressed();
        java.lang.Object[] objArray17 = functionEvaluationException15.getArguments();
        double[] doubleArray18 = functionEvaluationException15.getArgument();
        org.apache.commons.math.exception.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray24);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException26 = new org.apache.commons.math.linear.InvalidMatrixException(localizable20, objArray24);
        org.apache.commons.math.exception.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) invalidMatrixException26, localizable27, objArray28);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathRuntimeException29, (double) (short) 1, "hi!", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, "{0}", objArray32);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = blockRealMatrix45.transpose();
        double double47 = blockRealMatrix45.getNorm();
        double[] doubleArray49 = blockRealMatrix45.getColumn((int) (short) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor50 = null;
        try {
            double double55 = blockRealMatrix45.walkInRowOrder(realMatrixPreservingVisitor50, 10, 100, (int) '#', 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 197.0d + "'", double47 == 197.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray19 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray20 = new double[][] { doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix21.setRow(0, doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0f, realMatrix29, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable3, objArray32);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException41 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException33, 0.0d, "hi!", objArray40);
        org.apache.commons.math.exception.Localizable localizable44 = functionEvaluationException43.getLocalizablePattern();
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException45 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Object[] objArray46 = singularMatrixException45.getArguments();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException47 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable44, objArray46);
        double[] doubleArray49 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException55 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, localizable50, objArray54);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray61 = new double[] { ' ' };
        double[] doubleArray63 = new double[] { ' ' };
        double[] doubleArray65 = new double[] { ' ' };
        double[] doubleArray67 = new double[] { ' ' };
        double[] doubleArray69 = new double[] { ' ' };
        double[][] doubleArray70 = new double[][] { doubleArray61, doubleArray63, doubleArray65, doubleArray67, doubleArray69 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable59, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, "matrix is singular", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, 147.08500943332058d, localizable44, (java.lang.Object[]) doubleArray70);
        double[] doubleArray77 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable78 = null;
        double[] doubleArray80 = new double[] { ' ' };
        double[] doubleArray82 = new double[] { ' ' };
        double[] doubleArray84 = new double[] { ' ' };
        double[] doubleArray86 = new double[] { ' ' };
        double[] doubleArray88 = new double[] { ' ' };
        double[][] doubleArray89 = new double[][] { doubleArray80, doubleArray82, doubleArray84, doubleArray86, doubleArray88 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix91 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException(doubleArray77, localizable78, (java.lang.Object[]) doubleArray89);
        double[][] doubleArray93 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray89);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray89);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException(localizable44, (java.lang.Object[]) doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(arithmeticException41);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(arithmeticException55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", objArray1);
        java.lang.String str3 = mathException2.getPattern();
        java.io.ObjectInputStream objectInputStream5 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealVector((java.lang.Object) str3, "{0}", objectInputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str3.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray5 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray10, doubleArray15 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        java.lang.IllegalStateException illegalStateException18 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math.linear.RealMatrix realMatrix23 = array2DRowRealMatrix21.scalarMultiply((double) 1.0f);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(illegalStateException18);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) 1000, (double) (-1L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        levenbergMarquardtOptimizer0.setMaxIterations((int) '#');
        levenbergMarquardtOptimizer0.setMaxIterations((int) (short) 1);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) (byte) 0);
        int int9 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = array2DRowRealMatrix26.walkInColumnOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[][] doubleArray25 = blockRealMatrix16.getData();
        double[] doubleArray30 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray35 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray40 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray41 = new double[][] { doubleArray30, doubleArray35, doubleArray40 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray41);
        double double43 = blockRealMatrix42.getNorm();
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix42, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix16.subtract(blockRealMatrix42);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor47 = null;
        try {
            double double48 = blockRealMatrix16.walkInOptimizedOrder(realMatrixChangingVisitor47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 291.0d + "'", double43 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        double[] doubleArray24 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix18.setRow(0, doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, realMatrix26, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable0, objArray29);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException38 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable33, objArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException30, 0.0d, "hi!", objArray37);
        org.apache.commons.math.exception.Localizable localizable41 = functionEvaluationException40.getLocalizablePattern();
        double[] doubleArray44 = new double[] { 0.0f, 10.0d };
        double[] doubleArray47 = new double[] { 0.0f, 10.0d };
        double[] doubleArray50 = new double[] { 0.0f, 10.0d };
        double[] doubleArray53 = new double[] { 0.0f, 10.0d };
        double[] doubleArray56 = new double[] { 0.0f, 10.0d };
        double[] doubleArray59 = new double[] { 0.0f, 10.0d };
        double[][] doubleArray60 = new double[][] { doubleArray44, doubleArray47, doubleArray50, doubleArray53, doubleArray56, doubleArray59 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable41, (java.lang.Object[]) doubleArray60);
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable41, objArray63);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException64, 145.14131045295133d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(arithmeticException38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor46 = null;
        try {
            double double47 = blockRealMatrix45.walkInColumnOrder(realMatrixChangingVisitor46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray7, doubleArray12, doubleArray17 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray18);
        double[] doubleArray25 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix19.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, realMatrix27, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable1, objArray30);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException39 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray38);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException31, 0.0d, "hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable42 = functionEvaluationException41.getLocalizablePattern();
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray57 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray58 = new double[][] { doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray65 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix59.setRow(0, doubleArray65);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = blockRealMatrix59.copy();
        double[][] doubleArray68 = blockRealMatrix59.getData();
        java.lang.ArithmeticException arithmeticException69 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable42, (java.lang.Object[]) doubleArray68);
        double[] doubleArray72 = new double[] { 0.0f, 10.0d };
        double[] doubleArray75 = new double[] { 0.0f, 10.0d };
        double[] doubleArray78 = new double[] { 0.0f, 10.0d };
        double[] doubleArray81 = new double[] { 0.0f, 10.0d };
        double[] doubleArray84 = new double[] { 0.0f, 10.0d };
        double[] doubleArray87 = new double[] { 0.0f, 10.0d };
        double[][] doubleArray88 = new double[][] { doubleArray72, doubleArray75, doubleArray78, doubleArray81, doubleArray84, doubleArray87 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray88);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException90 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable42, (java.lang.Object[]) doubleArray88);
        java.lang.NullPointerException nullPointerException91 = org.apache.commons.math.MathRuntimeException.createNullPointerException("matrix is singular", (java.lang.Object[]) doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arithmeticException39);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(blockRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(arithmeticException69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException90);
        org.junit.Assert.assertNotNull(nullPointerException91);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix1 = org.apache.commons.math.linear.MatrixUtils.createRealIdentityMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = blockRealMatrix24.walkInOptimizedOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable1, objArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        org.apache.commons.math.exception.Localizable localizable7 = convergenceException6.getLocalizablePattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arithmeticException5);
        org.junit.Assert.assertNotNull(localizable7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        double[] doubleArray35 = vectorialPointValuePair34.getPoint();
        double[] doubleArray37 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray37, localizable38, objArray42);
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        double[] doubleArray67 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix61.setRow(0, doubleArray67);
        org.apache.commons.math.linear.RealMatrix realMatrix69 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray67);
        org.apache.commons.math.linear.RealMatrix realMatrix71 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair72 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray67);
        double[] doubleArray73 = vectorialPointValuePair72.getValueRef();
        org.apache.commons.math.linear.BigMatrix bigMatrix74 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray73);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arithmeticException43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(bigMatrix74);
        org.junit.Assert.assertNotNull(realMatrix75);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix25.getColumnDimension();
        double[] doubleArray37 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray42 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray48 = new double[][] { doubleArray37, doubleArray42, doubleArray47 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray48);
        java.lang.IllegalStateException illegalStateException50 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48, true);
        try {
            array2DRowRealMatrix25.copySubMatrix((int) ' ', (int) (short) 1, 100, (int) ' ', doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 32 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(illegalStateException50);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray42 = new double[][] { doubleArray31, doubleArray36, doubleArray41 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray42);
        double double44 = blockRealMatrix43.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix43);
        org.apache.commons.math.linear.RealMatrix realMatrix47 = blockRealMatrix43.scalarMultiply((double) 52);
        int[] intArray49 = new int[] { (short) -1 };
        int[] intArray53 = new int[] { (byte) 0, (byte) 100, (byte) 0 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix54 = blockRealMatrix43.getSubMatrix(intArray49, intArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 291.0d + "'", double44 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix25.walkInColumnOrder(realMatrixChangingVisitor29, (int) (byte) 1, (int) (short) 10, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray7, doubleArray12, doubleArray17 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray18);
        double[] doubleArray25 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix19.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, realMatrix27, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable1, objArray30);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException39 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray38);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException31, 0.0d, "hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable42 = functionEvaluationException41.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable44 = null;
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException62 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable44, (java.lang.Object[]) doubleArray60);
        java.text.ParseException parseException63 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable42, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.exception.Localizable localizable64 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException69 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray68);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException70 = new org.apache.commons.math.linear.InvalidMatrixException(localizable64, objArray68);
        java.lang.IllegalArgumentException illegalArgumentException71 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable42, objArray68);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException72 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) illegalArgumentException71);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arithmeticException39);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(parseException63);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(arithmeticException69);
        org.junit.Assert.assertNotNull(illegalArgumentException71);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray8 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray19 = new double[][] { doubleArray8, doubleArray13, doubleArray18 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray19);
        double[] doubleArray26 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix20.setRow(0, doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f, realMatrix28, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable2, objArray31);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException40 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException32, 0.0d, "hi!", objArray39);
        org.apache.commons.math.exception.Localizable localizable43 = functionEvaluationException42.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray50 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray55 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray60 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray61 = new double[][] { doubleArray50, doubleArray55, doubleArray60 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray61);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable45, (java.lang.Object[]) doubleArray61);
        java.text.ParseException parseException64 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable43, (java.lang.Object[]) doubleArray61);
        double[] doubleArray67 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable68 = null;
        double[] doubleArray70 = new double[] { ' ' };
        double[] doubleArray72 = new double[] { ' ' };
        double[] doubleArray74 = new double[] { ' ' };
        double[] doubleArray76 = new double[] { ' ' };
        double[] doubleArray78 = new double[] { ' ' };
        double[][] doubleArray79 = new double[][] { doubleArray70, doubleArray72, doubleArray74, doubleArray76, doubleArray78 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray79, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(doubleArray67, localizable68, (java.lang.Object[]) doubleArray79);
        java.lang.IllegalStateException illegalStateException83 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable43, (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(arithmeticException40);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(parseException64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(illegalStateException83);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray37 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray37, localizable38, objArray42);
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        double[] doubleArray67 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix61.setRow(0, doubleArray67);
        org.apache.commons.math.linear.RealMatrix realMatrix69 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray67);
        double[] doubleArray71 = vectorialPointValuePair70.getPoint();
        double[] doubleArray72 = vectorialPointValuePair70.getValue();
        try {
            double[] doubleArray73 = array2DRowRealMatrix35.operate(doubleArray72);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arithmeticException43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        levenbergMarquardtOptimizer0.setQRRankingThreshold((double) 97);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = blockRealMatrix45.transpose();
        java.lang.String str47 = blockRealMatrix45.toString();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "BlockRealMatrix{{1.0,11.0,11.0,1.0},{98.0,1.0,1.0,33.0},{98.0,1.0,1.0,33.0}}" + "'", str47.equals("BlockRealMatrix{{1.0,11.0,11.0,1.0},{98.0,1.0,1.0,33.0},{98.0,1.0,1.0,33.0}}"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        double[] doubleArray24 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix18.setRow(0, doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, realMatrix26, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable0, objArray29);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException38 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable33, objArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException30, 0.0d, "hi!", objArray37);
        org.apache.commons.math.exception.Localizable localizable41 = functionEvaluationException40.getLocalizablePattern();
        double[] doubleArray44 = new double[] { 0.0f, 10.0d };
        double[] doubleArray47 = new double[] { 0.0f, 10.0d };
        double[] doubleArray50 = new double[] { 0.0f, 10.0d };
        double[] doubleArray53 = new double[] { 0.0f, 10.0d };
        double[] doubleArray56 = new double[] { 0.0f, 10.0d };
        double[] doubleArray59 = new double[] { 0.0f, 10.0d };
        double[][] doubleArray60 = new double[][] { doubleArray44, doubleArray47, doubleArray50, doubleArray53, doubleArray56, doubleArray59 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable41, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        try {
            boolean boolean64 = array2DRowRealMatrix63.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 6x2 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(arithmeticException38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        int int29 = array2DRowRealMatrix25.getColumnDimension();
        org.apache.commons.math.exception.Localizable localizable31 = null;
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray46 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray47 = new double[][] { doubleArray36, doubleArray41, doubleArray46 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray47);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable31, (java.lang.Object[]) doubleArray47);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, false);
        double[] doubleArray56 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray61 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray66 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray67 = new double[][] { doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray67);
        double[] doubleArray74 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix68.setRow(0, doubleArray74);
        org.apache.commons.math.linear.RealMatrix realMatrix76 = array2DRowRealMatrix51.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix68);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix77 = array2DRowRealMatrix25.multiply(realMatrix76);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(realMatrix76);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double double13 = array2DRowRealMatrix12.getNorm();
        int int14 = array2DRowRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double16 = array2DRowRealMatrix12.walkInRowOrder(realMatrixChangingVisitor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 160.0d + "'", double13 == 160.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[][] doubleArray25 = blockRealMatrix16.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix26 = blockRealMatrix16.transpose();
        int int27 = blockRealMatrix16.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        int int3 = levenbergMarquardtOptimizer0.getMaxIterations();
        int int4 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1000 + "'", int3 == 1000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix25.getColumnDimension();
        double[] doubleArray33 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray44 = new double[][] { doubleArray33, doubleArray38, doubleArray43 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray44);
        double[] doubleArray51 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix45.setRow(0, doubleArray51);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix45.copy();
        double[] doubleArray58 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray63 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray68 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray69 = new double[][] { doubleArray58, doubleArray63, doubleArray68 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray69);
        double[] doubleArray76 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix70.setRow(0, doubleArray76);
        org.apache.commons.math.linear.RealMatrix realMatrix78 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray76);
        org.apache.commons.math.exception.Localizable localizable81 = null;
        double[] doubleArray83 = new double[] { ' ' };
        double[] doubleArray85 = new double[] { ' ' };
        double[] doubleArray87 = new double[] { ' ' };
        double[] doubleArray89 = new double[] { ' ' };
        double[] doubleArray91 = new double[] { ' ' };
        double[][] doubleArray92 = new double[][] { doubleArray83, doubleArray85, doubleArray87, doubleArray89, doubleArray91 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray92, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException95 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable81, (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException96 = new org.apache.commons.math.FunctionEvaluationException(doubleArray76, "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", (java.lang.Object[]) doubleArray92);
        double[] doubleArray97 = blockRealMatrix53.operate(doubleArray76);
        try {
            array2DRowRealMatrix25.setRow((int) (short) -1, doubleArray76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray97);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        double[] doubleArray24 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix18.setRow(0, doubleArray24);
        org.apache.commons.math.linear.RealMatrix realMatrix26 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100.0f, realMatrix26, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable0, objArray29);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException38 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray37);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException39 = new org.apache.commons.math.linear.InvalidMatrixException(localizable33, objArray37);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException30, 0.0d, "hi!", objArray37);
        org.apache.commons.math.exception.Localizable localizable41 = functionEvaluationException40.getLocalizablePattern();
        double[] doubleArray44 = new double[] { 0.0f, 10.0d };
        double[] doubleArray47 = new double[] { 0.0f, 10.0d };
        double[] doubleArray50 = new double[] { 0.0f, 10.0d };
        double[] doubleArray53 = new double[] { 0.0f, 10.0d };
        double[] doubleArray56 = new double[] { 0.0f, 10.0d };
        double[] doubleArray59 = new double[] { 0.0f, 10.0d };
        double[][] doubleArray60 = new double[][] { doubleArray44, doubleArray47, doubleArray50, doubleArray53, doubleArray56, doubleArray59 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable41, (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.exception.Localizable localizable63 = null;
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray79 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray80 = new double[][] { doubleArray69, doubleArray74, doubleArray79 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix81 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray80);
        double[] doubleArray87 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix81.setRow(0, doubleArray87);
        org.apache.commons.math.linear.RealMatrix realMatrix89 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray87);
        java.lang.Object[] objArray92 = new java.lang.Object[] { 100.0f, realMatrix89, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException(localizable63, objArray92);
        java.lang.UnsupportedOperationException unsupportedOperationException94 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException(localizable41, objArray92);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(arithmeticException38);
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix89);
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertNotNull(unsupportedOperationException94);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        org.apache.commons.math.linear.RealVector realVector35 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realMatrix36);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double double13 = array2DRowRealMatrix12.getNorm();
        int int14 = array2DRowRealMatrix12.getColumnDimension();
        int int15 = array2DRowRealMatrix12.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix12.walkInColumnOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 160.0d + "'", double13 == 160.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        try {
            boolean boolean13 = array2DRowRealMatrix12.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 5x1 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        double double24 = blockRealMatrix16.getFrobeniusNorm();
        double[] doubleArray29 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray34 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray39 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray40 = new double[][] { doubleArray29, doubleArray34, doubleArray39 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray40);
        double[] doubleArray46 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray51 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray56 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray57 = new double[][] { doubleArray46, doubleArray51, doubleArray56 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray57);
        double[] doubleArray63 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray68 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray73 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray74 = new double[][] { doubleArray63, doubleArray68, doubleArray73 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray74);
        double[] doubleArray81 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix75.setRow(0, doubleArray81);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix83 = blockRealMatrix58.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix75);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix75.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix41, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix75);
        org.apache.commons.math.linear.RealVector realVector88 = blockRealMatrix41.getColumnVector(0);
        org.apache.commons.math.linear.RealVector realVector89 = blockRealMatrix16.preMultiply(realVector88);
        blockRealMatrix16.addToEntry(0, 0, 291.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 145.14131045295133d + "'", double24 == 145.14131045295133d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(blockRealMatrix83);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(realVector89);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        int int36 = array2DRowRealMatrix35.getColumnDimension();
        boolean boolean37 = array2DRowRealMatrix35.isSquare();
        double[] doubleArray42 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray53 = new double[][] { doubleArray42, doubleArray47, doubleArray52 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray53);
        double[] doubleArray60 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix54.setRow(0, doubleArray60);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix54.copy();
        double[] doubleArray64 = blockRealMatrix62.getColumn((int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64);
        double[][] doubleArray66 = array2DRowRealMatrix65.getDataRef();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix65);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        double double24 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix26 = blockRealMatrix16.scalarMultiply((double) 97);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 145.14131045295133d + "'", double24 == 145.14131045295133d);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor22 = null;
        try {
            double double23 = array2DRowRealMatrix21.walkInColumnOrder(realMatrixPreservingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        double[] doubleArray35 = vectorialPointValuePair34.getPointRef();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        try {
            array2DRowRealMatrix21.setEntry((int) 'a', 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (97, 100) in a 3x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        java.lang.IllegalArgumentException illegalArgumentException19 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray17);
        java.lang.ArithmeticException arithmeticException20 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.optimization.OptimizationException: matrix is singular", (java.lang.Object[]) doubleArray17);
        double[][] doubleArray21 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(illegalArgumentException19);
        org.junit.Assert.assertNotNull(arithmeticException20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException2 = new org.apache.commons.math.linear.MatrixIndexException("BlockRealMatrix{{1.0,11.0,11.0,1.0},{98.0,1.0,1.0,33.0},{98.0,1.0,1.0,33.0}}", objArray1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker1 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.VectorialConvergenceChecker) simpleVectorialValueChecker1);
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) '4');
        org.apache.commons.math.optimization.VectorialConvergenceChecker vectorialConvergenceChecker5 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialConvergenceChecker5);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor(1.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = blockRealMatrix33.transpose();
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        double[] doubleArray66 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray71 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray76 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray77 = new double[][] { doubleArray66, doubleArray71, doubleArray76 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix78 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray77);
        double[] doubleArray84 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix78.setRow(0, doubleArray84);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix61.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix78);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix78.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix89 = blockRealMatrix78.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix33.multiply(realMatrix89);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor91 = null;
        try {
            double double96 = blockRealMatrix90.walkInOptimizedOrder(realMatrixChangingVisitor91, 52, (int) (byte) -1, (int) ' ', 1000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
        org.junit.Assert.assertNotNull(realMatrix89);
        org.junit.Assert.assertNotNull(blockRealMatrix90);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.lang.String[] strArray3 = new java.lang.String[] { "" };
        java.lang.String[] strArray5 = new java.lang.String[] { "" };
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        java.lang.String[][] strArray10 = new java.lang.String[][] { strArray1, strArray3, strArray5, strArray7, strArray9 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray42 = new double[][] { doubleArray31, doubleArray36, doubleArray41 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray42);
        double double44 = blockRealMatrix43.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix24.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix43);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix48 = blockRealMatrix45.getSubMatrix(intArray46, intArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: empty selected row index array");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 291.0d + "'", double44 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(0.0d);
        java.lang.Object[] objArray2 = functionEvaluationException1.getArguments();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = blockRealMatrix16.scalarMultiply(160.0d);
        try {
            blockRealMatrix16.multiplyEntry((int) (short) 0, (int) ' ', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: no entry at indices (0, 32) in a 3x4 matrix");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix63);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        double double42 = blockRealMatrix16.getNorm();
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray57 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray58 = new double[][] { doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray64 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray75 = new double[][] { doubleArray64, doubleArray69, doubleArray74 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray75);
        double[] doubleArray82 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix76.setRow(0, doubleArray82);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = blockRealMatrix59.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix76.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix87 = blockRealMatrix76.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix16.subtract(blockRealMatrix76);
        try {
            blockRealMatrix16.luDecompose();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 291.0d + "'", double42 == 291.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(blockRealMatrix84);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(realMatrix87);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        int int3 = levenbergMarquardtOptimizer0.getIterations();
        double double4 = levenbergMarquardtOptimizer0.getRMS();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix25.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double29 = array2DRowRealMatrix25.walkInColumnOrder(realMatrixChangingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix35.subtract(realMatrix36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[][] doubleArray25 = blockRealMatrix16.getData();
        double[] doubleArray30 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray35 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray40 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray41 = new double[][] { doubleArray30, doubleArray35, doubleArray40 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray41);
        double double43 = blockRealMatrix42.getNorm();
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix42, 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix16.subtract(blockRealMatrix42);
        int int47 = blockRealMatrix46.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double53 = blockRealMatrix46.walkInColumnOrder(realMatrixChangingVisitor48, (int) (short) -1, (int) (byte) 0, (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 291.0d + "'", double43 == 291.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray8 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray19 = new double[][] { doubleArray8, doubleArray13, doubleArray18 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray19);
        double[] doubleArray26 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix20.setRow(0, doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f, realMatrix28, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable2, objArray31);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException40 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException32, 0.0d, "hi!", objArray39);
        org.apache.commons.math.exception.Localizable localizable43 = functionEvaluationException42.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable45 = null;
        double[] doubleArray50 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray55 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray60 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray61 = new double[][] { doubleArray50, doubleArray55, doubleArray60 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray61);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException63 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable45, (java.lang.Object[]) doubleArray61);
        java.text.ParseException parseException64 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable43, (java.lang.Object[]) doubleArray61);
        double[] doubleArray67 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable68 = null;
        double[] doubleArray70 = new double[] { ' ' };
        double[] doubleArray72 = new double[] { ' ' };
        double[] doubleArray74 = new double[] { ' ' };
        double[] doubleArray76 = new double[] { ' ' };
        double[] doubleArray78 = new double[] { ' ' };
        double[][] doubleArray79 = new double[][] { doubleArray70, doubleArray72, doubleArray74, doubleArray76, doubleArray78 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray79, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(doubleArray67, localizable68, (java.lang.Object[]) doubleArray79);
        java.lang.IllegalStateException illegalStateException83 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable43, (java.lang.Object[]) doubleArray79);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException85 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) mathException84);
        java.lang.Throwable[] throwableArray86 = invalidMatrixException85.getSuppressed();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException87 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("org.apache.commons.math.optimization.OptimizationException: matrix is singular", (java.lang.Object[]) throwableArray86);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(arithmeticException40);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(parseException64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(illegalStateException83);
        org.junit.Assert.assertNotNull(throwableArray86);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException87);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        double[] doubleArray35 = vectorialPointValuePair34.getPoint();
        double[] doubleArray37 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException43 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException(doubleArray37, localizable38, objArray42);
        double[] doubleArray49 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray54 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray49, doubleArray54, doubleArray59 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray60);
        double[] doubleArray67 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix61.setRow(0, doubleArray67);
        org.apache.commons.math.linear.RealMatrix realMatrix69 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray67);
        org.apache.commons.math.linear.RealMatrix realMatrix71 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair72 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(arithmeticException43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix71);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.RealMatrix realMatrix24 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        org.apache.commons.math.linear.RealVector realVector28 = blockRealMatrix24.getColumnVector(0);
        int[] intArray31 = new int[] { (byte) -1, '#' };
        int[] intArray35 = new int[] { 3, (short) -1, 'a' };
        double[] doubleArray42 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray53 = new double[][] { doubleArray42, doubleArray47, doubleArray52 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray53);
        java.io.EOFException eOFException55 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray53);
        java.util.NoSuchElementException noSuchElementException56 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.linear.NonSquareMatrixException: a -1x100 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.linear.BigMatrix bigMatrix57 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(doubleArray53);
        try {
            blockRealMatrix24.copySubMatrix(intArray31, intArray35, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(eOFException55);
        org.junit.Assert.assertNotNull(noSuchElementException56);
        org.junit.Assert.assertNotNull(bigMatrix57);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray4 = new double[] { ' ' };
        double[] doubleArray6 = new double[] { ' ' };
        double[] doubleArray8 = new double[] { ' ' };
        double[] doubleArray10 = new double[] { ' ' };
        double[] doubleArray12 = new double[] { ' ' };
        double[][] doubleArray13 = new double[][] { doubleArray4, doubleArray6, doubleArray8, doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable2, (java.lang.Object[]) doubleArray13);
        java.lang.Throwable[] throwableArray17 = functionEvaluationException16.getSuppressed();
        java.lang.Object[] objArray18 = functionEvaluationException16.getArguments();
        double[] doubleArray20 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        double[] doubleArray23 = new double[] { ' ' };
        double[] doubleArray25 = new double[] { ' ' };
        double[] doubleArray27 = new double[] { ' ' };
        double[] doubleArray29 = new double[] { ' ' };
        double[] doubleArray31 = new double[] { ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray23, doubleArray25, doubleArray27, doubleArray29, doubleArray31 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math.exception.Localizable localizable37 = null;
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray53 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray54 = new double[][] { doubleArray43, doubleArray48, doubleArray53 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray54);
        double[] doubleArray61 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix55.setRow(0, doubleArray61);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray61);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 100.0f, realMatrix63, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable37, objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException16, doubleArray20, "", objArray66);
        org.apache.commons.math.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray66);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = blockRealMatrix45.transpose();
        double double47 = blockRealMatrix45.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix48 = blockRealMatrix45.transpose();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 147.08500943332058d + "'", double47 == 147.08500943332058d);
        org.junit.Assert.assertNotNull(realMatrix48);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[] doubleArray11 = new double[] { ' ' };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable1, (java.lang.Object[]) doubleArray12);
        java.lang.Throwable[] throwableArray16 = functionEvaluationException15.getSuppressed();
        java.lang.Object[] objArray17 = functionEvaluationException15.getArguments();
        double[] doubleArray19 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException25 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray24);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, objArray24);
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray42 = new double[][] { doubleArray31, doubleArray36, doubleArray41 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray42);
        double[] doubleArray49 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix43.setRow(0, doubleArray49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray49);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray49);
        double[] doubleArray55 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException61 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray55, localizable56, objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException15, doubleArray49, "", objArray60);
        org.apache.commons.math.linear.RealMatrix realMatrix64 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray49);
        org.apache.commons.math.linear.RealMatrix realMatrix65 = org.apache.commons.math.linear.MatrixUtils.createColumnRealMatrix(doubleArray49);
        double[] doubleArray72 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray77 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray82 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray83 = new double[][] { doubleArray72, doubleArray77, doubleArray82 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray83);
        java.lang.IllegalStateException illegalStateException85 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray83);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, "BlockRealMatrix{{0.0,10.0,10.0,0.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", (java.lang.Object[]) doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(arithmeticException61);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(realMatrix65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(illegalStateException85);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        java.lang.Throwable[] throwableArray20 = maxEvaluationsExceededException19.getSuppressed();
        java.io.ObjectInputStream objectInputStream22 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) throwableArray20, "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", objectInputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray37 = new double[][] { doubleArray26, doubleArray31, doubleArray36 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray37);
        double[] doubleArray44 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix38.setRow(0, doubleArray44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix38);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl47 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix46);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.scalarAdd((double) 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", objArray1);
        java.lang.String str3 = mathException2.getPattern();
        try {
            org.apache.commons.math.optimization.OptimizationException optimizationException4 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathException2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: can't parse argument number: {97.0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str3.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException6 = new org.apache.commons.math.linear.InvalidMatrixException(localizable0, objArray4);
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) invalidMatrixException6, localizable7, objArray8);
        java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) invalidMatrixException6);
        java.lang.Object[] objArray11 = invalidMatrixException6.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arithmeticException5);
        org.junit.Assert.assertNotNull(illegalArgumentException10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.io.ObjectInputStream objectInputStream8 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) convergenceException6, "BlockRealMatrix{{0.0,10.0,10.0,0.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", objectInputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arithmeticException5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        double double42 = blockRealMatrix16.getNorm();
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray57 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray58 = new double[][] { doubleArray47, doubleArray52, doubleArray57 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray58);
        double[] doubleArray64 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray75 = new double[][] { doubleArray64, doubleArray69, doubleArray74 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray75);
        double[] doubleArray82 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix76.setRow(0, doubleArray82);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix84 = blockRealMatrix59.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix86 = blockRealMatrix76.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix87 = blockRealMatrix76.transpose();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix88 = blockRealMatrix16.subtract(blockRealMatrix76);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix90 = blockRealMatrix88.scalarAdd((double) (byte) 100);
        try {
            double[] doubleArray92 = blockRealMatrix88.getRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 291.0d + "'", double42 == 291.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(blockRealMatrix84);
        org.junit.Assert.assertNotNull(blockRealMatrix86);
        org.junit.Assert.assertNotNull(realMatrix87);
        org.junit.Assert.assertNotNull(blockRealMatrix88);
        org.junit.Assert.assertNotNull(blockRealMatrix90);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        double double62 = blockRealMatrix16.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 176.91523393987302d + "'", double62 == 176.91523393987302d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealVector realVector63 = blockRealMatrix16.getColumnVector(0);
        int int64 = blockRealMatrix16.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 3 + "'", int64 == 3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException("", objArray1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double double13 = array2DRowRealMatrix12.getNorm();
        int int14 = array2DRowRealMatrix12.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix12.walkInRowOrder(realMatrixPreservingVisitor15, (int) (short) -1, (int) (short) 1, (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 160.0d + "'", double13 == 160.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        try {
            double double46 = blockRealMatrix45.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 3x4 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        java.lang.String str62 = blockRealMatrix16.toString();
        java.io.ObjectOutputStream objectOutputStream63 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) blockRealMatrix16, objectOutputStream63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str62.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray15);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException17 = new org.apache.commons.math.linear.InvalidMatrixException(localizable11, objArray15);
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 100, (-1L), 0.0f, (byte) -1, 10L, invalidMatrixException17 };
        java.util.NoSuchElementException noSuchElementException19 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray18);
        java.text.ParseException parseException20 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', "", objArray18);
        java.text.ParseException parseException21 = org.apache.commons.math.MathRuntimeException.createParseException(0, "matrix is singular", objArray18);
        java.lang.Throwable[] throwableArray22 = parseException21.getSuppressed();
        java.io.EOFException eOFException23 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.linear.NonSquareMatrixException: a -1x100 matrix was provided instead of a square matrix", (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray42 = new double[][] { doubleArray31, doubleArray36, doubleArray41 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray42);
        double[] doubleArray49 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix43.setRow(0, doubleArray49);
        org.apache.commons.math.linear.RealMatrix realMatrix51 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray49);
        java.lang.Object[] objArray54 = new java.lang.Object[] { 100.0f, realMatrix51, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable25, objArray54);
        org.apache.commons.math.exception.Localizable localizable58 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException63 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray62);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException64 = new org.apache.commons.math.linear.InvalidMatrixException(localizable58, objArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException55, 0.0d, "hi!", objArray62);
        org.apache.commons.math.exception.Localizable localizable66 = functionEvaluationException65.getLocalizablePattern();
        double[] doubleArray71 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray76 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray81 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray82 = new double[][] { doubleArray71, doubleArray76, doubleArray81 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix83 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray82);
        double[] doubleArray89 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix83.setRow(0, doubleArray89);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix91 = blockRealMatrix83.copy();
        double[][] doubleArray92 = blockRealMatrix83.getData();
        java.lang.ArithmeticException arithmeticException93 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable66, (java.lang.Object[]) doubleArray92);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) eOFException23, "matrix is singular", (java.lang.Object[]) doubleArray92);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arithmeticException16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(noSuchElementException19);
        org.junit.Assert.assertNotNull(parseException20);
        org.junit.Assert.assertNotNull(parseException21);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(eOFException23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(arithmeticException63);
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(blockRealMatrix91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(arithmeticException93);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray37 = new double[][] { doubleArray26, doubleArray31, doubleArray36 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray37);
        double[] doubleArray44 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix38.setRow(0, doubleArray44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix38);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor47 = null;
        try {
            double double48 = blockRealMatrix38.walkInOptimizedOrder(realMatrixPreservingVisitor47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix46);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray11 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray16 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray17 = new double[][] { doubleArray6, doubleArray11, doubleArray16 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray17);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException19 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable1, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray37 = new double[][] { doubleArray26, doubleArray31, doubleArray36 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray37);
        double[] doubleArray44 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix38.setRow(0, doubleArray44);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix21.add((org.apache.commons.math.linear.RealMatrix) blockRealMatrix38);
        double double47 = blockRealMatrix38.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.MatrixUtils.checkRowIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix38, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 145.14131045295133d + "'", double47 == 145.14131045295133d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray7);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, objArray7);
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray19 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray24 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray25 = new double[][] { doubleArray14, doubleArray19, doubleArray24 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray25);
        double[] doubleArray32 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix26.setRow(0, doubleArray32);
        org.apache.commons.math.linear.RealMatrix realMatrix34 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray32);
        org.apache.commons.math.linear.RealMatrix realMatrix36 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray32);
        org.apache.commons.math.linear.BigMatrix bigMatrix37 = org.apache.commons.math.linear.MatrixUtils.createColumnBigMatrix(doubleArray32);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray0, doubleArray32, true);
        org.apache.commons.math.linear.RealVector realVector40 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(bigMatrix37);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix25.getColumnDimension();
        array2DRowRealMatrix25.setEntry(1, (int) (byte) 0, 0.0d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = array2DRowRealMatrix25.walkInOptimizedOrder(realMatrixPreservingVisitor32, (int) (short) 10, (int) (short) 1, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 10 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray1);
        int int37 = array2DRowRealMatrix36.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray7, doubleArray12, doubleArray17 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray18);
        double[] doubleArray25 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix19.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100.0f, realMatrix27, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable1, objArray30);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException39 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray38);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException40 = new org.apache.commons.math.linear.InvalidMatrixException(localizable34, objArray38);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException31, 0.0d, "hi!", objArray38);
        org.apache.commons.math.exception.Localizable localizable42 = functionEvaluationException41.getLocalizablePattern();
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException43 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Object[] objArray44 = singularMatrixException43.getArguments();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException45 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable42, objArray44);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.linear.NonSquareMatrixException: a -1x100 matrix was provided instead of a square matrix", objArray44);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray55 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray60 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray65 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray66 = new double[][] { doubleArray55, doubleArray60, doubleArray65 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray66);
        double[] doubleArray73 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix67.setRow(0, doubleArray73);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray73);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 100.0f, realMatrix75, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable49, objArray78);
        org.apache.commons.math.exception.Localizable localizable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException87 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray86);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException88 = new org.apache.commons.math.linear.InvalidMatrixException(localizable82, objArray86);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException89 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException79, 0.0d, "hi!", objArray86);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException90 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) mathException79);
        java.lang.Throwable[] throwableArray91 = invalidMatrixException90.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException92 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) noSuchElementException46, 197.0d, "hi!", (java.lang.Object[]) throwableArray91);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(arithmeticException39);
        org.junit.Assert.assertNotNull(localizable42);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException45);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(arithmeticException87);
        org.junit.Assert.assertNotNull(throwableArray91);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray5 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray10, doubleArray15 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        double[] doubleArray23 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix17.setRow(0, doubleArray23);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray23);
        org.apache.commons.math.exception.Localizable localizable28 = null;
        double[] doubleArray30 = new double[] { ' ' };
        double[] doubleArray32 = new double[] { ' ' };
        double[] doubleArray34 = new double[] { ' ' };
        double[] doubleArray36 = new double[] { ' ' };
        double[] doubleArray38 = new double[] { ' ' };
        double[][] doubleArray39 = new double[][] { doubleArray30, doubleArray32, doubleArray34, doubleArray36, doubleArray38 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable28, (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray23, "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}", (java.lang.Object[]) doubleArray39);
        java.util.ConcurrentModificationException concurrentModificationException44 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", (java.lang.Object[]) doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray39);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = null;
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix45.add(realMatrix46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(concurrentModificationException44);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix12.walkInRowOrder(realMatrixPreservingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 160.0d + "'", double13 == 160.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double double13 = array2DRowRealMatrix12.getNorm();
        int int14 = array2DRowRealMatrix12.getColumnDimension();
        int int15 = array2DRowRealMatrix12.getColumnDimension();
        double double16 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix12.walkInColumnOrder(realMatrixPreservingVisitor17, 100, (int) (byte) 100, (int) (short) -1, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 4]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 160.0d + "'", double13 == 160.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 160.0d + "'", double16 == 160.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (-1));
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException5 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray4);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException6 = new org.apache.commons.math.linear.InvalidMatrixException(localizable0, objArray4);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) invalidMatrixException6, "", objArray8);
        double[][] doubleArray13 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(4, 10);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) invalidMatrixException6, "org.apache.commons.math.linear.InvalidMatrixException: ", (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(arithmeticException5);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray19 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray20 = new double[][] { doubleArray9, doubleArray14, doubleArray19 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray27 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix21.setRow(0, doubleArray27);
        org.apache.commons.math.linear.RealMatrix realMatrix29 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray27);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0f, realMatrix29, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable3, objArray32);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException41 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray40);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException42 = new org.apache.commons.math.linear.InvalidMatrixException(localizable36, objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException33, 0.0d, "hi!", objArray40);
        org.apache.commons.math.exception.Localizable localizable44 = functionEvaluationException43.getLocalizablePattern();
        org.apache.commons.math.linear.SingularMatrixException singularMatrixException45 = new org.apache.commons.math.linear.SingularMatrixException();
        java.lang.Object[] objArray46 = singularMatrixException45.getArguments();
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException47 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException(localizable44, objArray46);
        double[] doubleArray49 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable50 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException55 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray54);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, localizable50, objArray54);
        org.apache.commons.math.exception.Localizable localizable59 = null;
        double[] doubleArray61 = new double[] { ' ' };
        double[] doubleArray63 = new double[] { ' ' };
        double[] doubleArray65 = new double[] { ' ' };
        double[] doubleArray67 = new double[] { ' ' };
        double[] doubleArray69 = new double[] { ' ' };
        double[][] doubleArray70 = new double[][] { doubleArray61, doubleArray63, doubleArray65, doubleArray67, doubleArray69 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray70, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable59, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, "matrix is singular", (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, 147.08500943332058d, localizable44, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException76 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException75);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(arithmeticException41);
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(arithmeticException55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        java.lang.String str62 = blockRealMatrix16.toString();
        boolean boolean63 = blockRealMatrix16.isSquare();
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray79 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray80 = new double[][] { doubleArray69, doubleArray74, doubleArray79 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix81 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray80);
        double[] doubleArray87 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix81.setRow(0, doubleArray87);
        org.apache.commons.math.linear.RealVector realVector89 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray87);
        blockRealMatrix16.setRowVector(0, realVector89);
        double[] doubleArray92 = blockRealMatrix16.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix93 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str62.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realVector89);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(realMatrix93);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        double double24 = blockRealMatrix16.getFrobeniusNorm();
        double[] doubleArray29 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray34 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray39 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray40 = new double[][] { doubleArray29, doubleArray34, doubleArray39 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray40);
        double[] doubleArray47 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix41.setRow(0, doubleArray47);
        org.apache.commons.math.linear.RealMatrix realMatrix49 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray47);
        boolean boolean50 = blockRealMatrix16.equals((java.lang.Object) doubleArray47);
        double[] doubleArray52 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable53 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException58 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray52, localizable53, objArray57);
        double[] doubleArray64 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray74 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray75 = new double[][] { doubleArray64, doubleArray69, doubleArray74 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray75);
        double[] doubleArray82 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix76.setRow(0, doubleArray82);
        org.apache.commons.math.linear.RealMatrix realMatrix84 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray82);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair85 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray52, doubleArray82);
        double[] doubleArray86 = vectorialPointValuePair85.getPoint();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair88 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray86, true);
        org.apache.commons.math.linear.BigMatrix bigMatrix89 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 145.14131045295133d + "'", double24 == 145.14131045295133d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(arithmeticException58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(bigMatrix89);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double[] doubleArray5 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray10, doubleArray15 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        java.lang.IllegalStateException illegalStateException18 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double22 = array2DRowRealMatrix21.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix21.createMatrix(3, 52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(illegalStateException18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 291.0d + "'", double22 == 291.0d);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl1 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray8 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray19 = new double[][] { doubleArray8, doubleArray13, doubleArray18 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray19);
        double[] doubleArray26 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix20.setRow(0, doubleArray26);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100.0f, realMatrix28, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable2, objArray31);
        org.apache.commons.math.exception.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException40 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException(localizable35, objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException32, 0.0d, "hi!", objArray39);
        org.apache.commons.math.exception.Localizable localizable43 = functionEvaluationException42.getLocalizablePattern();
        java.lang.Object[] objArray44 = null;
        java.lang.IllegalArgumentException illegalArgumentException45 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable43, objArray44);
        double[] doubleArray48 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable49 = null;
        double[] doubleArray51 = new double[] { ' ' };
        double[] doubleArray53 = new double[] { ' ' };
        double[] doubleArray55 = new double[] { ' ' };
        double[] doubleArray57 = new double[] { ' ' };
        double[] doubleArray59 = new double[] { ' ' };
        double[][] doubleArray60 = new double[][] { doubleArray51, doubleArray53, doubleArray55, doubleArray57, doubleArray59 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray60, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray48, localizable49, (java.lang.Object[]) doubleArray60);
        java.lang.IllegalStateException illegalStateException64 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", (java.lang.Object[]) doubleArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable43, (java.lang.Object[]) doubleArray60);
        double[] doubleArray67 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable68 = null;
        double[] doubleArray70 = new double[] { ' ' };
        double[] doubleArray72 = new double[] { ' ' };
        double[] doubleArray74 = new double[] { ' ' };
        double[] doubleArray76 = new double[] { ' ' };
        double[] doubleArray78 = new double[] { ' ' };
        double[][] doubleArray79 = new double[][] { doubleArray70, doubleArray72, doubleArray74, doubleArray76, doubleArray78 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray79, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(doubleArray67, localizable68, (java.lang.Object[]) doubleArray79);
        java.io.EOFException eOFException83 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable43, (java.lang.Object[]) doubleArray79);
        java.lang.Throwable[] throwableArray84 = eOFException83.getSuppressed();
        org.apache.commons.math.MathRuntimeException mathRuntimeException85 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.linear.NonSquareMatrixException: a -1x100 matrix was provided instead of a square matrix", (java.lang.Object[]) throwableArray84);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(arithmeticException40);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(illegalArgumentException45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(illegalStateException64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(eOFException83);
        org.junit.Assert.assertNotNull(throwableArray84);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double[] doubleArray2 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable3 = null;
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[] doubleArray11 = new double[] { ' ' };
        double[] doubleArray13 = new double[] { ' ' };
        double[][] doubleArray14 = new double[][] { doubleArray5, doubleArray7, doubleArray9, doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, localizable3, (java.lang.Object[]) doubleArray14);
        org.apache.commons.math.exception.Localizable localizable19 = null;
        double[] doubleArray25 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray30 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray35 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray36 = new double[][] { doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray43 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix37.setRow(0, doubleArray43);
        org.apache.commons.math.linear.RealMatrix realMatrix45 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray43);
        java.lang.Object[] objArray48 = new java.lang.Object[] { 100.0f, realMatrix45, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable19, objArray48);
        org.apache.commons.math.exception.Localizable localizable52 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException57 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray56);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException58 = new org.apache.commons.math.linear.InvalidMatrixException(localizable52, objArray56);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException49, 0.0d, "hi!", objArray56);
        org.apache.commons.math.exception.Localizable localizable60 = functionEvaluationException59.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable62 = null;
        double[] doubleArray67 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray72 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray77 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray78 = new double[][] { doubleArray67, doubleArray72, doubleArray77 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix79 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray78);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException80 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 10, localizable62, (java.lang.Object[]) doubleArray78);
        java.text.ParseException parseException81 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 0, localizable60, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.exception.Localizable localizable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException87 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray86);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException88 = new org.apache.commons.math.linear.InvalidMatrixException(localizable82, objArray86);
        java.lang.IllegalArgumentException illegalArgumentException89 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(localizable60, objArray86);
        java.lang.Object[] objArray94 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException95 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray94);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException("", objArray94);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException17, localizable60, objArray94);
        java.io.EOFException eOFException98 = org.apache.commons.math.MathRuntimeException.createEOFException("", objArray94);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(arithmeticException57);
        org.junit.Assert.assertNotNull(localizable60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(parseException81);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(arithmeticException87);
        org.junit.Assert.assertNotNull(illegalArgumentException89);
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNotNull(arithmeticException95);
        org.junit.Assert.assertNotNull(eOFException98);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray1 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, localizable2, objArray6);
        double[] doubleArray13 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray18 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray23 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray24 = new double[][] { doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray24);
        double[] doubleArray31 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix25.setRow(0, doubleArray31);
        org.apache.commons.math.linear.RealMatrix realMatrix33 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray1, doubleArray31);
        double[] doubleArray35 = vectorialPointValuePair34.getPointRef();
        double[] doubleArray36 = vectorialPointValuePair34.getValueRef();
        double[] doubleArray37 = vectorialPointValuePair34.getPoint();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException(0.0d, "hi!", objArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        levenbergMarquardtOptimizer0.setInitialStepBoundFactor(197.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.RealVector realVector24 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray22);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray22);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) realMatrix25, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix48 = blockRealMatrix33.getSubMatrix(1, 6, (int) (short) 0, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 6 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealMatrix realMatrix63 = blockRealMatrix16.scalarMultiply(160.0d);
        boolean boolean64 = blockRealMatrix16.isSquare();
        java.lang.String str65 = blockRealMatrix16.toString();
        double double66 = blockRealMatrix16.getFrobeniusNorm();
        double double67 = blockRealMatrix16.getNorm();
        blockRealMatrix16.addToEntry((int) (short) 1, 0, (double) 5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}" + "'", str65.equals("BlockRealMatrix{{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0},{97.0,0.0,0.0,32.0}}"));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 176.91523393987302d + "'", double66 == 176.91523393987302d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 291.0d + "'", double67 == 291.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray43 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray48 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray49);
        double[] doubleArray56 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix50.setRow(0, doubleArray56);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = blockRealMatrix33.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = blockRealMatrix50.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix16, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix50);
        org.apache.commons.math.linear.RealVector realVector63 = blockRealMatrix16.getColumnVector(0);
        java.io.ObjectOutputStream objectOutputStream64 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector63, objectOutputStream64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(blockRealMatrix58);
        org.junit.Assert.assertNotNull(blockRealMatrix60);
        org.junit.Assert.assertNotNull(realVector63);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        int int27 = array2DRowRealMatrix12.getColumnDimension();
        java.io.ObjectOutputStream objectOutputStream28 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12, objectOutputStream28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setMaxEvaluations((int) (short) -1);
        double double3 = levenbergMarquardtOptimizer0.getChiSquare();
        try {
            double[] doubleArray4 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.optimization.OptimizationException; message: no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.optimization.OptimizationException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        double[] doubleArray30 = new double[] { ' ' };
        double[] doubleArray32 = new double[] { ' ' };
        double[] doubleArray34 = new double[] { ' ' };
        double[] doubleArray36 = new double[] { ' ' };
        double[] doubleArray38 = new double[] { ' ' };
        double[][] doubleArray39 = new double[][] { doubleArray30, doubleArray32, doubleArray34, doubleArray36, doubleArray38 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39, true);
        double double42 = array2DRowRealMatrix41.getNorm();
        int int43 = array2DRowRealMatrix41.getColumnDimension();
        int int44 = array2DRowRealMatrix41.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = array2DRowRealMatrix25.subtract(array2DRowRealMatrix41);
        double[] doubleArray47 = new double[] { ' ' };
        double[] doubleArray49 = new double[] { ' ' };
        double[] doubleArray51 = new double[] { ' ' };
        double[] doubleArray53 = new double[] { ' ' };
        double[] doubleArray55 = new double[] { ' ' };
        double[][] doubleArray56 = new double[][] { doubleArray47, doubleArray49, doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56, true);
        double[] doubleArray60 = new double[] { ' ' };
        double[] doubleArray62 = new double[] { ' ' };
        double[] doubleArray64 = new double[] { ' ' };
        double[] doubleArray66 = new double[] { ' ' };
        double[] doubleArray68 = new double[] { ' ' };
        double[][] doubleArray69 = new double[][] { doubleArray60, doubleArray62, doubleArray64, doubleArray66, doubleArray68 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray69, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = array2DRowRealMatrix58.subtract(array2DRowRealMatrix71);
        int int73 = array2DRowRealMatrix71.getColumnDimension();
        int int74 = array2DRowRealMatrix71.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix75 = array2DRowRealMatrix25.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 160.0d + "'", double42 == 160.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertNotNull(realMatrix75);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[][] doubleArray28 = array2DRowRealMatrix27.getDataRef();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (short) 10, 100);
        try {
            org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl4 = new org.apache.commons.math.linear.LUDecompositionImpl((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix2, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 10x100 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        double double24 = blockRealMatrix16.getFrobeniusNorm();
        double[] doubleArray29 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray34 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray39 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray40 = new double[][] { doubleArray29, doubleArray34, doubleArray39 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray40);
        double[] doubleArray46 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray51 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray56 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray57 = new double[][] { doubleArray46, doubleArray51, doubleArray56 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix58 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray57);
        double[] doubleArray63 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray68 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray73 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray74 = new double[][] { doubleArray63, doubleArray68, doubleArray73 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray74);
        double[] doubleArray81 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix75.setRow(0, doubleArray81);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix83 = blockRealMatrix58.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix75);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix85 = blockRealMatrix75.getRowMatrix(0);
        org.apache.commons.math.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix41, (org.apache.commons.math.linear.AnyMatrix) blockRealMatrix75);
        org.apache.commons.math.linear.RealVector realVector88 = blockRealMatrix41.getColumnVector(0);
        org.apache.commons.math.linear.RealVector realVector89 = blockRealMatrix16.preMultiply(realVector88);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor90 = null;
        try {
            double double95 = blockRealMatrix16.walkInOptimizedOrder(realMatrixChangingVisitor90, (int) (byte) -1, 0, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 145.14131045295133d + "'", double24 == 145.14131045295133d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(blockRealMatrix83);
        org.junit.Assert.assertNotNull(blockRealMatrix85);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(realVector89);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        levenbergMarquardtOptimizer0.setParRelativeTolerance((double) 10.0f);
        int int3 = levenbergMarquardtOptimizer0.getMaxIterations();
        levenbergMarquardtOptimizer0.setMaxEvaluations(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1000 + "'", int3 == 1000);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double[] doubleArray7 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray12 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray17 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray18 = new double[][] { doubleArray7, doubleArray12, doubleArray17 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray18);
        java.lang.IllegalArgumentException illegalArgumentException20 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException21 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (short) -1, "", (java.lang.Object[]) doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(illegalArgumentException20);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) (byte) 1);
        int int3 = blockRealMatrix2.getColumnDimension();
        double double6 = blockRealMatrix2.getEntry(5, 6);
        int int7 = blockRealMatrix2.getRowDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        double double42 = blockRealMatrix33.getNorm();
        int int43 = blockRealMatrix33.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor44 = null;
        try {
            double double45 = blockRealMatrix33.walkInOptimizedOrder(realMatrixChangingVisitor44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 194.0d + "'", double42 == 194.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray5 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray10 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray15 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray10, doubleArray15 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        java.lang.IllegalStateException illegalStateException18 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("matrix is singular", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        double double22 = array2DRowRealMatrix21.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double24 = array2DRowRealMatrix21.walkInRowOrder(realMatrixChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(illegalStateException18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 291.0d + "'", double22 == 291.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix33.scalarAdd((double) (byte) 1);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = blockRealMatrix33.getRowMatrix(1000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 1,000 out of allowed range [0, 2]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix33.createMatrix((int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray26 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray31 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray39 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix33.setRow(0, doubleArray39);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix16.subtract((org.apache.commons.math.linear.RealMatrix) blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix33.getRowMatrix(0);
        org.apache.commons.math.linear.RealMatrix realMatrix44 = blockRealMatrix33.transpose();
        double[] doubleArray47 = new double[] { 100 };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException53 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray52);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, objArray52);
        double[] doubleArray59 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray64 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray69 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray70 = new double[][] { doubleArray59, doubleArray64, doubleArray69 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray70);
        double[] doubleArray77 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix71.setRow(0, doubleArray77);
        org.apache.commons.math.linear.RealMatrix realMatrix79 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray77);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair80 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray77);
        org.apache.commons.math.linear.RealVector realVector81 = org.apache.commons.math.linear.MatrixUtils.createRealVector(doubleArray77);
        try {
            blockRealMatrix33.setColumn(0, doubleArray77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 4x1 but expected 3x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(arithmeticException53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realMatrix79);
        org.junit.Assert.assertNotNull(realVector81);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray1 = new double[] { ' ' };
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, true);
        double[] doubleArray14 = new double[] { ' ' };
        double[] doubleArray16 = new double[] { ' ' };
        double[] doubleArray18 = new double[] { ' ' };
        double[] doubleArray20 = new double[] { ' ' };
        double[] doubleArray22 = new double[] { ' ' };
        double[][] doubleArray23 = new double[][] { doubleArray14, doubleArray16, doubleArray18, doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix12.subtract(array2DRowRealMatrix25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix25.scalarAdd((double) (-1L));
        int int29 = array2DRowRealMatrix25.getColumnDimension();
        java.lang.Class<?> wildcardClass30 = array2DRowRealMatrix25.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.exception.Localizable localizable10 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (byte) -1 };
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray14);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException16 = new org.apache.commons.math.linear.InvalidMatrixException(localizable10, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 100, (-1L), 0.0f, (byte) -1, 10L, invalidMatrixException16 };
        java.util.NoSuchElementException noSuchElementException18 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray17);
        java.text.ParseException parseException19 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', "", objArray17);
        java.text.ParseException parseException20 = org.apache.commons.math.MathRuntimeException.createParseException(0, "matrix is singular", objArray17);
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException20);
        org.apache.commons.math.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException21);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(arithmeticException15);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(noSuchElementException18);
        org.junit.Assert.assertNotNull(parseException19);
        org.junit.Assert.assertNotNull(parseException20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double[] doubleArray4 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray9 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray14 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray15);
        double[] doubleArray22 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix16.setRow(0, doubleArray22);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix16.copy();
        double[] doubleArray26 = blockRealMatrix24.getColumn((int) (byte) 1);
        double double27 = blockRealMatrix24.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix24.getRowMatrix((int) (byte) 0);
        double[] doubleArray36 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray41 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray46 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray47 = new double[][] { doubleArray36, doubleArray41, doubleArray46 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray47);
        java.io.EOFException eOFException49 = org.apache.commons.math.MathRuntimeException.createEOFException("hi!", (java.lang.Object[]) doubleArray47);
        java.util.NoSuchElementException noSuchElementException50 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.linear.NonSquareMatrixException: a -1x100 matrix was provided instead of a square matrix", (java.lang.Object[]) doubleArray47);
        boolean boolean51 = blockRealMatrix29.equals((java.lang.Object) noSuchElementException50);
        boolean boolean52 = blockRealMatrix29.isSquare();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 194.0d + "'", double27 == 194.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(eOFException49);
        org.junit.Assert.assertNotNull(noSuchElementException50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { ' ' };
        double[] doubleArray5 = new double[] { ' ' };
        double[] doubleArray7 = new double[] { ' ' };
        double[] doubleArray9 = new double[] { ' ' };
        double[] doubleArray11 = new double[] { ' ' };
        double[][] doubleArray12 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(10.0d, localizable1, (java.lang.Object[]) doubleArray12);
        java.lang.Throwable[] throwableArray16 = functionEvaluationException15.getSuppressed();
        java.lang.Object[] objArray17 = functionEvaluationException15.getArguments();
        double[] doubleArray19 = new double[] { (byte) 100 };
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray22 = new double[] { ' ' };
        double[] doubleArray24 = new double[] { ' ' };
        double[] doubleArray26 = new double[] { ' ' };
        double[] doubleArray28 = new double[] { ' ' };
        double[] doubleArray30 = new double[] { ' ' };
        double[][] doubleArray31 = new double[][] { doubleArray22, doubleArray24, doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, true);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray19, localizable20, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math.exception.Localizable localizable36 = null;
        double[] doubleArray42 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray47 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[] doubleArray52 = new double[] { 'a', (short) 0, 0.0f, ' ' };
        double[][] doubleArray53 = new double[][] { doubleArray42, doubleArray47, doubleArray52 };
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray53);
        double[] doubleArray60 = new double[] { 0.0f, 10L, 10.0f, 0L };
        blockRealMatrix54.setRow(0, doubleArray60);
        org.apache.commons.math.linear.RealMatrix realMatrix62 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray60);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 100.0f, realMatrix62, (-1L), 100.0f };
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable36, objArray65);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException15, doubleArray19, "", objArray65);
        java.lang.Object[] objArray68 = functionEvaluationException15.getArguments();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realMatrix62);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray68);
    }
}

