import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray32 = new double[] {};
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray38 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray44 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        java.lang.Class<?> wildcardClass46 = doubleArray38.getClass();
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double[] doubleArray48 = new double[] {};
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray54 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray60 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        java.lang.Class<?> wildcardClass62 = doubleArray54.getClass();
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray54);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray67 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (-0.0d));
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray48);
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 35.15078488198184d + "'", double31 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.4056476493802699d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.980724780168636d + "'", double2 == 44.980724780168636d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.4276814831852543d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3479809392380016d) + "'", double1 == (-0.3479809392380016d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.044242678085070965d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-2.697156712436407E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray6 = new double[] { 4.662521952941945d, (-0.0d), 1.0142320547350045E304d, 35.00000000000001d, 152L, 8.625329E18f };
        double[] doubleArray11 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray17 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray24 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray30 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray30);
        double[] doubleArray37 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray43 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray43);
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 35.15078488198184d + "'", double19 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.118089298841471E9d + "'", double32 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.118089298841471E9d + "'", double45 == 1.118089298841471E9d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray32 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray32);
        int[] intArray38 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray43 = new int[] { (short) 1, 0, 0, 10 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray43);
        int[] intArray50 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int[] intArray55 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray60 = new int[] { (short) 1, 0, 0, 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int[] intArray68 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray68);
        java.lang.Class<?> wildcardClass71 = intArray43.getClass();
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 112.70314991161516d + "'", double33 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 110 + "'", int44 == 110);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 112.70314991161516d + "'", double51 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 110 + "'", int61 == 110);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 20 + "'", int69 == 20);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 102.60116958397697d + "'", double70 == 102.60116958397697d);
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long2 = org.apache.commons.math.util.FastMath.min((-4707426507428119391L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4707426507428119391L) + "'", long2 == (-4707426507428119391L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.662521952941945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998216898100953d + "'", double1 == 0.9998216898100953d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0142320547350045E304d, (-1.399519048E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 2146959360, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1399519048), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1399519048 + "'", int2 == 1399519048);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 130, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1118089298), 0.879180103820589d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.118089298E9d) + "'", double2 == (-1.118089298E9d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8388608.0d + "'", double1 == 8388608.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-620), 2146959360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        try {
            double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (-0.38405638914413504d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.879180103820589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0741387582883313d + "'", double1 == 1.0741387582883313d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 700, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1118089298), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7071067811865475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) '#');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 1);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (-62));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 30, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 800L + "'", long2 == 800L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 99, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray11 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray5.getClass();
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray35 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray41 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray48 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray54 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray35);
        double[] doubleArray71 = new double[] {};
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray83 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        java.lang.Class<?> wildcardClass85 = doubleArray77.getClass();
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray77);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray71);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.15078488198184d + "'", double43 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.118089298841471E9d + "'", double56 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.118089298841471E9d + "'", double69 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3410L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7931197251535193088L + "'", long2 == 7931197251535193088L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4677992676220695d, (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1L), (double) 735L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.9518224930797358d, (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-62), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (-62));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.731537741517051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, 534.4916555247646d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.2778677076244884E265d + "'", double2 == 5.2778677076244884E265d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1118089298), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1118089298) + "'", int2 == (-1118089298));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.38405638914413504d), (double) 48L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.384056389144135d) + "'", double2 == (-0.384056389144135d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.044242678085070965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0009788669371438d + "'", double1 == 1.0009788669371438d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, 2146959360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2146959360 + "'", int2 == 2146959360);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int2 = org.apache.commons.math.util.FastMath.min(1105198592, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1118089298), (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1118089199L) + "'", long2 == (-1118089199L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(4L, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        int[] intArray40 = new int[] { (byte) 10, 35, 20, (short) 10 };
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (-4707426507428119391L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4707426507428119391L) + "'", long2 == (-4707426507428119391L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-4707426507428119391L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.apache.commons.math.util.FastMath.max((-4707426507428119391L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7071067811865475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray16);
        try {
            double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(3200L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.47686392420406337d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49514360981578d + "'", double1 == 0.49514360981578d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.283185307179587d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9778808522778295d) + "'", double1 == (-0.9778808522778295d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-620));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1065132032) + "'", int1 == (-1065132032));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.4056476493802699d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.53767779197439d + "'", double1 == 80.53767779197439d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-4707426507428119391L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.399519048E9d), (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3995190479999998E9d) + "'", double2 == (-1.3995190479999998E9d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 110);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.283185307179586d + "'", number4.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray33 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray33);
        int[] intArray36 = null;
        try {
            int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.60116958397697d + "'", double35 == 102.60116958397697d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray35 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray41 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray48 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray54 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray35);
        double[] doubleArray71 = new double[] {};
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray83 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray83);
        java.lang.Class<?> wildcardClass85 = doubleArray77.getClass();
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray77);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray90 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (-0.0d));
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray92);
        try {
            double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.15078488198184d + "'", double43 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.118089298841471E9d + "'", double56 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.118089298841471E9d + "'", double69 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) (-1.0d), (-620));
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException7.getSuppressed();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(735L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 5200L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.acosh(112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.41788486822046d + "'", double1 == 5.41788486822046d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9801672890054735d + "'", double1 == 0.9801672890054735d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(700.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.879040017426007d + "'", double1 == 8.879040017426007d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-53L), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1026528268144425295L) + "'", long2 == (-1026528268144425295L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7071067811865475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.51423422706977d + "'", double1 == 40.51423422706977d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-620), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 48L, 110);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (-620));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NaN, 0.015050303523504572d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.4365658100345553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(735L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14700L + "'", long2 == 14700L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1079574590L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1399519048));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1399519048 + "'", int1 == 1399519048);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1118089298), 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.518412495074819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 86.99862752771602d + "'", double1 == 86.99862752771602d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1065132032));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-52L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-50.0d) + "'", double2 == (-50.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1065132032));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.util.FastMath.max(44.980724780168636d, 1.0142320547350045E304d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0142320547350045E304d + "'", double2 == 1.0142320547350045E304d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.666310772197643E157d + "'", double1 == 4.666310772197643E157d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.161687652319475d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.154434690031884d, 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8975475437951029d + "'", double2 == 0.8975475437951029d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1891529137764139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0741387582883313d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0d), 2.161687652319475d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4332837984272022d) + "'", double2 == (-0.4332837984272022d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.879040017426007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6072563063473564d) + "'", double1 == (-0.6072563063473564d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-52), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-744.4400719213812d), 0.09966865249116202d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long1 = org.apache.commons.math.util.FastMath.abs((-52L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 20.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4258259770489514E8d + "'", double1 == 2.4258259770489514E8d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.4071364206539694E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9839976396436506d) + "'", double1 == (-0.9839976396436506d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(32L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 2146959360);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8975475437951029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0009788669371438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long long2 = org.apache.commons.math.util.FastMath.max((-52L), 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3569687047394818d + "'", double1 == 1.3569687047394818d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 30, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 101, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.0d + "'", double2 == 101.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.FastMath.max(10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, 1105198592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1105198592 + "'", int2 == 1105198592);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray19 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (-0.0d));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException27.getSuppressed();
        java.lang.Class<?> wildcardClass30 = nonMonotonousSequenceException27.getClass();
        java.lang.Number number31 = nonMonotonousSequenceException27.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException27.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection32, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (short) 1 + "'", number31.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100L, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9933858671331224d + "'", double2 == 0.9933858671331224d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 32L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1105198592L, 99);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) -1, 130);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 109 and 110 are not decreasing (0 < 3.142)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 109 and 110 are not decreasing (0 < 3.142)"));
        org.junit.Assert.assertNull(orderDirection8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1079574528, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.384017341061263E11d + "'", double1 == 1.384017341061263E11d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9271524016877463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5273021797487805d + "'", double1 == 1.5273021797487805d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (-1118089199L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-50.0d), (-0.0d), 100.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 14700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4688371876123612d) + "'", double1 == (-0.4688371876123612d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(52.0d, (-0.4332837984272022d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7345175425633101d + "'", double2 == 1.7345175425633101d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.662521952941945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.159287371551537d + "'", double1 == 2.159287371551537d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-4707426507428119391L), 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7083508509607389407L) + "'", long2 == (-7083508509607389407L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.999020813314648d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.239676248656245d) + "'", double1 == (-57.239676248656245d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 4L, 101);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), (long) (-1399519048));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1399519048L) + "'", long2 == (-1399519048L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 48L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 48.0f + "'", float1 == 48.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.FastMath.min(5L, (long) 1399519048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1118089298), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5430806348152437d, 1.7345175425633101d, (double) (-1118089298));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(99, (-620));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(800L, 14700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 800L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, 1105198592L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1105198592L + "'", long2 == 1105198592L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9801672890054735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9801672890054735d + "'", double1 == 0.9801672890054735d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2146959360, 48L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2146959360L + "'", long2 == 2146959360L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long1 = org.apache.commons.math.util.FastMath.abs(1105198592L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1105198592L + "'", long1 == 1105198592L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5413248546129181d, 0.862318872287684d, (double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(735L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23520L + "'", long2 == 23520L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5395564933646284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) Float.NEGATIVE_INFINITY, 0.9271524016877463d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(700, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.util.MathUtils.log(534.4916555247646d, 0.9518224930797358d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.00786088735110676d) + "'", double2 == (-0.00786088735110676d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.049875621120893d + "'", double1 == 19.049875621120893d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2758547353515625L, (double) 101, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3410L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3410 + "'", int1 == 3410);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-52), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1552941056 + "'", int2 == 1552941056);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2, 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.6072563063473564d), 99, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        int[] intArray39 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray44 = new int[] { (short) 1, 0, 0, 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        try {
            int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 110 + "'", int45 == 110);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.floor(80.53767779197439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.0d + "'", double1 == 80.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1079525376, 5, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.07952538E9f + "'", float3 == 1.07952538E9f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 99, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3465L + "'", long2 == 3465L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.log(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long1 = org.apache.commons.math.util.MathUtils.sign(8625328718985906577L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1399519048L), (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5598076192L + "'", long2 == 5598076192L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.tan(35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6742957450437334d + "'", double1 == 0.6742957450437334d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) Float.NEGATIVE_INFINITY, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.141592653589793d, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9912209064978486E30d + "'", double2 == 1.9912209064978486E30d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3410L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 100, 110, orderDirection10, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.4365658100345553d, (double) (-1065132032));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9443504370351303d + "'", double1 == 0.9443504370351303d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(735L, (-1118089199L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-821795561265L) + "'", long2 == (-821795561265L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.sinh(198.99499987499365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3225142992058E86d + "'", double1 == 1.3225142992058E86d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.00786088735110676d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007861049272487425d) + "'", double1 == (-0.007861049272487425d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.118089298E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.04847649056286d + "'", double1 == 9.04847649056286d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.249561075883902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5199.999999999999d + "'", double1 == 5199.999999999999d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.09966865249116202d + "'", number9.equals(0.09966865249116202d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2146959360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.9912209064978486E30d, 1.384017341061263E11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1L, 101, 1105198592);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 52, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 208.0d + "'", double2 == 208.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5713088006770572d + "'", double1 == 1.5713088006770572d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 700, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5600L + "'", long2 == 5600L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray23 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray23);
        double[] doubleArray30 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray36 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        java.lang.Class<?> wildcardClass38 = doubleArray30.getClass();
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.118089298841471E9d + "'", double25 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        long long2 = org.apache.commons.math.util.FastMath.max(48L, (long) 1105198592);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1105198592L + "'", long2 == 1105198592L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-96));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7031839360032603E-108d + "'", double1 == 1.7031839360032603E-108d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(110L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 30, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 129L + "'", long2 == 129L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1399519048);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        try {
            double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 52.0f);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-620));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-620) + "'", int1 == (-620));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.6234111137925007d, (double) 23520L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.6234111137925007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.623411113792501d + "'", double1 == 1.623411113792501d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9120458137799814d + "'", double1 == 0.9120458137799814d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.6072563063473564d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6526026816585506d) + "'", double1 == (-0.6526026816585506d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, 110);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 130);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 130L + "'", long1 == 130L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.118089298E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray23 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray23);
        double[] doubleArray26 = new double[] {};
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray38 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray32.getClass();
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray47 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray53 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        java.lang.Class<?> wildcardClass55 = doubleArray47.getClass();
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray47);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray74 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray80 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray80);
        double[] doubleArray87 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray93 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray93);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray61);
        double double97 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray47);
        double[] doubleArray99 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 6.938893903907228E-18d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.118089298841471E9d + "'", double25 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 35.15078488198184d + "'", double69 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.118089298841471E9d + "'", double82 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.118089298841471E9d + "'", double95 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1105198592L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1065132032));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1504440784612413d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double2 = org.apache.commons.math.util.FastMath.max(2.2250738585072014E-308d, 5199.999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5199.999999999999d + "'", double2 == 5199.999999999999d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 735L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 7931197251535193088L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.exp(80.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.54062238439351E34d + "'", double1 == 5.54062238439351E34d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.49514360981578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.125108610420262d + "'", double1 == 1.125108610420262d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.7763568394002505E-15d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-1065132032));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.1891529137764139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8715887107714164d + "'", double1 == 0.8715887107714164d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9933858671331224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5353413938087774d + "'", double1 == 1.5353413938087774d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double2 = org.apache.commons.math.util.FastMath.min(2.2250738585072014E-308d, 0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2250738585072014E-308d + "'", double2 == 2.2250738585072014E-308d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 130);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 130.0d + "'", double1 == 130.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 130L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 130.0f + "'", float1 == 130.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2748734119735194E-306d + "'", double1 == 1.2748734119735194E-306d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1399519048));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.3995191E9f) + "'", float2 == (-1.3995191E9f));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.ulp(20.799832845832398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.ceil(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 157.0d + "'", double1 == 157.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.053150169140215E-107d, 0.8975475437951029d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int2 = org.apache.commons.math.util.FastMath.min(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, (long) 700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1150962225 + "'", int2 == 1150962225);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3410, 3410);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1105198592, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6625219529419444d + "'", double1 == 3.6625219529419444d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(20, 1105198592);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-821795561265L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3284429331859869d) + "'", double1 == (-0.3284429331859869d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        int[] intArray39 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray44 = new int[] { (short) 1, 0, 0, 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int[] intArray51 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray56 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray61 = new int[] { (short) 1, 0, 0, 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray69 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray69);
        java.lang.Class<?> wildcardClass72 = intArray44.getClass();
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray44);
        int[] intArray77 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray82 = new int[] { (short) 1, 0, 0, 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray82);
        int[] intArray90 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray90);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 110 + "'", int45 == 110);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 112.70314991161516d + "'", double52 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 110 + "'", int62 == 110);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 20 + "'", int70 == 20);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 102.60116958397697d + "'", double71 == 102.60116958397697d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 99.508793581271d + "'", double73 == 99.508793581271d);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 110 + "'", int83 == 110);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 20 + "'", int91 == 20);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 14.212670403551895d + "'", double92 == 14.212670403551895d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 800L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 48.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.016735912097631E20d + "'", double1 == 7.016735912097631E20d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1105198592, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(19.049875621120893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.380497402550226E7d + "'", double1 == 9.380497402550226E7d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6742957450437334d, (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.sin(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097466d) + "'", double1 == (-0.5063656411097466d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.0d + "'", double1 == 30.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9589242746631385d) + "'", double1 == (-0.9589242746631385d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.apache.commons.math.util.FastMath.min(3200L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.0d + "'", double1 == 101.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.asin(35.00000000000001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0741387582883313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0241261664664894d + "'", double1 == 1.0241261664664894d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1118089298), (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.8606487491999707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.39379096750323d + "'", double1 == 1.39379096750323d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 800L, 163);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-52));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.92097202766467E47d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5598076192L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(48.21273601220948d, (-1399519048));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1821728472264846E57d) + "'", double2 == (-1.1821728472264846E57d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray33 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray33);
        int[] intArray39 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray44 = new int[] { (short) 1, 0, 0, 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int[] intArray51 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray56 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray61 = new int[] { (short) 1, 0, 0, 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray69 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray69);
        java.lang.Class<?> wildcardClass72 = intArray44.getClass();
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.60116958397697d + "'", double35 == 102.60116958397697d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 110 + "'", int45 == 110);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 112.70314991161516d + "'", double52 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 110 + "'", int62 == 110);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 20 + "'", int70 == 20);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 102.60116958397697d + "'", double71 == 102.60116958397697d);
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9039295044086464d) + "'", double1 == (-0.9039295044086464d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-2.697156712436407E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5453569630798636E22d) + "'", double1 == (-1.5453569630798636E22d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10, 52, 101);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, (long) 1105198592);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5525992960L + "'", long2 == 5525992960L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.9518224930797358d, (-620));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.301801982276166d + "'", double1 == 2.301801982276166d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-7083508509607389407L), (float) 99);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.0835086E18f) + "'", float2 == (-7.0835086E18f));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray32 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray32);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 112.70314991161516d + "'", double33 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 152L, (float) 152L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 152.0f + "'", float2 == 152.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-4707426507428119391L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 5200L, (-62));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.cos(14.212670403551895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07543174482860404d) + "'", double1 == (-0.07543174482860404d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1399519048);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(68.36991068444502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 68.36991068444503d + "'", double1 == 68.36991068444503d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1150962225);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8975475437951029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4535784328948413d + "'", double1 == 1.4535784328948413d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int2 = org.apache.commons.math.util.FastMath.max(2, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 163, 2.0d, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 1079574590L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.846893402426231d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6623138832856035d + "'", double1 == 0.6623138832856035d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1180893200525117E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52, 1.07952538E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07952538E9f + "'", float2 == 1.07952538E9f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(5, 163);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 815 + "'", int2 == 815);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.016735912097631E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8886110.520507872d + "'", double1 == 8886110.520507872d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9518224930797358d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 62.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-4707426507428119391L), 163);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2826385754148210145L + "'", long2 == 2826385754148210145L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException4.getDirection();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = nonMonotonousSequenceException4.getClass();
        java.lang.Number number8 = nonMonotonousSequenceException4.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException4.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.6623138832856035d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.92097202766467E47d, 208.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1399519048L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3925628333392019d + "'", double1 == 0.3925628333392019d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.00786088735110676d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007891947004112108d) + "'", double1 == (-0.007891947004112108d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 800L + "'", long2 == 800L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1932800507380155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.011664008437068d + "'", double1 == 1.011664008437068d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.161687652319475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.400457267951947d + "'", double1 == 4.400457267951947d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number14, (java.lang.Number) 48L, 110);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection18, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 35.15078488198184d + "'", double13 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2748734119735194E-306d, 1.518412495074819d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-62));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.2250738585072014E-308d, 5.54062238439351E34d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1118089199L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9839976396436506d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double2 = org.apache.commons.math.util.MathUtils.log((-3.620442679126975d), 44.980724780168636d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2758547353515625L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.185039863261519d) + "'", double1 == (-2.185039863261519d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 62.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219178334370727E26d + "'", double1 == 4.219178334370727E26d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 62.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219178334370727E26d + "'", double1 == 4.219178334370727E26d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.007861049272487425d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007830232029482274d) + "'", double1 == (-0.007830232029482274d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.cosh(99.508793581271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.224129827130919E42d + "'", double1 == 8.224129827130919E42d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(35, (-1065132032));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray7 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray13 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray7.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray17 = new double[] {};
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray23 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray29 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray23.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray36 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (-0.0d));
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray17);
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.sin(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6584793034514765d) + "'", double1 == (-0.6584793034514765d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.math.util.FastMath.max(1105198592, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1105198592 + "'", int2 == 1105198592);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.731537741517051d, 3410);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.393304448401136E-207d + "'", double2 == 5.393304448401136E-207d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3, (double) (-1399519048));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.54062238439351E34d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1399519048, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.01529359817505d + "'", double2 == 97.01529359817505d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-7083508509607389407L), (long) 1399519048);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long1 = org.apache.commons.math.util.FastMath.round((double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, (double) (-1118089199L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray19 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (-0.0d));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray29 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray35 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray35);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-2.697156712436407E20d));
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray39);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 35.15078488198184d + "'", double24 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.118089298841471E9d + "'", double37 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        long long2 = org.apache.commons.math.util.MathUtils.pow(152L, 129L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-52), (long) 1105198592);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1105198540L + "'", long2 == 1105198540L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-62), 0.8686709614860095d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int2 = org.apache.commons.math.util.FastMath.min((-62), 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-62) + "'", int2 == (-62));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1118089298));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray9 = new int[] { (short) 1, 0, 0, 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        try {
            int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 110 + "'", int10 == 110);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.05235987755982989d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05240777928304121d + "'", double1 == 0.05240777928304121d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(110);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(5.0711602736750225E303d, (-62), (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException10.getClass();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.String str15 = nonMonotonousSequenceException10.toString();
        java.lang.Number number16 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) -1 + "'", number11.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.09966865249116202d + "'", number16.equals(0.09966865249116202d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 129L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 129.0f + "'", float1 == 129.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2748734119735194E-306d, (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1504440784612413d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 9.9f, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5117484916013424d + "'", double2 == 1.5117484916013424d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.48232336227865d + "'", double2 == 30.48232336227865d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 110, (long) (-1118089298));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1118089298L) + "'", long2 == (-1118089298L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-225811322) + "'", int1 == (-225811322));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7853981633974483d, 0.8975475437951029d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-7083508509607389407L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1399519048), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.017874927409903d + "'", double1 == 10.017874927409903d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 163);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7802358370342162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031070976818244278d + "'", double1 == 0.031070976818244278d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.605170185988092d, (double) 62.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1), (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.3225142992058E86d, (double) 5200L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1118089298L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray19 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray25 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray19.getClass();
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray34 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray40 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray34.getClass();
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray34);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 35.15078488198184d + "'", double44 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2146959360, 14700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31560302592000L + "'", long2 == 31560302592000L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.3018019822761655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.9518224930797358d, (-225811322));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1530810176314278E-268d) + "'", double2 == (-1.1530810176314278E-268d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        long long2 = org.apache.commons.math.util.MathUtils.pow(152L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 0, 2146959360);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023058681398d, (java.lang.Number) 52L, 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 130L, 1, (-62));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-53L), 2.4365658100345553d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.4688371876123612d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7768562856686253d) + "'", double1 == (-0.7768562856686253d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.118089298E9d, 1.4535784328948413d, 20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.125108610420262d, Double.NEGATIVE_INFINITY, 0.6687635479337126d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 0, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3200L, 0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5706271627794437d + "'", double2 == 1.5706271627794437d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(157.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.529964086141668d + "'", double1 == 12.529964086141668d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.sinh(130.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.436324775408916E56d + "'", double1 == 1.436324775408916E56d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1079574590L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 99);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 52.0f, 8388608.0d, 20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(101.0d, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.548635623644201E17d + "'", double2 == 4.548635623644201E17d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950547536867305d + "'", double1 == 0.9950547536867305d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray44 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray50 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray50);
        double[] doubleArray58 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray64 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray71 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray77 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray77);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (-2.697156712436407E20d));
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.118089298E9d + "'", double52 == 1.118089298E9d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 35.15078488198184d + "'", double66 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.118089298841471E9d + "'", double79 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1552941056);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-7083508509607389407L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.4332837984272022d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7567007248655965d) + "'", double1 == (-0.7567007248655965d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-96), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7768562856686253d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1552941056);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.846893402426231d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9518224930797357d + "'", double1 == 0.9518224930797357d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1118089298));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int1 = org.apache.commons.math.util.FastMath.round((-7.0835086E18f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.6234111137925007d, 163);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6234111137925007d + "'", double2 == 1.6234111137925007d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.662521952941945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04984636245302756d) + "'", double1 == (-0.04984636245302756d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 100, (long) 1079525376);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107952537600L + "'", long2 == 107952537600L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1.1f), (double) (-53L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.006400106306439639d) + "'", double2 == (-0.006400106306439639d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-620), 99L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(52, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(20, 1552941056);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-52L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long2 = org.apache.commons.math.util.FastMath.max((-53L), 275854735351562500L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 275854735351562500L + "'", long2 == 275854735351562500L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.6253289708097372E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1552941056);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(100L, (long) 1399519048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1399519148L + "'", long2 == 1399519148L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9518224930797358d, 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0198875938040729E-158d + "'", double2 == 1.0198875938040729E-158d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray7 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray13 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray7.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray17 = new double[] {};
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray23 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray29 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        java.lang.Class<?> wildcardClass31 = doubleArray23.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray36 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (-0.0d));
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray17);
        try {
            double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5413248546129181d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.814990705660335d + "'", double1 == 0.814990705660335d);
    }
}

