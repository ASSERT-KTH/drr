import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test01");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.011768680883201384d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test02");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test03");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 9700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test04");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test05");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 102.60116958397697d, (java.lang.Number) 4.662521952941945d, 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test06");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5514266812416906d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test07");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(198743.24000384324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.35760434034037d + "'", double1 == 58.35760434034037d);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test08");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.1965079820738467d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test09");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1905747767), 5200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1905752967L) + "'", long2 == (-1905752967L));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test10");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 780, (long) 1807551715);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1807551715L + "'", long2 == 1807551715L);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test11");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', 9178556838640688257L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9178556838640688257L + "'", long2 == 9178556838640688257L);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test12");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.871201010907891d, 1.488231613290465d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.293734425634101d + "'", double2 == 0.293734425634101d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test13");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.249561075883902d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test14");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.749382843354661d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 312.9968152543229d + "'", double1 == 312.9968152543229d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test15");
        int int2 = org.apache.commons.math.util.FastMath.min((-1118089344), 1105198592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1118089344) + "'", int2 == (-1118089344));
    }
}

