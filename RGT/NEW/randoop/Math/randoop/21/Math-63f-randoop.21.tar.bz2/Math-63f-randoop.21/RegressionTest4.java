import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass8 = nonMonotonousSequenceException5.getClass();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 110 + "'", int7 == 110);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-933449039));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 1399519059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1151677663) + "'", int2 == (-1151677663));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.9471802323192449d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9471802323192448d) + "'", double1 == (-0.9471802323192448d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1932800507380155d, (java.lang.Number) 101.0d, 32);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.1932800507380155d + "'", number4.equals(1.1932800507380155d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 109 and 110 are not decreasing (0 < 3.142)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 109 and 110 are not decreasing (0 < 3.142)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 110 + "'", int8 == 110);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(90, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(129.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2514747350726854d + "'", double1 == 2.2514747350726854d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8930184728248454d + "'", double1 == 1.8930184728248454d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 33466810368L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-7083508509607389407L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.10397838873113555d), 2170);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.10397838873113555d) + "'", double2 == (-0.10397838873113555d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1905747897));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1905747897L + "'", long1 == 1905747897L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3410, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(62, 3300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102300 + "'", int2 == 102300);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.5063656411097466d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7059602000407386d) + "'", double1 == (-0.7059602000407386d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1174218874400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1083613.8031605172d + "'", double1 == 1083613.8031605172d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.5403023058681398d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double double1 = org.apache.commons.math.util.FastMath.acos(329.415371729147d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7071067811865475d, 1.118089320052512E9d, 100.00000000000001d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1521073243L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.323669049311247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5600.000000000002d + "'", double1 == 5600.000000000002d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.4688371876123612d), (-0.25103907878345744d), (-0.4688371876123612d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 1079574590L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-52), 2758547353515625L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.82932278424705d + "'", double1 == 92.82932278424705d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1065132032L), (long) 132);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35149357056L + "'", long2 == 35149357056L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray32 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray32);
        int[] intArray38 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray43 = new int[] { (short) 1, 0, 0, 10 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray43);
        int[] intArray50 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int[] intArray55 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray60 = new int[] { (short) 1, 0, 0, 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int[] intArray68 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray68);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray68);
        int[] intArray72 = null;
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 112.70314991161516d + "'", double33 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 110 + "'", int44 == 110);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 112.70314991161516d + "'", double51 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 110 + "'", int61 == 110);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 20 + "'", int69 == 20);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 102.60116958397697d + "'", double70 == 102.60116958397697d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 99 + "'", int71 == 99);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.4258259770489514E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.6102790696677047E-23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6102790696677047E-23d + "'", double1 == 2.6102790696677047E-23d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10L, 5.298292365610484d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198743.24000384324d + "'", double2 == 198743.24000384324d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray15 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray15);
        int[] intArray20 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray25 = new int[] { (short) 1, 0, 0, 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray32 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray32);
        int[] intArray38 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray43 = new int[] { (short) 1, 0, 0, 10 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray43);
        int[] intArray50 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int[] intArray55 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray60 = new int[] { (short) 1, 0, 0, 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int[] intArray68 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray68);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray68);
        int[] intArray75 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray80 = new int[] { (short) 1, 0, 0, 10 };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray80);
        int[] intArray88 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray88);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 112.70314991161516d + "'", double16 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 110 + "'", int26 == 110);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 112.70314991161516d + "'", double33 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 110 + "'", int44 == 110);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 112.70314991161516d + "'", double51 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 110 + "'", int61 == 110);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 20 + "'", int69 == 20);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 102.60116958397697d + "'", double70 == 102.60116958397697d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 99 + "'", int71 == 99);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 110 + "'", int81 == 110);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 20 + "'", int89 == 20);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7853981633974482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6657737500283538d + "'", double1 == 0.6657737500283538d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 961);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.3342280380345604d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1399519059, (-52L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 20, 506.132825342035d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 506.132825342035d + "'", double2 == 506.132825342035d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3300, 1118089397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1118092697 + "'", int2 == 1118092697);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147483638));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1545456228, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-777.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) '#');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2146959360);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 10);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 10);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger37);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger38);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 0);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 10);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) '#');
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 2146959360);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger48);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 5200L);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) 0);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) 10);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) '#');
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, 2146959360);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger58);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 101);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger63);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger63, (java.lang.Number) 5600, 887825539);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger64);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 129L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.552944561447435d + "'", double1 == 5.552944561447435d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 139951904801L, 0.0d, 0.7151016276674029d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        try {
            double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) '#');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2146959360);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 5200L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 10);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) '#');
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 2146959360);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger33);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 10);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger39);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) 10);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) '#');
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, (long) 1079525376);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 800L);
        java.math.BigInteger bigInteger58 = null;
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) 0);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, (long) 10);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) 0);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (long) 10);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, (long) 0);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, bigInteger70);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger71);
        java.math.BigInteger bigInteger73 = null;
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, (long) 0);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) 10);
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (long) '#');
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, 2146959360);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, bigInteger81);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, bigInteger82);
        java.math.BigInteger bigInteger84 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, bigInteger83);
        try {
            java.math.BigInteger bigInteger86 = org.apache.commons.math.util.MathUtils.pow(bigInteger84, (-821795561265L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger84);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(11.291656529484548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19707658444382153d + "'", double1 == 0.19707658444382153d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.4085924434143047d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.43295877657865656d) + "'", double1 == (-0.43295877657865656d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-4400L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7567007248655965d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        long long1 = org.apache.commons.math.util.FastMath.abs(1079574590L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1079574590L + "'", long1 == 1079574590L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7814031344344955d), 8.6253289708097372E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.6253289708097372E18d + "'", double2 == 8.6253289708097372E18d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-340980509), 30);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int int2 = org.apache.commons.math.util.FastMath.max((-1065132000), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray19 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray25 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray19.getClass();
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 5.92097202766467E47d);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 152.0f);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1399519048) + "'", int29 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1569002534 + "'", int34 == 1569002534);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-4400L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-52));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, 1022647254);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.625329E18f + "'", float2 == 8.625329E18f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int2 = org.apache.commons.math.util.MathUtils.pow(99, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 110, (-1065132032L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray29 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray35 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray35);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-2.697156712436407E20d));
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray39);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (2,412,291,016,406.291 >= 241,229,101,640.629)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 35.15078488198184d + "'", double24 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.118089298841471E9d + "'", double37 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray35 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray41 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray48 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray54 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray35);
        double[] doubleArray76 = new double[] { 8.625329E18f, (short) -1, 5, (-1.0d), 52.0f };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray76);
        double[] doubleArray78 = new double[] {};
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray78);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.15078488198184d + "'", double43 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.118089298841471E9d + "'", double56 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.118089298841471E9d + "'", double69 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 8.6253289708097372E18d + "'", double77 == 8.6253289708097372E18d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 8.6253289708097372E18d + "'", double83 == 8.6253289708097372E18d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 8.6253289708097372E18d + "'", double84 == 8.6253289708097372E18d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray16);
        double[] doubleArray44 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray50 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray50);
        double[] doubleArray58 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray64 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 3.0d);
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.118089298E9d + "'", double52 == 1.118089298E9d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 35.15078488198184d + "'", double66 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        long long1 = org.apache.commons.math.util.MathUtils.sign(13860L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.545793183769947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3.34668104E10f, 7.211102550927978d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.3466810367999996E10d + "'", double2 == 3.3466810367999996E10d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1399519059);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(2, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 5.92097202766467E47d);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1399519048) + "'", int16 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1569002534 + "'", int19 == 1569002534);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-4707426507428119391L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1180133287), (-933449039));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2113582326) + "'", int2 == (-2113582326));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.011664008437068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5568934708223685d + "'", double1 == 1.5568934708223685d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 68);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 68L + "'", long1 == 68L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 101, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.33791696896E11d + "'", double2 == 4.33791696896E11d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.552944561447435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.9961239727768d + "'", double1 == 256.9961239727768d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6623138832856035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7118088090747461d + "'", double1 == 0.7118088090747461d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.92097202766467E47d, 0.6742957450437334d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.302585092994046d, (java.lang.Number) 0L, (-2147483648));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.283185307179586d + "'", number4.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 6.283185307179586d + "'", number6.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (6.283 >= 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (6.283 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 129.0f, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 129.0d + "'", double2 == 129.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(961);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-2147483638), 9178556838640688257L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9178556840788171895L) + "'", long2 == (-9178556840788171895L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.18070977791825d) + "'", double1 == (-22.18070977791825d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.93006726156721E14d + "'", double1 == 7.93006726156721E14d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9271524016877463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-340980509), 205);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1102907955 + "'", int2 == 1102907955);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.00786088735110676d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45039566844619067d) + "'", double1 == (-0.45039566844619067d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7029074376504d), 3.3466810367999996E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.1003120103805887E-11d) + "'", double2 == (-2.1003120103805887E-11d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.1296280268036493E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5600L, (java.lang.Number) 2.2514747350726854d, (-620), orderDirection3, true);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray16);
        double[] doubleArray31 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray37 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1399519048) + "'", int24 == (-1399519048));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1399519048) + "'", int25 == (-1399519048));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1399519048) + "'", int39 == (-1399519048));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (-1 >= 0.1)"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int int1 = org.apache.commons.math.util.FastMath.abs(1399519059);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1399519059 + "'", int1 == 1399519059);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-32));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0009788669371438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.35186445728556d + "'", double1 == 57.35186445728556d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.8263857541482102E18d, (double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        java.lang.Class<?> wildcardClass40 = doubleArray16.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (-53));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-62), (long) 620);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-682L) + "'", long2 == (-682L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 30L, (-0.999020813314648d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1118089298L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1118089344) + "'", int1 == (-1118089344));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray35 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray41 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray48 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray54 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray35);
        double[] doubleArray76 = new double[] { 8.625329E18f, (short) -1, 5, (-1.0d), 52.0f };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray76);
        double[] doubleArray78 = new double[] {};
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray78);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.15078488198184d + "'", double43 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.118089298841471E9d + "'", double56 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.118089298841471E9d + "'", double69 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 8.6253289708097372E18d + "'", double77 == 8.6253289708097372E18d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1079525376);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 131.928407798297d + "'", double1 == 131.928407798297d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1151677663));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1151677663L + "'", long1 == 1151677663L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 735L, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 110, (-2.695228193983273E72d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.399519148E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 815);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1068859392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray9 = new int[] { (short) 1, 0, 0, 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray17 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray17);
        int[] intArray22 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray27 = new int[] { (short) 1, 0, 0, 10 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray27);
        int[] intArray35 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray35);
        int[] intArray40 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray45 = new int[] { (short) 1, 0, 0, 10 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int[] intArray52 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray52);
        int[] intArray58 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray63 = new int[] { (short) 1, 0, 0, 10 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray70 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray70);
        int[] intArray75 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray80 = new int[] { (short) 1, 0, 0, 10 };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray80);
        int[] intArray88 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray88);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray88);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray52);
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 110 + "'", int10 == 110);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 110 + "'", int28 == 110);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 110 + "'", int46 == 110);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 112.70314991161516d + "'", double53 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 102.0d + "'", double54 == 102.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 110 + "'", int64 == 110);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 112.70314991161516d + "'", double71 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 110 + "'", int81 == 110);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 20 + "'", int89 == 20);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 102.60116958397697d + "'", double90 == 102.60116958397697d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 99 + "'", int91 == 99);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 90 + "'", int92 == 90);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-52), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 5600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.1415919583190752d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 163L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 107952537600L, 1.7345175425633101d, 3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        long long2 = org.apache.commons.math.util.FastMath.min(14700L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.3690739602064348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.023894848308920115d + "'", double1 == 0.023894848308920115d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 5600);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1118089344));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1180893439999998E9d) + "'", double1 == (-1.1180893439999998E9d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(257, 1552941056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1552940799) + "'", int2 == (-1552940799));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 1102907955);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1102907955 + "'", int2 == 1102907955);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2.75854737E17f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.440680446296252d + "'", double1 == 17.440680446296252d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(198743.24000384324d, 9.323669049311247d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.4535784328948413d, (double) (-818967101L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9589242746631385d), 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-225811322));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-109710.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7657120440275322d + "'", double1 == 0.7657120440275322d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(887825440, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 887825388 + "'", int2 == 887825388);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(139951904800L, (long) (-818967101));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1399518996, 5600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1399524596 + "'", int2 == 1399524596);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1065132000));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.464385515193583d + "'", double1 == 1.464385515193583d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1399519048, 3465.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3465.0f + "'", float2 == 3465.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5706271627794437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.99030761586906d + "'", double1 == 89.99030761586906d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.4916681462400413E-154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4916681462400413E-154d + "'", double1 == 1.4916681462400413E-154d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray23 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        java.lang.Class<?> wildcardClass27 = doubleArray23.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.118089298841471E9d + "'", double25 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.118089298E9d + "'", double26 == 1.118089298E9d);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        long long1 = org.apache.commons.math.util.FastMath.abs(48L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 48L + "'", long1 == 48L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4899094351437512d, (java.lang.Number) (-1.113407146813537d), (-32));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950371902099892d + "'", double1 == 0.9950371902099892d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1072693248, 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269325E9f + "'", float2 == 1.07269325E9f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 163);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 620);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 620.0f + "'", float2 == 620.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1072693248);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1072693248L + "'", long1 == 1072693248L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double double2 = org.apache.commons.math.util.MathUtils.round(22025.465794806718d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22025.0d + "'", double2 == 22025.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(506.132825342035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.9693243243642655d + "'", double1 == 7.9693243243642655d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray23 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray23);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.118089298841471E9d + "'", double25 == 1.118089298841471E9d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double[] doubleArray2 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-0.0d));
        double[] doubleArray9 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray15 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (-2.697156712436407E20d));
        double[] doubleArray37 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray43 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray50 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray56 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray56);
        double[] doubleArray63 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray69 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray69);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray69);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.15078488198184d + "'", double17 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.118089298841471E9d + "'", double30 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 35.15078488198184d + "'", double45 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.118089298841471E9d + "'", double58 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.118089298841471E9d + "'", double71 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1022647254 + "'", int74 == 1022647254);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        int int9 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (1 >= 10)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (1 >= 10)"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.math.util.FastMath.max((-933449039), 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 5.92097202766467E47d);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 152.0f);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1399519048) + "'", int16 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1569002534 + "'", int21 == 1569002534);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1569002534 + "'", int22 == 1569002534);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.011664008437068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.011664008437068d + "'", double1 == 1.011664008437068d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int2 = org.apache.commons.math.util.FastMath.max(99, 1079525376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525376 + "'", int2 == 1079525376);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 9178556838640688204L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.178557E18f + "'", float1 == 9.178557E18f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-818967101L), 1150962225);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.181502132678056E177d) + "'", double2 == (-6.181502132678056E177d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.185224792207329E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.1852247922E10d + "'", double1 == 6.1852247922E10d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 48L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.871201010907891d + "'", double1 == 3.871201010907891d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        int int2 = org.apache.commons.math.util.MathUtils.pow(780, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 48L, 110);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException12.getClass();
        java.lang.Number number16 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        int int18 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable throwable21 = null;
        try {
            nonMonotonousSequenceException12.addSuppressed(throwable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 1 + "'", number16.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2.0f, (double) 39587057540L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9587057542287224E10d + "'", double2 == 3.9587057542287224E10d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 892278075, (-0.997588934979024d), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35L, (float) (-933449039));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.3344902E8f) + "'", float2 == (-9.3344902E8f));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.011664008437068d, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0116640084370683d + "'", double2 == 1.0116640084370683d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray12 = new double[] {};
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray18 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray24 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray18.getClass();
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray18);
        double[] doubleArray34 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray40 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray47 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray53 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray53);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (-2.697156712436407E20d));
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray53);
        double[] doubleArray63 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray69 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1399519048) + "'", int28 == (-1399519048));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 35.15078488198184d + "'", double42 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.118089298841471E9d + "'", double55 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.118089298841471E9d + "'", double58 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 35.15078488198184d + "'", double71 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 6820L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6820.0d + "'", double1 == 6820.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(329.415371729147d, 9.249561075883902d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 1, 1399519148L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1399519148L + "'", long2 == 1399519148L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 33466810368L, 3.61406888E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.34668104E10f + "'", float2 == 3.34668104E10f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        int[] intArray39 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray44 = new int[] { (short) 1, 0, 0, 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int[] intArray51 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int[] intArray56 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray61 = new int[] { (short) 1, 0, 0, 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray69 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray69);
        java.lang.Class<?> wildcardClass72 = intArray44.getClass();
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray44);
        int[] intArray74 = null;
        try {
            int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 110 + "'", int45 == 110);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 112.70314991161516d + "'", double52 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 110 + "'", int62 == 110);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 20 + "'", int70 == 20);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 102.60116958397697d + "'", double71 == 102.60116958397697d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 99.508793581271d + "'", double73 == 99.508793581271d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1118089397);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5938004457661669d) + "'", double1 == (-0.5938004457661669d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.731537741517051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0470692561817962d + "'", double1 == 1.0470692561817962d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1118089344), 1105198592);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (-933449039));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.3344902E8f) + "'", float2 == (-9.3344902E8f));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-620));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3300, (long) 2200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079574528E9d + "'", double1 == 1.079574528E9d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1118089344));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.125108610420262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9671317861733741d + "'", double1 == 0.9671317861733741d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-4400L), (double) 13L, (-0.983060527454897d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1180133287));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray41 = new double[] {};
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray53 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray53);
        java.lang.Class<?> wildcardClass55 = doubleArray47.getClass();
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray47);
        double[] doubleArray57 = new double[] {};
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray63 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray69 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray69);
        java.lang.Class<?> wildcardClass71 = doubleArray63.getClass();
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray63);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray76 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (-0.0d));
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray57);
        double[] doubleArray81 = new double[] {};
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double[] doubleArray87 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray93 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray87, doubleArray93);
        java.lang.Class<?> wildcardClass95 = doubleArray87.getClass();
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray81, doubleArray87);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray87);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray41);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(wildcardClass95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double[] doubleArray2 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-0.0d));
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1022647254 + "'", int6 == 1022647254);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1102907955);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray19 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray25 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray19.getClass();
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray34 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray40 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray34.getClass();
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray34);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray34);
        double[] doubleArray50 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray56 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        java.lang.Class<?> wildcardClass58 = doubleArray50.getClass();
        double[] doubleArray59 = new double[] {};
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray65 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray71 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        java.lang.Class<?> wildcardClass73 = doubleArray65.getClass();
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray80 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray86 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray86);
        java.lang.Class<?> wildcardClass88 = doubleArray80.getClass();
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray80);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray50);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 35.15078488198184d + "'", double44 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 35.15078488198184d + "'", double90 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-821795561113L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.220703125E-4d + "'", double1 == 1.220703125E-4d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(6820L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6820L + "'", long2 == 6820L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray7 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray13 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray7.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray7);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(52, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57 + "'", int2 == 57);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8975475437951029d, number1, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 35, 1026528268144425295L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2106419706920663989L) + "'", long2 == (-2106419706920663989L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(205);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 107952537600L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1072693248, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.399519148E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.399519148E9d + "'", double1 == 1.399519148E9d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 99, 3168);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5550727364664641663L) + "'", long2 == (-5550727364664641663L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1079525376);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 700, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 636781166840L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 11, 31560302592000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 347163328512000L + "'", long2 == 347163328512000L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        float float1 = org.apache.commons.math.util.FastMath.abs(3410.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3410.0f + "'", float1 == 3410.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.749382843354661d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999797149956874d + "'", double1 == 0.9999797149956874d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 3465L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3465.0d + "'", double1 == 3465.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1521073060L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(101, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102 + "'", int2 == 102);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.3995190479999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3654152544441114d) + "'", double1 == (-0.3654152544441114d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) '#');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2146959360);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 5200L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 10);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) '#');
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 2146959360);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger33);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 10);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger39);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 1399519148L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2147483648), (-777));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double2 = org.apache.commons.math.util.FastMath.min(1047.9816784013124d, (double) 1026528268144425295L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1047.9816784013124d + "'", double2 == 1047.9816784013124d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.18838862103418857d, 5.149099138580496E65d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3168, (float) 887825539);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.8782554E8f + "'", float2 == 8.8782554E8f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5568934708223685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9149157481952099d + "'", double1 == 0.9149157481952099d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int[] intArray3 = new int[] { (-52), 10, (short) 10 };
        int[] intArray7 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, 0, 0, 10 };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray12);
        int[] intArray20 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray26 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray31 = new int[] { (short) 1, 0, 0, 10 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray39 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray39);
        int[] intArray44 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray49 = new int[] { (short) 1, 0, 0, 10 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray49);
        int[] intArray56 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray56);
        int[] intArray62 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, 0, 0, 10 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray67);
        int[] intArray75 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray62);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray62);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 110 + "'", int13 == 110);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 163 + "'", int22 == 163);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 110 + "'", int32 == 110);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 20 + "'", int40 == 20);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 110 + "'", int50 == 110);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 112.70314991161516d + "'", double57 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 102.0d + "'", double58 == 102.0d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 110 + "'", int68 == 110);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 20 + "'", int76 == 20);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.0d), 1.623411113792501d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        float float1 = org.apache.commons.math.util.FastMath.abs((-777.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 777.0f + "'", float1 == 777.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray16);
        double[] doubleArray40 = new double[] {};
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray46 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray52 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray46.getClass();
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray46);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray46);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.3569687047394818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.11271350514232d + "'", double1 == 1.11271350514232d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double1 = org.apache.commons.math.util.FastMath.sinh(243666.62065197784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.math.util.FastMath.max(68, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0398208803931389d + "'", double1 == 0.0398208803931389d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 53L, (double) (-96));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-96.0d) + "'", double2 == (-96.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.7802358370342162d, (double) (-1979352877));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.979352878375718E9d) + "'", double2 == (-1.979352878375718E9d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 48L, 110);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 110 + "'", int4 == 110);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 48L + "'", number5.equals(48L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.38247186391080956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException6.getClass();
        java.lang.Number number10 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.552974607718716d, (java.lang.Number) 1.5707963267948966d, (-620), orderDirection11, false);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        java.lang.Number number15 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 1 + "'", number10.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 5.552974607718716d + "'", number15.equals(5.552974607718716d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 132, 2826385754148210145L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2826385754148210277L + "'", long2 == 2826385754148210277L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(99, 3300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.983060527454897d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.078108726895701d) + "'", double1 == (-4.078108726895701d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.0470692561817962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2491617519793643d + "'", double1 == 1.2491617519793643d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.4365658100345553d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1998998943 + "'", int1 == 1998998943);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int int2 = org.apache.commons.math.util.FastMath.max((-1552940799), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-94L), 1905747897L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 179140302318L + "'", long2 == 179140302318L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1118089199L), (long) 892278075);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 997646478162011925L + "'", long2 == 997646478162011925L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        double double2 = org.apache.commons.math.util.FastMath.max(11.0d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2147483638), (float) (-2113582326));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.11358234E9f) + "'", float2 == (-2.11358234E9f));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        double[] doubleArray40 = new double[] {};
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray46 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray52 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray46.getClass();
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray46);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray59 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (-0.0d));
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray40);
        double[] doubleArray65 = new double[] {};
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        java.lang.Class<?> wildcardClass68 = doubleArray65.getClass();
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray18 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray24 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray31 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray37 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray37);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (-2.697156712436407E20d));
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 1.0142320547350045E304d);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray44);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number50 = nonMonotonousSequenceException49.getPrevious();
        boolean boolean51 = nonMonotonousSequenceException49.getStrict();
        java.lang.Class<?> wildcardClass52 = nonMonotonousSequenceException49.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException49.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection53, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 35.15078488198184d + "'", double26 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.118089298841471E9d + "'", double39 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (short) -1 + "'", number50.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.17190230687955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.864381776896534d + "'", double1 == 0.864381776896534d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 48L, 110);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 110 + "'", int5 == 110);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 48L + "'", number6.equals(48L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double2 = org.apache.commons.math.util.MathUtils.round(40.51423422706977d, 132);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 40.51423422706977d + "'", double2 == 40.51423422706977d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.06513203E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray16);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1399519048) + "'", int24 == (-1399519048));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1399519048) + "'", int25 == (-1399519048));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 35.15078488198184d + "'", double27 == 35.15078488198184d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1047.9816784013124d, 101, (-2113582326));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 7931197251535193088L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.9311974E18f + "'", float1 == 7.9311974E18f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-2.697156712436407E20d), (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(205, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 887825388);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1521073243L), 9.380497402550226E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.380497402550226E7d + "'", double2 == 9.380497402550226E7d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1151677663));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1118089298), (-777));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        double double1 = org.apache.commons.math.util.FastMath.atanh(89.96144956033727d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        long long2 = org.apache.commons.math.util.FastMath.max(33466810368L, (long) 1998998943);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33466810368L + "'", long2 == 33466810368L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1399518996, (long) 1807551715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8606487491999707d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 53.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09247351917780995d + "'", double1 == 0.09247351917780995d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 5.92097202766467E47d);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 152.0f);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1399524596);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1399519048) + "'", int16 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-2147483638), (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.656612894761436E-10d) + "'", double2 == (-4.656612894761436E-10d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 700.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 62L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62L) + "'", long2 == (-62L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1079525376, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 35149357056L, 2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03160780813572381d + "'", double2 == 0.03160780813572381d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950371902099892d + "'", double1 == 0.9950371902099892d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray31 = new double[] {};
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray37 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray43 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray37.getClass();
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray37);
        double[] doubleArray47 = new double[] {};
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray53 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray59 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        java.lang.Class<?> wildcardClass61 = doubleArray53.getClass();
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray53);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray66 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (-0.0d));
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray47);
        double[] doubleArray75 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray81 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1.1f));
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray75);
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray75);
        double[] doubleArray88 = null;
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 35.15078488198184d + "'", double86 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(8.065817517094494E67d, (-57.0d), (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 68L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4401430224960407d + "'", double1 == 0.4401430224960407d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1174218874400L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray19 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (-0.0d));
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        try {
            double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1399519048) + "'", int16 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 130, (-52.83185307179586d), 0.9950547536867306d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.125108610420262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.46397487090977d + "'", double1 == 64.46397487090977d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1552941056L, 100.69314718055995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707962619546074d + "'", double2 == 1.5707962619546074d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.39418561761740006d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.733218799276818d) + "'", double1 == (-0.733218799276818d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-96));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.01648202441891042d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray18 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray24 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray26 = new double[] {};
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray38 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray32.getClass();
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray32);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1399519048) + "'", int12 == (-1399519048));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1399519048) + "'", int13 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1399519048) + "'", int42 == (-1399519048));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4916681462400413E-154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        double[] doubleArray35 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray41 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray48 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray54 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray61 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray67 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray35);
        double[] doubleArray76 = new double[] { 8.625329E18f, (short) -1, 5, (-1.0d), 52.0f };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (-57.29577951308232d));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.15078488198184d + "'", double43 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.118089298841471E9d + "'", double56 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.118089298841471E9d + "'", double69 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 8.6253289708097372E18d + "'", double77 == 8.6253289708097372E18d);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1080066048, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        double double1 = org.apache.commons.math.util.FastMath.asinh(23520.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.758753583024433d + "'", double1 == 10.758753583024433d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.3569687047394818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1026528268144425295L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1008765.6941432969d) + "'", double1 == (-1008765.6941432969d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1026528268144425295L, (-1068859392));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0796749199151885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int int2 = org.apache.commons.math.util.FastMath.min((-225811322), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-225811322) + "'", int2 == (-225811322));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 102);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079574528, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9999797149956874d, (-0.3776518329102733d), 1.5117484916013424d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-94L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5007857627073948E-41d + "'", double1 == 1.5007857627073948E-41d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray7 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray13 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray7.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 5.92097202766467E47d);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1399519048) + "'", int17 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, 275854735351562500L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 275854735351562500L + "'", long2 == 275854735351562500L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 31560302592000L, (double) 1552941056);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1026528268144425295L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.02652826814442534E18d) + "'", double1 == (-1.02652826814442534E18d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-821795561265L), (-0.25103907878345744d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.905517578125d) + "'", double2 == (-1.905517578125d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 152L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 152 + "'", int1 == 152);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8975475437951029d, number1, 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 33466810269L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.820254586680325d) + "'", double1 == (-1.820254586680325d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        int[] intArray39 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray44 = new int[] { (short) 1, 0, 0, 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int[] intArray52 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray39);
        int[] intArray58 = new int[] { (-52), 10, (short) 10 };
        int[] intArray62 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, 0, 0, 10 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray67);
        int[] intArray75 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray62);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray58);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 110 + "'", int45 == 110);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 20 + "'", int53 == 20);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 110 + "'", int68 == 110);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 20 + "'", int76 == 20);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 163 + "'", int77 == 163);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 152 + "'", int78 == 152);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1552941056);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.897696834138922E10d + "'", double1 == 8.897696834138922E10d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray23 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray23);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (-2.697156712436407E20d));
        java.lang.Class<?> wildcardClass28 = doubleArray27.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.118089298841471E9d + "'", double25 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.1821728472264846E57d), (double) 8.625329E18f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 3465L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5705077265143088d + "'", double1 == 1.5705077265143088d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1079574590L, 1079574528);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-2070));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        int int14 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException10.getArgument();
        int int16 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number21 = nonMonotonousSequenceException20.getPrevious();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean27 = nonMonotonousSequenceException26.getStrict();
        int int28 = nonMonotonousSequenceException26.getIndex();
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException26.getSuppressed();
        java.lang.Number number30 = nonMonotonousSequenceException26.getArgument();
        int int31 = nonMonotonousSequenceException26.getIndex();
        java.lang.Number number32 = nonMonotonousSequenceException26.getPrevious();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 110 + "'", int14 == 110);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 3.141592653589793d + "'", number15.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 110 + "'", int16 == 110);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 6.283185307179586d + "'", number21.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.09966865249116202d + "'", number30.equals(0.09966865249116202d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (short) -1 + "'", number32.equals((short) -1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 48L, 110);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (6.283 >= 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (6.283 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 6.283185307179586d + "'", number11.equals(6.283185307179586d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0384616609185666E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0384616609185666E31d + "'", double1 == 1.0384616609185666E31d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-2.7675139904022217d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9371820231188533d) + "'", double1 == (-0.9371820231188533d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-53.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        int int9 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 1 + "'", number11.equals((short) 1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4071364206539694E18d, (java.lang.Number) 6.283185307179587d, 130, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5573190252106903E7d, (java.lang.Number) 110, 961, orderDirection10, false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int2 = org.apache.commons.math.util.FastMath.max((-1180133287), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int[] intArray3 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray8 = new int[] { (short) 1, 0, 0, 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray16 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray16);
        int[] intArray21 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray26 = new int[] { (short) 1, 0, 0, 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray26);
        int[] intArray33 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray33);
        java.lang.Class<?> wildcardClass36 = intArray3.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 110 + "'", int9 == 110);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 110 + "'", int27 == 110);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 112.70314991161516d + "'", double34 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 102.0d + "'", double35 == 102.0d);
        org.junit.Assert.assertNotNull(wildcardClass36);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 62, (float) 1399518996L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 62.0f + "'", float2 == 62.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) '#');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2146959360);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 5200L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 2L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.5063656411097466d), (-2070));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 318.15263962020936d + "'", double1 == 318.15263962020936d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.7814031344344955d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(700L, 5600L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3920000L + "'", long2 == 3920000L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 6.283185307179586d, 0);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 48L, 110);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException12.getSuppressed();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException12.getClass();
        java.lang.Number number16 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        int int18 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException12.getDirection();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        int int21 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 1 + "'", number16.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.118089299E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1102907955, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 205);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 205.00000000000003d + "'", double1 == 205.00000000000003d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.298292365610484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.56979117586565d + "'", double1 == 303.56979117586565d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1521073243L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.570796326137466d) + "'", double1 == (-1.570796326137466d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double double1 = org.apache.commons.math.util.FastMath.asin(318.15263962020936d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1065132032), 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1065132000) + "'", int2 == (-1065132000));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3410);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1079574590L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 0, 3410);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        boolean boolean30 = nonMonotonousSequenceException29.getStrict();
        java.lang.Throwable[] throwableArray31 = nonMonotonousSequenceException29.getSuppressed();
        nonMonotonousSequenceException25.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        int int33 = nonMonotonousSequenceException25.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3410 + "'", int33 == 3410);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-340980509), (-0.04984636245302756d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.40980509E8d) + "'", double2 == (-3.40980509E8d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5199.999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1521073243L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.10435473734071847d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0054498986536549d + "'", double1 == 1.0054498986536549d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) '#');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2146959360);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 2L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1065132032));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 0, (-821795561113L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int1 = org.apache.commons.math.util.MathUtils.sign(93);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1807551715);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.315239123482765d + "'", double1 == 21.315239123482765d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1150962225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1150962225 + "'", int2 == 1150962225);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.9587057542287224E10d, (double) (-2106419706920663989L), (double) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.7664493898273668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 53);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '#');
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) '#');
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1079525376);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 10);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 0);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 10);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger34);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 0);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 10);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) '#');
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 2146959360);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, bigInteger44);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger45);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger45);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException55.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8994750024618055d, (java.lang.Number) 110L, 110, orderDirection56, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) bigInteger45, 10, orderDirection56, false);
        java.math.BigInteger bigInteger61 = null;
        try {
            java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-225811322), number1, 90, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException7.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4071364206539694E18d, (java.lang.Number) 6.283185307179587d, 130, orderDirection8, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1490.479161252178d + "'", double1 == 1490.479161252178d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 5);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 780);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 48L, 110);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 110 + "'", int4 == 110);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(887825440, 132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9443504370351303d, 2.7103934516597643E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1998998943, 1022647254);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1749260653237925d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(110, 1552941056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1552941166 + "'", int2 == 1552941166);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray9 = new int[] { (short) 1, 0, 0, 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray17 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray17);
        int[] intArray22 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray27 = new int[] { (short) 1, 0, 0, 10 };
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray27);
        int[] intArray35 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray35);
        int[] intArray40 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray45 = new int[] { (short) 1, 0, 0, 10 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int[] intArray52 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray52);
        int[] intArray58 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray63 = new int[] { (short) 1, 0, 0, 10 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray70 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray70);
        int[] intArray75 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray80 = new int[] { (short) 1, 0, 0, 10 };
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray80);
        int[] intArray88 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray88);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray88);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray52);
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 110 + "'", int10 == 110);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20 + "'", int18 == 20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 110 + "'", int28 == 110);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 110 + "'", int46 == 110);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 112.70314991161516d + "'", double53 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 102.0d + "'", double54 == 102.0d);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 110 + "'", int64 == 110);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 112.70314991161516d + "'", double71 == 112.70314991161516d);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 110 + "'", int81 == 110);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 20 + "'", int89 == 20);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 102.60116958397697d + "'", double90 == 102.60116958397697d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 99 + "'", int91 == 99);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 90 + "'", int92 == 90);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1545456228);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-656996494) + "'", int1 == (-656996494));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.890818211544806E11d + "'", double1 == 6.890818211544806E11d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        long long2 = org.apache.commons.math.util.FastMath.min(23520L, 1399519148L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23520L + "'", long2 == 23520L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1521073190));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20321057778875d + "'", double1 == 74.20321057778875d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.380497402550226E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.380497402550228E7d + "'", double1 == 9.380497402550228E7d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int2 = org.apache.commons.math.util.FastMath.max(101, 3410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3410 + "'", int2 == 3410);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-62L), (-2.185039863261519d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.9039295044086464d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.atan(3628798.3290464333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707960512215775d + "'", double1 == 1.5707960512215775d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (-1.1f));
        double[] doubleArray18 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray24 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray13.getClass();
        double[] doubleArray30 = new double[] {};
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray36 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray42 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray36.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray36);
        double[] doubleArray46 = new double[] {};
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray52 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray58 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        java.lang.Class<?> wildcardClass60 = doubleArray52.getClass();
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray65 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (-0.0d));
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray46);
        double[] doubleArray74 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray80 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (-1.1f));
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray74);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.1180893200525117E9d + "'", double26 == 1.1180893200525117E9d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.17190230687955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1552941056);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 3465L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-2106419706920663989L), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.10641970692066406E18d) + "'", double2 == (-2.10641970692066406E18d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-9.3344902E8f), (double) 1905747897L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(163);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0001132579559047d, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21173.17976860135d + "'", double2 == 21173.17976860135d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2146959360L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1572864L + "'", long2 == 1572864L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.7853981633974482d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.5453569630798636E22d), 257, (-1552940799));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray29 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray35 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray35);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-2.697156712436407E20d));
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 1.0142320547350045E304d);
        double[] doubleArray43 = new double[] {};
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray49 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray55 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        java.lang.Class<?> wildcardClass57 = doubleArray49.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray49);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray62 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (-0.0d));
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray64);
        double[] doubleArray70 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray76 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray64);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 35.15078488198184d + "'", double24 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.118089298841471E9d + "'", double37 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.999020813314648d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Class<?> wildcardClass10 = number9.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.09966865249116202d + "'", number7.equals(0.09966865249116202d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 715L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 715.0d + "'", double1 == 715.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        float float1 = org.apache.commons.math.util.FastMath.abs(3.61406888E18f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.61406888E18f + "'", float1 == 3.61406888E18f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1068859392));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1068859392 + "'", int1 == 1068859392);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.301801982276166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1609552812709372d + "'", double1 == 1.1609552812709372d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1026528268144425295L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.4365658100345553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.042526095826625684d + "'", double1 == 0.042526095826625684d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-656996494), (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1807551715);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1547728826820176E7d + "'", double1 == 3.1547728826820176E7d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(700L, (-1180133287));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int2 = org.apache.commons.math.util.MathUtils.pow(62, (long) 1399519059);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9441913666508144d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4L, (float) 107952537600L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07952538E11f + "'", float2 == 1.07952538E11f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.932366719745925d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.412973267396569d) + "'", double1 == (-1.412973267396569d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-52.83185307179586d), (-777), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 3410L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 1, (-1521073190));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1521073190) + "'", int2 == (-1521073190));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray16 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray22 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray16);
        double[] doubleArray31 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray37 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray44 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray50 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (-2.697156712436407E20d));
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1399519048) + "'", int24 == (-1399519048));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1399519048) + "'", int25 == (-1399519048));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 35.15078488198184d + "'", double39 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.118089298841471E9d + "'", double52 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9518224930797359d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.983675801594142d + "'", double1 == 0.983675801594142d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray21 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray27 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        java.lang.Class<?> wildcardClass29 = doubleArray21.getClass();
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray21);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 110 + "'", int8 == 110);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        double[] doubleArray16 = new double[] {};
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray22 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray28 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray22.getClass();
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray35 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (-0.0d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray16);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        int int9 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1932800507380155d, (java.lang.Number) 101.0d, 32);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        int int18 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str19 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10.0d + "'", number10.equals(10.0d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (101 >= 1.193)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (101 >= 1.193)"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (1 >= 10)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (1 >= 10)"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 93);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.920972027664669E47d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.006400106306439639d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9518224930797358d, (java.lang.Number) 5600L, 5);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { 715, 5, 1072693248, 2200 };
        try {
            double double6 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray6 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray12 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass14 = doubleArray6.getClass();
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray6);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double[] doubleArray19 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (-0.0d));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray27 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray33 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray33);
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        boolean boolean43 = nonMonotonousSequenceException42.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException42.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number36, (java.lang.Number) (byte) 1, 0, orderDirection44, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection44, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 5388148334800L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5388148334800L + "'", long1 == 5388148334800L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 1545456228);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        double double1 = org.apache.commons.math.util.FastMath.signum(3628798.3290464333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double[] doubleArray12 = new double[] {};
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray18 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray24 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        java.lang.Class<?> wildcardClass26 = doubleArray18.getClass();
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 5.92097202766467E47d);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1399519048) + "'", int28 == (-1399519048));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 700, (long) 780);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27300L + "'", long2 == 27300L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        double double1 = org.apache.commons.math.util.FastMath.signum(21173.17976860135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.6687635479337126d, (double) 5598076192L, (-0.43295877657865656d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 13860L, (double) 887825539);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.87825539E8d + "'", double2 == 8.87825539E8d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 5200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.324782106818056d + "'", double1 == 17.324782106818056d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        float float2 = org.apache.commons.math.util.MathUtils.round(53.0f, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4071364206539694E18d, (java.lang.Number) 6.283185307179587d, 130, orderDirection7, true);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 129 and 130 are not strictly increasing (6.283 >= 2,407,136,420,653,969,400)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 129 and 130 are not strictly increasing (6.283 >= 2,407,136,420,653,969,400)"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.384017341061263E11d, 163);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.618194888044319E60d + "'", double2 == 1.618194888044319E60d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-2.0d), 72.11102550927978d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.027727901550731536d) + "'", double2 == (-0.027727901550731536d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int1 = org.apache.commons.math.util.FastMath.round(8.8782554E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 887825536 + "'", int1 == 887825536);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 735L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 735.0d + "'", double1 == 735.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1118089298));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1037.9079301271756d) + "'", double1 == (-1037.9079301271756d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1022647254, 110L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(68, (long) (-777));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.2514747350726854d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2146959360L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 887825539);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.086865632862747E10d + "'", double1 == 5.086865632862747E10d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5384786408469177d + "'", double1 == 0.5384786408469177d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray13 = new double[] {};
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray19 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray25 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray19.getClass();
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray34 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray40 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray34.getClass();
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray34);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray34);
        double[] doubleArray50 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray56 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        java.lang.Class<?> wildcardClass58 = doubleArray50.getClass();
        double[] doubleArray59 = new double[] {};
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray65 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray71 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        java.lang.Class<?> wildcardClass73 = doubleArray65.getClass();
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray80 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray86 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray86);
        java.lang.Class<?> wildcardClass88 = doubleArray80.getClass();
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray80);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray50);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double94 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 35.15078488198184d + "'", double44 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(wildcardClass88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 35.15078488198184d + "'", double90 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 35.15078488198184d + "'", double93 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 35.15078488198184d + "'", double94 == 35.15078488198184d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) '#');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 1);
        java.lang.Class<?> wildcardClass9 = bigInteger8.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(2200, 163);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.9167321690051E250d + "'", double2 == 6.9167321690051E250d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 275854735351562500L, 1552941056);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) '#');
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 2146959360);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) (short) 1, (int) ' ');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 48.21273601220948d, (java.lang.Number) bigInteger10, (int) ' ', orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1521073243), (java.lang.Number) 4L, 2146959360, orderDirection18, false);
        java.lang.String str23 = nonMonotonousSequenceException22.toString();
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,146,959,359 and 2,146,959,360 are not increasing (4 > -1,521,073,243)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,146,959,359 and 2,146,959,360 are not increasing (4 > -1,521,073,243)"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        java.lang.Class<?> wildcardClass3 = doubleArray0.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09966865249116202d, (java.lang.Number) (short) -1, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.997588934979024d), (java.lang.Number) 1022647254, 0, orderDirection11, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.3479809392380016d), (java.lang.Number) 62.0f, 110, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.3479809392380016d) + "'", number6.equals((-0.3479809392380016d)));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1998998943);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.655154728220008E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.78917618171882d + "'", double1 == 29.78917618171882d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 9178556838640688257L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.25103907878345744d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2537535600215429d) + "'", double1 == (-0.2537535600215429d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5568934708223685d, (double) 1151677663L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 1, (long) 152);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 152L + "'", long2 == 152L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray7 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray13 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray7.getClass();
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray20 = new double[] { 1.7802358370342162d, 52 };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.0d));
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray22);
        double[] doubleArray24 = new double[] {};
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray30 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray36 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray36);
        java.lang.Class<?> wildcardClass38 = doubleArray30.getClass();
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray30);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray45 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray51 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        java.lang.Class<?> wildcardClass53 = doubleArray45.getClass();
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray45);
        double[] doubleArray59 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray65 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray72 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray78 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray78);
        double[] doubleArray85 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray91 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray85, doubleArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray91);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray59);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray45);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        try {
            double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 35.15078488198184d + "'", double67 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.118089298841471E9d + "'", double80 == 1.118089298841471E9d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.118089298841471E9d + "'", double93 == 1.118089298841471E9d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.4917798526449113d, (double) 35149357056L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.920972027664669E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.112963841460668E31d + "'", double1 == 8.112963841460668E31d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1105198540L, (-2147483648), (-620));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.400457267951947d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 944023644 + "'", int1 == 944023644);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.5701229979268445d), (double) 31560302592000L, (double) 130.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17792019397232475d) + "'", double1 == (-0.17792019397232475d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.7278759594743862d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1905747767), 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1905747767L + "'", long2 == 1905747767L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int2 = org.apache.commons.math.util.MathUtils.pow(102300, (long) 1150962225);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1905747767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.905747767E9d) + "'", double1 == (-1.905747767E9d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        float float2 = org.apache.commons.math.util.FastMath.min(1.07952538E9f, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 2170);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0741387582883313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 10);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 10);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) '#');
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 2146959360);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger26);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) ' ');
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 1118089397);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3410.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3410L + "'", long1 == 3410L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 777.0f, (double) 2826385754148210145L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1932800507380155d, (java.lang.Number) 101.0d, 32);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        int int12 = nonMonotonousSequenceException10.getIndex();
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException10.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.0d, 110, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        int int22 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        boolean boolean24 = nonMonotonousSequenceException10.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (101 >= 1.193)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (101 >= 1.193)"));
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 110 + "'", int12 == 110);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(orderDirection20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 3.141592653589793d + "'", number21.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 110 + "'", int22 == 110);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        double[] doubleArray4 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray10 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 3.0d);
        double[] doubleArray19 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray25 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        java.lang.Class<?> wildcardClass27 = doubleArray19.getClass();
        double[] doubleArray28 = new double[] {};
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray34 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray40 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray34.getClass();
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray49 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray55 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        java.lang.Class<?> wildcardClass57 = doubleArray49.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray49);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray49);
        double[] doubleArray61 = new double[] {};
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray67 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray73 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        java.lang.Class<?> wildcardClass75 = doubleArray67.getClass();
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray67);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray82 = new double[] { 35, (short) 0, 3.141592653589793d, 0.8414709848078965d };
        double[] doubleArray88 = new double[] { (byte) 10, (short) 1, (short) 10, (-1118089298), 2.4917798526449118d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray88);
        java.lang.Class<?> wildcardClass90 = doubleArray82.getClass();
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray82);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray82);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray19);
        double double94 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.15078488198184d + "'", double12 == 35.15078488198184d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 35.15078488198184d + "'", double59 == 35.15078488198184d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 2.7050812533388635d + "'", double94 == 2.7050812533388635d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int[] intArray3 = new int[] { (-52), 10, (short) 10 };
        int[] intArray7 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray12 = new int[] { (short) 1, 0, 0, 10 };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray12);
        int[] intArray20 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray26 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray31 = new int[] { (short) 1, 0, 0, 10 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray39 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray39);
        int[] intArray44 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray49 = new int[] { (short) 1, 0, 0, 10 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray49);
        int[] intArray56 = new int[] { '4', 100, (-1), (byte) 0, (byte) 10 };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray56);
        int[] intArray62 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray67 = new int[] { (short) 1, 0, 0, 10 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray67);
        int[] intArray75 = new int[] { 100, 1, 10, '#', (short) 10, (byte) -1 };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray62);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray26);
        int[] intArray82 = new int[] { (short) 100, (short) 10, (byte) -1 };
        int[] intArray87 = new int[] { (short) 1, 0, 0, 10 };
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray82);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 110 + "'", int13 == 110);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 163 + "'", int22 == 163);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 110 + "'", int32 == 110);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 20 + "'", int40 == 20);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 110 + "'", int50 == 110);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 112.70314991161516d + "'", double57 == 112.70314991161516d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 102.0d + "'", double58 == 102.0d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 110 + "'", int68 == 110);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 20 + "'", int76 == 20);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 110 + "'", int88 == 110);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int int1 = org.apache.commons.math.util.FastMath.abs(132);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 132 + "'", int1 == 132);
    }
}

