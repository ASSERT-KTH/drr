import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner6);
        int int8 = nonLinearConjugateGradientOptimizer7.getIterations();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = nonLinearConjugateGradientOptimizer7.getGoalType();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = nonLinearConjugateGradientOptimizer7.getConvergenceChecker();
        double[] doubleArray11 = nonLinearConjugateGradientOptimizer7.getUpperBound();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray12 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair13 = nonLinearConjugateGradientOptimizer7.optimize(optimizationDataArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(goalType9);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker10);
        org.junit.Assert.assertNull(doubleArray11);
        org.junit.Assert.assertNotNull(optimizationDataArray12);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, 0.0d, 4.687033507878418E7d, 0.0d, 4.9E-324d, 0.017453292519943295d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.629395E-6f + "'", float1 == 7.629395E-6f);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix31.scalarMultiply((double) 0);
        java.io.ObjectOutputStream objectOutputStream36 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix35, objectOutputStream36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(9410.0d, (double) (short) 1);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        double double33 = blockRealMatrix31.getFrobeniusNorm();
        boolean boolean35 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31, 0.8414709848078966d);
        double[] doubleArray42 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double43 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42);
        double[] doubleArray49 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.scale((double) 1, doubleArray44);
        double[] doubleArray59 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59);
        double[] doubleArray66 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double67 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray66);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray61, doubleArray68);
        org.apache.commons.math3.optim.PointValuePair pointValuePair72 = new org.apache.commons.math3.optim.PointValuePair(doubleArray68, 0.0d, true);
        double[] doubleArray73 = pointValuePair72.getPoint();
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray73);
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray73);
        org.apache.commons.math3.optim.PointValuePair pointValuePair78 = new org.apache.commons.math3.optim.PointValuePair(doubleArray75, 11.7910068511973d, false);
        try {
            blockRealMatrix31.setColumn(100, doubleArray75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 113.59577456930342d + "'", double43 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 113.59577456930342d + "'", double50 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 113.59577456930342d + "'", double60 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 113.59577456930342d + "'", double67 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.17877966098643805d, 0.017302733123681042d, 0.8414709848078965d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, 0.0d, true);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat18 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        boolean boolean19 = pointValuePair17.equals((java.lang.Object) realMatrixFormat18);
        double[] doubleArray20 = pointValuePair17.getPointRef();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray20, (double) 1.0f, 1.6256400572219838d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrixFormat18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        java.lang.String str37 = arrayRealVector34.toString();
        double[] doubleArray38 = arrayRealVector34.toArray();
        boolean boolean39 = arrayRealVector29.equals((java.lang.Object) doubleArray38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str43 = arrayRealVector42.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector29.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector47.set((double) ' ');
        java.lang.String str50 = arrayRealVector47.toString();
        double[] doubleArray51 = arrayRealVector47.toArray();
        double[] doubleArray52 = arrayRealVector47.toArray();
        java.lang.String str53 = arrayRealVector47.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector57.set((double) ' ');
        java.lang.String str60 = arrayRealVector57.toString();
        double[] doubleArray61 = arrayRealVector57.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.copy();
        double double63 = arrayRealVector47.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double double64 = arrayRealVector26.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        java.lang.String str68 = arrayRealVector67.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector26.append(arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector69.copy();
        boolean boolean71 = arrayRealVector70.isNaN();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{}" + "'", str50.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{}" + "'", str53.equals("{}"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{}" + "'", str60.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{}" + "'", str68.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 97, (java.lang.Number) 1L, 0, orderDirection3, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        double[] doubleArray7 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray13 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray19 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray25 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray31 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray32 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix33, (int) (byte) 0);
        int int36 = blockRealMatrix33.getRowDimension();
        double[] doubleArray42 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray48 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray54 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray60 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray66 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray67 = new double[][] { doubleArray42, doubleArray48, doubleArray54, doubleArray60, doubleArray66 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix68.transpose();
        double[][] doubleArray70 = blockRealMatrix69.getData();
        blockRealMatrix69.multiplyEntry(0, 0, (double) 235552016);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix33.multiply(blockRealMatrix69);
        java.lang.String str76 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix33);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str76.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
    }
}

