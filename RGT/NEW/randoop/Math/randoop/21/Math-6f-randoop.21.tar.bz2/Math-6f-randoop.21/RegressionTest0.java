import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math3.util.FastMath.sin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double[] doubleArray4 = new double[] { (short) 1, 100.0f, 10.0d, (-1) };
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 100.0f, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 112.71202242884297d + "'", double2 == 112.71202242884297d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) 0.0f, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(10.0d, (double) 0.0f, (double) (short) 100);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 100 };
        double[] doubleArray4 = new double[] { 100 };
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math3.util.FastMath.signum((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (-1.0f), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math3.util.FastMath.exp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (short) 10, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 'a', (double) 'a', (double) (byte) -1, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9410.570796326794d + "'", double4 == 9410.570796326794d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 0.0d, (byte) -1, (-1), 0.0d, 10.0d, (short) 100 };
        try {
            double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double[] doubleArray6 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[] doubleArray11 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[] doubleArray16 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[] doubleArray21 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[] doubleArray26 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[] doubleArray31 = new double[] { 1, 100.0d, (short) 1, 1L };
        double[][] doubleArray32 = new double[][] { doubleArray6, doubleArray11, doubleArray16, doubleArray21, doubleArray26, doubleArray31 };
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, (int) (byte) 100, doubleArray32, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 2,704");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        try {
            double double5 = brentSolver0.solve(10, univariateFunction2, 1.5430806348152437d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { (-1.0d) };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, (int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 194 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math3.util.FastMath.sin(112.71202242884297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3758492992847182d) + "'", double1 == (-0.3758492992847182d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(12771.287977571159d, (double) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector4.set((double) ' ');
        java.lang.String str7 = arrayRealVector4.toString();
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        try {
            java.lang.StringBuffer stringBuffer10 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer8, fieldPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(12771.287977571159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12771.28797757116d + "'", double1 == 12771.28797757116d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) '#', Double.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) 10, (-1.0d), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 1L, (int) 'a', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) '#', (int) ' ');
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        int[] intArray37 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray44 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int45 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray37, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray51 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray58 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int59 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray51, intArray58);
        int int60 = org.apache.commons.math3.util.MathArrays.distance1(intArray46, intArray51);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix61 = array2DRowRealMatrix15.getSubMatrix(intArray37, intArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 10L, (double) 1L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (byte) -1, 0.7615941559557649d, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 10, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray34 = null;
        try {
            array2DRowRealMatrix31.setRow((int) (short) -1, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int2 = org.apache.commons.math3.util.FastMath.min((-1), 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 100L, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.distance(doubleArray6, doubleArray18);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray18, 1.0d, 0.8414709848078965d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.8414709848078965d, (java.lang.Number) 9410.570796326794d, false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor13 = null;
        try {
            double double16 = arrayRealVector2.walkInOptimizedOrder(realVectorPreservingVisitor13, (int) '4', 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        try {
            blockRealMatrix31.addToEntry(0, (int) (byte) 100, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor18 = null;
        try {
            double double21 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor18, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix15, (int) (byte) 0, (int) (byte) 10, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat1.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        float float3 = org.apache.commons.math3.util.Precision.round((float) (byte) 0, 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.1f) + "'", float3 == (-0.1f));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((-0.3758492992847182d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.35909740519917466d) + "'", double1 == (-0.35909740519917466d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int2 = org.apache.commons.math3.util.FastMath.max(97, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        boolean boolean33 = array2DRowRealMatrix32.isTransposable();
        double double34 = array2DRowRealMatrix32.getNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector36 = array2DRowRealMatrix32.getRowVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        int[] intArray20 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray27 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int28 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray20, intArray27);
        int[] intArray33 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray40 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int41 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray33, intArray40);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix15.getSubMatrix(intArray20, intArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = blockRealMatrix31.walkInRowOrder(realMatrixPreservingVisitor32, (int) ' ', (int) (short) 1, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor33 = null;
        try {
            double double34 = array2DRowRealMatrix15.walkInColumnOrder(realMatrixPreservingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(0.017453292519943295d, (double) (byte) 0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0.017 is larger than, or equal to, the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(6.283185307179586d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.362265131567328d + "'", double2 == 6.362265131567328d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, 0.8414709848078965d, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector35.set((double) ' ');
        java.lang.String str38 = arrayRealVector35.toString();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{}" + "'", str38.equals("{}"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 10, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[] doubleArray38 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray44 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray50 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray56 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray62 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray63 = new double[][] { doubleArray38, doubleArray44, doubleArray50, doubleArray56, doubleArray62 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray63);
        try {
            blockRealMatrix31.setRowMatrix((int) (short) 10, blockRealMatrix64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 0L, 97, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector3.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector8.set((double) ' ');
        java.lang.String str11 = arrayRealVector8.toString();
        double[] doubleArray12 = arrayRealVector8.toArray();
        boolean boolean13 = arrayRealVector3.equals((java.lang.Object) doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str17 = arrayRealVector16.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector3.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{}" + "'", str11.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("; ", "{", "", "", "{}", "{}", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, Double.NaN, (-0.3758492992847182d), 0.0d, 0.0d, (double) 1L);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator8 = null;
        try {
            nelderMeadSimplex6.iterate(multivariateFunction7, pointValuePairComparator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = blockRealMatrix31.walkInOptimizedOrder(realMatrixPreservingVisitor32, 0, 0, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.scale((double) 1, doubleArray55);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds66 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray46, doubleArray65);
        try {
            blockRealMatrix31.setRow(0, doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x4 but expected 1x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3043045862358962d + "'", double1 == 1.3043045862358962d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (byte) 10, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.5d + "'", double2 == 5.5d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector2.getSubVector(97, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[] doubleArray35 = new double[] { (short) 1, 1.0E-6d, 100 };
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray35, 0.017453292519943295d);
        try {
            double[] doubleArray38 = blockRealMatrix31.preMultiply(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 1, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) (-1.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        try {
            double double34 = blockRealMatrix31.getEntry(1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        try {
            org.apache.commons.math3.linear.RealVector realVector33 = blockRealMatrix31.getRowVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = blockRealMatrix31.walkInOptimizedOrder(realMatrixPreservingVisitor32, (int) (short) 1, (int) 'a', 97, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector35.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector40.set((double) ' ');
        java.lang.String str43 = arrayRealVector40.toString();
        double[] doubleArray44 = arrayRealVector40.toArray();
        boolean boolean45 = arrayRealVector35.equals((java.lang.Object) doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Target target46 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray44);
        try {
            blockRealMatrix31.setRow((int) (short) 100, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double2 = org.apache.commons.math3.util.FastMath.pow(100.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E200d + "'", double2 == 1.0E200d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray5 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray7, doubleArray14);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 113.59577456930342d + "'", double6 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 113.59577456930342d + "'", double13 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix31.walkInOptimizedOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str3 = arrayRealVector2.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector6.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector11.set((double) ' ');
        java.lang.String str14 = arrayRealVector11.toString();
        double[] doubleArray15 = arrayRealVector11.toArray();
        boolean boolean16 = arrayRealVector6.equals((java.lang.Object) doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str20 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        try {
            double double22 = arrayRealVector2.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{}" + "'", str3.equals("{}"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{}" + "'", str14.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray12 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int13 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        int int14 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray5);
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        mersenneTwister16.clear();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            java.lang.String str2 = realVectorFormat0.format(realVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        try {
            double double67 = array2DRowRealMatrix31.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix15.walkInRowOrder(realMatrixPreservingVisitor16, (int) (byte) -1, 97, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(1.0E-14d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner6);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction9 = null;
        try {
            double double13 = brentSolver4.solve((int) (byte) 100, univariateFunction9, (double) (-1.0f), (double) 0, Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(100.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[] doubleArray36 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double37 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray36);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        double[] doubleArray43 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double44 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray43);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray45);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix48 = blockRealMatrix31.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 4x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 113.59577456930342d + "'", double37 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 113.59577456930342d + "'", double44 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.017453292519943295d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017453292519943295d + "'", double2 == 0.017453292519943295d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (-1L), 12771.28797757116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12772.715729496098d + "'", double2 == 12772.715729496098d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        try {
            arrayRealVector2.addToEntry((int) (short) 0, 1.0E-14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.7615941559557649d, (double) (short) 1, (double) 10L, 1.0d, (java.lang.Object[]) doubleArray7);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int[] intArray4 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray11 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int12 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray4, intArray11);
        int[] intArray17 = new int[] { (byte) -1, 0, (short) 0, (short) 0 };
        try {
            int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray11, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing(univariateFunction0, 112.71202242884297d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(3.1622776601683795d, (double) (-0.1f));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = array2DRowRealMatrix32.getRowVector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.7910068511973d + "'", double1 == 11.7910068511973d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math3.util.FastMath.tan(112.71202242884297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.40558658329085623d) + "'", double1 == (-0.40558658329085623d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        boolean boolean33 = array2DRowRealMatrix32.isTransposable();
        double double34 = array2DRowRealMatrix32.getNorm();
        try {
            array2DRowRealMatrix32.setEntry((int) (short) 10, 100, 9410.570796326794d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", 0);
        java.lang.Class<?> wildcardClass3 = mathParseException2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 10L, 1.0d, univariatePointValuePairConvergenceChecker2);
        int int4 = brentOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor32 = null;
        try {
            double double33 = blockRealMatrix31.walkInRowOrder(realMatrixChangingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.util.Pair<java.io.Serializable, org.apache.commons.math3.exception.MathIllegalArgumentException> serializablePair0 = null;
        try {
            org.apache.commons.math3.util.Pair<java.io.Serializable, org.apache.commons.math3.exception.MathIllegalArgumentException> serializablePair1 = new org.apache.commons.math3.util.Pair<java.io.Serializable, org.apache.commons.math3.exception.MathIllegalArgumentException>(serializablePair0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double34 = blockRealMatrix31.walkInColumnOrder(realMatrixChangingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math3.util.FastMath.abs(5.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.5d + "'", double1 == 5.5d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray15 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray21 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray27 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray33 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray39 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray40 = new double[][] { doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray40);
        double[][] doubleArray42 = blockRealMatrix41.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix43 = blockRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.0d, 0.0d, univariatePointValuePairConvergenceChecker2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double2 = org.apache.commons.math3.util.FastMath.pow(100.0d, 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor67 = null;
        try {
            double double68 = array2DRowRealMatrix48.walkInRowOrder(realMatrixChangingVisitor67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex35 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray32, (double) 1L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15, 1.0E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        boolean boolean33 = array2DRowRealMatrix32.isTransposable();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = array2DRowRealMatrix32.walkInRowOrder(realMatrixChangingVisitor34, 1, (int) (short) 100, 774819465, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, Double.NaN, (-0.3758492992847182d), 0.0d, 0.0d, (double) 1L);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray18 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray20);
        double[] doubleArray26 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double27 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray21, doubleArray26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector31.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector36.set((double) ' ');
        java.lang.String str39 = arrayRealVector36.toString();
        double[] doubleArray40 = arrayRealVector36.toArray();
        boolean boolean41 = arrayRealVector31.equals((java.lang.Object) doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Target target42 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray40, false);
        double[] doubleArray45 = pointVectorValuePair44.getValueRef();
        try {
            nelderMeadSimplex6.build(doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 113.59577456930342d + "'", double19 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 113.59577456930342d + "'", double27 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 12771.287977571159d + "'", double28 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{}" + "'", str39.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.getColumnMatrix(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 10L, 1.0d, univariatePointValuePairConvergenceChecker2);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray4 = null;
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair5 = brentOptimizer3.optimize(optimizationDataArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math3.util.FastMath.exp(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector10.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector15.set((double) ' ');
        java.lang.String str18 = arrayRealVector15.toString();
        double[] doubleArray19 = arrayRealVector15.toArray();
        boolean boolean20 = arrayRealVector10.equals((java.lang.Object) doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str24 = arrayRealVector23.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector10.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix27 = arrayRealVector7.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{}" + "'", str18.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{}" + "'", str24.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector25);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        int[] intArray33 = new int[] {};
        int[] intArray38 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray45 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int46 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray38, intArray45);
        int int47 = org.apache.commons.math3.util.MathArrays.distance1(intArray33, intArray38);
        int[] intArray48 = org.apache.commons.math3.util.MathArrays.copyOf(intArray38);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister49 = new org.apache.commons.math3.random.MersenneTwister(intArray38);
        int[] intArray54 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray61 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int62 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray54, intArray61);
        double[] doubleArray68 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray74 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray80 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray86 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray92 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray93 = new double[][] { doubleArray68, doubleArray74, doubleArray80, doubleArray86, doubleArray92 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix94 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray93);
        double[][] doubleArray95 = blockRealMatrix94.getData();
        try {
            array2DRowRealMatrix32.copySubMatrix(intArray38, intArray54, doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix48.getColumnMatrix(36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double33 = blockRealMatrix31.walkInRowOrder(realMatrixPreservingVisitor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 36, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix70 = array2DRowRealMatrix48.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(100.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = null;
        try {
            bracketFinder0.search(univariateFunction2, goalType3, (double) Float.NaN, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector71.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector76.set((double) ' ');
        java.lang.String str79 = arrayRealVector76.toString();
        double[] doubleArray80 = arrayRealVector76.toArray();
        boolean boolean81 = arrayRealVector71.equals((java.lang.Object) doubleArray80);
        org.apache.commons.math3.optim.nonlinear.vector.Target target82 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray80);
        try {
            double[] doubleArray83 = array2DRowRealMatrix48.operate(doubleArray80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{}" + "'", str79.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x4) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = blockRealMatrix9.getColumnVector((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, (double) 1, 1.0E-6d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math3.util.FastMath.tan(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        try {
            double[] doubleArray34 = blockRealMatrix31.getColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 97);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        double[] doubleArray72 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double73 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray72);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72);
        double[] doubleArray79 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double80 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray79);
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79);
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray74, doubleArray81);
        org.apache.commons.math3.optim.PointValuePair pointValuePair85 = new org.apache.commons.math3.optim.PointValuePair(doubleArray81, 0.0d, true);
        try {
            array2DRowRealMatrix31.setRow((int) (short) 10, doubleArray81);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 113.59577456930342d + "'", double73 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 113.59577456930342d + "'", double80 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 36 };
        java.lang.Integer[] intArray3 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException4 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray2, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(6.283185307179586d, 774819465);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray1 = null;
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair2 = levenbergMarquardtOptimizer0.optimize(optimizationDataArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector18.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector23.set((double) ' ');
        java.lang.String str26 = arrayRealVector23.toString();
        double[] doubleArray27 = arrayRealVector23.toArray();
        boolean boolean28 = arrayRealVector18.equals((java.lang.Object) doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str32 = arrayRealVector31.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector18.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        try {
            org.apache.commons.math3.linear.RealVector realVector35 = array2DRowRealMatrix15.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector33);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(12771.287977571159d, (double) (-0.1f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12771.287977571157d + "'", double2 == 12771.287977571157d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 113.59577456930342d, (java.lang.Number) 10L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 113.59577456930342d + "'", number5.equals(113.59577456930342d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 0.0f, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray36 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double37 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray36);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36);
        double[] doubleArray43 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double44 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray43);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray38, doubleArray45);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix31.subtract(array2DRowRealMatrix47);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray69 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double70 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray69);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69);
        double[] doubleArray76 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double77 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray76);
        double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray76);
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray71, doubleArray78);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = array2DRowRealMatrix64.subtract(array2DRowRealMatrix80);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix47, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix64);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = array2DRowRealMatrix15.multiply(array2DRowRealMatrix64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 113.59577456930342d + "'", double37 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 113.59577456930342d + "'", double44 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 113.59577456930342d + "'", double70 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 113.59577456930342d + "'", double77 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix81);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double2 = org.apache.commons.math3.util.FastMath.min(6.283185307179586d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.distance(doubleArray6, doubleArray18);
        double[] doubleArray25 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double26 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray25);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        double[] doubleArray32 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray32);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray34);
        double[] doubleArray41 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double42 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray41);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41);
        double[] doubleArray48 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double49 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray48);
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray43, doubleArray50);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.scale((double) 1, doubleArray43);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds54 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray34, doubleArray53);
        try {
            double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 113.59577456930342d + "'", double26 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 113.59577456930342d + "'", double33 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 113.59577456930342d + "'", double42 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 113.59577456930342d + "'", double49 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor35 = null;
        try {
            double double36 = blockRealMatrix32.walkInOptimizedOrder(realMatrixChangingVisitor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSeparator();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector5.set((double) ' ');
        java.lang.String str8 = arrayRealVector5.toString();
        double[] doubleArray9 = arrayRealVector5.toArray();
        double[] doubleArray10 = arrayRealVector5.toArray();
        java.lang.String str11 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        double[] doubleArray19 = arrayRealVector14.toArray();
        java.lang.String str20 = arrayRealVector14.toString();
        java.lang.StringBuffer stringBuffer21 = null;
        java.text.FieldPosition fieldPosition22 = null;
        try {
            java.lang.StringBuffer stringBuffer23 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14, stringBuffer21, fieldPosition22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{}" + "'", str8.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{}" + "'", str11.equals("{}"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor67 = null;
        try {
            double double72 = array2DRowRealMatrix48.walkInRowOrder(realMatrixChangingVisitor67, (int) (short) 1, (int) (byte) 1, (-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition68 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix31, 1.0E-6d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = blockRealMatrix32.getSubMatrix(2147483647, (int) (short) 1, 6, 235552016);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 235552016, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 235552016L + "'", long2 == 235552016L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray33, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector40.set((double) ' ');
        java.lang.String str43 = arrayRealVector40.toString();
        double[] doubleArray44 = arrayRealVector40.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector47.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector52.set((double) ' ');
        java.lang.String str55 = arrayRealVector52.toString();
        double[] doubleArray56 = arrayRealVector52.toArray();
        boolean boolean57 = arrayRealVector47.equals((java.lang.Object) doubleArray56);
        double double58 = org.apache.commons.math3.util.MathArrays.distance(doubleArray44, doubleArray56);
        try {
            double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray19, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{}" + "'", str55.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        double[] doubleArray7 = arrayRealVector2.toArray();
        java.lang.String str8 = arrayRealVector2.toString();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor9 = null;
        try {
            double double10 = arrayRealVector2.walkInDefaultOrder(realVectorPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{}" + "'", str8.equals("{}"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            double double12 = blockRealMatrix9.getEntry(2147483647, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        int[] intArray33 = new int[] {};
        int[] intArray38 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray45 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int46 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray38, intArray45);
        int int47 = org.apache.commons.math3.util.MathArrays.distance1(intArray33, intArray38);
        int[] intArray48 = org.apache.commons.math3.util.MathArrays.copyOf(intArray38);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister49 = new org.apache.commons.math3.random.MersenneTwister(intArray38);
        int[] intArray50 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix32, intArray38, intArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, 50, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5430806348152437d, (-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2788395171581284d + "'", double2 == 0.2788395171581284d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix32.getData();
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) (short) 1);
        try {
            blockRealMatrix32.setSubMatrix(doubleArray36, (int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1L, (byte) 0, '4', true };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray6);
        org.apache.commons.math3.util.Pair<java.io.Serializable, org.apache.commons.math3.exception.MathIllegalArgumentException> serializablePair8 = new org.apache.commons.math3.util.Pair<java.io.Serializable, org.apache.commons.math3.exception.MathIllegalArgumentException>((java.io.Serializable) 10.0f, mathIllegalArgumentException7);
        java.io.Serializable serializable9 = serializablePair8.getFirst();
        java.io.ObjectInputStream objectInputStream11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) serializablePair8, "; ", objectInputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + serializable9 + "' != '" + 10.0f + "'", serializable9.equals(10.0f));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int2 = org.apache.commons.math3.util.FastMath.min(235552016, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) 100.00001f, false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = array2DRowRealMatrix32.getColumnVector(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 12771.287977571157d, (java.lang.Number) (-0.40558658329085623d), true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix15, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector20.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector25.set((double) ' ');
        java.lang.String str28 = arrayRealVector25.toString();
        double[] doubleArray29 = arrayRealVector25.toArray();
        boolean boolean30 = arrayRealVector20.equals((java.lang.Object) doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str34 = arrayRealVector33.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector20.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector38.set((double) ' ');
        java.lang.String str41 = arrayRealVector38.toString();
        double[] doubleArray42 = arrayRealVector38.toArray();
        double[] doubleArray43 = arrayRealVector38.toArray();
        java.lang.String str44 = arrayRealVector38.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector48.set((double) ' ');
        java.lang.String str51 = arrayRealVector48.toString();
        double[] doubleArray52 = arrayRealVector48.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector48.copy();
        double double54 = arrayRealVector38.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        try {
            org.apache.commons.math3.linear.RealVector realVector55 = array2DRowRealMatrix15.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{}" + "'", str28.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{}" + "'", str34.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{}" + "'", str41.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{}" + "'", str44.equals("{}"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{}" + "'", str51.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(arrayRealVector53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str38 = arrayRealVector37.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector24.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{}" + "'", str38.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertNotNull(arrayRealVector43);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor69 = null;
        try {
            double double70 = array2DRowRealMatrix48.walkInColumnOrder(realMatrixPreservingVisitor69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix31.add(realMatrix32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (-1L), 0.6483608274590866d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 774819465);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.74819465E8d + "'", double1 == 7.74819465E8d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double38 = array2DRowRealMatrix31.walkInOptimizedOrder(realMatrixChangingVisitor33, (int) '#', 235552016, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix31.preMultiply(realMatrix67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSeparator();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector5.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector10.set((double) ' ');
        java.lang.String str13 = arrayRealVector10.toString();
        double[] doubleArray14 = arrayRealVector10.toArray();
        boolean boolean15 = arrayRealVector5.equals((java.lang.Object) doubleArray14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector18.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector23.set((double) ' ');
        java.lang.String str26 = arrayRealVector23.toString();
        double[] doubleArray27 = arrayRealVector23.toArray();
        boolean boolean28 = arrayRealVector18.equals((java.lang.Object) doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str32 = arrayRealVector31.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector18.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector36.set((double) ' ');
        java.lang.String str39 = arrayRealVector36.toString();
        double[] doubleArray40 = arrayRealVector36.toArray();
        double[] doubleArray41 = arrayRealVector36.toArray();
        java.lang.String str42 = arrayRealVector36.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18, arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5, arrayRealVector43);
        java.lang.StringBuffer stringBuffer45 = null;
        java.text.FieldPosition fieldPosition46 = null;
        try {
            java.lang.StringBuffer stringBuffer47 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector44, stringBuffer45, fieldPosition46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{}" + "'", str13.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "{}" + "'", str39.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{}" + "'", str42.equals("{}"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        double double33 = blockRealMatrix31.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor34 = null;
        try {
            double double39 = blockRealMatrix31.walkInRowOrder(realMatrixPreservingVisitor34, 235552016, 100, 235552016, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (235,552,016)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 12772.715729496098d, (java.lang.Number) (short) 1, 235552016);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray7 = null;
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds8 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray6, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        int[] intArray67 = new int[] {};
        int[] intArray72 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray79 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int80 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray72, intArray79);
        int int81 = org.apache.commons.math3.util.MathArrays.distance1(intArray67, intArray72);
        int[] intArray82 = org.apache.commons.math3.util.MathArrays.copyOf(intArray72);
        int[] intArray83 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix84 = array2DRowRealMatrix31.getSubMatrix(intArray82, intArray83);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 100 + "'", int80 == 100);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray82);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) 'a');
        incrementor1.setMaximalCount((int) (byte) -1);
        int int4 = incrementor1.getCount();
        boolean boolean5 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(0.2788395171581284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (double) 52, 0.017453292519943295d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("; ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, (double) (short) 0, (double) 'a', (double) 1.1920929E-7f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.17877966098643805d + "'", double0 == 0.17877966098643805d);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1L, (byte) 0, '4', true };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray6);
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray6);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError9 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) zeroException8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 235552016L, (double) (short) 100, 52);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector35.set((double) ' ');
        java.lang.String str38 = arrayRealVector35.toString();
        double[] doubleArray39 = arrayRealVector35.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector42.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector47.set((double) ' ');
        java.lang.String str50 = arrayRealVector47.toString();
        double[] doubleArray51 = arrayRealVector47.toArray();
        boolean boolean52 = arrayRealVector42.equals((java.lang.Object) doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str56 = arrayRealVector55.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector42.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector35.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector62.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector67.set((double) ' ');
        java.lang.String str70 = arrayRealVector67.toString();
        double[] doubleArray71 = arrayRealVector67.toArray();
        boolean boolean72 = arrayRealVector62.equals((java.lang.Object) doubleArray71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str76 = arrayRealVector75.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector62.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector80.set((double) ' ');
        java.lang.String str83 = arrayRealVector80.toString();
        double[] doubleArray84 = arrayRealVector80.toArray();
        double[] doubleArray85 = arrayRealVector80.toArray();
        java.lang.String str86 = arrayRealVector80.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector62, arrayRealVector80);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector90.set((double) ' ');
        java.lang.String str93 = arrayRealVector90.toString();
        double[] doubleArray94 = arrayRealVector90.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = arrayRealVector90.copy();
        double double96 = arrayRealVector80.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector95);
        double double97 = arrayRealVector59.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector80);
        try {
            blockRealMatrix31.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{}" + "'", str38.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{}" + "'", str50.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{}" + "'", str56.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(arrayRealVector59);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{}" + "'", str70.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "{}" + "'", str76.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector77);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "{}" + "'", str83.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "{}" + "'", str86.equals("{}"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "{}" + "'", str93.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(arrayRealVector95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math3.util.FastMath.acos(12771.28797757116d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray2, (double) 97, (double) 10, 0.8414709848078965d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double6 = brentSolver5.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5, preconditioner7);
        double double9 = simpleValueChecker4.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        try {
            double double16 = brentSolver10.solve(10, univariateFunction13, 112.71202242884297d, 12771.28797757116d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-6d + "'", double6 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor27 = null;
        try {
            double double30 = arrayRealVector26.walkInDefaultOrder(realVectorPreservingVisitor27, 0, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector17.mapSubtractToSelf(6.283185307179586d);
        double double21 = arrayRealVector17.getLInfNorm();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor69 = null;
        try {
            double double74 = array2DRowRealMatrix48.walkInColumnOrder(realMatrixPreservingVisitor69, 36, (int) (short) 1, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix32.getData();
        org.apache.commons.math3.linear.RealVector realVector35 = null;
        try {
            blockRealMatrix32.setColumnVector(0, realVector35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int1 = org.apache.commons.math3.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSeparator();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector5.set((double) ' ');
        java.lang.String str8 = arrayRealVector5.toString();
        double[] doubleArray9 = arrayRealVector5.toArray();
        double[] doubleArray10 = arrayRealVector5.toArray();
        java.lang.String str11 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = realVectorFormat1.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{}" + "'", str8.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{}" + "'", str11.equals("{}"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1290.159154892091d + "'", double1 == 1290.159154892091d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.copy();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor8 = null;
        try {
            double double11 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor8, (int) (short) 0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray4);
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray4, (double) (-1L));
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray12 = new double[] { 10.0d };
        double[] doubleArray14 = new double[] { 10.0d };
        double[] doubleArray16 = new double[] { 10.0d };
        double[] doubleArray18 = new double[] { 10.0d };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray4, orderDirection10, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        int[] intArray0 = null;
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(intArray0);
//        long long2 = mersenneTwister1.nextLong();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2575744870520794374L + "'", long2 == 2575744870520794374L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        try {
            double double72 = blockRealMatrix66.getEntry((int) (short) 1, 774819465);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (774,819,465)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray34 = new double[] { 10.0d };
        double[] doubleArray36 = new double[] { 10.0d };
        double[] doubleArray38 = new double[] { 10.0d };
        double[] doubleArray40 = new double[] { 10.0d };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray36, doubleArray38, doubleArray40 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray41);
        try {
            array2DRowRealMatrix15.setSubMatrix(doubleArray41, 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 10.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E52d + "'", double2 == 1.0E52d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix32.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector37.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector42.set((double) ' ');
        java.lang.String str45 = arrayRealVector42.toString();
        double[] doubleArray46 = arrayRealVector42.toArray();
        boolean boolean47 = arrayRealVector37.equals((java.lang.Object) doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str51 = arrayRealVector50.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector37.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector55.set((double) ' ');
        java.lang.String str58 = arrayRealVector55.toString();
        double[] doubleArray59 = arrayRealVector55.toArray();
        double[] doubleArray60 = arrayRealVector55.toArray();
        java.lang.String str61 = arrayRealVector55.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector37, arrayRealVector55);
        try {
            blockRealMatrix32.setRowVector((int) ' ', (org.apache.commons.math3.linear.RealVector) arrayRealVector62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{}" + "'", str45.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{}" + "'", str51.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{}" + "'", str58.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{}" + "'", str61.equals("{}"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        org.apache.commons.math3.linear.RealVector realVector70 = array2DRowRealMatrix48.getColumnVector((int) (short) 0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor71 = null;
        try {
            double double76 = array2DRowRealMatrix48.walkInColumnOrder(realMatrixChangingVisitor71, (int) (byte) -1, (int) '#', (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realVector70);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) (byte) 1, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector10.set((double) ' ');
        java.lang.String str13 = arrayRealVector10.toString();
        double[] doubleArray14 = arrayRealVector10.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.copy();
        try {
            arrayRealVector2.setSubVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{}" + "'", str13.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(arrayRealVector15);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) ' ', (-1.0d), 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray33, false);
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15, (-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, Double.NaN, (-0.3758492992847182d), 0.0d, 0.0d, (double) 1L);
        int int7 = nelderMeadSimplex6.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction8 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator9 = null;
        try {
            nelderMeadSimplex6.iterate(multivariateFunction8, pointValuePairComparator9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, (double) (-1), (int) (byte) 100);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1), (float) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix68, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor19 = null;
        try {
            double double22 = arrayRealVector18.walkInOptimizedOrder(realVectorPreservingVisitor19, (int) (short) -1, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.scale((double) 1, doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds33 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray32);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex36 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray32, 0.0d, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 0L, (int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        double[] doubleArray14 = sigma13.getSigma();
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray19);
        try {
            double double23 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray14, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) 'a');
        int int2 = incrementor1.getCount();
        int int3 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double39 = blockRealMatrix32.walkInOptimizedOrder(realMatrixChangingVisitor34, (int) (byte) 10, 774819465, 36, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        try {
            double double72 = blockRealMatrix32.getEntry((int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        long[] longArray5 = new long[] { 6, (short) 10, (byte) 0, 100, (short) 1 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) 100, (double) 2575744870520794374L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.00001f + "'", float2 == 100.00001f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        double double70 = blockRealMatrix66.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 12771.287977571159d, (java.lang.Number) 0.0d, true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(1.0E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000005E-14d + "'", double1 == 1.000000000000005E-14d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 0, (int) '#', (double) (byte) 0);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix66.getColumnMatrix(235552016);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (235,552,016)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector20.set((double) ' ');
        java.lang.String str23 = arrayRealVector20.toString();
        double[] doubleArray24 = arrayRealVector20.toArray();
        double[] doubleArray25 = arrayRealVector20.toArray();
        java.lang.String str26 = arrayRealVector20.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector30.set((double) ' ');
        java.lang.String str33 = arrayRealVector30.toString();
        double[] doubleArray34 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector30.copy();
        double double36 = arrayRealVector20.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector41.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector46.set((double) ' ');
        java.lang.String str49 = arrayRealVector46.toString();
        double[] doubleArray50 = arrayRealVector46.toArray();
        boolean boolean51 = arrayRealVector41.equals((java.lang.Object) doubleArray50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str55 = arrayRealVector54.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = arrayRealVector41.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector35.combine((double) (short) 0, (-1.5707963267948966d), (org.apache.commons.math3.linear.RealVector) arrayRealVector57);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.mapDivide((double) 50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector63.set((double) ' ');
        java.lang.String str66 = arrayRealVector63.toString();
        double[] doubleArray67 = arrayRealVector63.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector63.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector58.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{}" + "'", str33.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{}" + "'", str55.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector56);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{}" + "'", str66.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(arrayRealVector68);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double2 = org.apache.commons.math3.util.Precision.round(1.0E-6d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula2 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double7 = brentSolver6.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula2, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, preconditioner8);
        int int10 = nonLinearConjugateGradientOptimizer9.getIterations();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = nonLinearConjugateGradientOptimizer9.getGoalType();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker12 = nonLinearConjugateGradientOptimizer9.getConvergenceChecker();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 35, 100.0d, pointValuePairConvergenceChecker12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-6d + "'", double7 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(goalType11);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(9410.570796326794d, (double) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long[] longArray6 = new long[] { ' ', (short) -1, 2147483647, 235552016, 97, '4' };
        long[] longArray13 = new long[] { ' ', (short) -1, 2147483647, 235552016, 97, '4' };
        long[][] longArray14 = new long[][] { longArray6, longArray13 };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing(univariateFunction0, 3.1622776601683795d, 0.17877966098643805d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        try {
            blockRealMatrix31.addToEntry(0, 774819465, 9410.570796326794d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (774,819,465)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        double double33 = blockRealMatrix31.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor34 = null;
        try {
            double double35 = blockRealMatrix31.walkInOptimizedOrder(realMatrixPreservingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.9030187f + "'", float1 == 0.9030187f);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix31, 50, 52, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix69.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = blockRealMatrix69.createMatrix(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker7 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver8 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double9 = brentSolver8.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8, preconditioner10);
        double[] doubleArray17 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        double[] doubleArray24 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double25 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray19, doubleArray26);
        org.apache.commons.math3.optim.PointValuePair pointValuePair30 = new org.apache.commons.math3.optim.PointValuePair(doubleArray26, 0.0d, true);
        double[] doubleArray35 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double36 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray35);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35);
        double[] doubleArray42 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double43 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray37, doubleArray44);
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, 0.0d, true);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat49 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        boolean boolean50 = pointValuePair48.equals((java.lang.Object) realMatrixFormat49);
        boolean boolean51 = simpleValueChecker7.converged((int) (byte) 1, pointValuePair30, pointValuePair48);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-0.35909740519917466d), (double) (short) 1, 1.0E200d, (double) 7.6293945E-6f, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -0.359 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-6d + "'", double9 == 1.0E-6d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 113.59577456930342d + "'", double18 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 113.59577456930342d + "'", double25 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 113.59577456930342d + "'", double36 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 113.59577456930342d + "'", double43 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realMatrixFormat49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) (short) 10, (double) (byte) 100, 0.054843730427087234d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        java.io.ObjectOutputStream objectOutputStream27 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, objectOutputStream27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula11 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker14 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner17 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula11, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker14, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15, preconditioner17);
        double[] doubleArray24 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double25 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray24);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24);
        double[] doubleArray31 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double32 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray26, doubleArray33);
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, 0.0d, true);
        double[] doubleArray42 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double43 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42);
        double[] doubleArray49 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray51);
        org.apache.commons.math3.optim.PointValuePair pointValuePair55 = new org.apache.commons.math3.optim.PointValuePair(doubleArray51, 0.0d, true);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat56 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        boolean boolean57 = pointValuePair55.equals((java.lang.Object) realMatrixFormat56);
        boolean boolean58 = simpleValueChecker14.converged((int) (byte) 1, pointValuePair37, pointValuePair55);
        double[] doubleArray59 = pointValuePair55.getPoint();
        try {
            blockRealMatrix9.setRow(0, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x4 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-6d + "'", double16 == 1.0E-6d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 113.59577456930342d + "'", double25 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 113.59577456930342d + "'", double32 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 113.59577456930342d + "'", double43 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 113.59577456930342d + "'", double50 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrixFormat56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double2 = org.apache.commons.math3.util.Precision.round(9410.570796326794d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9410.0d + "'", double2 == 9410.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) (-1), (double) (short) 10);
        double double3 = univariatePointValuePair2.getValue();
        double double4 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.text.ParsePosition parsePosition3 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse(",", parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.7615941559557649d, (double) (short) 1, (double) 10L, 1.0d, (java.lang.Object[]) doubleArray7);
        double double9 = noBracketingException8.getHi();
        double double10 = noBracketingException8.getLo();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7615941559557649d + "'", double10 == 0.7615941559557649d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[] doubleArray5 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double6 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray5);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double13 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray12);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray7, doubleArray14);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray15, doubleArray20);
        double[] doubleArray26 = new double[] { (short) 1, 1.0E-6d, 100 };
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray26, 0.017453292519943295d);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray28);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.scale(0.0d, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 113.59577456930342d + "'", double6 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 113.59577456930342d + "'", double13 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12771.287977571159d + "'", double22 == 12771.287977571159d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.junit.Assert.assertNotNull(maxIter0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (byte) 1, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) 0, '4', true };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable8, objArray13);
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException(localizable7, objArray13);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException16 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable6, objArray13);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math3.exception.NoBracketingException(localizable1, 2.010811343333877d, Double.POSITIVE_INFINITY, (double) 1.1920929E-7f, 9410.570796326794d, objArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray13);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 10, 35, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix69.copy();
        try {
            double double73 = blockRealMatrix69.getEntry(35, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Number number0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, objArray1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        try {
            double[] doubleArray34 = blockRealMatrix31.getColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector4.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        java.lang.String str12 = arrayRealVector9.toString();
        double[] doubleArray13 = arrayRealVector9.toArray();
        boolean boolean14 = arrayRealVector4.equals((java.lang.Object) doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str18 = arrayRealVector17.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector4.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double double24 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        try {
            arrayRealVector23.addToEntry(2147483647, (double) 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{}" + "'", str12.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{}" + "'", str18.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor5 = null;
        try {
            double double8 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor5, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(1.0E-14d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0E-14d + "'", double2 == 2.0E-14d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        int[] intArray71 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray78 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int79 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray71, intArray78);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister80 = new org.apache.commons.math3.random.MersenneTwister(intArray78);
        int[] intArray85 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray92 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int93 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray85, intArray92);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, intArray78, intArray85);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 100 + "'", int79 == 100);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 100 + "'", int93 == 100);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19);
        double[] doubleArray26 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double27 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray21, doubleArray28);
        double[] doubleArray34 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double35 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray34);
        double double36 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray29, doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector39.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector44.set((double) ' ');
        java.lang.String str47 = arrayRealVector44.toString();
        double[] doubleArray48 = arrayRealVector44.toArray();
        boolean boolean49 = arrayRealVector39.equals((java.lang.Object) doubleArray48);
        org.apache.commons.math3.optim.nonlinear.vector.Target target50 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray48);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray34, doubleArray48, false);
        double[] doubleArray53 = pointVectorValuePair52.getValueRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds54 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray53);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (112.712 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 113.59577456930342d + "'", double27 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 113.59577456930342d + "'", double35 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 12771.287977571159d + "'", double36 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{}" + "'", str47.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray5 = nonLinearConjugateGradientOptimizer4.getStartPoint();
        int int6 = nonLinearConjugateGradientOptimizer4.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(50);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[][] doubleArray33 = array2DRowRealMatrix15.getData();
        double[] doubleArray39 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray45 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray51 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray57 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray63 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray64 = new double[][] { doubleArray39, doubleArray45, doubleArray51, doubleArray57, doubleArray63 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix65 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray64);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = blockRealMatrix65.transpose();
        double[][] doubleArray67 = blockRealMatrix65.getData();
        try {
            array2DRowRealMatrix15.setSubMatrix(doubleArray67, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(blockRealMatrix66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        double[] doubleArray52 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double53 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray52);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52);
        double[] doubleArray59 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray61);
        double[] doubleArray67 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double68 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray62);
        double[] doubleArray71 = array2DRowRealMatrix31.preMultiply(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector74.set((double) ' ');
        java.lang.String str77 = arrayRealVector74.toString();
        double[] doubleArray78 = arrayRealVector74.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector81.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector86.set((double) ' ');
        java.lang.String str89 = arrayRealVector86.toString();
        double[] doubleArray90 = arrayRealVector86.toArray();
        boolean boolean91 = arrayRealVector81.equals((java.lang.Object) doubleArray90);
        double double92 = org.apache.commons.math3.util.MathArrays.distance(doubleArray78, doubleArray90);
        org.apache.commons.math3.optim.PointValuePair pointValuePair94 = new org.apache.commons.math3.optim.PointValuePair(doubleArray78, (double) 2147483647);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair95 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray70, doubleArray78);
        double[] doubleArray96 = pointVectorValuePair95.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 113.59577456930342d + "'", double53 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 113.59577456930342d + "'", double60 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 113.59577456930342d + "'", double68 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 12771.287977571159d + "'", double69 == 12771.287977571159d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{}" + "'", str77.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "{}" + "'", str89.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray96);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int[] intArray5 = new int[] { 10, 774819465, (short) -1, '#', 235552016 };
        int[] intArray6 = new int[] {};
        int[] intArray11 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray18 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int19 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray11, intArray18);
        int int20 = org.apache.commons.math3.util.MathArrays.distance1(intArray6, intArray11);
        try {
            int int21 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray11);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (-1L), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray13, 0.0d, true);
        java.lang.Double double18 = pointValuePair17.getValue();
        double[] doubleArray19 = pointValuePair17.getFirst();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18.equals(0.0d));
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector72.set((double) ' ');
        java.lang.String str75 = arrayRealVector72.toString();
        double[] doubleArray76 = arrayRealVector72.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector72.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector78 = blockRealMatrix32.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "{}" + "'", str75.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(arrayRealVector77);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        boolean boolean27 = arrayRealVector2.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix32 = arrayRealVector28.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray33, false);
        double[] doubleArray38 = pointVectorValuePair37.getValueRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray41 = new double[] { 10.0d };
        double[] doubleArray43 = new double[] { 10.0d };
        double[] doubleArray45 = new double[] { 10.0d };
        double[] doubleArray47 = new double[] { 10.0d };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray43, doubleArray45, doubleArray47 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray48);
        try {
            array2DRowRealMatrix39.setSubMatrix(doubleArray48, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 0, (double) (byte) 10, 22026.465794806718d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        double double70 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(10, (int) (short) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix74 = blockRealMatrix32.multiply(realMatrix73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (-1439493793));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        java.io.ObjectInputStream objectInputStream68 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) array2DRowRealMatrix48, "; ", objectInputStream68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        org.apache.commons.math3.linear.RealVector realVector70 = array2DRowRealMatrix48.getColumnVector((int) (short) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix73 = array2DRowRealMatrix48.createMatrix((int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realVector70);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.getSubVector(1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(arrayRealVector7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix31, (int) (byte) 0);
        double[] doubleArray38 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double39 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray38);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38);
        double[] doubleArray45 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double46 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray45);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray47);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix49, 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix52 = blockRealMatrix31.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 113.59577456930342d + "'", double39 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 113.59577456930342d + "'", double46 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        org.apache.commons.math3.linear.RealVector realVector34 = blockRealMatrix32.getRowVector(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.getColumnMatrix((int) (byte) 0);
        double[] doubleArray42 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray48 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray54 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray60 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray66 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray67 = new double[][] { doubleArray42, doubleArray48, doubleArray54, doubleArray60, doubleArray66 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix68 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray67);
        double[][] doubleArray69 = blockRealMatrix68.getData();
        try {
            blockRealMatrix32.setSubMatrix(doubleArray69, 93740670, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (93,740,670)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.3758492992847182d), (double) 6, 0.2788395171581284d, (double) '#', 1.0E200d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.504287304826184d + "'", double6 == 7.504287304826184d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 97, (java.lang.Number) 1L, 0, orderDirection4, true);
        boolean boolean7 = nonMonotonicSequenceException6.getStrict();
        java.lang.Number number8 = nonMonotonicSequenceException6.getPrevious();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = nonMonotonicSequenceException6.getDirection();
        double[] doubleArray15 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray21 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray27 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray33 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray39 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray40 = new double[][] { doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray40);
        double[][] doubleArray42 = blockRealMatrix41.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection9, doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((-0.40558658329085623d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007078821280339659d) + "'", double1 == (-0.007078821280339659d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[] doubleArray9 = new double[] { 10.0d };
        double[][] doubleArray10 = new double[][] { doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix(1684133433, 52, doubleArray10, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2,704");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        boolean boolean66 = array2DRowRealMatrix65.isTransposable();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = array2DRowRealMatrix15.add(array2DRowRealMatrix65);
        double[][] doubleArray74 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        try {
            array2DRowRealMatrix65.copySubMatrix(0, (int) 'a', (int) ' ', 774819465, doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix67);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        double[] doubleArray14 = sigma13.getSigma();
        double[] doubleArray15 = sigma13.getSigma();
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix69.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix69.getRowMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        boolean boolean66 = array2DRowRealMatrix65.isTransposable();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = array2DRowRealMatrix15.add(array2DRowRealMatrix65);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor68 = null;
        try {
            double double69 = array2DRowRealMatrix15.walkInColumnOrder(realMatrixPreservingVisitor68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix67);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, 1290.159154892091d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner6);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker8 = nonLinearConjugateGradientOptimizer7.getConvergenceChecker();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector11.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        java.lang.String str19 = arrayRealVector16.toString();
        double[] doubleArray20 = arrayRealVector16.toArray();
        boolean boolean21 = arrayRealVector11.equals((java.lang.Object) doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Target target22 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray23 = new org.apache.commons.math3.optim.OptimizationData[] { target22 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair24 = nonLinearConjugateGradientOptimizer7.optimize(optimizationDataArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker8);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(optimizationDataArray23);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray5 = nonLinearConjugateGradientOptimizer4.getLowerBound();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double[] doubleArray1 = new double[] { 10.0d };
        double[] doubleArray3 = new double[] { 10.0d };
        double[] doubleArray5 = new double[] { 10.0d };
        double[] doubleArray7 = new double[] { 10.0d };
        double[][] doubleArray8 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray16 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray22 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray28 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray34 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray41 = new double[][] { doubleArray16, doubleArray22, doubleArray28, doubleArray34, doubleArray40 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix42 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix42.transpose();
        double[][] doubleArray44 = blockRealMatrix42.getData();
        try {
            blockRealMatrix9.setRowMatrix(1684133433, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,684,133,433)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(blockRealMatrix43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "; ", "hi!");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector6.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector11.set((double) ' ');
        java.lang.String str14 = arrayRealVector11.toString();
        double[] doubleArray15 = arrayRealVector11.toArray();
        boolean boolean16 = arrayRealVector6.equals((java.lang.Object) doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str20 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        java.lang.String str27 = arrayRealVector24.toString();
        double[] doubleArray28 = arrayRealVector24.toArray();
        double[] doubleArray29 = arrayRealVector24.toArray();
        java.lang.String str30 = arrayRealVector24.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        java.lang.String str37 = arrayRealVector34.toString();
        double[] doubleArray38 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector34.copy();
        double double40 = arrayRealVector24.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector45.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector50.set((double) ' ');
        java.lang.String str53 = arrayRealVector50.toString();
        double[] doubleArray54 = arrayRealVector50.toArray();
        boolean boolean55 = arrayRealVector45.equals((java.lang.Object) doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str59 = arrayRealVector58.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector45.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector39.combine((double) (short) 0, (-1.5707963267948966d), (org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapDivide((double) 50);
        java.lang.String str65 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        java.lang.String str66 = realVectorFormat3.getSeparator();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{}" + "'", str14.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{}" + "'", str27.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{}" + "'", str53.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{}" + "'", str59.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "; " + "'", str65.equals("; "));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) (byte) 100, (double) 2147483647);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int[] intArray0 = null;
        try {
            int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        java.lang.String str19 = arrayRealVector16.toString();
        double[] doubleArray20 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector27.set((double) ' ');
        java.lang.String str30 = arrayRealVector27.toString();
        double[] doubleArray31 = arrayRealVector27.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector39.set((double) ' ');
        java.lang.String str42 = arrayRealVector39.toString();
        double[] doubleArray43 = arrayRealVector39.toArray();
        boolean boolean44 = arrayRealVector34.equals((java.lang.Object) doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str48 = arrayRealVector47.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector34.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector27.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        boolean boolean52 = arrayRealVector27.isInfinite();
        double double53 = arrayRealVector27.getL1Norm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector16.combine((double) (short) -1, (double) 100, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        try {
            org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector54.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{}" + "'", str42.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{}" + "'", str48.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector54);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        double[] doubleArray14 = null;
        try {
            double double15 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray11, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 774819465, (-0.1f), 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 0L, (double) 774819465);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence(0.17877966098643805d, 2.010811343333877d, (double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078966d + "'", double1 == 0.8414709848078966d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) (byte) 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        boolean boolean33 = array2DRowRealMatrix32.isTransposable();
        double double34 = array2DRowRealMatrix32.getNorm();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor35 = null;
        try {
            double double40 = array2DRowRealMatrix32.walkInOptimizedOrder(realMatrixPreservingVisitor35, (int) (short) 10, 0, 52, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-0.3758492992847182d), (java.lang.Number) Float.NaN, false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor27 = null;
        try {
            double double28 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) '4', (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 52, (-0.35909740519917466d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7345175425633101d + "'", double2 == 1.7345175425633101d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(9410.570796326794d, 0.7615941559557649d, (double) 0, (double) 36);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7167.035722690474d + "'", double4 == 7167.035722690474d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray33, false);
        double[] doubleArray38 = pointVectorValuePair37.getValueRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double41 = array2DRowRealMatrix39.walkInColumnOrder(realMatrixChangingVisitor40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, 100 };
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable3, (java.lang.Number) 97, objArray7);
        java.lang.Throwable[] throwableArray9 = maxCountExceededException8.getSuppressed();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) 9410.570796326794d, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.ConvergenceException convergenceException11 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(0.2788395171581284d, 50, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix(obj0, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray12 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int13 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray12);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math3.random.MersenneTwister();
        mersenneTwister14.setSeed((long) '4');
        int[] intArray21 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray28 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int29 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray21, intArray28);
        mersenneTwister14.setSeed(intArray28);
        int int31 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray28);
        try {
            int int32 = org.apache.commons.math3.util.MathArrays.distance1(intArray0, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        boolean boolean66 = array2DRowRealMatrix65.isTransposable();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = array2DRowRealMatrix15.add(array2DRowRealMatrix65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector70.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector75.set((double) ' ');
        java.lang.String str78 = arrayRealVector75.toString();
        double[] doubleArray79 = arrayRealVector75.toArray();
        boolean boolean80 = arrayRealVector70.equals((java.lang.Object) doubleArray79);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str84 = arrayRealVector83.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = arrayRealVector70.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector85.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector88);
        try {
            org.apache.commons.math3.linear.RealVector realVector90 = array2DRowRealMatrix67.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector85);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix67);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{}" + "'", str78.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "{}" + "'", str84.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector85);
        org.junit.Assert.assertNotNull(arrayRealVector89);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 7.6293945E-6f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing(univariateFunction0, (double) 0.9030187f, (double) 235552016);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) 235552016L, (-0.5872139151569291d), (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [235,552,016, -0.587]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 396021980 + "'", int8 == 396021980);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 97, (java.lang.Number) 1L, 0, orderDirection4, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 2147483647, localizable1, objArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        java.lang.String str2 = realVectorFormat1.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = realVectorFormat1.parse("; ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"; \" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector20.set((double) ' ');
        java.lang.String str23 = arrayRealVector20.toString();
        double[] doubleArray24 = arrayRealVector20.toArray();
        double[] doubleArray25 = arrayRealVector20.toArray();
        java.lang.String str26 = arrayRealVector20.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector30.set((double) ' ');
        java.lang.String str33 = arrayRealVector30.toString();
        double[] doubleArray34 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector30.copy();
        double double36 = arrayRealVector20.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        try {
            arrayRealVector20.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{}" + "'", str33.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 0.0f, 0.0d, (double) 100.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        try {
            double double7 = brentSolver3.solve((int) (short) 1, univariateFunction5, 7167.035722690474d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix31, (int) (byte) 0);
        int int34 = blockRealMatrix31.getRowDimension();
        try {
            double[] doubleArray36 = blockRealMatrix31.getColumn(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        try {
            org.apache.commons.math3.linear.RealVector realVector36 = blockRealMatrix32.getColumnVector((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        double double70 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = null;
        try {
            blockRealMatrix32.setRowMatrix(0, realMatrix72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        int int2 = bracketFinder0.getEvaluations();
        double double3 = bracketFinder0.getFHi();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((int) (byte) 1);
        int int2 = populationSize1.getPopulationSize();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        boolean boolean27 = arrayRealVector2.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        double[] doubleArray29 = arrayRealVector2.getDataRef();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex34 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray29, (double) 2575744870520794374L, 201.7156361224559d, (double) '#', (double) 396021980);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(100, (int) (short) 10);
        int[] intArray3 = null;
        int[] intArray8 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray15 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int16 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray8, intArray15);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, intArray3, intArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 52, 36, 5, 1684133433 };
        java.lang.Integer[] intArray5 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException6 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.add(blockRealMatrix35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor19 = null;
        try {
            double double20 = arrayRealVector17.walkInOptimizedOrder(realVectorChangingVisitor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker7 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver8 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double9 = brentSolver8.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver8, preconditioner10);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker12 = nonLinearConjugateGradientOptimizer11.getConvergenceChecker();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 9410.570796326794d, (-0.9999999999999999d), 0.8414709848078965d, pointValuePairConvergenceChecker12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-6d + "'", double9 == 1.0E-6d);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 0.7615941559557649d, (double) (short) 1, (double) 10L, 1.0d, (java.lang.Object[]) doubleArray7);
        double double9 = noBracketingException8.getLo();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7615941559557649d + "'", double9 == 0.7615941559557649d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "; ", "hi!");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector6.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector11.set((double) ' ');
        java.lang.String str14 = arrayRealVector11.toString();
        double[] doubleArray15 = arrayRealVector11.toArray();
        boolean boolean16 = arrayRealVector6.equals((java.lang.Object) doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str20 = arrayRealVector19.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        java.lang.String str27 = arrayRealVector24.toString();
        double[] doubleArray28 = arrayRealVector24.toArray();
        double[] doubleArray29 = arrayRealVector24.toArray();
        java.lang.String str30 = arrayRealVector24.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        java.lang.String str37 = arrayRealVector34.toString();
        double[] doubleArray38 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector34.copy();
        double double40 = arrayRealVector24.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector45.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector50.set((double) ' ');
        java.lang.String str53 = arrayRealVector50.toString();
        double[] doubleArray54 = arrayRealVector50.toArray();
        boolean boolean55 = arrayRealVector45.equals((java.lang.Object) doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str59 = arrayRealVector58.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = arrayRealVector45.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector39.combine((double) (short) 0, (-1.5707963267948966d), (org.apache.commons.math3.linear.RealVector) arrayRealVector61);
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapDivide((double) 50);
        java.lang.String str65 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        org.apache.commons.math3.linear.RealVector realVector66 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix67 = arrayRealVector62.outerProduct(realVector66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{}" + "'", str14.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{}" + "'", str20.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{}" + "'", str27.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{}" + "'", str53.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{}" + "'", str59.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector60);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "; " + "'", str65.equals("; "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        boolean boolean27 = arrayRealVector2.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector28 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector2.projection(realVector28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((-0.6321205588285577d), 0.0d, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 396021980, (double) 0L, 50);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        java.lang.String str37 = arrayRealVector34.toString();
        double[] doubleArray38 = arrayRealVector34.toArray();
        boolean boolean39 = arrayRealVector29.equals((java.lang.Object) doubleArray38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str43 = arrayRealVector42.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector29.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector47.set((double) ' ');
        java.lang.String str50 = arrayRealVector47.toString();
        double[] doubleArray51 = arrayRealVector47.toArray();
        double[] doubleArray52 = arrayRealVector47.toArray();
        java.lang.String str53 = arrayRealVector47.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector57.set((double) ' ');
        java.lang.String str60 = arrayRealVector57.toString();
        double[] doubleArray61 = arrayRealVector57.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.copy();
        double double63 = arrayRealVector47.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double double64 = arrayRealVector26.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        java.lang.String str68 = arrayRealVector67.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector26.append(arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector69.copy();
        try {
            arrayRealVector70.addToEntry(0, (double) 3.8146973E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{}" + "'", str50.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{}" + "'", str53.equals("{}"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{}" + "'", str60.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{}" + "'", str68.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(36);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        double double2 = bracketFinder0.getLo();
        double double3 = bracketFinder0.getFMid();
        double double4 = bracketFinder0.getHi();
        int int5 = bracketFinder0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 50 + "'", int5 == 50);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector24.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        java.lang.String str32 = arrayRealVector29.toString();
        double[] doubleArray33 = arrayRealVector29.toArray();
        boolean boolean34 = arrayRealVector24.equals((java.lang.Object) doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray33, false);
        double[] doubleArray38 = pointVectorValuePair37.getValueRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        try {
            double double40 = array2DRowRealMatrix39.getFrobeniusNorm();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 10L, 1.0d, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getStartValue();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = brentOptimizer3.getGoalType();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(goalType5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector73.set((double) ' ');
        try {
            blockRealMatrix69.setColumnVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(36, 52);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) 'a');
        incrementor1.setMaximalCount((int) (byte) -1);
        int int4 = incrementor1.getCount();
        int int5 = incrementor1.getCount();
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor32 = null;
        try {
            double double37 = blockRealMatrix31.walkInRowOrder(realMatrixPreservingVisitor32, (int) ' ', 52, 235552016, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        java.lang.String str19 = arrayRealVector16.toString();
        double[] doubleArray20 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapAdd((double) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector27.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector32.set((double) ' ');
        java.lang.String str35 = arrayRealVector32.toString();
        double[] doubleArray36 = arrayRealVector32.toArray();
        boolean boolean37 = arrayRealVector27.equals((java.lang.Object) doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector40.set((double) ' ');
        java.lang.String str43 = arrayRealVector40.toString();
        double[] doubleArray44 = arrayRealVector40.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.copy();
        double double46 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector22.append(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector52.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector57.set((double) ' ');
        java.lang.String str60 = arrayRealVector57.toString();
        double[] doubleArray61 = arrayRealVector57.toArray();
        boolean boolean62 = arrayRealVector52.equals((java.lang.Object) doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector65.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector70.set((double) ' ');
        java.lang.String str73 = arrayRealVector70.toString();
        double[] doubleArray74 = arrayRealVector70.toArray();
        boolean boolean75 = arrayRealVector65.equals((java.lang.Object) doubleArray74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str79 = arrayRealVector78.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = arrayRealVector65.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector83.set((double) ' ');
        java.lang.String str86 = arrayRealVector83.toString();
        double[] doubleArray87 = arrayRealVector83.toArray();
        double[] doubleArray88 = arrayRealVector83.toArray();
        java.lang.String str89 = arrayRealVector83.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector65, arrayRealVector83);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector52, arrayRealVector90);
        org.apache.commons.math3.linear.RealVector realVector93 = arrayRealVector52.mapSubtract((double) (byte) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = arrayRealVector27.combine(1.0E200d, (double) 100L, (org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{}" + "'", str35.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{}" + "'", str60.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "{}" + "'", str73.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{}" + "'", str79.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector80);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "{}" + "'", str86.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "{}" + "'", str89.equals("{}"));
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertNotNull(arrayRealVector94);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.8414709848078965d, Double.NaN, (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = simpleVectorValueChecker3.getClass();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker6);
        int int8 = levenbergMarquardtOptimizer7.getIterations();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(pointVectorValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        java.lang.String str12 = arrayRealVector9.toString();
        double[] doubleArray13 = arrayRealVector9.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector21.set((double) ' ');
        java.lang.String str24 = arrayRealVector21.toString();
        double[] doubleArray25 = arrayRealVector21.toArray();
        boolean boolean26 = arrayRealVector16.equals((java.lang.Object) doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str30 = arrayRealVector29.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector16.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double34 = arrayRealVector9.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.combineToSelf(12591.931263079863d, (double) 10.0f, (org.apache.commons.math3.linear.RealVector) arrayRealVector9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{}" + "'", str12.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{}" + "'", str24.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 12772.715729496098d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) Float.NaN, 1.3043045862358962d, (-0.6321205588285577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 35, 10, 1, 52, 50, 50 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray7);
        try {
            int int10 = multiDimensionMismatchException8.getExpectedDimension((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        float float2 = org.apache.commons.math3.util.FastMath.min(1.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(1.7345175425633101d, 1684133433);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 0, 4.9E-324d, 5.5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.8414709848078965d, Double.NaN, (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = simpleVectorValueChecker3.getClass();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getUpperBound();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker8 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(pointVectorValuePairConvergenceChecker8);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        try {
            double[] doubleArray71 = blockRealMatrix32.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor67 = null;
        try {
            double double72 = array2DRowRealMatrix31.walkInRowOrder(realMatrixPreservingVisitor67, 100, (int) '#', 50, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(7.6293945E-6f, (float) 235552016L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.2788395171581284d, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2788395171581284d + "'", double2 == 0.2788395171581284d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 0, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(1.1102230246251565E-16d, (double) 5, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getStartValue();
        double double2 = brentSolver0.getRelativeAccuracy();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        try {
            double double8 = brentSolver0.solve(35, univariateFunction4, (double) 774819465, (double) 2147483647, (double) 1684133433);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.054843730427087234d, 3.1622776601683795d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6256400572219838d + "'", double3 == 1.6256400572219838d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        double[] doubleArray6 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray12 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray18 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray24 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray30 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray31 = new double[][] { doubleArray6, doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix32.transpose();
        java.lang.String str34 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix32);
        double[] doubleArray40 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray46 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray52 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray58 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray64 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray65 = new double[][] { doubleArray40, doubleArray46, doubleArray52, doubleArray58, doubleArray64 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix66 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray65);
        double[][] doubleArray67 = blockRealMatrix66.getData();
        double double68 = blockRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix32.subtract(blockRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector73.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector78.set((double) ' ');
        java.lang.String str81 = arrayRealVector78.toString();
        double[] doubleArray82 = arrayRealVector78.toArray();
        boolean boolean83 = arrayRealVector73.equals((java.lang.Object) doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str87 = arrayRealVector86.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector73.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector91.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector88, arrayRealVector91);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector88, true);
        try {
            blockRealMatrix66.setRowVector((int) (byte) 10, (org.apache.commons.math3.linear.RealVector) arrayRealVector88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}" + "'", str34.equals("{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}"));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertEquals((double) double68, Double.NaN, 0);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "{}" + "'", str81.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "{}" + "'", str87.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector88);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray53 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray53);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53);
        double[] doubleArray60 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double61 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray60);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray55, doubleArray62);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = array2DRowRealMatrix48.subtract(array2DRowRealMatrix64);
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = array2DRowRealMatrix48.scalarAdd(113.59577456930342d);
        try {
            org.apache.commons.math3.linear.RealVector realVector70 = array2DRowRealMatrix48.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 113.59577456930342d + "'", double54 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 113.59577456930342d + "'", double61 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix65);
        org.junit.Assert.assertNotNull(realMatrix68);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 0, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.7615941559557649d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.8414709848078965d, Double.NaN, (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = simpleVectorValueChecker3.getClass();
        double[] doubleArray10 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray17 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray12, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double26 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray20, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector30.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector35.set((double) ' ');
        java.lang.String str38 = arrayRealVector35.toString();
        double[] doubleArray39 = arrayRealVector35.toArray();
        boolean boolean40 = arrayRealVector30.equals((java.lang.Object) doubleArray39);
        org.apache.commons.math3.optim.nonlinear.vector.Target target41 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray39);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray39, false);
        double[] doubleArray44 = pointVectorValuePair43.getKey();
        double[] doubleArray49 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray56 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double57 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray56);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray51, doubleArray58);
        double[] doubleArray64 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double65 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray59, doubleArray64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector69.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector74.set((double) ' ');
        java.lang.String str77 = arrayRealVector74.toString();
        double[] doubleArray78 = arrayRealVector74.toArray();
        boolean boolean79 = arrayRealVector69.equals((java.lang.Object) doubleArray78);
        org.apache.commons.math3.optim.nonlinear.vector.Target target80 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray78);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray64, doubleArray78, false);
        double[] doubleArray83 = pointVectorValuePair82.getValueRef();
        boolean boolean84 = simpleVectorValueChecker3.converged(2147483647, pointVectorValuePair43, pointVectorValuePair82);
        double[] doubleArray85 = pointVectorValuePair43.getValueRef();
        double[] doubleArray86 = pointVectorValuePair43.getPointRef();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 113.59577456930342d + "'", double11 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 113.59577456930342d + "'", double18 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 113.59577456930342d + "'", double26 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 12771.287977571159d + "'", double27 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{}" + "'", str38.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 113.59577456930342d + "'", double50 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 113.59577456930342d + "'", double57 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 113.59577456930342d + "'", double65 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 12771.287977571159d + "'", double66 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{}" + "'", str77.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        java.lang.String str5 = arrayRealVector2.toString();
        double[] doubleArray6 = arrayRealVector2.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector14.set((double) ' ');
        java.lang.String str17 = arrayRealVector14.toString();
        double[] doubleArray18 = arrayRealVector14.toArray();
        boolean boolean19 = arrayRealVector9.equals((java.lang.Object) doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str23 = arrayRealVector22.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector9.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector29.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector34.set((double) ' ');
        java.lang.String str37 = arrayRealVector34.toString();
        double[] doubleArray38 = arrayRealVector34.toArray();
        boolean boolean39 = arrayRealVector29.equals((java.lang.Object) doubleArray38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str43 = arrayRealVector42.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector29.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector47.set((double) ' ');
        java.lang.String str50 = arrayRealVector47.toString();
        double[] doubleArray51 = arrayRealVector47.toArray();
        double[] doubleArray52 = arrayRealVector47.toArray();
        java.lang.String str53 = arrayRealVector47.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector57.set((double) ' ');
        java.lang.String str60 = arrayRealVector57.toString();
        double[] doubleArray61 = arrayRealVector57.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector57.copy();
        double double63 = arrayRealVector47.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double double64 = arrayRealVector26.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        java.lang.String str68 = arrayRealVector67.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector26.append(arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector69.copy();
        try {
            org.apache.commons.math3.linear.RealVector realVector73 = arrayRealVector70.getSubVector((int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{}" + "'", str5.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{}" + "'", str50.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{}" + "'", str53.equals("{}"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "{}" + "'", str60.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{}" + "'", str68.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray7 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray13 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray19 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray25 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray31 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray32 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) doubleArray32);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        org.apache.commons.math3.linear.RealVector realVector34 = blockRealMatrix32.getRowVector(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix32.getColumnMatrix((int) (byte) 0);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor37 = null;
        try {
            double double42 = blockRealMatrix32.walkInRowOrder(realMatrixPreservingVisitor37, 396021980, (int) (short) -1, 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (396,021,980)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 0, (int) '#', (double) (byte) 0);
        int int4 = nonSymmetricMatrixException3.getColumn();
        int int5 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        java.lang.String str19 = arrayRealVector16.toString();
        double[] doubleArray20 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapAdd((double) 'a');
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = realVector24.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            array2DRowRealMatrix15.multiplyEntry(774819465, (int) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (774,819,465)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double20 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray19);
        double[] doubleArray26 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double27 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray26);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26);
        double[] doubleArray33 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double34 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray33);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray28, doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector39.set((double) ' ');
        java.lang.String str42 = arrayRealVector39.toString();
        double[] doubleArray43 = arrayRealVector39.toArray();
        double[] doubleArray44 = arrayRealVector39.toArray();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds45 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray44);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma46 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray44);
        try {
            double double47 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray19, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.59577456930342d + "'", double20 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 12771.287977571159d + "'", double21 == 12771.287977571159d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 113.59577456930342d + "'", double27 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 113.59577456930342d + "'", double34 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{}" + "'", str42.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 3.8146973E-6f, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.814697265625E-6d + "'", double2 == 3.814697265625E-6d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, 1684133433);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer3 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 10L, 1.0d, univariatePointValuePairConvergenceChecker2);
        double double4 = brentOptimizer3.getMax();
        double double5 = brentOptimizer3.getMax();
        int int6 = brentOptimizer3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector4.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector9.set((double) ' ');
        java.lang.String str12 = arrayRealVector9.toString();
        double[] doubleArray13 = arrayRealVector9.toArray();
        boolean boolean14 = arrayRealVector4.equals((java.lang.Object) doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str18 = arrayRealVector17.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector4.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector19.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        double double24 = arrayRealVector1.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double double25 = arrayRealVector1.getLInfNorm();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{}" + "'", str12.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "{}" + "'", str18.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathIllegalStateException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        long[][] longArray0 = new long[][] {};
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray0);
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double6 = brentSolver5.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner7 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5, preconditioner7);
        double double9 = simpleValueChecker4.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction13 = null;
        try {
            double double17 = brentSolver10.solve(0, univariateFunction13, (double) (byte) -1, (double) 0.0f, 12771.28797757116d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-6d + "'", double6 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 100L, (float) 93740670);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble(12771.287977571157d, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix15.copy();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector23.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector28.set((double) ' ');
        java.lang.String str31 = arrayRealVector28.toString();
        double[] doubleArray32 = arrayRealVector28.toArray();
        boolean boolean33 = arrayRealVector23.equals((java.lang.Object) doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str37 = arrayRealVector36.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector23.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector38.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        double double43 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        try {
            array2DRowRealMatrix15.setRowVector(100, (org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{10.0},{112.7120224288},{10.0},{0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{10.0},{112.7120224288},{10.0},{0.0}}"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{}" + "'", str31.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertNotNull(arrayRealVector42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector3.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector8.set((double) ' ');
        java.lang.String str11 = arrayRealVector8.toString();
        double[] doubleArray12 = arrayRealVector8.toArray();
        boolean boolean13 = arrayRealVector3.equals((java.lang.Object) doubleArray12);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray12);
        double[] doubleArray15 = sigma14.getSigma();
        org.apache.commons.math3.util.MathArrays.scaleInPlace(0.6483608274590866d, doubleArray15);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{}" + "'", str11.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        double double34 = lUDecomposition33.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = lUDecomposition33.getP();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(realMatrix35);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        double[] doubleArray18 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray11, doubleArray20, false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 113.59577456930342d + "'", double19 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        double[] doubleArray37 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double38 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray37);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray39, doubleArray46);
        double[] doubleArray52 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double53 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray52);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52);
        double[] doubleArray59 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray54, doubleArray61);
        double[] doubleArray67 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double68 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray62);
        double[] doubleArray71 = array2DRowRealMatrix31.preMultiply(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector74.set((double) ' ');
        java.lang.String str77 = arrayRealVector74.toString();
        double[] doubleArray78 = arrayRealVector74.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector81.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector86.set((double) ' ');
        java.lang.String str89 = arrayRealVector86.toString();
        double[] doubleArray90 = arrayRealVector86.toArray();
        boolean boolean91 = arrayRealVector81.equals((java.lang.Object) doubleArray90);
        double double92 = org.apache.commons.math3.util.MathArrays.distance(doubleArray78, doubleArray90);
        org.apache.commons.math3.optim.PointValuePair pointValuePair94 = new org.apache.commons.math3.optim.PointValuePair(doubleArray78, (double) 2147483647);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair95 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray70, doubleArray78);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex96 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 113.59577456930342d + "'", double38 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 113.59577456930342d + "'", double53 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 113.59577456930342d + "'", double60 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 113.59577456930342d + "'", double68 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 12771.287977571159d + "'", double69 == 12771.287977571159d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{}" + "'", str77.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "{}" + "'", str89.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        double[] doubleArray7 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double8 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray7);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7);
        double[] doubleArray14 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double15 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray14);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray9, doubleArray16);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray23 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double24 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray23);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        double[] doubleArray30 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double31 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray30);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray25, doubleArray32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = array2DRowRealMatrix18.subtract(array2DRowRealMatrix34);
        boolean boolean36 = array2DRowRealMatrix35.isTransposable();
        double double37 = array2DRowRealMatrix35.getNorm();
        double[] doubleArray42 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double43 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42);
        double[] doubleArray49 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray44, doubleArray51);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        double[] doubleArray58 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double59 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray58);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58);
        double[] doubleArray65 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double66 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray65);
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray60, doubleArray67);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = array2DRowRealMatrix53.subtract(array2DRowRealMatrix69);
        boolean boolean71 = array2DRowRealMatrix70.isTransposable();
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix35, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix70);
        java.lang.String str73 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix35);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor74 = null;
        try {
            double double75 = array2DRowRealMatrix35.walkInRowOrder(realMatrixChangingVisitor74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 113.59577456930342d + "'", double8 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 113.59577456930342d + "'", double15 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 113.59577456930342d + "'", double24 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 113.59577456930342d + "'", double31 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 113.59577456930342d + "'", double43 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 113.59577456930342d + "'", double50 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 113.59577456930342d + "'", double59 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 113.59577456930342d + "'", double66 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "{{0},{0},{0},{0}}" + "'", str73.equals("{{0},{0},{0},{0}}"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray6 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double7 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray6);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6);
        double[] doubleArray13 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray15);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[] doubleArray22 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double23 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray22);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22);
        double[] doubleArray29 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray31);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix17.subtract(array2DRowRealMatrix33);
        double[][] doubleArray35 = array2DRowRealMatrix17.getData();
        org.apache.commons.math3.exception.ZeroException zeroException36 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray35);
        org.apache.commons.math3.exception.MathInternalError mathInternalError37 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 113.59577456930342d + "'", double7 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 113.59577456930342d + "'", double14 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 113.59577456930342d + "'", double23 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 113.59577456930342d + "'", double30 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3);
        double[] doubleArray5 = nonLinearConjugateGradientOptimizer4.getUpperBound();
        int int6 = nonLinearConjugateGradientOptimizer4.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector20.set((double) ' ');
        java.lang.String str23 = arrayRealVector20.toString();
        double[] doubleArray24 = arrayRealVector20.toArray();
        double[] doubleArray25 = arrayRealVector20.toArray();
        java.lang.String str26 = arrayRealVector20.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector20);
        int int28 = arrayRealVector20.getMinIndex();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat(",", ",", "{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}", "}", "{", "");
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray18 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray13, doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray34 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double35 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray34);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray29, doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = array2DRowRealMatrix22.subtract(array2DRowRealMatrix38);
        double[] doubleArray44 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double45 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray44);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44);
        double[] doubleArray51 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double52 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray51);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray46, doubleArray53);
        double[] doubleArray59 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double60 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray59);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59);
        double[] doubleArray66 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double67 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray66);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray61, doubleArray68);
        double[] doubleArray74 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double75 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray69, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray53, doubleArray69);
        double[] doubleArray78 = array2DRowRealMatrix38.preMultiply(doubleArray77);
        java.lang.String str79 = realMatrixFormat6.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix38);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition81 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix38, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (4x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 113.59577456930342d + "'", double19 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 113.59577456930342d + "'", double35 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 113.59577456930342d + "'", double45 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 113.59577456930342d + "'", double52 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 113.59577456930342d + "'", double60 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 113.59577456930342d + "'", double67 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 113.59577456930342d + "'", double75 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 12771.287977571159d + "'", double76 == 12771.287977571159d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + ",{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}10}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}112.7120224288}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}10}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}0}," + "'", str79.equals(",{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}10}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}112.7120224288}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}10}{{{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)},{97,0,0,100,(NaN)}}0},"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(1.5430806348152437d, (double) (short) -1, 0.0d, 1.0d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector16.set((double) ' ');
        java.lang.String str19 = arrayRealVector16.toString();
        double[] doubleArray20 = arrayRealVector16.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector16.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapAdd((double) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector27.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector32.set((double) ' ');
        java.lang.String str35 = arrayRealVector32.toString();
        double[] doubleArray36 = arrayRealVector32.toArray();
        boolean boolean37 = arrayRealVector27.equals((java.lang.Object) doubleArray36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector40.set((double) ' ');
        java.lang.String str43 = arrayRealVector40.toString();
        double[] doubleArray44 = arrayRealVector40.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector40.copy();
        double double46 = arrayRealVector27.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector22.append(arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector49 = arrayRealVector47.append((-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "{}" + "'", str35.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{}" + "'", str43.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(realVector49);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 1.1920929E-7f, 1.3043045862358962d, (double) '4', 12772.715729496098d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = powellOptimizer4.getConvergenceChecker();
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100, (double) 'a', 7.74819465E8d, 201.7156361224559d);
        double[] doubleArray5 = null;
        try {
            multiDirectionalSimplex4.build(doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 10.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double5 = brentSolver4.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner6 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4, preconditioner6);
        double[] doubleArray13 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray15, doubleArray22);
        org.apache.commons.math3.optim.PointValuePair pointValuePair26 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, 0.0d, true);
        double[] doubleArray31 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double32 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray31);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31);
        double[] doubleArray38 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double39 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray38);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray33, doubleArray40);
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, 0.0d, true);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat45 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        boolean boolean46 = pointValuePair44.equals((java.lang.Object) realMatrixFormat45);
        boolean boolean47 = simpleValueChecker3.converged((int) (byte) 1, pointValuePair26, pointValuePair44);
        double[] doubleArray48 = pointValuePair44.getPoint();
        double[] doubleArray49 = pointValuePair44.getFirst();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 113.59577456930342d + "'", double14 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 113.59577456930342d + "'", double32 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 113.59577456930342d + "'", double39 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrixFormat45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix31.scalarMultiply((double) 0);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula36 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker39 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver40 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double41 = brentSolver40.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner42 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer43 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula36, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker39, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver40, preconditioner42);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker44 = nonLinearConjugateGradientOptimizer43.getConvergenceChecker();
        boolean boolean45 = blockRealMatrix31.equals((java.lang.Object) pointValuePairConvergenceChecker44);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor46 = null;
        try {
            double double47 = blockRealMatrix31.walkInOptimizedOrder(realMatrixPreservingVisitor46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0E-6d + "'", double41 == 1.0E-6d);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        mersenneTwister0.setSeed((long) '4');
        int[] intArray7 = new int[] { (byte) 0, (byte) 1, (byte) 100, 0 };
        int[] intArray14 = new int[] { 100, 10, (byte) 1, 100, 0, (byte) 10 };
        int int15 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray14);
        mersenneTwister0.setSeed(intArray14);
        mersenneTwister0.clear();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        double[][] doubleArray32 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition33 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix31);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = lUDecomposition33.getU();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver35 = lUDecomposition33.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = lUDecomposition33.getL();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNull(realMatrix34);
        org.junit.Assert.assertNotNull(decompositionSolver35);
        org.junit.Assert.assertNull(realMatrix36);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 2575744870520794374L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 61 + "'", int1 == 61);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double[] doubleArray4 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray6, doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray20 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double21 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray22, doubleArray29);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix15.subtract(array2DRowRealMatrix31);
        boolean boolean33 = array2DRowRealMatrix32.isTransposable();
        int int34 = array2DRowRealMatrix32.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor35 = null;
        try {
            double double40 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixPreservingVisitor35, (int) (short) 1, 6, (int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 113.59577456930342d + "'", double5 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 113.59577456930342d + "'", double12 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 113.59577456930342d + "'", double21 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 113.59577456930342d + "'", double28 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.8414709848078965d, Double.NaN, (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = simpleVectorValueChecker3.getClass();
        double[] doubleArray10 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double11 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray10);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        double[] doubleArray17 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray12, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double26 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray20, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector30.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector35.set((double) ' ');
        java.lang.String str38 = arrayRealVector35.toString();
        double[] doubleArray39 = arrayRealVector35.toArray();
        boolean boolean40 = arrayRealVector30.equals((java.lang.Object) doubleArray39);
        org.apache.commons.math3.optim.nonlinear.vector.Target target41 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray39);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray39, false);
        double[] doubleArray44 = pointVectorValuePair43.getKey();
        double[] doubleArray49 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray49);
        double[] doubleArray56 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double57 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray56);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray51, doubleArray58);
        double[] doubleArray64 = new double[] { (short) 10, 112.71202242884297d, 10, (short) 0 };
        double double65 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray59, doubleArray64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector69.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector74.set((double) ' ');
        java.lang.String str77 = arrayRealVector74.toString();
        double[] doubleArray78 = arrayRealVector74.toArray();
        boolean boolean79 = arrayRealVector69.equals((java.lang.Object) doubleArray78);
        org.apache.commons.math3.optim.nonlinear.vector.Target target80 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray78);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray64, doubleArray78, false);
        double[] doubleArray83 = pointVectorValuePair82.getValueRef();
        boolean boolean84 = simpleVectorValueChecker3.converged(2147483647, pointVectorValuePair43, pointVectorValuePair82);
        double[] doubleArray85 = pointVectorValuePair43.getValueRef();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex86 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray85);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 113.59577456930342d + "'", double11 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 113.59577456930342d + "'", double18 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 113.59577456930342d + "'", double26 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 12771.287977571159d + "'", double27 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{}" + "'", str38.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 113.59577456930342d + "'", double50 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 113.59577456930342d + "'", double57 == 113.59577456930342d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 113.59577456930342d + "'", double65 == 113.59577456930342d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 12771.287977571159d + "'", double66 == 12771.287977571159d);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "{}" + "'", str77.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(doubleArray85);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector2.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector7.set((double) ' ');
        java.lang.String str10 = arrayRealVector7.toString();
        double[] doubleArray11 = arrayRealVector7.toArray();
        boolean boolean12 = arrayRealVector2.equals((java.lang.Object) doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str16 = arrayRealVector15.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector2.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector20.set((double) ' ');
        java.lang.String str23 = arrayRealVector20.toString();
        double[] doubleArray24 = arrayRealVector20.toArray();
        double[] doubleArray25 = arrayRealVector20.toArray();
        java.lang.String str26 = arrayRealVector20.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector30.set((double) ' ');
        java.lang.String str33 = arrayRealVector30.toString();
        double[] doubleArray34 = arrayRealVector30.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector37.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector42.set((double) ' ');
        java.lang.String str45 = arrayRealVector42.toString();
        double[] doubleArray46 = arrayRealVector42.toArray();
        boolean boolean47 = arrayRealVector37.equals((java.lang.Object) doubleArray46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str51 = arrayRealVector50.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector37.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector30.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector57.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector62.set((double) ' ');
        java.lang.String str65 = arrayRealVector62.toString();
        double[] doubleArray66 = arrayRealVector62.toArray();
        boolean boolean67 = arrayRealVector57.equals((java.lang.Object) doubleArray66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str71 = arrayRealVector70.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector57.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector75.set((double) ' ');
        java.lang.String str78 = arrayRealVector75.toString();
        double[] doubleArray79 = arrayRealVector75.toArray();
        double[] doubleArray80 = arrayRealVector75.toArray();
        java.lang.String str81 = arrayRealVector75.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector57, arrayRealVector75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector85.set((double) ' ');
        java.lang.String str88 = arrayRealVector85.toString();
        double[] doubleArray89 = arrayRealVector85.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = arrayRealVector85.copy();
        double double91 = arrayRealVector75.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector90);
        double double92 = arrayRealVector54.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector75);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 0);
        java.lang.String str96 = arrayRealVector95.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = arrayRealVector54.append(arrayRealVector95);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector98 = arrayRealVector27.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector95);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{}" + "'", str10.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{}" + "'", str23.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{}" + "'", str33.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{}" + "'", str45.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{}" + "'", str51.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector52);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "{}" + "'", str65.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{}" + "'", str71.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{}" + "'", str78.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "{}" + "'", str81.equals("{}"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "{}" + "'", str88.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(arrayRealVector90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "{}" + "'", str96.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector97);
        org.junit.Assert.assertNotNull(arrayRealVector98);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray5 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray11 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray17 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray23 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[] doubleArray29 = new double[] { 97, 0L, (byte) 0, 100.0d, Double.NaN };
        double[][] doubleArray30 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29 };
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix31.transpose();
        double[][] doubleArray33 = blockRealMatrix31.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix31.scalarMultiply((double) 0);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula36 = null;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker39 = new org.apache.commons.math3.optim.SimpleValueChecker(10.0d, (double) 10);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver40 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double41 = brentSolver40.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner42 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer43 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula36, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker39, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver40, preconditioner42);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker44 = nonLinearConjugateGradientOptimizer43.getConvergenceChecker();
        boolean boolean45 = blockRealMatrix31.equals((java.lang.Object) pointValuePairConvergenceChecker44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector49.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector54.set((double) ' ');
        java.lang.String str57 = arrayRealVector54.toString();
        double[] doubleArray58 = arrayRealVector54.toArray();
        boolean boolean59 = arrayRealVector49.equals((java.lang.Object) doubleArray58);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        java.lang.String str63 = arrayRealVector62.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = arrayRealVector49.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector64.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector71.set((double) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 0, (double) (short) -1);
        arrayRealVector76.set((double) ' ');
        java.lang.String str79 = arrayRealVector76.toString();
        double[] doubleArray80 = arrayRealVector76.toArray();
        boolean boolean81 = arrayRealVector71.equals((java.lang.Object) doubleArray80);
        double double82 = arrayRealVector64.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector71);
        try {
            blockRealMatrix31.setRowVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0E-6d + "'", double41 == 1.0E-6d);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{}" + "'", str57.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "{}" + "'", str63.equals("{}"));
        org.junit.Assert.assertNotNull(arrayRealVector64);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{}" + "'", str79.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 2575744870520794374L, (java.lang.Number) Double.POSITIVE_INFINITY, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException2 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) Float.NaN);
        java.lang.Throwable[] throwableArray3 = tooManyIterationsException2.getSuppressed();
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 0, (double) (-2108458431), (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) (byte) 10);
        int int2 = maxEval1.getMaxEval();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }
}

