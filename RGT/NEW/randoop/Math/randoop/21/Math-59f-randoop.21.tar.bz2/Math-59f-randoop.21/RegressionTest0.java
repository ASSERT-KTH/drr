import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1), (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.9155040003582885E22d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0975029486095565E24d + "'", double1 == 1.0975029486095565E24d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray9);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        mathIllegalArgumentException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException21);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException21);
        java.lang.String str24 = mathIllegalArgumentException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray36);
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) mathIllegalArgumentException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray47);
        mathIllegalArgumentException43.addSuppressed((java.lang.Throwable) mathIllegalArgumentException48);
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) mathIllegalArgumentException48);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException32);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray61);
        mathIllegalArgumentException57.addSuppressed((java.lang.Throwable) mathIllegalArgumentException62);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable70, objArray72);
        mathIllegalArgumentException68.addSuppressed((java.lang.Throwable) mathIllegalArgumentException73);
        mathIllegalArgumentException57.addSuppressed((java.lang.Throwable) mathIllegalArgumentException73);
        java.lang.Object[] objArray76 = new java.lang.Object[] { roundingMode27, mathRuntimeException51, (byte) 10, mathIllegalArgumentException73 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable25, localizable26, objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray76);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str24.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0975029486095565E24d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0975029486095565E24d + "'", double2 == 1.0975029486095565E24d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37293782932771496d + "'", double1 == 0.37293782932771496d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable11, localizable12, objArray16);
        java.lang.Class<?> wildcardClass19 = mathRuntimeException18.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        java.lang.String str24 = mathRuntimeException23.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str24.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 52, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5872139151569291d + "'", double1 == 0.5872139151569291d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.99739562137696d + "'", double1 == 31.99739562137696d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.0f, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 3.141592653589793d, true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable11, localizable12, objArray16);
        java.lang.Throwable[] throwableArray19 = mathIllegalArgumentException4.getSuppressed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.37293782932771496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006508993027009297d + "'", double1 == 0.006508993027009297d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.006508993027009297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1996977908);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1259.2861304356516d + "'", double1 == 1259.2861304356516d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 10, (double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.tanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.log(31.99739562137696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.465654512655669d + "'", double1 == 3.465654512655669d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.465654512655669d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.861626845706644d + "'", double1 == 1.861626845706644d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8342233605065102d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 7317830776458656096L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            boolean boolean8 = dfp5.lessThan(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 57.29577951308232d + "'", number5.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        int int6 = dfp3.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0d, Double.NaN);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0975029486095565E24d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100L, (java.lang.Number) 100.0f, true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp3.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.4649576521875536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4649576521875536d + "'", double1 == 0.4649576521875536d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + Double.POSITIVE_INFINITY + "'", number5.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32766.999999999996d) + "'", double1 == (-32766.999999999996d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0975029486095565E24d, (-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0975029486095564E24d + "'", double2 == 1.0975029486095564E24d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 3, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6, localizable13, localizable14, objArray18);
        java.lang.Object[] objArray21 = mathRuntimeException20.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray21);
        java.lang.Throwable[] throwableArray23 = mathIllegalArgumentException22.getSuppressed();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalArgumentException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math.util.FastMath.max(4.9E-324d, (double) (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5872139151569291d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5872139151569291d + "'", double2 == 0.5872139151569291d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1996977908);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.414900828725006d + "'", double1 == 21.414900828725006d);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1009305719 + "'", int1 == 1009305719);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (-32767));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathRuntimeException23.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, (float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        java.lang.String str23 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray35);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray46);
        mathIllegalArgumentException42.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException31);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray60);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable69, objArray71);
        mathIllegalArgumentException67.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { roundingMode26, mathRuntimeException50, (byte) 10, mathIllegalArgumentException72 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable24, localizable25, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable77 = mathIllegalArgumentException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str23.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNull(localizable77);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 100);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0L, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950547536867305d + "'", double1 == 0.9950547536867305d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.ulp(31.99739562137696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = dfp20.multiply(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9950547536867305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5444569635349489d + "'", double1 == 0.5444569635349489d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.ulp(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        boolean boolean13 = dfp3.lessThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 0);
        boolean boolean19 = dfp17.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.multiply(dfp17);
        int int21 = dfp20.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-8286316095047268352L) + "'", long1 == (-8286316095047268352L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp3.multiply(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(97);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 35.0f, (java.lang.Number) (-0.6321205588285577d), false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6215477523208264d) + "'", double1 == (-0.6215477523208264d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        int[] intArray4 = new int[] { 4, (-32767) };
        mersenneTwister1.setSeed(intArray4);
        boolean boolean6 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        int int17 = dfp3.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.nextAfter(dfp20);
        int int23 = dfp22.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.006508993027009297d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        boolean boolean7 = mersenneTwister6.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.141592653589793d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.floor(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray13);
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable16, localizable17, objArray21);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException23);
        java.lang.String str25 = mathRuntimeException23.toString();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str25.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        int int2 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister5.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        float float21 = mersenneTwister20.nextFloat();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.9699086f + "'", float21 == 0.9699086f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9999999999999999d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfp2.divide(dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.465654512655669d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03464268006739521d + "'", double2 == 0.03464268006739521d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-9002580193226221695L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-8286316095047268352L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.2863160950472684E18d + "'", double1 == 8.2863160950472684E18d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        java.lang.String str23 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray35);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray46);
        mathIllegalArgumentException42.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException31);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray60);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable69, objArray71);
        mathIllegalArgumentException67.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { roundingMode26, mathRuntimeException50, (byte) 10, mathIllegalArgumentException72 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable24, localizable25, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable77 = mathRuntimeException76.getSpecificPattern();
        java.lang.Object[] objArray78 = mathRuntimeException76.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str23.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNull(localizable77);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5557.690612768985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        long long12 = mersenneTwister5.nextLong();
        mersenneTwister5.setSeed(2);
        boolean boolean15 = mersenneTwister5.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7317830776458656096L + "'", long12 == 7317830776458656096L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3L);
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.06268069909038654d) + "'", double2 == (-0.06268069909038654d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        long long2 = mersenneTwister1.nextLong();
        int int3 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8286316095047268712L) + "'", long2 == (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1253495559) + "'", int3 == (-1253495559));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.String str2 = mathRuntimeException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str2.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        double[] doubleArray7 = dfp5.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfp7.divide(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-31.99967447585524d) + "'", double1 == (-31.99967447585524d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.5872139151569291d, (java.lang.Number) (byte) 100, false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5557.690612768985d + "'", number3.equals(5557.690612768985d));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        java.lang.String str23 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray35);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray46);
        mathIllegalArgumentException42.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException31);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray60);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable69, objArray71);
        mathIllegalArgumentException67.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { roundingMode26, mathRuntimeException50, (byte) 10, mathIllegalArgumentException72 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable24, localizable25, objArray75);
        java.lang.Object[] objArray77 = mathRuntimeException76.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException76);
        org.apache.commons.math.exception.util.Localizable localizable79 = mathRuntimeException76.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str23.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNull(localizable79);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.9155040003582885E22d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.ulp(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32768, (float) 1996977908);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.99697792E9f + "'", float2 == 1.99697792E9f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1253495559));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        try {
            int int3 = mersenneTwister1.nextInt((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-8286316095047268712L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.636130838093536d + "'", double1 == 43.636130838093536d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp5.remainder(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        long long11 = mersenneTwister5.nextLong();
        double double12 = mersenneTwister5.nextDouble();
        long long13 = mersenneTwister5.nextLong();
        long long14 = mersenneTwister5.nextLong();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9002580193226221695L) + "'", long11 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4649576521875536d + "'", double12 == 0.4649576521875536d);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7317830776458656096L + "'", long13 == 7317830776458656096L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4784062645013524012L + "'", long14 == 4784062645013524012L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        dfpField1.setIEEEFlagsBits((-1253495559));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        boolean boolean16 = dfp7.lessThan(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        java.lang.String str8 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.7071067811865475" + "'", str8.equals("0.7071067811865475"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        int int12 = mersenneTwister5.nextInt((int) (byte) 1);
        boolean boolean13 = mersenneTwister5.nextBoolean();
        double double14 = mersenneTwister5.nextGaussian();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.3088477688815203d) + "'", double14 == (-1.3088477688815203d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.newDfp();
        dfpField3.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField3.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray6);
        java.lang.Class<?> wildcardClass8 = mathIllegalArgumentException7.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.rint();
        int int7 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.tan(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int1 = org.apache.commons.math.util.FastMath.abs((-982170359));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 982170359 + "'", int1 == 982170359);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 4, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        int int9 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 31.99739562137696d, (java.lang.Number) (-9002580193226221695L), false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField2.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray5);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance(1.5707963267948966d);
        org.apache.commons.math.dfp.Dfp dfp16 = null;
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) 0);
        boolean boolean22 = dfp20.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = dfp13.dotrap((int) (byte) 2, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp16, dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.999999999999998d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp3.multiply(dfp14);
        java.lang.Object obj16 = null;
        boolean boolean17 = dfp3.equals(obj16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.4649576521875536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4483849496555382d + "'", double1 == 0.4483849496555382d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8390715290764524d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance(1.5707963267948966d);
        java.lang.Class<?> wildcardClass14 = dfp4.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4802620430283604E-16d + "'", double1 == 2.4802620430283604E-16d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.006508993027009297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) (-8286316095047268352L), false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister6.setSeed(8);
        long long9 = mersenneTwister6.nextLong();
        mersenneTwister6.setSeed(1009305719);
        double double12 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2334815402550860460L) + "'", long9 == (-2334815402550860460L));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9388841318430117d + "'", double12 == 0.9388841318430117d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) '#');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.3088477688815203d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        boolean boolean5 = dfp3.equals((java.lang.Object) 0.1411200080598672d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.floor();
        boolean boolean23 = dfp13.lessThan(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) 0);
        boolean boolean29 = dfp27.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp13.multiply(dfp27);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp9.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10K((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        long long6 = mersenneTwister5.nextLong();
        mersenneTwister5.setSeed(2);
        mersenneTwister5.setSeed(0L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-555087506780952317L) + "'", long6 == (-555087506780952317L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p(31.99739562137696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.496428637787754d + "'", double1 == 3.496428637787754d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn5();
        boolean boolean21 = dfp3.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = null;
        try {
            boolean boolean23 = dfp20.lessThan(dfp22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.String str11 = numberIsTooSmallException8.toString();
        java.lang.String str12 = numberIsTooSmallException8.toString();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 57.29577951308232d + "'", number9.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)" + "'", str11.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)" + "'", str12.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.ceil(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean6 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5557.690612768985d + "'", number3.equals(5557.690612768985d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        boolean boolean16 = dfp7.lessThan(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp7.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            boolean boolean9 = dfp7.greaterThan(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(1);
        int int11 = dfp8.log10K();
        double double12 = dfp8.toDouble();
        boolean boolean13 = dfp4.unequal(dfp8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.7320508075688772d + "'", double12 == 1.7320508075688772d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5872139151569291d, (java.lang.Number) (-8286316095047268712L), false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.String str6 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32768 + "'", number4.equals(32768));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 32,768 is smaller than, or equal to, the minimum (10)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 32,768 is smaller than, or equal to, the minimum (10)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        long long6 = mersenneTwister5.nextLong();
        boolean boolean7 = mersenneTwister5.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-555087506780952317L) + "'", long6 == (-555087506780952317L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(8.2863160950472684E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4462349871957424E17d + "'", double1 == 1.4462349871957424E17d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfp7.subtract(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        long long2 = org.apache.commons.math.util.FastMath.max(4L, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.868335738447959d) + "'", double1 == (-3.868335738447959d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.0f, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + Double.POSITIVE_INFINITY + "'", number5.equals(Double.POSITIVE_INFINITY));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + Double.POSITIVE_INFINITY + "'", number6.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.7320508075688772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1462158347805889d + "'", double1 == 1.1462158347805889d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10(0);
        boolean boolean18 = dfp7.greaterThan(dfp15);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance((long) 8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField22.newDfp(10.0d);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        dfpField32.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField32.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField32.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField32.getOne();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp30.subtract(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.newInstance(dfp40);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        java.lang.String str10 = dfp9.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0000000000000e97" + "'", str10.equals("1.0000000000000e97"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.4802620430283604E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.605502432952306d) + "'", double1 == (-15.605502432952306d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        boolean boolean12 = dfp10.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0975029486095564E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.288228695849086E25d + "'", double1 == 6.288228695849086E25d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        long long11 = mersenneTwister5.nextLong();
        int int12 = mersenneTwister5.nextInt();
        int int13 = mersenneTwister5.nextInt();
        int int14 = mersenneTwister5.nextInt();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9002580193226221695L) + "'", long11 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1996977908 + "'", int12 == 1996977908);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-659647536) + "'", int13 == (-659647536));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1703815249 + "'", int14 == 1703815249);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        double double12 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.3967004095459796d + "'", double12 == 0.3967004095459796d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.asinh(21.414900828725006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7577788552427434d + "'", double1 == 3.7577788552427434d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.getTwo();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.power10(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        long long11 = mersenneTwister5.nextLong();
        double double12 = mersenneTwister5.nextDouble();
        int int14 = mersenneTwister5.nextInt((int) (byte) 2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9002580193226221695L) + "'", long11 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4649576521875536d + "'", double12 == 0.4649576521875536d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        int int8 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("1.0000000000000e97");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((double) 0.5156107f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float2 = org.apache.commons.math.util.FastMath.min(0.5156107f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10.0f, (-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.11512370958611d + "'", double2 == 2.11512370958611d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1415888721402332d + "'", double1 == 0.1415888721402332d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, (-1.0000679992263888d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.tanh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.5156107f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.515610694885254d + "'", double2 == 0.515610694885254d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister5.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        double double21 = mersenneTwister20.nextDouble();
        float float22 = mersenneTwister20.nextFloat();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9699086474175624d + "'", double21 == 0.9699086474175624d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0655607f + "'", float22 == 0.0655607f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6532914227998379d + "'", double0 == 0.6532914227998379d);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347994d + "'", double1 == 1.7160033436347994d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.0f, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable13, localizable14, objArray15);
        boolean boolean17 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        int int10 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        dfpField9.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.newInstance(dfp15);
        int int17 = dfp16.log10();
        int int18 = dfp16.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K(13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.cosh(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getOne();
        int int11 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getZero();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.floor();
        boolean boolean33 = dfp23.lessThan(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-1));
        int int36 = dfpField35.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getPi();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp17.dotrap((-32767), "", dfp32, dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp9.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp40 = new org.apache.commons.math.dfp.Dfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("2.");
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getE();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getOne();
        int int52 = dfp50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.getTwo();
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.Dfp.copysign(dfp47, dfp53);
        int int55 = dfp47.intValue();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.sqrt();
        java.lang.String str57 = dfp47.toString();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp40.nextAfter(dfp47);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp6.multiply(dfp40);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2.718281828459" + "'", str57.equals("2.718281828459"));
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', 1703815249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1703815249 + "'", int2 == 1703815249);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.ceil();
        double[] doubleArray7 = dfp6.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4483849496555382d, (-32766.999999999996d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4483849496555382d + "'", double2 == 0.4483849496555382d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5156107f, (java.lang.Number) (-4), true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        int int7 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0.0655607f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1833564279343307d) + "'", double1 == (-1.1833564279343307d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        double double5 = dfp3.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.609437912434d + "'", double5 == 1.609437912434d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.11512370958611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1291563043683344d + "'", double1 == 1.1291563043683344d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.2340874536277584d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        long long11 = mersenneTwister5.nextLong();
        int int12 = mersenneTwister5.nextInt();
        int int13 = mersenneTwister5.nextInt();
        mersenneTwister5.setSeed(52);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9002580193226221695L) + "'", long11 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1996977908 + "'", int12 == 1996977908);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-659647536) + "'", int13 == (-659647536));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextDouble();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        byte[] byteArray21 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister17.nextBytes(byteArray21);
        mersenneTwister5.nextBytes(byteArray21);
        int int24 = mersenneTwister5.nextInt();
        long long25 = mersenneTwister5.nextLong();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5119691500896333d + "'", double11 == 0.5119691500896333d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-659647536) + "'", int24 == (-659647536));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 7317830776458656096L + "'", long25 == 7317830776458656096L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        boolean boolean13 = dfp3.lessThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 0);
        boolean boolean19 = dfp17.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.getOne();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.divide(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0.0655607f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        int int17 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.1415888721402332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1521028895607049d + "'", double1 == 0.1521028895607049d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(1L);
        boolean boolean9 = dfp8.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getOne();
        int int22 = dfp20.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.getTwo();
        double double24 = dfp23.toDouble();
        double[] doubleArray25 = dfp23.toSplitDouble();
        boolean boolean26 = dfp16.greaterThan(dfp23);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfp2.remainder(dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.atan(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570765801764381d + "'", double1 == 1.570765801764381d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass4 = dfpField1.getClass();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', 1703815249);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1703815249 + "'", int2 == 1703815249);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0947125472611012d + "'", double1 == 2.0947125472611012d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.3088477688815203d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister6.setSeed(8);
        long long9 = mersenneTwister6.nextLong();
        int int11 = mersenneTwister6.nextInt(1009305719);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2334815402550860460L) + "'", long9 == (-2334815402550860460L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 938625009 + "'", int11 == 938625009);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        int int12 = dfp4.intValue();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance(dfp19);
        boolean boolean22 = dfp20.equals((java.lang.Object) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp20);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52, (java.lang.Number) 16, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        long long11 = mersenneTwister5.nextLong();
        int int12 = mersenneTwister5.nextInt();
        int int13 = mersenneTwister5.nextInt();
        double double14 = mersenneTwister5.nextDouble();
        int int16 = mersenneTwister5.nextInt(32760);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9002580193226221695L) + "'", long11 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1996977908 + "'", int12 == 1996977908);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-659647536) + "'", int13 == (-659647536));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.3967004095459796d + "'", double14 == 0.3967004095459796d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 26528 + "'", int16 == 26528);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1703815249);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7038153E9f + "'", float1 == 1.7038153E9f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        int int12 = mersenneTwister5.nextInt((int) (byte) 1);
        double double13 = mersenneTwister5.nextGaussian();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.3442572939312747d + "'", double13 == 0.3442572939312747d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 2, (long) (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        int int18 = dfp17.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.0000679992263888d), 9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.10119467660239159d) + "'", double2 == (-0.10119467660239159d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1.0000679992263888d), number2, false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        long long2 = mersenneTwister1.nextLong();
        int[] intArray7 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        byte[] byteArray12 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister8.nextBytes(byteArray12);
        double double14 = mersenneTwister8.nextGaussian();
        int[] intArray19 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        mersenneTwister8.setSeed(intArray19);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        org.apache.commons.math.random.MersenneTwister mersenneTwister24 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        mersenneTwister1.setSeed(intArray19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8286316095047268712L) + "'", long2 == (-8286316095047268712L));
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.2340874536277584d) + "'", double14 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        long long2 = org.apache.commons.math.util.FastMath.max(7317830776458656096L, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7317830776458656096L + "'", long2 == 7317830776458656096L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9092974268256817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6467353350307651d + "'", double1 == 0.6467353350307651d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 100, (long) (-129241382));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-129241382L) + "'", long2 == (-129241382L));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9330920755982086d + "'", double1 == 0.9330920755982086d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.288228695849086E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp3.multiply(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance(2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.floor();
        boolean boolean13 = dfp3.lessThan(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 0);
        boolean boolean19 = dfp17.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.getOne();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        dfpField30.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.newDfp(0.8342233605065102d);
        boolean boolean37 = dfp26.unequal(dfp36);
        boolean boolean38 = dfp17.greaterThan(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int2 = org.apache.commons.math.util.FastMath.max(26528, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26528 + "'", int2 == 26528);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0.9092974268256817d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        boolean boolean14 = dfp5.greaterThan(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp5.getOne();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        dfpField9.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.sqrt();
        int int19 = dfp18.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getZero();
        boolean boolean10 = dfp4.greaterThan(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((byte) 1, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        boolean boolean6 = dfp3.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass4 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 52);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray12);
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray23);
        mathIllegalArgumentException19.addSuppressed((java.lang.Throwable) mathIllegalArgumentException24);
        mathIllegalArgumentException8.addSuppressed((java.lang.Throwable) mathIllegalArgumentException24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException8);
        java.lang.Throwable[] throwableArray28 = mathRuntimeException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.String str11 = numberIsTooSmallException8.toString();
        boolean boolean12 = numberIsTooSmallException8.getBoundIsAllowed();
        java.lang.Number number13 = numberIsTooSmallException8.getMin();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 57.29577951308232d + "'", number9.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)" + "'", str11.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1) + "'", number13.equals((-1)));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        boolean boolean16 = dfp7.lessThan(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp7.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp7.divide((int) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getE();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.getOne();
        int int42 = dfp40.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.getTwo();
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp37, dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp43);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.getZero();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.nextAfter(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp28.divide(dfp51);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        java.lang.String str23 = mathIllegalArgumentException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray35);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray46);
        mathIllegalArgumentException42.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        mathIllegalArgumentException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException31);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray60);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable69, objArray71);
        mathIllegalArgumentException67.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        mathIllegalArgumentException56.addSuppressed((java.lang.Throwable) mathIllegalArgumentException72);
        java.lang.Object[] objArray75 = new java.lang.Object[] { roundingMode26, mathRuntimeException50, (byte) 10, mathIllegalArgumentException72 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException76 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable24, localizable25, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable77 = mathRuntimeException76.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable78 = mathRuntimeException76.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = mathRuntimeException76.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str23.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNull(localizable77);
        org.junit.Assert.assertNull(localizable78);
        org.junit.Assert.assertNull(localizable79);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        boolean boolean16 = dfp7.lessThan(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp7.newInstance(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp7.divide((int) (short) 100);
        java.lang.String str29 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0.7853981633975" + "'", str29.equals("0.7853981633975"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000655634848852d + "'", double1 == 1.0000655634848852d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-32767), (double) (-1253495559));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141566513090326d) + "'", double2 == (-3.141566513090326d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, (long) 1009305719);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1009305719L + "'", long2 == 1009305719L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray21);
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) mathIllegalArgumentException22);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException22);
        java.lang.String str25 = mathIllegalArgumentException6.toString();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray37);
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) mathIllegalArgumentException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray48);
        mathIllegalArgumentException44.addSuppressed((java.lang.Throwable) mathIllegalArgumentException49);
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) mathIllegalArgumentException49);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException33);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable60, objArray62);
        mathIllegalArgumentException58.addSuppressed((java.lang.Throwable) mathIllegalArgumentException63);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray68);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, localizable71, objArray73);
        mathIllegalArgumentException69.addSuppressed((java.lang.Throwable) mathIllegalArgumentException74);
        mathIllegalArgumentException58.addSuppressed((java.lang.Throwable) mathIllegalArgumentException74);
        java.lang.Object[] objArray77 = new java.lang.Object[] { roundingMode28, mathRuntimeException52, (byte) 10, mathIllegalArgumentException74 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException78 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6, localizable26, localizable27, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray77);
        java.lang.String str80 = mathIllegalArgumentException79.toString();
        org.apache.commons.math.exception.util.Localizable localizable81 = mathIllegalArgumentException79.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str25.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str80.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable81);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode5);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        int int25 = dfp18.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp18.divide((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double2 = org.apache.commons.math.util.FastMath.min(3.0d, (-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5440211108893698d) + "'", double2 == (-0.5440211108893698d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getE();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.getOne();
        int int35 = dfp33.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.Dfp.copysign(dfp30, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp30.power10K((-4));
        org.apache.commons.math.dfp.Dfp dfp40 = dfp25.divide(dfp30);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp18.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 0, (byte) -1);
        int int8 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-4) + "'", int8 == (-4));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.544346900318835d + "'", double1 == 21.544346900318835d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-32767), (long) 1703815249);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32767L) + "'", long2 == (-32767L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.3967004095459796d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7347747374820058d + "'", double1 == 0.7347747374820058d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathIllegalArgumentException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray9);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray20);
        mathIllegalArgumentException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException21);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        java.lang.Throwable[] throwableArray25 = mathRuntimeException24.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray40);
        mathIllegalArgumentException36.addSuppressed((java.lang.Throwable) mathIllegalArgumentException41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray48);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException36, localizable43, localizable44, objArray48);
        numberIsTooSmallException31.addSuppressed((java.lang.Throwable) mathRuntimeException50);
        mathIllegalArgumentException26.addSuppressed((java.lang.Throwable) numberIsTooSmallException31);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4);
        java.lang.Class<?> wildcardClass24 = mathRuntimeException23.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField5.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, (java.lang.Object[]) dfpArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        mathIllegalArgumentException10.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10, localizable17, localizable18, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathRuntimeException25.getGeneralPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathRuntimeException25);
        java.lang.Number number28 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5557.690612768985d + "'", number3.equals(5557.690612768985d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 5557.690612768985d + "'", number28.equals(5557.690612768985d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.3442572939312747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 0, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.getZero();
        boolean boolean9 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException8.getSuppressed();
        java.lang.Object[] objArray12 = numberIsTooSmallException8.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 57.29577951308232d + "'", number9.equals(57.29577951308232d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        long long6 = mersenneTwister5.nextLong();
        double double7 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-555087506780952317L) + "'", long6 == (-555087506780952317L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.06556079484459221d + "'", double7 == 0.06556079484459221d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass4 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 4784062645013524012L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.70496896570883d + "'", double1 == 43.70496896570883d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("1.");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9640275800758169d + "'", double1 == 0.9640275800758169d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getLn2Split();
        int int11 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp("2.718281828459");
        boolean boolean15 = dfp5.unequal(dfp14);
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8286316095047268712L) + "'", long2 == (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.40849546527617625d) + "'", double3 == (-0.40849546527617625d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5872139151569291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1774215933195176d + "'", double1 == 1.1774215933195176d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0.9092974268256817d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        boolean boolean14 = dfp5.greaterThan(dfp13);
        int int15 = dfp5.log10();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        byte[] byteArray13 = new byte[] { (byte) 3, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray13);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.4649576521875536d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlags((-32767));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.newInstance();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.multiply((int) (byte) 10);
        boolean boolean7 = dfp4.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 26528);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32,768 is smaller than, or equal to, the minimum (10)");
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }
}

