import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        boolean boolean8 = dfp6.equals((java.lang.Object) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        dfpField10.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.sqrt();
        boolean boolean25 = dfp16.lessThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp16.newInstance((int) (short) -1);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.getOne();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.ceil();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp16.newInstance(dfp32);
        boolean boolean34 = dfp6.lessThan(dfp16);
        org.apache.commons.math.dfp.Dfp dfp35 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.String str11 = numberIsTooSmallException8.toString();
        boolean boolean12 = numberIsTooSmallException8.getBoundIsAllowed();
        java.lang.Object[] objArray13 = numberIsTooSmallException8.getArguments();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 57.29577951308232d + "'", number9.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)" + "'", str11.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 938625009);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.386250090000001E8d + "'", double1 == 9.386250090000001E8d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        boolean boolean8 = dfp6.equals((java.lang.Object) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance(dfp14);
        boolean boolean16 = dfp6.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.0f, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable6, objArray10);
        boolean boolean13 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + Double.POSITIVE_INFINITY + "'", number14.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 57.29577951308232d + "'", number5.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getZero();
        boolean boolean18 = dfp12.greaterThan(dfp17);
        boolean boolean19 = dfp7.unequal(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.newDfp();
        dfpField21.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getLn5();
        boolean boolean25 = dfp7.greaterThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp3.subtract(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        dfpField29.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getOne();
        int int38 = dfp36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.newInstance(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.floor();
        boolean boolean60 = dfp50.lessThan(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((-1));
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.getPi();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp44.dotrap((-32767), "", dfp59, dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp36.nextAfter(dfp59);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp33.nextAfter(dfp59);
        boolean boolean68 = dfp24.unequal(dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
        int[] intArray4 = new int[] { (byte) 0, (byte) 10 };
        mersenneTwister1.setSeed(intArray4);
        double double6 = mersenneTwister1.nextGaussian();
        int int7 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0000679992263888d) + "'", double6 == (-1.0000679992263888d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 896490231 + "'", int7 == 896490231);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable11, localizable12, objArray13);
        java.lang.Throwable[] throwableArray15 = mathRuntimeException14.getSuppressed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        int int13 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.rint();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.getOne();
        int int23 = dfp21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        int int25 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp17.multiply(dfp21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-4) + "'", int25 == (-4));
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1259.2861304356516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.1390940618123695d + "'", double1 == 7.1390940618123695d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9896835559265444d + "'", double1 == 0.9896835559265444d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.ulp(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        int int10 = dfp9.classify();
        java.lang.String str11 = dfp9.toString();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getZero();
        boolean boolean26 = dfp20.greaterThan(dfp25);
        boolean boolean27 = dfp15.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        dfpField29.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn5();
        boolean boolean33 = dfp15.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp9.newInstance(dfp15);
        boolean boolean35 = dfp9.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1." + "'", str11.equals("1."));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4210854715202004E-14d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        boolean boolean26 = dfp16.lessThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp10.dotrap((-32767), "", dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.nextAfter(dfp25);
        int int33 = dfp2.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(100L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("2.718281828459");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) -1, (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.power10K((-4));
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        long long1 = org.apache.commons.math.util.FastMath.round(21.414900828725006d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21L + "'", long1 == 21L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1009305719);
        mersenneTwister1.setSeed(1009305719);
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9388841318430117d + "'", double4 == 0.9388841318430117d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 7317830776458656096L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.861626845706644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.10119467660239159d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1015415207887365d) + "'", double1 == (-0.1015415207887365d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9699086474175624d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((byte) 0, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.7160033436347994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.562253565251373d + "'", double1 == 4.562253565251373d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        mathIllegalArgumentException10.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10, localizable17, localizable18, objArray22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathRuntimeException25.getGeneralPattern();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathRuntimeException25);
        java.lang.Number number28 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5557.690612768985d + "'", number3.equals(5557.690612768985d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1774215933195176d, (double) 13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.0d + "'", double2 == 13.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfp9.subtract(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.0947125472611012d, (double) 1.99697792E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0489412658408868E-9d + "'", double2 == 1.0489412658408868E-9d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.newDfp();
        dfpField2.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray6);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6931471805599453d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        int int18 = dfp8.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        dfpField9.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.newDfp();
        dfpField18.clearIEEEFlags();
        java.lang.Class<?> wildcardClass21 = dfpField18.getClass();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField18.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField18.newDfp((byte) 2);
        double double29 = dfp28.toDouble();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp16.subtract(dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance((-1.5707963267948966d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.divide((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(0.9092974268256817d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        int int3 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4) + "'", int3 == (-4));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray9);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray17);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathIllegalArgumentException20.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable21);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int2 = org.apache.commons.math.util.FastMath.max(896490231, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 896490231 + "'", int2 == 896490231);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister5.setSeed(intArray16);
        int int20 = mersenneTwister5.nextInt();
        int[] intArray25 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister(intArray25);
        byte[] byteArray30 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister26.nextBytes(byteArray30);
        mersenneTwister5.nextBytes(byteArray30);
        float float33 = mersenneTwister5.nextFloat();
        mersenneTwister5.setSeed(0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-129241382) + "'", int20 == (-129241382));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0655607f + "'", float33 == 0.0655607f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        int int9 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        dfpField12.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField12.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField20.setRoundingMode(roundingMode24);
        dfpField12.setRoundingMode(roundingMode24);
        dfpField1.setRoundingMode(roundingMode24);
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4, (java.lang.Number) 4.641588833612779d, true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException1);
        java.lang.Object[] objArray3 = mathRuntimeException2.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        int int20 = dfp18.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        int[] intArray6 = new int[] { 4, (-32767) };
        mersenneTwister3.setSeed(intArray6);
        mersenneTwister1.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getPi();
        int int29 = dfpField27.getIEEEFlags();
        dfpField27.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField27.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable24, localizable25, (java.lang.Object[]) dfpArray32);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471428d) + "'", double1 == (-0.4161468365471428d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        int[] intArray10 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        byte[] byteArray15 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister11.nextBytes(byteArray15);
        long long17 = mersenneTwister11.nextLong();
        int int18 = mersenneTwister11.nextInt();
        int int19 = mersenneTwister11.nextInt();
        int[] intArray24 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        int[] intArray30 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math.random.MersenneTwister(intArray30);
        byte[] byteArray35 = new byte[] { (byte) 0, (byte) -1, (byte) 0 };
        mersenneTwister31.nextBytes(byteArray35);
        mersenneTwister25.nextBytes(byteArray35);
        mersenneTwister11.nextBytes(byteArray35);
        mersenneTwister5.nextBytes(byteArray35);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-9002580193226221695L) + "'", long17 == (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1996977908 + "'", int18 == 1996977908);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-659647536) + "'", int19 == (-659647536));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(byteArray35);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long2 = org.apache.commons.math.util.FastMath.min((-32767L), (long) 896490231);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32767L) + "'", long2 == (-32767L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 982170359);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 982170368 + "'", int1 == 982170368);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        dfpField1.clearIEEEFlags();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp23);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0000655634848852d, 31.99739562137696d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000655634848852d + "'", double2 == 1.0000655634848852d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.FastMath.min(10000, (-1253495559));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1253495559) + "'", int2 == (-1253495559));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        int int8 = dfp6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp3.divide(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        int int21 = dfp20.classify();
        java.lang.String str22 = dfp20.toString();
        int int23 = dfp20.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.newDfp();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.floor();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp27.multiply(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.divide(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.multiply((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp3.add(dfp42);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1." + "'", str22.equals("1."));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3, number2, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1703815249);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.math.util.FastMath.max(1703815249, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1703815249 + "'", int2 == 1703815249);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        dfpField6.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp(0.8342233605065102d);
        boolean boolean13 = dfp2.unequal(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp2.newInstance(1.1462158347805889d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(10.0d);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        dfpField11.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField11.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp9.subtract(dfp18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.newInstance((byte) 100, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.getOne();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField27.getE();
        org.apache.commons.math.dfp.DfpField dfpField36 = dfp35.getField();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp25.multiply(dfp35);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpField36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        int int6 = dfp5.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.00949495958537668d) + "'", double1 == (-0.00949495958537668d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9699086474175624d, (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0155914852309773d + "'", double2 == 1.0155914852309773d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray19);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException4.getSpecificPattern();
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException4.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathIllegalArgumentException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.10119467660239159d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10085066227334832d) + "'", double1 == (-0.10085066227334832d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        int int16 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-3.868335738447959d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-221.63931155269074d) + "'", double1 == (-221.63931155269074d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.9699086f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.714973875118524d + "'", double1 == 18.714973875118524d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-129241382));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.286316E18f + "'", float1 == 8.286316E18f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-15.605502432952306d), (java.lang.Number) 1.861626845706644d, false);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -15.606 is smaller than, or equal to, the minimum (1.862)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -15.606 is smaller than, or equal to, the minimum (1.862)"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        boolean boolean26 = dfp16.lessThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp10.dotrap((-32767), "", dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.floor();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.getZero();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.newInstance(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp54.floor();
        boolean boolean56 = dfp46.lessThan(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((double) 0);
        boolean boolean62 = dfp60.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp46.multiply(dfp60);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp42.newInstance(dfp60);
        boolean boolean65 = dfp2.equals((java.lang.Object) dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp64.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 100, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Class<?> wildcardClass4 = roundingMode3.getClass();
        dfpField1.setRoundingMode(roundingMode3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-15.605502432952306d), (java.lang.Number) 1.861626845706644d, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.090354889191955d + "'", double1 == 11.090354889191955d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getLn2Split();
        int int11 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp("2.718281828459");
        boolean boolean15 = dfp5.unequal(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((long) (-1));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.FastMath.pow(18.714973875118524d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.714973875118524d + "'", double2 == 18.714973875118524d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getE();
        boolean boolean10 = dfp4.unequal(dfp9);
        java.lang.String str11 = dfp4.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0." + "'", str11.equals("0."));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        int[] intArray6 = new int[] { 4, (-32767) };
        mersenneTwister3.setSeed(intArray6);
        mersenneTwister1.setSeed(intArray6);
        boolean boolean9 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException9);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number20 = numberIsTooSmallException19.getArgument();
        numberIsTooSmallException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.Throwable[] throwableArray22 = numberIsTooSmallException19.getSuppressed();
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 57.29577951308232d + "'", number20.equals(57.29577951308232d));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9640275800758169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        double double6 = dfp5.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6467353350307651d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-32767L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.090324371148174d) + "'", double1 == (-11.090324371148174d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.40849546527617625d));
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5872139151569291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8324875211176866d + "'", double1 == 0.8324875211176866d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7764722807237177d + "'", double1 == 2.7764722807237177d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getZero();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.floor();
        boolean boolean27 = dfp17.lessThan(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-1));
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp11.dotrap((-32767), "", dfp26, dfp31);
        int int33 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp11.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.getZero();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.floor();
        boolean boolean52 = dfp42.lessThan(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp38.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.getE();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp59.multiply(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) 0);
        boolean boolean70 = dfp68.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp68.rint();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp59.multiply(dfp68);
        boolean boolean73 = dfp38.unequal(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((-1));
        int int76 = dfpField75.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField75.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField75.newDfp((double) (-4));
        org.apache.commons.math.dfp.Dfp dfp81 = org.apache.commons.math.dfp.DfpField.computeLn(dfp34, dfp38, dfp80);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp7.add(dfp38);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 16 + "'", int76 == 16);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 0, (byte) -1, (byte) 0 };
        mersenneTwister5.nextBytes(byteArray9);
        mersenneTwister5.setSeed((int) (byte) 10);
        int int13 = mersenneTwister5.nextInt();
        boolean boolean14 = mersenneTwister5.nextBoolean();
        boolean boolean15 = mersenneTwister5.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-982170359) + "'", int13 == (-982170359));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.power10K((-4));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        dfpField15.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.getE();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.getZero();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.floor();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10(0);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp23.multiply(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        double[] doubleArray37 = dfp36.toSplitDouble();
        boolean boolean38 = dfp19.unequal(dfp36);
        java.lang.String str39 = dfp36.toString();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp13.subtract(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getZero();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.newInstance(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.floor();
        boolean boolean60 = dfp50.lessThan(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((-1));
        int int63 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.getPi();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp44.dotrap((-32767), "", dfp59, dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp40.divide(dfp59);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1." + "'", str39.equals("1."));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 16 + "'", int63 == 16);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4462349871957424E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.51291019986641d + "'", double1 == 39.51291019986641d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32760, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3796077390275217d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9288100617506275d + "'", double1 == 0.9288100617506275d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5557.690612768985d);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 5,557.691 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 5,557.691 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.sqrt();
        boolean boolean16 = dfp7.lessThan(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp7.newInstance(dfp25);
        int int27 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0.9699086f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.power10K((-4));
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField17.setRoundingMode(roundingMode19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.divide(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 32768, (java.lang.Number) (short) 10, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 57.29577951308232d, (java.lang.Number) (-1), true);
        java.lang.Number number9 = numberIsTooSmallException8.getArgument();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.String str11 = numberIsTooSmallException8.toString();
        boolean boolean12 = numberIsTooSmallException8.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 57.29577951308232d + "'", number9.equals(57.29577951308232d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)" + "'", str11.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 57.296 is smaller than the minimum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        boolean boolean11 = dfp9.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        java.lang.Class<?> wildcardClass8 = roundingMode7.getClass();
        dfpField1.setRoundingMode(roundingMode7);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable8, objArray10);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) mathIllegalArgumentException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException6, localizable13, localizable14, objArray18);
        java.lang.Object[] objArray21 = mathRuntimeException20.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException22.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = null;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        int int9 = dfp8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.multiply(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.newInstance(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.floor();
        boolean boolean34 = dfp24.lessThan(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) 0);
        boolean boolean40 = dfp38.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp24.multiply(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp20.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp5.newInstance(dfp42);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.0f, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4210854715202004E-14d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4210854715202004E-14d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray21);
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) mathIllegalArgumentException22);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray29);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException17, localizable24, localizable25, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray29);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        dfpField34.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField34.getPi();
        int int42 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField34.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField45.setRoundingMode(roundingMode48);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getE();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp62.getOne();
        int int64 = dfp62.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.getTwo();
        org.apache.commons.math.dfp.Dfp dfp66 = org.apache.commons.math.dfp.Dfp.copysign(dfp59, dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.Dfp.copysign(dfp54, dfp65);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.newDfp();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.newDfp();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.getZero();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp67.nextAfter(dfp71);
        java.lang.Object[] objArray74 = new java.lang.Object[] { objArray29, dfpField34, dfpArray50, dfp71 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable8, localizable11, objArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.10119467660239159d), (java.lang.Number) (-982170359), false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + Double.POSITIVE_INFINITY + "'", number5.equals(Double.POSITIVE_INFINITY));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField9.setRoundingMode(roundingMode13);
        dfpField1.setRoundingMode(roundingMode13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K(97);
        int int5 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.1415888721402332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 67.3340684745264d + "'", double1 == 67.3340684745264d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        boolean boolean26 = dfp16.lessThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp10.dotrap((-32767), "", dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp32.getField();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((byte) 0, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4462349871957424E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4462349871957424E17d + "'", double1 == 1.4462349871957424E17d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (short) -1);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        boolean boolean20 = dfp19.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        dfpField10.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.sqrt();
        boolean boolean25 = dfp16.lessThan(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField26 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.newInstance(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.newDfp();
        dfpField30.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField30.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getPi();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getLn10();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.sqrt();
        boolean boolean45 = dfp36.lessThan(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField46 = dfp36.getField();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField48.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp55 = dfp36.newInstance(dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp36.divide((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp8.nextAfter(dfp57);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfpField26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfpField46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.sqrt();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getZero();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.newDfp();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.newInstance(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.floor();
        boolean boolean35 = dfp25.lessThan(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 0);
        boolean boolean41 = dfp39.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp25.multiply(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.newDfp(2);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeExp(dfp42, dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp19.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.newDfp();
        dfpField10.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.sqrt();
        boolean boolean25 = dfp16.lessThan(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField26 = dfp16.getField();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.newInstance(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.newDfp();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.multiply(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 0);
        boolean boolean47 = dfp45.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp45.rint();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp36.multiply(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.newDfp();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp52.newInstance(dfp55);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp56.floor();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.power10(0);
        int int60 = dfp59.classify();
        java.lang.String str61 = dfp59.toString();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.newDfp();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField63.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.newDfp();
        dfpField67.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField72.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField72.getZero();
        boolean boolean76 = dfp70.greaterThan(dfp75);
        boolean boolean77 = dfp65.unequal(dfp70);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.newDfp();
        dfpField79.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField79.getLn5();
        boolean boolean83 = dfp65.greaterThan(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp59.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp8.dotrap((-129241382), "0.7853981633975", dfp45, dfp65);
        org.apache.commons.math.dfp.DfpField dfpField87 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField87.newDfp();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField87.getLn5();
        org.apache.commons.math.dfp.Dfp dfp90 = dfp89.newInstance();
        org.apache.commons.math.dfp.Dfp dfp91 = dfp85.multiply(dfp89);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfpField26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1." + "'", str61.equals("1."));
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((-1.0000679992263888d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        int int12 = mersenneTwister5.nextInt((int) (byte) 1);
        double double13 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8464138417944371d + "'", double13 == 0.8464138417944371d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-9002580193226221695L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2);
        java.lang.String str7 = dfp6.toString();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2." + "'", str7.equals("2."));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10(0);
        boolean boolean18 = dfp7.greaterThan(dfp15);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance((long) 8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.newInstance(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp15.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp15.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField9.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        int int3 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags(97);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long1 = org.apache.commons.math.util.FastMath.abs(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        int int15 = dfp13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.ceil();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField18.getLn2Split();
        int int22 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getLn10();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp("2.718281828459");
        boolean boolean26 = dfp16.unequal(dfp25);
        boolean boolean27 = dfp9.unequal(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7853981633974483d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1996977908, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray13);
        mathIllegalArgumentException9.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 2 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray21);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable16, localizable17, objArray21);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException23);
        java.lang.Object[] objArray25 = numberIsTooSmallException4.getArguments();
        boolean boolean26 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number27 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 1996977908 + "'", number27.equals(1996977908));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.atan(43.636130838093536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5478835484114637d + "'", double1 == 1.5478835484114637d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(2.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.newInstance(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.floor();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        int int20 = dfp19.classify();
        java.lang.String str21 = dfp19.toString();
        int int22 = dfp19.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getZero();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.floor();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp26.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp19.divide(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.multiply((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp39);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1." + "'", str21.equals("1."));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
        long long2 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8286316095047268712L) + "'", long2 == (-8286316095047268712L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(982170359);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(97);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7347747374820058d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7419817927308304d + "'", double1 == 0.7419817927308304d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        mersenneTwister5.setSeed((-32767L));
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0);
        boolean boolean5 = dfp3.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.divide((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        dfpField15.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField15.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField15.newDfp(0.8342233605065102d);
        boolean boolean22 = dfp11.unequal(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp8.newInstance(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.power10(982170368);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.power10((int) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 0);
        boolean boolean17 = dfp15.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.add(dfp15);
        int int20 = dfp19.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("0.7071067811865475");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp9.multiply(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.getOne();
        double[] doubleArray23 = dfp22.toSplitDouble();
        boolean boolean24 = dfp5.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.newDfp();
        dfpField26.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField26.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp37 = dfp5.add(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 1703815249);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        int int9 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp4.power10K((-4));
        int int14 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        boolean boolean14 = dfp8.greaterThan(dfp13);
        boolean boolean15 = dfp3.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn5();
        boolean boolean21 = dfp3.greaterThan(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((-982170359));
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp3.multiply(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.floor();
        boolean boolean23 = dfp13.lessThan(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-1));
        int int26 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp7.dotrap((-32767), "", dfp22, dfp27);
        int int29 = dfp7.log10();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.newInstance(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.floor();
        boolean boolean48 = dfp38.lessThan(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp34.add(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.newDfp();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.newDfp();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.getE();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp55.multiply(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((double) 0);
        boolean boolean66 = dfp64.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp64.rint();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp55.multiply(dfp64);
        boolean boolean69 = dfp34.unequal(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((-1));
        int int72 = dfpField71.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField71.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField71.newDfp((double) (-4));
        org.apache.commons.math.dfp.Dfp dfp77 = org.apache.commons.math.dfp.DfpField.computeLn(dfp30, dfp34, dfp76);
        org.apache.commons.math.dfp.Dfp dfp78 = org.apache.commons.math.dfp.Dfp.copysign(dfp3, dfp34);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 16 + "'", int72 == 16);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(97);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        boolean boolean26 = dfp16.lessThan(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-1));
        int int29 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp10.dotrap((-32767), "", dfp25, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp2.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField35.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField35.newDfp(10.0d);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.floor();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp57.getZero();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.newDfp();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.newInstance(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp65.floor();
        boolean boolean67 = dfp57.lessThan(dfp66);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((-1));
        int int70 = dfpField69.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.getPi();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp51.dotrap((-32767), "", dfp66, dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp71.newInstance();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp71.getTwo();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp47.divide(dfp71);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 16 + "'", int70 == 16);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister6.setSeed(8);
        int[] intArray10 = new int[] { 100 };
        mersenneTwister6.setSeed(intArray10);
        int int12 = mersenneTwister6.nextInt();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 625644691 + "'", int12 == 625644691);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0000000000000004d + "'", double1 == 2.0000000000000004d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 32760);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32760 + "'", int2 == 32760);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        boolean boolean8 = dfp6.equals((java.lang.Object) 1);
        java.lang.String str9 = dfp6.toString();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 0);
        boolean boolean14 = dfp6.equals((java.lang.Object) dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0." + "'", str9.equals("0."));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-129241382));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        int int10 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister5.setSeed(intArray16);
        int int20 = mersenneTwister5.nextInt();
        int[] intArray25 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister(intArray25);
        byte[] byteArray30 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister26.nextBytes(byteArray30);
        mersenneTwister5.nextBytes(byteArray30);
        float float33 = mersenneTwister5.nextFloat();
        mersenneTwister5.setSeed((long) (-1));
        int int36 = mersenneTwister5.nextInt();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-129241382) + "'", int20 == (-129241382));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0655607f + "'", float33 == 0.0655607f);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 93740670 + "'", int36 == 93740670);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10(0);
        boolean boolean18 = dfp7.greaterThan(dfp15);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance((long) 8);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.newDfp();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.newInstance(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp15.getField();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((-1));
        int int32 = dfpField31.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp15.newInstance(dfp33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        byte[] byteArray9 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister5.nextBytes(byteArray9);
        double double11 = mersenneTwister5.nextGaussian();
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister5.setSeed(intArray16);
        int int20 = mersenneTwister5.nextInt();
        int[] intArray25 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister(intArray25);
        byte[] byteArray30 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister26.nextBytes(byteArray30);
        mersenneTwister5.nextBytes(byteArray30);
        double double33 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.2340874536277584d) + "'", double11 == (-1.2340874536277584d));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-129241382) + "'", int20 == (-129241382));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.06556079484459221d + "'", double33 == 0.06556079484459221d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.floor();
        boolean boolean19 = dfp9.lessThan(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((-1));
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp3.dotrap((-32767), "", dfp18, dfp23);
        int int25 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp3.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getZero();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.floor();
        boolean boolean44 = dfp34.lessThan(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp30.add(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.newDfp();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.multiply(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((double) 0);
        boolean boolean62 = dfp60.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.rint();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp51.multiply(dfp60);
        boolean boolean65 = dfp30.unequal(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((-1));
        int int68 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.newDfp((double) (-4));
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeLn(dfp26, dfp30, dfp72);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.divide(52);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 16 + "'", int68 == 16);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        int int10 = dfp9.classify();
        java.lang.String str11 = dfp9.toString();
        int int12 = dfp9.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp16.multiply(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp29, dfp30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1." + "'", str11.equals("1."));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.max(4.562253565251373d, (double) (-8286316095047268712L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.562253565251373d + "'", double2 == 4.562253565251373d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 2);
        dfpField1.setIEEEFlagsBits(3);
        int int11 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister6.setSeed(8);
        long long9 = mersenneTwister6.nextLong();
        mersenneTwister6.setSeed(1009305719);
        int[] intArray16 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        byte[] byteArray21 = new byte[] { (byte) 10, (byte) -1, (byte) 2 };
        mersenneTwister17.nextBytes(byteArray21);
        mersenneTwister6.nextBytes(byteArray21);
        float float24 = mersenneTwister6.nextFloat();
        mersenneTwister6.setSeed((-8286316095047268352L));
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2334815402550860460L) + "'", long9 == (-2334815402550860460L));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5156107f + "'", float24 == 0.5156107f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52, (java.lang.Number) 16, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Class<?> wildcardClass6 = number5.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 16 + "'", number5.equals(16));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52, (java.lang.Number) 16, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 16 + "'", number5.equals(16));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        dfpField6.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.floor();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.power10(0);
        boolean boolean23 = dfp12.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.newInstance("0.7071067811865475");
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getTwo();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.floor();
        boolean boolean41 = dfp31.lessThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 0);
        boolean boolean47 = dfp45.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp31.multiply(dfp45);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.nextAfter(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int[] intArray4 = new int[] { 4, (short) 100, 52, 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister6.setSeed(8);
        mersenneTwister6.setSeed((int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.newDfp();
        dfpField5.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField5.newDfp(0.8342233605065102d);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField5.getESplit();
        boolean boolean14 = dfp2.equals((java.lang.Object) dfpArray13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp2.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) 2);
        java.lang.Class<?> wildcardClass9 = dfp8.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9149994957367078d + "'", double1 == 0.9149994957367078d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((long) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.negate();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(32760.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(52);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.newDfp();
        dfpField11.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((-1));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getZero();
        boolean boolean20 = dfp14.greaterThan(dfp19);
        boolean boolean21 = dfp9.unequal(dfp14);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp14.newInstance(2);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.sqrt();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.getZero();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getOne();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.getZero();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.floor();
        boolean boolean41 = dfp31.lessThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 0);
        boolean boolean47 = dfp45.equals((java.lang.Object) 10L);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp31.multiply(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.newDfp();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField50.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp(2);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.power10((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeExp(dfp48, dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp25.add(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.newDfp();
        dfpField61.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray65 = dfpField61.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField61.newDfp(0.7853981633974483d);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((-32767));
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.newDfp();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp70.newInstance(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp74.floor();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp75.power10(0);
        boolean boolean78 = dfp67.greaterThan(dfp75);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp75.newInstance("0.7071067811865475");
        boolean boolean81 = dfp25.unequal(dfp80);
        org.apache.commons.math.dfp.Dfp dfp82 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp80);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(dfp82);
    }
}

