import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.717546220098004d, (java.lang.Number) 32, false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, number5, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray11 = new java.lang.Object[] { numberIsTooSmallException8, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray11);
        java.lang.IllegalStateException illegalStateException14 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable0, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, number21, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { numberIsTooSmallException24, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException("", objArray27);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException29 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray27);
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray27);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6931471805599453d);
        java.lang.Throwable throwable34 = null;
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, number39, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray45 = new java.lang.Object[] { numberIsTooSmallException42, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.MathRuntimeException("", objArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException(throwable34, doubleArray35, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray45);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats53, number54, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray60 = new java.lang.Object[] { numberIsTooSmallException57, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException("", objArray60);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException62 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray60);
        java.lang.IllegalStateException illegalStateException63 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray60);
        java.lang.IllegalStateException illegalStateException64 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException65 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) notStrictlyPositiveException33, doubleArray35, "", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException15, doubleArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats72, number73, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray79 = new java.lang.Object[] { numberIsTooSmallException76, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException80 = new org.apache.commons.math.MathRuntimeException("", objArray79);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException81 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("d6a3b008f3", objArray79);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("aae2f9838d", objArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, "abd9c71dbfc360c83c4b866a7e88299176e", objArray79);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertNotNull(illegalStateException14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException62);
        org.junit.Assert.assertNotNull(illegalStateException63);
        org.junit.Assert.assertNotNull(illegalStateException64);
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException81);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        java.lang.Throwable throwable8 = null;
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, number13, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { numberIsTooSmallException16, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.MathRuntimeException("", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable8, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) notStrictlyPositiveException7, doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) numberIsTooLargeException3, doubleArray9);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray19);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        double double6 = randomDataImpl1.nextF(10.0d, (double) 10.0f);
//        int int9 = randomDataImpl1.nextInt((int) ' ', 2147483647);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "04efefc85a" + "'", str3.equals("04efefc85a"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3064454017700219d + "'", double6 == 0.3064454017700219d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1583711688 + "'", int9 == 1583711688);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "2c2cd52a8a", objArray3);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(5.298342365610589d, (-1));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray10 = new java.lang.Object[] { numberIsTooSmallException7, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException("", objArray10);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray10);
        java.lang.IllegalStateException illegalStateException13 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray10);
        java.lang.Class<?> wildcardClass14 = illegalStateException13.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(illegalStateException13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        double double2 = org.apache.commons.math.util.FastMath.max(12.870831702626395d, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.870831702626395d + "'", double2 == 12.870831702626395d);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, number5, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray11 = new java.lang.Object[] { numberIsTooSmallException8, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException("", objArray11);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException13 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray11);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("a4a2dc899dd592c5c22313546452216e", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, number23, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray29 = new java.lang.Object[] { numberIsTooSmallException26, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException("", objArray29);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException31 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray29);
        java.lang.IllegalStateException illegalStateException32 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable18, objArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, number39, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray45 = new java.lang.Object[] { numberIsTooSmallException42, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.MathRuntimeException("", objArray45);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException47 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray45);
        org.apache.commons.math.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray45);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException15, (double) 10, "", objArray45);
        java.lang.Throwable throwable53 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(throwable53, 0.0d, "hi!", objArray57);
        java.lang.IllegalStateException illegalStateException59 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("0ed3c1f8291207affd0ab7647596474502d", objArray57);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, "", objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException13);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException31);
        org.junit.Assert.assertNotNull(illegalStateException32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException47);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(illegalStateException59);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1L), (double) 1.0f, 1.0E200d);
        normalDistributionImpl3.reseedRandomGenerator((long) 97);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (byte) 100, 12.870831702626395d);
        int[] intArray4 = poissonDistributionImpl2.sample(0);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number7, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray13 = new java.lang.Object[] { numberIsTooSmallException10, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException("", objArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray13);
        java.lang.IllegalStateException illegalStateException16 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) 32L, "", objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(illegalStateException16);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1L), (double) 1.0f, 1.0E200d);
//        normalDistributionImpl7.reseedRandomGenerator(100L);
//        double double10 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = randomDataImpl1.nextExponential(0.6610060414837631d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6177398fae" + "'", str3.equals("6177398fae"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5688742105403115d + "'", double12 == 0.5688742105403115d);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 52);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        java.lang.ArithmeticException arithmeticException4 = org.apache.commons.math.MathRuntimeException.createArithmeticException("442162e842", (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(arithmeticException4);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) 2147483647, (double) (-1L), 13);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b1edfc60b52c9fbe648e24e8f679620f945e1da627975a8cbe211cf252375fa6c585829f370529bab156c172ac2ef09fa5f9" + "'", str2.equals("b1edfc60b52c9fbe648e24e8f679620f945e1da627975a8cbe211cf252375fa6c585829f370529bab156c172ac2ef09fa5f9"));
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double double1 = org.apache.commons.math.util.FastMath.log10(61.18254030032512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7866275049387876d + "'", double1 == 1.7866275049387876d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10000000, (java.lang.Number) 2.220446049250313E-16d, false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        try {
            org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((-0.017453292519943295d), 1548.5311953349976d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.017 is smaller than, or equal to, the minimum (0): mean (-0.017)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, 0.0d, "hi!", objArray5);
        java.lang.Throwable[] throwableArray7 = functionEvaluationException6.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, number14, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { numberIsTooSmallException17, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.MathRuntimeException("", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable9, doubleArray10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException6, localizable8, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, number29, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { numberIsTooSmallException32, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException("", objArray35);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException37 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray35);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException38 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("7ffb1ef8d7", objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        java.lang.ArithmeticException arithmeticException40 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray35);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException37);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException38);
        org.junit.Assert.assertNotNull(arithmeticException40);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1L), (double) 1.0f, 1.0E200d);
        normalDistributionImpl3.reseedRandomGenerator(100L);
        double double7 = normalDistributionImpl3.cumulativeProbability((double) 32L);
        double double8 = normalDistributionImpl3.getMean();
        java.lang.Class<?> wildcardClass9 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        double double1 = org.apache.commons.math.util.FastMath.expm1(31.999999996210352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896295988343789E13d + "'", double1 == 7.896295988343789E13d);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable throwable6 = null;
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, number11, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { numberIsTooSmallException14, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException("", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable6, doubleArray7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        java.lang.ArithmeticException arithmeticException20 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray17);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 10L, 0L, (byte) 1 };
        java.lang.ArithmeticException arithmeticException31 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0.6610060414837631d, localizedFormats25, arithmeticException31, localizedFormats32 };
        java.lang.IllegalArgumentException illegalArgumentException34 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) arithmeticException21, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        java.lang.String str36 = convergenceException35.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(arithmeticException20);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(arithmeticException31);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(illegalArgumentException34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "no result available" + "'", str36.equals("no result available"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.0E-9d);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 1L);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number7, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray13 = new java.lang.Object[] { numberIsTooSmallException10, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException("", objArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray13);
        java.lang.IllegalStateException illegalStateException16 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable2, objArray13);
        java.util.ConcurrentModificationException concurrentModificationException18 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(illegalStateException16);
        org.junit.Assert.assertNotNull(concurrentModificationException18);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(12.870831702626395d, (double) 32L, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator(1L);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextLong(0L, (long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 10);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dca543f1ec" + "'", str6.equals("dca543f1ec"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3371070a4694571d0f3a5f386edb082c3510a4c3e2e3cfaadc0ac08e78ecbb49ae70aeb335b7b7431840c4c7149c111e7" + "'", str8.equals("3371070a4694571d0f3a5f386edb082c3510a4c3e2e3cfaadc0ac08e78ecbb49ae70aeb335b7b7431840c4c7149c111e7"));
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        long long2 = org.apache.commons.math.util.FastMath.min(89L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number7, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray13 = new java.lang.Object[] { numberIsTooSmallException10, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException("", objArray13);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException15 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray13);
        java.lang.IllegalStateException illegalStateException16 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable2, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, number23, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray29 = new java.lang.Object[] { numberIsTooSmallException26, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.MathRuntimeException("", objArray29);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException31 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray29);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6931471805599453d);
        java.lang.Throwable throwable36 = null;
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, number41, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray47 = new java.lang.Object[] { numberIsTooSmallException44, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.MathRuntimeException("", objArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(throwable36, doubleArray37, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, number56, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { numberIsTooSmallException59, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.MathRuntimeException("", objArray62);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException64 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray62);
        java.lang.IllegalStateException illegalStateException65 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray62);
        java.lang.IllegalStateException illegalStateException66 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats51, objArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) notStrictlyPositiveException35, doubleArray37, "", objArray62);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException17, doubleArray37);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException(throwable72, 0.0d, "hi!", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("hi!", objArray76);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException17, 1.7253747334040217E-8d, (org.apache.commons.math.exception.util.Localizable) localizedFormats70, objArray76);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException((double) 10.0f, "d6a3b008f3", objArray76);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException15);
        org.junit.Assert.assertNotNull(illegalStateException16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException64);
        org.junit.Assert.assertNotNull(illegalStateException65);
        org.junit.Assert.assertNotNull(illegalStateException66);
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray12 = new java.lang.Object[] { numberIsTooSmallException9, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.MathRuntimeException("", objArray12);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException14 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray12);
        java.lang.IllegalStateException illegalStateException15 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, number22, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray28 = new java.lang.Object[] { numberIsTooSmallException25, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.MathRuntimeException("", objArray28);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException30 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray28);
        org.apache.commons.math.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray28);
        org.apache.commons.math.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        java.lang.Throwable throwable37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6931471805599453d);
        java.lang.Throwable throwable40 = null;
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, number45, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { numberIsTooSmallException48, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.MathRuntimeException("", objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(throwable40, doubleArray41, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray51);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats59, number60, (java.lang.Number) (-1.0f), false);
        java.lang.Object[] objArray66 = new java.lang.Object[] { numberIsTooSmallException63, 100.0f, Double.NaN };
        org.apache.commons.math.MathRuntimeException mathRuntimeException67 = new org.apache.commons.math.MathRuntimeException("", objArray66);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException68 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("0ed3c1f8291207affd0ab7647596474502d", objArray66);
        java.lang.IllegalStateException illegalStateException69 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray66);
        java.lang.IllegalStateException illegalStateException70 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) notStrictlyPositiveException39, doubleArray41, "", objArray66);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.Throwable throwable73 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(throwable73, 0.0d, "hi!", objArray77);
        java.lang.Throwable[] throwableArray79 = functionEvaluationException78.getSuppressed();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException80 = new org.apache.commons.math.FunctionEvaluationException(throwable37, doubleArray41, (org.apache.commons.math.exception.util.Localizable) localizedFormats72, (java.lang.Object[]) throwableArray79);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException81 = new org.apache.commons.math.FunctionEvaluationException((double) 0.0f, "", (java.lang.Object[]) throwableArray79);
        java.text.ParseException parseException82 = org.apache.commons.math.MathRuntimeException.createParseException(0, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Object[]) throwableArray79);
        java.lang.Throwable throwable85 = null;
        java.lang.Object[] objArray89 = new java.lang.Object[] { 'a' };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException90 = new org.apache.commons.math.FunctionEvaluationException(throwable85, 0.0d, "hi!", objArray89);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(10, "", objArray89);
        java.util.NoSuchElementException noSuchElementException92 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray89);
        java.text.ParseException parseException93 = org.apache.commons.math.MathRuntimeException.createParseException(98, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray89);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException14);
        org.junit.Assert.assertNotNull(illegalStateException15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException30);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException68);
        org.junit.Assert.assertNotNull(illegalStateException69);
        org.junit.Assert.assertNotNull(illegalStateException70);
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray79);
        org.junit.Assert.assertNotNull(parseException82);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(noSuchElementException92);
        org.junit.Assert.assertNotNull(parseException93);
    }
}

