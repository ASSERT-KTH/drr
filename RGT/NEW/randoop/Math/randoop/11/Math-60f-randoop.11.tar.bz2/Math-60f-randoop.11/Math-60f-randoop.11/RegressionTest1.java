import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        long long2 = org.apache.commons.math.util.FastMath.min(64L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextZipf((int) (byte) 100, 1.0E-9d);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric((int) (byte) 1, 0, 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (1): sample size (35) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.48450888965172056d + "'", double3 == 0.48450888965172056d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 89 + "'", int6 == 89);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.9065898968108168d + "'", number6.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.9065898968108168d + "'", number7.equals(0.9065898968108168d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0d, objArray12, convergenceException14, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable3, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0d, objArray30, convergenceException32, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable21, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("hi!", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable18, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.0f, (java.lang.Number) 31.693742175909772d, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(141.8044771078766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.90816850350534d + "'", double1 == 11.90816850350534d);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextSecureInt(0, (int) (byte) 100);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.33705718692910663d + "'", double3 == 0.33705718692910663d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray9 = outOfRangeException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable3, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray38 = outOfRangeException37.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable32, objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10, localizable12, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable12, objArray53);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 100, (java.lang.Number) (-5.294775415650245d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.643774567583453d, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException66.addSuppressed((java.lang.Throwable) outOfRangeException70);
        org.apache.commons.math.exception.util.Localizable localizable72 = outOfRangeException70.getGeneralPattern();
        java.lang.String str73 = outOfRangeException70.toString();
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable75 = convergenceException74.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray83 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, objArray83);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable75, objArray83);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException89 = new org.apache.commons.math.exception.OutOfRangeException(localizable75, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException89);
        org.apache.commons.math.exception.util.Localizable localizable91 = outOfRangeException89.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable92 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException96 = new org.apache.commons.math.exception.OutOfRangeException(localizable92, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray97 = outOfRangeException96.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException65, localizable91, objArray97);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException99 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', localizable12, objArray97);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str73.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + localizable91 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable91.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.0d, 3.726369000956119d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            int[] intArray11 = randomDataImpl1.nextPermutation((int) (byte) 1, 77);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 77 is larger than the maximum (1): permutation size (77) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 95.81982176892296d + "'", double6 == 95.81982176892296d);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.expm1(141.8044771078766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8450493404416856E61d + "'", double1 == 3.8450493404416856E61d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.23866189121683237d) + "'", double1 == (-0.23866189121683237d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 28, (java.lang.Number) 3.735545630309108E-74d, (java.lang.Number) 3.141592653589793d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.735545630309108E-74d + "'", number4.equals(3.735545630309108E-74d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 77L, 115.09728129317894d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3488189291325196E217d + "'", double2 == 1.3488189291325196E217d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.09927014223709542d, (java.lang.Number) 2.1685525535511587d, number2);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.09927014223709542d + "'", number4.equals(0.09927014223709542d));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9065898968108168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04258912510058354d) + "'", double1 == (-0.04258912510058354d));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextGaussian((double) ' ', (double) 52);
//        randomDataImpl1.reSeed(0L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl20.reseedRandomGenerator((long) (short) 0);
//        double double26 = normalDistributionImpl20.getMean();
//        double double28 = normalDistributionImpl20.density((double) (-1L));
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        double double31 = normalDistributionImpl20.density(5.052393630276104E31d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 68.25214156712859d + "'", double6 == 68.25214156712859d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 53.173756936942354d + "'", double14 == 53.173756936942354d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.021127442416575826d + "'", double23 == 0.021127442416575826d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.003989223337860822d + "'", double28 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.574258689729206d + "'", double29 == 61.574258689729206d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        java.lang.String str12 = randomDataImpl1.nextHexString(28);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 68.59266352397778d + "'", double6 == 68.59266352397778d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f67a723814e136e3fb2465d8c7b7" + "'", str12.equals("f67a723814e136e3fb2465d8c7b7"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.special.Gamma.digamma(80.54517617338425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.382597679953344d + "'", double1 == 4.382597679953344d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) '4', 0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.608269748985484E-160d + "'", double2 == 4.608269748985484E-160d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray18);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 34, (java.lang.Number) (-3380.198766790388d));
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10.0d, objArray40, convergenceException42, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable31, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0d, objArray57, convergenceException59, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable48, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray61);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("d37efa674a", objArray61);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, localizable10, objArray61);
        java.lang.Throwable[] throwableArray66 = mathException65.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        double double8 = normalDistributionImpl3.cumulativeProbability(0.17453292519943295d);
        double double11 = normalDistributionImpl3.cumulativeProbability(0.770166228581069d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5006962852783409d + "'", double8 == 0.5006962852783409d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.007770551826479011d + "'", double11 == 0.007770551826479011d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(71);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3271.480315004861d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.786145061094437d + "'", double1 == 8.786145061094437d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 7.470823387293811E-10d, number3, true);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-6.588237319642563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8746624406502408d) + "'", double1 == (-1.8746624406502408d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.33665995534951054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3303363951458766d + "'", double1 == 0.3303363951458766d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.ulp(87.58746384397638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.470823387293811E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.acos((-4.002831361813725d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.signum((-68.38520399242948d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 2.167772400816433d, number19, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        long long14 = randomDataImpl1.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double21 = normalDistributionImpl18.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl18.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray25 = normalDistributionImpl18.sample(100);
//        double[] doubleArray27 = normalDistributionImpl18.sample((int) (byte) 10);
//        normalDistributionImpl18.reseedRandomGenerator(10L);
//        double double30 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        try {
//            double double33 = randomDataImpl1.nextF(0.0d, 46.24392217854551d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 40.955244732707136d + "'", double6 == 40.955244732707136d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.021127442416575826d + "'", double21 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 94.42533273286628d + "'", double30 == 94.42533273286628d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 34, (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.asin(5.288292537319899d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 100);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.14287653361550923d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.989810499564719d + "'", double1 == 0.989810499564719d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5579770166397535d, (java.lang.Number) 1, (java.lang.Number) (-0.16299078079570548d));
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, objArray27, convergenceException29, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable18, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray41 = outOfRangeException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable35, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException33, localizable35, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        int int13 = randomDataImpl1.nextHypergeometric(32, (int) (byte) 10, 0);
//        randomDataImpl1.reSeed();
//        try {
//            int int17 = randomDataImpl1.nextBinomial(22, 47.45540159179914d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 47.455 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 229.48681804323888d + "'", double6 == 229.48681804323888d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray18 = outOfRangeException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, "c4c8d87665b9caedfd1b6ff750", objArray18);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(29.42344462838165d, 0.7035022480356141d, 1.4033645483243735d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.268233064739847E-37d + "'", double4 == 4.268233064739847E-37d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double3 = randomDataImpl1.nextExponential((-3.175449884744881d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.175 is smaller than, or equal to, the minimum (0): mean (-3.175)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0, (java.lang.Number) (-68.35683674763067d), (java.lang.Number) (-43.081586862544455d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.158638853279167d, 0.6005946583803949d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.353633238285959d + "'", double2 == 2.353633238285959d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 77);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5578100438747242d + "'", double1 == 1.5578100438747242d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.log(20.15320800367033d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.003363481858225d + "'", double1 == 3.003363481858225d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 28, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException7.addSuppressed((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException11.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0d, objArray24, convergenceException26, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable13, objArray42);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "f6def14de9f5ab4f4ca8479bf5d517f2", objArray42);
        boolean boolean47 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number48 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.9065898968108168d + "'", number48.equals(0.9065898968108168d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, 92L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.2686379367523434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.special.Erf.erf(0.010482354258628446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011827636960030754d + "'", double1 == 0.011827636960030754d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.String str20 = outOfRangeException19.toString();
        java.lang.Number number21 = outOfRangeException19.getHi();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.601, 363.25] range: convergence failed" + "'", str20.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.601, 363.25] range: convergence failed"));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 363.25026563894824d + "'", number21.equals(363.25026563894824d));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
//        randomDataImpl1.reSeedSecure((long) 'a');
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) 10, 32);
//        double double11 = randomDataImpl1.nextT(2553.1481114157705d);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.10411203212163339d) + "'", double11 == (-0.10411203212163339d));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) (-184.92705276475087d), (java.lang.Number) 24L, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.floor(92.26158218674396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.0d + "'", double1 == 92.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        double double11 = normalDistributionImpl3.density((double) (-1L));
        double double12 = normalDistributionImpl3.getMean();
        double double14 = normalDistributionImpl3.cumulativeProbability((double) 25);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.003989223337860822d + "'", double11 == 0.003989223337860822d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5987063256829237d + "'", double14 == 0.5987063256829237d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.String str7 = outOfRangeException4.toString();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray17);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Number number25 = outOfRangeException23.getLo();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str7.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-169.0734029878853d) + "'", number25.equals((-169.0734029878853d)));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-31.37968648851352d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.641588833612778d, 0.14287653361550923d, 0.0d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.FastMath.max(34, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 77);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 56.84593885778443d, (java.lang.Number) 0.007770551826479011d, (java.lang.Number) 3.7816657475251736d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.atan2(20.723265836369194d, 0.022558322423987094d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5697077766748524d + "'", double2 == 1.5697077766748524d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.052393630276104E31d, (-31.403275395537243d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.052393630276103E31d + "'", double2 == 5.052393630276103E31d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.tanh(42.345147054658426d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.8875396689831697d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.74802278105165d + "'", double1 == 81.74802278105165d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-97.92378046101976d), (java.lang.Number) 0.9967924452521242d, false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray18);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(number25, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray29 = numberIsTooLargeException28.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable10, objArray29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) (-47.47333749536576d), (java.lang.Number) 0.5093651006252229d, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(115.09728129317894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.864314972142391d + "'", double1 == 4.864314972142391d);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double10 = randomDataImpl1.nextT(0.4116673457546182d);
//        double double12 = randomDataImpl1.nextExponential(8.924115048159364E7d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 134.92586840110943d + "'", double6 == 134.92586840110943d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.575539243570034d) + "'", double10 == (-1.575539243570034d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.927145616240397E8d + "'", double12 == 3.927145616240397E8d);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.log(147.54341206207422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.994122451541425d + "'", double1 == 4.994122451541425d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double17 = randomDataImpl1.nextBeta(87.58746384397638d, (double) 1.0f);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 146.7216466186438d + "'", double6 == 146.7216466186438d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 146.39302882230652d + "'", double13 == 146.39302882230652d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-159.58870109271902d) + "'", double14 == (-159.58870109271902d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9925911791165837d + "'", double17 == 0.9925911791165837d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable15 = maxIterationsExceededException14.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        normalDistributionImpl3.reseedRandomGenerator((long) '#');
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8622957433108482d + "'", double1 == 1.8622957433108482d);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        int[] intArray9 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) (short) 1);
//        double double12 = randomDataImpl1.nextF(0.003989223337860822d, (double) 35.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double17 = normalDistributionImpl16.sample();
//        double double18 = normalDistributionImpl16.getMean();
//        normalDistributionImpl16.reseedRandomGenerator(64L);
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        int[] intArray24 = randomDataImpl1.nextPermutation((int) 'a', 4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 103.76289542592326d + "'", double6 == 103.76289542592326d);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.936173255354128E-9d + "'", double12 == 1.936173255354128E-9d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-120.3782297348183d) + "'", double17 == (-120.3782297348183d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 14.651536272001948d + "'", double21 == 14.651536272001948d);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray18);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 34, (java.lang.Number) (-3380.198766790388d));
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10.0d, objArray40, convergenceException42, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable31, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0d, objArray57, convergenceException59, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable48, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray61);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("d37efa674a", objArray61);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, localizable10, objArray61);
        java.lang.Number number66 = outOfRangeException8.getHi();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 5729.5779513082325d + "'", number66.equals(5729.5779513082325d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        double double11 = normalDistributionImpl3.density((double) (-1L));
        double double13 = normalDistributionImpl3.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.003989223337860822d + "'", double11 == 0.003989223337860822d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        normalDistributionImpl3.reseedRandomGenerator((long) 10);
        double[] doubleArray14 = normalDistributionImpl3.sample((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        java.lang.Class<?> wildcardClass9 = normalDistributionImpl3.getClass();
        double double10 = normalDistributionImpl3.getMean();
        double double12 = normalDistributionImpl3.density(44.64514687179607d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0036110085238977574d + "'", double12 == 0.0036110085238977574d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.281159063192008d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double11 = randomDataImpl1.nextBeta((double) 1.0f, (double) 1);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(1, 0, 77);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 77 is larger than the maximum (1): sample size (77) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-91.4919124220487d) + "'", double6 == (-91.4919124220487d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4832254524084042d + "'", double11 == 0.4832254524084042d);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.18259255427222398d, 1.0091616062506952d, (-0.04258912510058354d), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (97) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, objArray27, convergenceException29, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable18, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray41 = outOfRangeException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable35, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException33, localizable35, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException52);
        java.lang.Object[] objArray54 = convergenceException53.getArguments();
        java.lang.String str55 = convergenceException53.getPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{0}" + "'", str55.equals("{0}"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray18 = mathException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        mathException19.addSuppressed((java.lang.Throwable) convergenceException24);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.14650887609631272d), (java.lang.Number) 4.15105023781094d, (java.lang.Number) (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.770166228581069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0207362104730586d + "'", double1 == 1.0207362104730586d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(27.44750970086492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.447509700864924d + "'", double1 == 27.447509700864924d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.0d + "'", double1 == 34.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9470343583194655d, 146.7216466186438d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9470343583194656d + "'", double2 == 0.9470343583194656d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 100.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, number1, (java.lang.Number) 33.220884553971885d);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double11 = randomDataImpl1.nextGamma(5.298342365610589d, 1.0d);
//        long long14 = randomDataImpl1.nextLong((long) (byte) 0, (long) 21);
//        double double17 = randomDataImpl1.nextUniform(0.0d, 1.128379167095513E-9d);
//        try {
//            double double20 = randomDataImpl1.nextF((double) 16L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-113.68449323676275d) + "'", double6 == (-113.68449323676275d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.726369000956119d + "'", double11 == 3.726369000956119d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.470823387293811E-10d + "'", double17 == 7.470823387293811E-10d);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double7 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        randomDataImpl2.reSeedSecure((long) (byte) 0);
//        int int12 = randomDataImpl2.nextInt((-1), 0);
//        long long15 = randomDataImpl2.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double22 = normalDistributionImpl19.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl19.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray26 = normalDistributionImpl19.sample(100);
//        double[] doubleArray28 = normalDistributionImpl19.sample((int) (byte) 10);
//        normalDistributionImpl19.reseedRandomGenerator(10L);
//        double double31 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        double double32 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        randomDataImpl0.reSeedSecure((long) 12);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-113.001547716213d) + "'", double7 == (-113.001547716213d));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.021127442416575826d + "'", double22 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray26);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 72.57928328815686d + "'", double31 == 72.57928328815686d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-104.0978549266288d) + "'", double32 == (-104.0978549266288d));
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextGaussian((double) ' ', (double) 52);
//        randomDataImpl1.reSeed(0L);
//        try {
//            int int19 = randomDataImpl1.nextBinomial(12, 5.3204824060079865E11d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 532,048,240,600.799 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-103.98212281893039d) + "'", double6 == (-103.98212281893039d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 50.1849862309639d + "'", double14 == 50.1849862309639d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-48.68536463578576d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.962339795355212E20d) + "'", double1 == (-6.962339795355212E20d));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        int int14 = randomDataImpl1.nextHypergeometric(32, 19, 0);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-105.30208550235649d) + "'", double6 == (-105.30208550235649d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.ulp(42.345147054658426d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-69.26051228825149d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0d, objArray28, convergenceException30, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable19, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35, localizable37, objArray38);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray53);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException(number60, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray64 = numberIsTooLargeException63.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable45, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable17, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable67 = maxIterationsExceededException66.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNull(localizable67);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 34, (double) 87L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.00000000000001d + "'", double2 == 34.00000000000001d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 1.6308214017997043d, (java.lang.Number) 2.1685525535511587d, true);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10.0d, objArray41, convergenceException43, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0d, objArray59, convergenceException61, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable50, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("hi!", objArray63);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException46, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable0, localizable13, objArray63);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(throwable0);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7035022480356141d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6555333590376314d + "'", double1 == 0.6555333590376314d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-32.277302845186895d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(8.465870199742896E161d, (-0.9999999999999998d), (double) (byte) 10, 77);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
//        randomDataImpl1.reSeedSecure(0L);
//        long long9 = randomDataImpl1.nextLong((long) 4, (long) 28);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 23L + "'", long9 == 23L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 77);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-2789.4659176859964d), (java.lang.Number) 92.26158218674396d, (java.lang.Number) 0.7229290946355417d);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        long long17 = randomDataImpl1.nextSecureLong((long) 52, 64L);
//        try {
//            long long20 = randomDataImpl1.nextLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-195.2994912606275d) + "'", double6 == (-195.2994912606275d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-194.8479136603728d) + "'", double13 == (-194.8479136603728d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-56.393899694639984d) + "'", double14 == (-56.393899694639984d));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60L + "'", long17 == 60L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "d37efa674a", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray38);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, localizable30, objArray41);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        randomDataImpl1.reSeedSecure(16L);
//        randomDataImpl1.reSeedSecure((long) (short) 0);
//        try {
//            double double15 = randomDataImpl1.nextBeta((-0.23866189121683237d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.269");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-160.16764037908106d) + "'", double6 == (-160.16764037908106d));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5574077246549023d);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.cosh(42.3511618545047d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.23550896186198374E18d + "'", double1 == 1.23550896186198374E18d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.floor(17.568997884802346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.0d + "'", double1 == 17.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 69L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 47.45540159179914d, (java.lang.Number) 69.05051438273028d, true);
        convergenceException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException19.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 19);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19.0f + "'", float2 == 19.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.35151428327459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6276127056362188d + "'", double1 == 0.6276127056362188d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.exp(77.5169141017528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6255997255601596E33d + "'", double1 == 4.6255997255601596E33d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.FastMath.max(9223372036854775807L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.4728309560445906E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.388039421150388E26d + "'", double1 == 8.388039421150388E26d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.14650887609631272d), (double) 77L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0019027103804403938d) + "'", double2 == (-0.0019027103804403938d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.09927014223709542d, (java.lang.Number) 2.1685525535511587d, number2);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray5 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.09927014223709542d + "'", number4.equals(0.09927014223709542d));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.4210854715202004E-14d, 77.5169141017528d, 5.356051485998998d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.9134305434275405E-50d + "'", double4 == 3.9134305434275405E-50d);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        java.lang.String str10 = randomDataImpl1.nextHexString((int) (byte) 100);
//        double double13 = randomDataImpl1.nextBeta(2.353633238285959d, (double) 100L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 116.88552277549617d + "'", double6 == 116.88552277549617d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e64a1bff5376b8f98e80f5d84ec16bcccf9b40" + "'", str10.equals("33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e64a1bff5376b8f98e80f5d84ec16bcccf9b40"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0059207404998706786d + "'", double13 == 0.0059207404998706786d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        java.lang.String str19 = mathException17.getPattern();
        java.lang.Throwable[] throwableArray20 = mathException17.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        double double12 = randomDataImpl1.nextGaussian(572.9577951308232d, (double) 20L);
//        randomDataImpl1.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 132.78304932605494d + "'", double6 == 132.78304932605494d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 561.6985675484794d + "'", double12 == 561.6985675484794d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        double double11 = normalDistributionImpl3.density((double) (-1L));
        double double13 = normalDistributionImpl3.cumulativeProbability(107.70561330707827d);
        try {
            double double15 = normalDistributionImpl3.inverseCumulativeProbability((double) 71.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 71 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.003989223337860822d + "'", double11 == 0.003989223337860822d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8592724055028231d + "'", double13 == 0.8592724055028231d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooSmallException: 0.504 is smaller than, or equal to, the minimum (0.2): 0.504 out of [0.2, {2}] range", objArray1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1, localizable3, objArray4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray19);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(number26, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray30 = numberIsTooLargeException29.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable11, objArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 5.356051485998998d, (java.lang.Number) 0.539827837277029d);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.09927014223709542d, (java.lang.Number) 2.1685525535511587d, number38);
        java.lang.Number number40 = outOfRangeException39.getArgument();
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException41.addSuppressed((java.lang.Throwable) outOfRangeException50);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException41.getGeneralPattern();
        java.lang.Number number53 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, number53, number54, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException39, localizable52, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable11, objArray64);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0.09927014223709542d + "'", number40.equals(0.09927014223709542d));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray64);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.tanh(155.73628358382308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.special.Erf.erf(8.786145061094437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.4116673457546182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.478633993361739d) + "'", double1 == (-2.478633993361739d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double2 = org.apache.commons.math.util.FastMath.min(8.786145061094437d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.643774567583453d, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException4.addSuppressed((java.lang.Throwable) outOfRangeException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = outOfRangeException8.getGeneralPattern();
        java.lang.String str11 = outOfRangeException8.toString();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException8.addSuppressed((java.lang.Throwable) outOfRangeException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray35 = outOfRangeException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable29, objArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 1.6680439019765374d);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str11.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.special.Erf.erf(0.4840352766869618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5063589762203976d + "'", double1 == 0.5063589762203976d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 27, (long) 26);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double9 = randomDataImpl1.nextWeibull(5.298342365610589d, (double) 100.0f);
//        try {
//            int int12 = randomDataImpl1.nextSecureInt((int) '4', 25);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (25): lower bound (52) must be strictly less than upper bound (25)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.76408140278606d + "'", double6 == 81.76408140278606d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 86.41514716154728d + "'", double9 == 86.41514716154728d);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 1);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        normalDistributionImpl3.reseedRandomGenerator((long) 23);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) (-1), true);
        java.lang.Object[] objArray20 = numberIsTooSmallException19.getArguments();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(number28, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable27, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 0.9967924452521242d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 0.5039893563146316d, (java.lang.Number) 0.20023056282962837d, false);
        java.lang.String str40 = numberIsTooSmallException39.toString();
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException39.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 363.25026563894824d + "'", number20.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.6005946583803949d + "'", number21.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.504 is smaller than, or equal to, the minimum (0.2): 0.504 out of [0.2, {2}] range" + "'", str40.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.504 is smaller than, or equal to, the minimum (0.2): 0.504 out of [0.2, {2}] range"));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.tanh(343.1826665480668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.max(565.3742883190779d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 565.3742883190779d + "'", double2 == 565.3742883190779d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException0.getGeneralPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, number12, (java.lang.Number) 26.897608610330366d, false);
        java.lang.Number number16 = numberIsTooSmallException15.getMin();
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 26.897608610330366d + "'", number16.equals(26.897608610330366d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5234086996188485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6877709597556378d + "'", double1 == 0.6877709597556378d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double10 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + Double.NEGATIVE_INFINITY + "'", double10 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number7 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 23, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double11 = randomDataImpl1.nextGamma(5.298342365610589d, 1.0d);
//        long long14 = randomDataImpl1.nextLong((long) (byte) 0, (long) 21);
//        double double17 = randomDataImpl1.nextUniform(0.0d, 1.128379167095513E-9d);
//        double double20 = randomDataImpl1.nextCauchy(1.0091616062506952d, 0.2686379367523434d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 93.25845060024487d + "'", double6 == 93.25845060024487d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.726369000956119d + "'", double11 == 3.726369000956119d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.470823387293811E-10d + "'", double17 == 7.470823387293811E-10d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.936973696252411d + "'", double20 == 0.936973696252411d);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5039893563146316d, (-0.23866189121683237d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1776620491309495d + "'", double2 == 1.1776620491309495d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomGenerator randomGenerator1 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl2 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double7 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        randomDataImpl2.reSeedSecure((long) (byte) 0);
//        int int12 = randomDataImpl2.nextInt((-1), 0);
//        long long15 = randomDataImpl2.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double22 = normalDistributionImpl19.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl19.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray26 = normalDistributionImpl19.sample(100);
//        double[] doubleArray28 = normalDistributionImpl19.sample((int) (byte) 10);
//        normalDistributionImpl19.reseedRandomGenerator(10L);
//        double double31 = randomDataImpl2.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        double double32 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        try {
//            double double34 = normalDistributionImpl19.inverseCumulativeProbability(107.70561330707827d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 107.706 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 93.39728232999843d + "'", double7 == 93.39728232999843d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.021127442416575826d + "'", double22 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray26);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 111.12577447557115d + "'", double31 == 111.12577447557115d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 91.9140831738748d + "'", double32 == 91.9140831738748d);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Number number8 = outOfRangeException4.getLo();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.7453292519943295d + "'", number7.equals(1.7453292519943295d));
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        randomDataImpl1.reSeed((long) 0);
        int int9 = randomDataImpl1.nextZipf(12, 1.2924966677897853d);
        randomDataImpl1.reSeed((long) (byte) 100);
        int[] intArray14 = randomDataImpl1.nextPermutation((int) '#', 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(intArray14);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double11 = randomDataImpl1.nextGamma(5.298342365610589d, 1.0d);
//        try {
//            double double14 = randomDataImpl1.nextBeta((double) 99L, (-197.3915283557718d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.012");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 67.54636539710647d + "'", double6 == 67.54636539710647d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.726369000956119d + "'", double11 == 3.726369000956119d);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        long long14 = randomDataImpl1.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double21 = normalDistributionImpl18.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl18.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray25 = normalDistributionImpl18.sample(100);
//        double[] doubleArray27 = normalDistributionImpl18.sample((int) (byte) 10);
//        normalDistributionImpl18.reseedRandomGenerator(10L);
//        double double30 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl35 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double38 = normalDistributionImpl35.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl35.reseedRandomGenerator((long) (short) 0);
//        double double41 = normalDistributionImpl35.getMean();
//        double double43 = normalDistributionImpl35.density((double) (-1L));
//        double double45 = normalDistributionImpl35.cumulativeProbability(107.70561330707827d);
//        double double46 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl35);
//        try {
//            double double49 = normalDistributionImpl35.cumulativeProbability(5.052393630276103E31d, (-100.78729148515268d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 66.95516567953987d + "'", double6 == 66.95516567953987d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.021127442416575826d + "'", double21 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-43.861072760229845d) + "'", double30 == (-43.861072760229845d));
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.021127442416575826d + "'", double38 == 0.021127442416575826d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.003989223337860822d + "'", double43 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.8592724055028231d + "'", double45 == 0.8592724055028231d);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 67.01136514301665d + "'", double46 == 67.01136514301665d);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException20, "", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("d37efa674a", objArray29);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.9065898968108168d + "'", number5.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.9065898968108168d + "'", number6.equals(0.9065898968108168d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 19);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.332204510175204d + "'", double1 == 3.332204510175204d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.643774567583453d, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException6.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException10.getGeneralPattern();
        java.lang.String str13 = outOfRangeException10.toString();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray23);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException10.addSuppressed((java.lang.Throwable) outOfRangeException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray37 = outOfRangeException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException5, localizable31, objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(0, "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray37);
        int int40 = maxIterationsExceededException39.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str13.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.9065898968108168d + "'", number7.equals(0.9065898968108168d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow((-68.08478954698403d), (-68.35683674763067d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(number28, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable27, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 0.9967924452521242d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 92.26158218674396d, (java.lang.Number) 0.33665995534951054d, true);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 363.25026563894824d + "'", number20.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.6005946583803949d + "'", number21.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 100L);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable6, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (-159.58870109271902d));
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray34 = outOfRangeException33.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable28, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable6, objArray34);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextSecureInt(0, (int) (byte) 100);
//        double double9 = randomDataImpl1.nextUniform(0.0d, 7.530486572925153E34d);
//        int int12 = randomDataImpl1.nextInt(77, 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-8.488258296766674d) + "'", double3 == (-8.488258296766674d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 50 + "'", int6 == 50);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.7191741983868396E34d + "'", double9 == 2.7191741983868396E34d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 79 + "'", int12 == 79);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.23866189121683237d), (java.lang.Number) (-8.488258296766674d), false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray7 = outOfRangeException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable1, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray36 = outOfRangeException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable30, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable10, objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.17453292519943295d, number1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.17453292519943295d + "'", number5.equals(0.17453292519943295d));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(77.5169141017528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 77.51691410175282d + "'", double1 == 77.51691410175282d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextGamma((double) '4', 58.64496087462543d);
//        java.lang.Class<?> wildcardClass15 = randomDataImpl1.getClass();
//        int int18 = randomDataImpl1.nextPascal(11, 0.6555333590376314d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-158.64448999851876d) + "'", double6 == (-158.64448999851876d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2943.2884111393982d + "'", double14 == 2943.2884111393982d);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 23L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.744803445248903E9d + "'", double1 == 9.744803445248903E9d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.asinh(7.530486572925153E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.0d + "'", double1 == 81.0d);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double8 = randomDataImpl1.nextChiSquare((double) '4');
//        double double11 = randomDataImpl1.nextGaussian(42.3511618545047d, 0.4840352766869618d);
//        try {
//            double double14 = randomDataImpl1.nextWeibull(0.0d, 0.5412178608367032d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-162.05526567069725d) + "'", double6 == (-162.05526567069725d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.3204832196412d + "'", double8 == 52.3204832196412d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 42.036538395791396d + "'", double11 == 42.036538395791396d);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextCauchy(0.0d, (double) 1.0f);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-160.24543213671146d) + "'", double6 == (-160.24543213671146d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-160.65214178037138d) + "'", double13 == (-160.65214178037138d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 87.26193006952589d + "'", double14 == 87.26193006952589d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-5.829199290782603d) + "'", double18 == (-5.829199290782603d));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        int[] intArray9 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) (short) 1);
//        double double12 = randomDataImpl1.nextF(0.003989223337860822d, (double) 35.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double17 = normalDistributionImpl16.sample();
//        double double18 = normalDistributionImpl16.getMean();
//        normalDistributionImpl16.reseedRandomGenerator(64L);
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        double double24 = randomDataImpl1.nextUniform((-159.58870109271902d), 77.5169141017528d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-162.5581884982363d) + "'", double6 == (-162.5581884982363d));
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.7066705784412401E-9d + "'", double12 == 1.7066705784412401E-9d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-57.418875404260206d) + "'", double17 == (-57.418875404260206d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-11.135860137354802d) + "'", double21 == (-11.135860137354802d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-105.51326972309104d) + "'", double24 == (-105.51326972309104d));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.332204510175204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4660765372061442d + "'", double1 == 1.4660765372061442d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) (short) 10);
        double double6 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.539827837277029d + "'", double5 == 0.539827837277029d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2048.0d + "'", double1 == 2048.0d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            double double6 = randomDataImpl1.nextWeibull((-4.002831361813725d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.003 is smaller than, or equal to, the minimum (0): shape (-4.003)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.975535605150895d + "'", double3 == 12.975535605150895d);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 69L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 69.0f + "'", float1 == 69.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException1.addSuppressed((java.lang.Throwable) outOfRangeException5);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException1.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException1.getGeneralPattern();
        java.lang.Number number13 = null;
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, number14, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 19, (java.lang.Number) 1.3332436050969099d, true);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException21.addSuppressed((java.lang.Throwable) outOfRangeException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0d, objArray38, convergenceException40, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable29, objArray42);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47, "", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable27, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable12, objArray56);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("33ec59c443a207f097a0a4831e7fcb0ce9defe29cc3b4d191a331bea8c45b7e64a1bff5376b8f98e80f5d84ec16bcccf9b40", objArray56);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.9065898968108168d, Double.NaN);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.cumulativeProbability(0.5039893563146316d);
        try {
            double[] doubleArray8 = normalDistributionImpl3.sample((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.019416865714155625d + "'", double4 == 0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7035022480356141d + "'", double6 == 0.7035022480356141d);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        randomDataImpl1.reSeed(0L);
//        double double16 = randomDataImpl1.nextUniform(0.7035022480356141d, (double) 69L);
//        int int19 = randomDataImpl1.nextSecureInt(0, 4);
//        try {
//            long long22 = randomDataImpl1.nextSecureLong(24L, (long) 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 24 is larger than, or equal to, the maximum (23): lower bound (24) must be strictly less than upper bound (23)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 250.00626073068346d + "'", double6 == 250.00626073068346d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 50.62604209536384d + "'", double16 == 50.62604209536384d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException0.getGeneralPattern();
        java.lang.Number number12 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, number12, number13, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 19, (java.lang.Number) 1.3332436050969099d, true);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = outOfRangeException24.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10.0d, objArray37, convergenceException39, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable28, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException46, "", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable26, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable11, objArray55);
        java.lang.Throwable[] throwableArray60 = convergenceException59.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray60);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.FastMath.pow(155.4349724162767d, 14.569070339568102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.488437440315975E31d + "'", double2 == 8.488437440315975E31d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(number28, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable27, objArray32);
        java.lang.Number number34 = outOfRangeException19.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 363.25026563894824d + "'", number20.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.6005946583803949d + "'", number21.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.6005946583803949d + "'", number34.equals(0.6005946583803949d));
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        long long14 = randomDataImpl1.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double21 = normalDistributionImpl18.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl18.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray25 = normalDistributionImpl18.sample(100);
//        double[] doubleArray27 = normalDistributionImpl18.sample((int) (byte) 10);
//        normalDistributionImpl18.reseedRandomGenerator(10L);
//        double double30 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl35 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double38 = normalDistributionImpl35.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl35.reseedRandomGenerator((long) (short) 0);
//        double double41 = normalDistributionImpl35.getMean();
//        double double43 = normalDistributionImpl35.density((double) (-1L));
//        double double45 = normalDistributionImpl35.cumulativeProbability(107.70561330707827d);
//        double double46 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl35);
//        normalDistributionImpl35.reseedRandomGenerator((long) ' ');
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 185.5825405261355d + "'", double6 == 185.5825405261355d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.021127442416575826d + "'", double21 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 91.76521667034638d + "'", double30 == 91.76521667034638d);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.021127442416575826d + "'", double38 == 0.021127442416575826d);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.003989223337860822d + "'", double43 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.8592724055028231d + "'", double45 == 0.8592724055028231d);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 180.89045952895526d + "'", double46 == 180.89045952895526d);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        long long14 = randomDataImpl1.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double21 = normalDistributionImpl18.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl18.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray25 = normalDistributionImpl18.sample(100);
//        double[] doubleArray27 = normalDistributionImpl18.sample((int) (byte) 10);
//        normalDistributionImpl18.reseedRandomGenerator(10L);
//        double double30 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        randomDataImpl1.reSeed();
//        double double33 = randomDataImpl1.nextT(0.2686379367523434d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 181.58665529515008d + "'", double6 == 181.58665529515008d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.021127442416575826d + "'", double21 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 35.95667043312821d + "'", double30 == 35.95667043312821d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4127.3547594020765d + "'", double33 == 4127.3547594020765d);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        java.lang.String str6 = convergenceException4.getPattern();
        java.lang.Object[] objArray7 = convergenceException4.getArguments();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable10, objArray11);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray26);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(number33, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray37 = numberIsTooLargeException36.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable18, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "{0}", objArray37);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.9065898968108168d + "'", number6.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number21 = outOfRangeException20.getHi();
        java.lang.Number number22 = outOfRangeException20.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str27 = outOfRangeException26.toString();
        org.apache.commons.math.exception.util.Localizable localizable28 = outOfRangeException26.getGeneralPattern();
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(number29, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray33 = numberIsTooLargeException32.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException20, localizable28, objArray33);
        java.lang.Object[] objArray35 = mathException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("f67a723814e136e3fb2465d8c7b7", objArray35);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 363.25026563894824d + "'", number21.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.6005946583803949d + "'", number22.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str27.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 100.0d, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(number28, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable27, objArray32);
        java.lang.Throwable throwable34 = null;
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException39.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException42.addSuppressed((java.lang.Throwable) outOfRangeException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = outOfRangeException46.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0d, objArray59, convergenceException61, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable50, objArray63);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable50, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException68, "", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable48, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(throwable34, localizable41, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray77);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 363.25026563894824d + "'", number20.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.6005946583803949d + "'", number21.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray77);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5697077766748524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1621787670141563d + "'", double1 == 1.1621787670141563d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 26);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
//        double double7 = randomDataImpl1.nextGaussian((double) (short) 0, 1.0d);
//        java.lang.String str9 = randomDataImpl1.nextHexString((int) (byte) 10);
//        try {
//            int int12 = randomDataImpl1.nextBinomial((int) (short) 0, (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5938042611411771d + "'", double7 == 0.5938042611411771d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0981fcef99" + "'", str9.equals("0981fcef99"));
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0d, objArray18, convergenceException20, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable9, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("hi!", objArray22);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException24, "d37efa674a", objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable6, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray48);
        org.apache.commons.math.exception.util.Localizable localizable51 = maxIterationsExceededException50.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable51, (java.lang.Number) 1.6308214017997043d, (java.lang.Number) 2.1685525535511587d, true);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray70 = new java.lang.Object[] { 10.0d, objArray66, convergenceException68, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable57, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable75 = convergenceException74.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable77, objArray84);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray88 = new java.lang.Object[] { 10.0d, objArray84, convergenceException86, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(localizable75, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("hi!", objArray88);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException71, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException37, "a92b495c90", objArray88);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        randomDataImpl1.reSeedSecure((long) 35);
        randomDataImpl1.reSeed();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 17, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-3.175449884744881d), 0.0d, (double) 35.0f, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        normalDistributionImpl3.reseedRandomGenerator((long) 10);
        normalDistributionImpl3.reseedRandomGenerator((long) 79);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, 16.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double8 = randomDataImpl1.nextChiSquare((double) '4');
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(11, 52, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-8.606867317970854d) + "'", double6 == (-8.606867317970854d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 53.93627729227434d + "'", double8 == 53.93627729227434d);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((-3380.198766790388d));
        double[] doubleArray4 = normalDistributionImpl0.sample(25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.ulp(57.55504356934539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(81.74802278105165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.34002687767925d + "'", double1 == 4.34002687767925d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.20023056282962837d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19761724504543673d + "'", double1 == 0.19761724504543673d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 69.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 69L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 69 + "'", int1 == 69);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.8414709848078964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.764725154011207d) + "'", double1 == (-0.764725154011207d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.7191741983868396E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.434437030674964d + "'", double1 == 34.434437030674964d);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        int[] intArray9 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) (short) 1);
//        double double12 = randomDataImpl1.nextF(0.003989223337860822d, (double) 35.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double17 = normalDistributionImpl16.sample();
//        double double18 = normalDistributionImpl16.getMean();
//        normalDistributionImpl16.reseedRandomGenerator(64L);
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        randomDataImpl1.reSeedSecure((long) 52);
//        int[] intArray26 = randomDataImpl1.nextPermutation(20, (int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-24.073517381384274d) + "'", double6 == (-24.073517381384274d));
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-22.227655739729606d) + "'", double17 == (-22.227655739729606d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-160.18511861330754d) + "'", double21 == (-160.18511861330754d));
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable7, objArray8);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray23);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(number30, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray34 = numberIsTooLargeException33.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, "org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.601, 363.25] range: convergence failed", objArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((-1), "{0}", objArray34);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        double double10 = randomDataImpl1.nextT((double) 1L);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 1, 34);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-23.057686561537754d) + "'", double6 == (-23.057686561537754d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.8875396689831697d) + "'", double10 == (-0.8875396689831697d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 34 + "'", int13 == 34);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        double double13 = randomDataImpl1.nextGaussian(0.7685705204390633d, 0.2686379367523434d);
//        try {
//            int int16 = randomDataImpl1.nextSecureInt(77, 28);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 77 is larger than, or equal to, the maximum (28): lower bound (77) must be strictly less than upper bound (28)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-22.619775135054617d) + "'", double6 == (-22.619775135054617d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.1164073876581249d + "'", double13 == 1.1164073876581249d);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        double double11 = normalDistributionImpl3.density((double) (-1L));
        double double12 = normalDistributionImpl3.getMean();
        double double13 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.003989223337860822d + "'", double11 == 0.003989223337860822d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double11 = randomDataImpl1.nextGamma(5.298342365610589d, 1.0d);
//        long long14 = randomDataImpl1.nextLong((long) (byte) 0, (long) 21);
//        double double17 = randomDataImpl1.nextUniform(0.0d, 1.128379167095513E-9d);
//        try {
//            double double20 = randomDataImpl1.nextGamma((-7.0d), (-9.283209894535057d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -7 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-23.842431404897173d) + "'", double6 == (-23.842431404897173d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.726369000956119d + "'", double11 == 3.726369000956119d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 7.470823387293811E-10d + "'", double17 == 7.470823387293811E-10d);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.8597790185857428d, number19, false);
        java.lang.Number number22 = numberIsTooLargeException21.getMax();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 1.7453292519943295d, 5.838500553561399d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-11.135860137354802d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-34293.563297616965d) + "'", double1 == (-34293.563297616965d));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = normalDistributionImpl10.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl10.reseedRandomGenerator((long) (short) 0);
//        java.lang.Class<?> wildcardClass16 = normalDistributionImpl10.getClass();
//        double double17 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-19.1541722910298d) + "'", double6 == (-19.1541722910298d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.021127442416575826d + "'", double13 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-15.621941038091334d) + "'", double17 == (-15.621941038091334d));
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        java.lang.Class<?> wildcardClass2 = randomDataImpl1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.010482354258628446d, 1.922524670220843E61d, (double) 24, 60);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        randomDataImpl1.reSeedSecure(16L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.random.RandomGenerator randomGenerator12 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator12);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double18 = randomDataImpl13.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        randomDataImpl13.reSeedSecure((long) (byte) 0);
//        int int23 = randomDataImpl13.nextInt((-1), 0);
//        long long26 = randomDataImpl13.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl30 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double33 = normalDistributionImpl30.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl30.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray37 = normalDistributionImpl30.sample(100);
//        double[] doubleArray39 = normalDistributionImpl30.sample((int) (byte) 10);
//        normalDistributionImpl30.reseedRandomGenerator(10L);
//        double double42 = randomDataImpl13.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl30);
//        double double43 = randomDataImpl11.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl30);
//        double double44 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl30);
//        double double46 = normalDistributionImpl30.density((double) 19.0f);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-20.71174886789509d) + "'", double6 == (-20.71174886789509d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-20.84941463280823d) + "'", double18 == (-20.84941463280823d));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.021127442416575826d + "'", double33 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray37);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-38.713483901477495d) + "'", double42 == (-38.713483901477495d));
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-20.803520394566075d) + "'", double43 == (-20.803520394566075d));
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-61.60140274389526d) + "'", double44 == (-61.60140274389526d));
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.003918059711821211d + "'", double46 == 0.003918059711821211d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, objArray56, convergenceException58, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable47, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65, "", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable45, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, objArray74);
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException78.getSpecificPattern();
        java.lang.Class<?> wildcardClass80 = convergenceException78.getClass();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNull(localizable79);
        org.junit.Assert.assertNotNull(wildcardClass80);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) 1, 17.0d, (-100.93666598905612d), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 17 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.643774567583453d, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException8.addSuppressed((java.lang.Throwable) outOfRangeException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException12.getGeneralPattern();
        java.lang.String str15 = outOfRangeException12.toString();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray25);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray39 = outOfRangeException38.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, localizable33, objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException(0, "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException(0, "convergence failed", objArray39);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str15.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray39);
    }
}

