import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 0, (double) 100.0f, (double) 1L, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.asinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 1L);
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability((double) (byte) 10, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5039893563146316d + "'", double5 == 0.5039893563146316d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.rint(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.32584491663629733d + "'", double0 == 0.32584491663629733d);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.5574077246549023d), Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5574077246549023d) + "'", double2 == (-1.5574077246549023d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019416865714155625d + "'", double1 == 0.019416865714155625d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-6.588237319642563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.25026563894824d + "'", double1 == 363.25026563894824d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(34.411539123298105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6005946583803949d + "'", double1 == 0.6005946583803949d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.String str1 = mathException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.ulp(60.42501668672861d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            int int17 = randomDataImpl1.nextZipf(0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-186.3437152068701d) + "'", double6 == (-186.3437152068701d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-186.08944452487123d) + "'", double13 == (-186.08944452487123d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-19.91140190966823d) + "'", double14 == (-19.91140190966823d));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.0f, 34.411539123298105d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            double double6 = randomDataImpl1.nextUniform(3.141592653589793d, (-47.47333749536576d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3.142 is larger than, or equal to, the maximum (-47.473): lower bound (3.142) must be strictly less than upper bound (-47.473)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.453769437858822d + "'", double3 == 12.453769437858822d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5.298342365610589d, (double) (byte) 10, (double) 1.0f, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 10 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 100, 1.0E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1.0f, (-178.63269976766173d), 100.0d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException17.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-18.522474246984295d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "d37efa674a", objArray19);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.atan2(100.0d, 363.25026563894824d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2686379367523434d + "'", double2 == 0.2686379367523434d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d, (double) (short) 0, (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.ulp(205.10770177750956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        try {
//            double double13 = randomDataImpl1.nextGamma((-169.0734029878853d), 0.021127442416575826d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -169.073 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 143.8594918766832d + "'", double6 == 143.8594918766832d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a584acce4f" + "'", str10.equals("a584acce4f"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-47.47333749536576d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        java.lang.Class<?> wildcardClass18 = mathException17.getClass();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (-169.0734029878853d), false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-6.588237319642563d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.special.Erf.erf(141.8044771078766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.acos((-181.93987645118537d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        long long12 = randomDataImpl1.nextSecureLong(0L, (long) 35);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15.593245408153793d) + "'", double6 == (-15.593245408153793d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 47L + "'", long9 == 47L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948681d + "'", double1 == 1.5707963267948681d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.781665747525173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5579770166397535d + "'", double1 == 1.5579770166397535d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000003E-9d + "'", double1 == 1.0000000000000003E-9d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '#', (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2924966677897853d + "'", double2 == 1.2924966677897853d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            int int11 = randomDataImpl1.nextSecureInt(35, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (0): lower bound (35) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-18.875246131885557d) + "'", double6 == (-18.875246131885557d));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.0d, Double.POSITIVE_INFINITY, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            double double6 = randomDataImpl1.nextBeta((-47.47333749536576d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.977");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-41.38023663602522d) + "'", double3 == (-41.38023663602522d));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double16 = randomDataImpl1.nextExponential((-0.16299078079570548d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.163 is smaller than, or equal to, the minimum (0): mean (-0.163)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-200.35094064779022d) + "'", double6 == (-200.35094064779022d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-200.017846945788d) + "'", double13 == (-200.017846945788d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 96.32809905742133d + "'", double14 == 96.32809905742133d);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0000000000000003E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double2 = org.apache.commons.math.util.FastMath.pow((-169.0734029878853d), 0.5039893563146316d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        try {
//            int int13 = randomDataImpl1.nextBinomial((int) (byte) 0, (-181.93987645118537d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -181.94 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 163.9668566706043d + "'", double6 == 163.9668566706043d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a7027510c3" + "'", str10.equals("a7027510c3"));
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        try {
//            double double13 = randomDataImpl1.nextBeta(46.24392217854551d, (-169.0734029878853d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.775");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 161.18874420492037d + "'", double6 == 161.18874420492037d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b3e73d66ec" + "'", str10.equals("b3e73d66ec"));
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        try {
//            double double11 = randomDataImpl1.nextChiSquare((-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.5 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 180.10728653985285d + "'", double6 == 180.10728653985285d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 67L + "'", long9 == 67L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.2924966677897853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.022558322423987094d + "'", double1 == 0.022558322423987094d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10.0d, objArray13, convergenceException15, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable4, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray17);
        java.lang.Object[] objArray20 = mathException19.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "{0}", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0000000000000003E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000003E-9d + "'", double1 == 1.0000000000000003E-9d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number16 = outOfRangeException15.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-169.0734029878853d) + "'", number16.equals((-169.0734029878853d)));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math.util.FastMath.min((-18.522474246984295d), (-16.207239058423028d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-18.522474246984295d) + "'", double2 == (-18.522474246984295d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0L, 363.25026563894824d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, objArray27, convergenceException29, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable18, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) 1.2924966677897853d, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) -1, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.691649480399091E41d + "'", double1 == 4.691649480399091E41d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.35151428327459d + "'", double1 == 2.35151428327459d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-178.63269976766173d), (-18.522474246984295d), (double) 92L, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.cosh(141.8044771078766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9225246702208428E61d + "'", double1 == 1.9225246702208428E61d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.6005946583803949d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6005946583803949d + "'", double2 == 0.6005946583803949d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long1 = org.apache.commons.math.util.FastMath.abs(73L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 73L + "'", long1 == 73L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078964d) + "'", double1 == (-0.8414709848078964d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        long long2 = org.apache.commons.math.util.FastMath.min(69L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100, 57.52854145469d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        try {
//            double double9 = randomDataImpl1.nextBeta(22025.465794806718d, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.835");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 59.90301364412207d + "'", double6 == 59.90301364412207d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 73L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8875396689831697d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4116673457546182d + "'", double1 == 0.4116673457546182d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.4116673457546182d, (double) 0.0f, 0.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long1 = org.apache.commons.math.util.FastMath.round((double) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 205.10770177750956d, (java.lang.Number) 0.0d, true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0000000000000003E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795E-5d + "'", double1 == 3.1622776601683795E-5d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5039893563146316d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        double[] doubleArray12 = normalDistributionImpl3.sample((int) (byte) 10);
        double double15 = normalDistributionImpl3.cumulativeProbability((double) '4', 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.14287653361550923d + "'", double15 == 0.14287653361550923d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.rint((-6.588237319642563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.0d) + "'", double1 == (-7.0d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.9999999999999999d), 46.24392217854551d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException9.getSpecificPattern();
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.atan2(99.99999999999999d, (-68.08478954698403d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1685525535511587d + "'", double2 == 2.1685525535511587d);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        try {
//            int int14 = randomDataImpl1.nextSecureInt((int) ' ', (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (10): lower bound (32) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.54949691454093d + "'", double6 == 47.54949691454093d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 92L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 100, number1, false);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            double double10 = randomDataImpl1.nextT(4.9E-324d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument -1 p = 0.269");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 50.92092129830013d + "'", double6 == 50.92092129830013d);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        long long12 = randomDataImpl1.nextSecureLong(0L, (long) 35);
//        try {
//            double double15 = randomDataImpl1.nextBeta((-169.0734029878853d), (double) 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.42");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 31.652163011174704d + "'", double6 == 31.652163011174704d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 63L + "'", long9 == 63L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 16L + "'", long12 == 16L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.022558322423987094d, 46.24392217854551d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        try {
//            long long11 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 162.52339476288125d + "'", double6 == 162.52339476288125d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 90L + "'", long9 == 90L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.2924966677897853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextZipf((int) (byte) 100, 1.0E-9d);
//        try {
//            double double8 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.33849886780905d + "'", double3 == 8.33849886780905d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (short) 100, 0.5772156649015329d, 3.1622776601683795E-5d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.723265836369194d + "'", double1 == 20.723265836369194d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double2 = org.apache.commons.math.util.FastMath.atan2(46.24392217854551d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0d, objArray12, convergenceException14, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable3, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getSpecificPattern();
        java.lang.String str20 = convergenceException18.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0d, objArray31, convergenceException33, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable22, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40, "", objArray49);
        java.lang.Object[] objArray52 = new java.lang.Object[] { str20, mathException51 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("d37efa674a", objArray52);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        double double11 = randomDataImpl1.nextExponential((double) 10L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 79.68631081516308d + "'", double6 == 79.68631081516308d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 99L + "'", long9 == 99L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.6308214017997043d + "'", double11 == 1.6308214017997043d);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.1685525535511587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08011580306857291d + "'", double1 == 0.08011580306857291d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 1.3332436050969099d, (java.lang.Number) 2.6881171418161356E43d);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            double double10 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 85.62709218926771d + "'", double6 == 85.62709218926771d);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5579770166397535d, 1.1311311101032817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5412178608367032d + "'", double2 == 0.5412178608367032d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, objArray56, convergenceException58, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable47, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65, "", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable45, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, objArray74);
        java.lang.Number number79 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException(number79, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray83 = numberIsTooLargeException82.getArguments();
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable6, objArray83);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.util.FastMath.atan2(87.58746384397638d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 12, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(205.10770177750956d, 100.16435195066585d, 100.55567426575568d, 71);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NEGATIVE_INFINITY, 47.45540159179914d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("hi!", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getSpecificPattern();
        java.lang.String str19 = convergenceException17.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0d, objArray32, convergenceException34, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable23, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("hi!", objArray36);
        java.lang.Object[] objArray39 = mathException38.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.601, 363.25] range: convergence failed", objArray39);
        java.lang.String str41 = convergenceException17.toString();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math.ConvergenceException: hi!" + "'", str41.equals("org.apache.commons.math.ConvergenceException: hi!"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-142.47141063084348d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5412178608367032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        try {
//            int int7 = randomDataImpl1.nextHypergeometric(0, 0, 23);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6811018225498465d) + "'", double3 == (-0.6811018225498465d));
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.util.FastMath.max(60.42501668672861d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.42501668672861d + "'", double2 == 60.42501668672861d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(number1, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray5 = numberIsTooLargeException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 100 out of [0.601, 363.25] range: convergence failed", objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) (byte) -1, 100.16435195066585d, (int) '#');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6005946583803949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010482354258628446d + "'", double1 == 0.010482354258628446d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9377047211159066E-18d + "'", double1 == 1.9377047211159066E-18d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.String str11 = outOfRangeException9.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str11.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextZipf((int) (byte) 100, 1.0E-9d);
//        try {
//            int[] intArray9 = randomDataImpl1.nextPermutation(100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6398743459983136d) + "'", double3 == (-0.6398743459983136d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 78 + "'", int6 == 78);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.exp(79.68631081516308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0487883088955243E34d + "'", double1 == 4.0487883088955243E34d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        try {
//            java.lang.String str13 = randomDataImpl1.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-47.756127882954196d) + "'", double6 == (-47.756127882954196d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        try {
//            double double13 = randomDataImpl1.nextCauchy(34.411539123298105d, (-169.0734029878853d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -169.073 is smaller than, or equal to, the minimum (0): scale (-169.073)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-65.7912401824211d) + "'", double6 == (-65.7912401824211d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a1601cc78" + "'", str10.equals("1a1601cc78"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0.907)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0.907)"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5574077246549023d, 46.24392217854551d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 46.24392217854551d + "'", double2 == 46.24392217854551d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long1 = org.apache.commons.math.util.FastMath.round(0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9065898968108168d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.18259255427222398d + "'", double2 == 0.18259255427222398d);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextSecureInt(0, (int) (byte) 100);
//        try {
//            long long9 = randomDataImpl1.nextSecureLong(99L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 99 is larger than, or equal to, the maximum (-1): lower bound (99) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.065033964706973d) + "'", double3 == (-1.065033964706973d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 44 + "'", int6 == 44);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        try {
//            long long13 = randomDataImpl1.nextPoisson((-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-71.33039739697756d) + "'", double6 == (-71.33039739697756d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.2686379367523434d, (-6.588237319642563d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.0487883088955243E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.exp((-169.0734029878853d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.735545630309108E-74d + "'", double1 == 3.735545630309108E-74d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-181.93987645118537d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(205.10770177750956d, 0.0d, (-0.16299078079570548d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.tan((-69.26051228825149d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14650887609631272d) + "'", double1 == (-0.14650887609631272d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.special.Erf.erf((-68.08478954698403d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int2 = org.apache.commons.math.util.FastMath.max(23, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.3332436050969099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.log10((-142.47141063084348d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        java.lang.String str16 = convergenceException15.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.ConvergenceException: convergence failed" + "'", str16.equals("org.apache.commons.math.ConvergenceException: convergence failed"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        long long1 = org.apache.commons.math.util.FastMath.round(0.539827837277029d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double9 = normalDistributionImpl3.getMean();
        double double10 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double8 = randomDataImpl1.nextChiSquare((double) '4');
//        try {
//            double double11 = randomDataImpl1.nextBeta((double) 19, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.845");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-85.634038789039d) + "'", double6 == (-85.634038789039d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 48.508214753892354d + "'", double8 == 48.508214753892354d);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612778d + "'", double1 == 4.641588833612778d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 71, (double) 12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4033645483243735d + "'", double2 == 1.4033645483243735d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.2924966677897853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8597790185857428d + "'", double1 == 0.8597790185857428d);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        try {
//            double double11 = randomDataImpl1.nextBeta(3.141592653589793d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.269");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-87.99067240956519d) + "'", double6 == (-87.99067240956519d));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1712659507785417d + "'", double1 == 1.1712659507785417d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        double double8 = normalDistributionImpl3.cumulativeProbability(0.17453292519943295d);
        double double9 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5006962852783409d + "'", double8 == 0.5006962852783409d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong(10L, (long) 'a');
//        try {
//            double double6 = randomDataImpl0.nextF((double) (short) 0, 47.45540159179914d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 66L + "'", long3 == 66L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-4.002831361813725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 124744.07957402238d + "'", double1 == 124744.07957402238d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextGamma((-1.5574077246549023d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.557 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextZipf((int) (byte) 100, 1.0E-9d);
//        try {
//            double double8 = randomDataImpl1.nextT((-4.002831361813725d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.003 is smaller than, or equal to, the minimum (0): degrees of freedom (-4.003)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.9224953173457348d) + "'", double3 == (-0.9224953173457348d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 37 + "'", int6 == 37);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        try {
            java.lang.String str6 = randomDataImpl1.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0d, objArray15, convergenceException17, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable6, objArray19);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException24, "", objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray33);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100L, (-0.7615941559557649d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextUniform((double) '#', (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (32): lower bound (35) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.max(142.1736662230781d, (-52.034448565839455d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 142.1736662230781d + "'", double2 == 142.1736662230781d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-69.26051228825149d), 10.0d, (double) 92L, (int) 'a');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.08011580306857291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9967924452521242d + "'", double1 == 0.9967924452521242d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5039893563146316d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-144.93046919915895d), (-100.712694703437d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -100.713 is smaller than, or equal to, the minimum (0): standard deviation (-100.713)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
//        double double7 = randomDataImpl1.nextGaussian((double) (short) 0, 1.0d);
//        try {
//            double double10 = randomDataImpl1.nextBeta(0.0d, (-0.8875396689831697d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.71");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4024769249785397d) + "'", double7 == (-0.4024769249785397d));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 92L, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.09927014223709542d, (double) 64L, (double) 92L, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 64 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.special.Erf.erf(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.128379167095513E-9d + "'", double1 == 1.128379167095513E-9d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-18.522474246984295d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 73L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.052393630276104E31d + "'", double1 == 5.052393630276104E31d);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        java.lang.String str13 = randomDataImpl1.nextHexString((int) ' ');
//        try {
//            int[] intArray16 = randomDataImpl1.nextPermutation((int) ' ', (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (32): permutation size (52) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 25.73161213444838d + "'", double6 == 25.73161213444838d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "55ef27d09f7cd7a6f41451442a92dbbe" + "'", str13.equals("55ef27d09f7cd7a6f41451442a92dbbe"));
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double10 = randomDataImpl1.nextT(0.4116673457546182d);
//        double double12 = randomDataImpl1.nextExponential(0.022558322423987094d);
//        try {
//            int int15 = randomDataImpl1.nextSecureInt((int) '#', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (32): lower bound (35) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 24.364552379300928d + "'", double6 == 24.364552379300928d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.575539243570034d) + "'", double10 == (-1.575539243570034d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.09927014223709542d + "'", double12 == 0.09927014223709542d);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(80.54517617338425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.54517617338426d + "'", double1 == 80.54517617338426d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1L, 87.58746384397638d, (double) 12, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 87.587 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) 4.0487883088955243E34d, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8414709848078964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999998d) + "'", double1 == (-0.9999999999999998d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.rint((-5.294775415650245d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.0d) + "'", double1 == (-5.0d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7685705204390633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray9);
        java.lang.Object[] objArray12 = maxIterationsExceededException11.getArguments();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double4 = normalDistributionImpl3.sample();
//        java.lang.Class<?> wildcardClass5 = normalDistributionImpl3.getClass();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13.358798717468693d + "'", double4 == 13.358798717468693d);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 10, (java.lang.Number) 47.45540159179914d, (java.lang.Number) 73L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17453292519943295d, (java.lang.Number) 10L, false);
        java.lang.Number number11 = numberIsTooSmallException10.getArgument();
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.17453292519943295d + "'", number11.equals(0.17453292519943295d));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int2 = org.apache.commons.math.util.FastMath.max(19, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        double[] doubleArray12 = normalDistributionImpl3.sample((int) (byte) 10);
        double double13 = normalDistributionImpl3.getMean();
        try {
            double double15 = normalDistributionImpl3.inverseCumulativeProbability(13.358798717468693d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 13.359 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.924115048159364E7d + "'", double1 == 8.924115048159364E7d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.9377047211159066E-18d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray9);
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, number12, (java.lang.Number) 1.0E-9d, true);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, number16, (java.lang.Number) 1.0f, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double2 = org.apache.commons.math.util.FastMath.pow(5729.5779513082325d, 0.9065898968108168d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2553.1481114157705d + "'", double2 == 2553.1481114157705d);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        try {
//            long long12 = randomDataImpl1.nextLong((long) (byte) 1, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-59.129261763961985d) + "'", double6 == (-59.129261763961985d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getSpecificPattern();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.junit.Assert.assertNull(localizable1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math.util.FastMath.pow(57.55504356934539d, (double) 92L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.465870199742896E161d + "'", double2 == 8.465870199742896E161d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6680439019765374d + "'", double1 == 1.6680439019765374d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1311311101032817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.756652876377936d + "'", double1 == 0.756652876377936d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math.util.FastMath.min(69.05051438273028d, 1.6308214017997043d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6308214017997043d + "'", double2 == 1.6308214017997043d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10.0d, objArray13, convergenceException15, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable4, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("hi!", objArray17);
        java.lang.Object[] objArray20 = mathException19.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "{0}", objArray20);
        java.lang.Object[] objArray22 = mathException0.getArguments();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("convergence failed", objArray1);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) 100.0f, true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.09927014223709542d, (java.lang.Number) 2.1685525535511587d, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.1685525535511587d + "'", number4.equals(2.1685525535511587d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 1, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int2 = org.apache.commons.math.util.FastMath.max(71, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17453292519943295d, (java.lang.Number) 10L, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.17453292519943295d + "'", number4.equals(0.17453292519943295d));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            int int17 = randomDataImpl1.nextSecureInt(1, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 39.79461420548884d + "'", double6 == 39.79461420548884d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 39.79461420548884d + "'", double13 == 39.79461420548884d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 37.86196457454528d + "'", double14 == 37.86196457454528d);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.log((-48.68536463578576d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.32584491663629733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0091616062506952d + "'", double1 == 1.0091616062506952d);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        long long12 = randomDataImpl1.nextSecureLong(0L, (long) 35);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 19.742413444984876d + "'", double6 == 19.742413444984876d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 42L + "'", long9 == 42L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 21L + "'", long12 == 21L);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.539827837277029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.929856739648734d + "'", double1 == 30.929856739648734d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        java.lang.Number number7 = outOfRangeException4.getLo();
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        randomDataImpl1.reSeed((long) 0);
        try {
            double double9 = randomDataImpl1.nextGamma(4.158638853279167d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Class<?> wildcardClass1 = convergenceException0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.log((-69.26051228825149d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        try {
//            int[] intArray12 = randomDataImpl1.nextPermutation((int) ' ', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.461790194450117d + "'", double6 == 18.461790194450117d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 80L + "'", long9 == 80L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(100);
        try {
            double[] doubleArray12 = normalDistributionImpl3.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288292537319899d + "'", double1 == 5.288292537319899d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.String str7 = outOfRangeException4.toString();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray17);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Number number25 = outOfRangeException23.getHi();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str7.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextGaussian((double) ' ', (double) 52);
//        randomDataImpl1.reSeed(0L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl20.reseedRandomGenerator((long) (short) 0);
//        double double26 = normalDistributionImpl20.getMean();
//        double double28 = normalDistributionImpl20.density((double) (-1L));
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int int32 = randomDataImpl1.nextSecureInt(23, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 23 is larger than, or equal to, the maximum (0): lower bound (23) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.316252115956471d + "'", double6 == 7.316252115956471d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.100128462910902d) + "'", double14 == (-7.100128462910902d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.021127442416575826d + "'", double23 == 0.021127442416575826d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.003989223337860822d + "'", double28 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.574258689729206d + "'", double29 == 61.574258689729206d);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        long long9 = randomDataImpl1.nextSecureLong((long) '#', (long) (byte) 100);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        double double13 = randomDataImpl1.nextExponential(57.52854145469d);
//        try {
//            long long16 = randomDataImpl1.nextSecureLong(69L, (long) 52);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 69 is larger than, or equal to, the maximum (52): lower bound (69) must be strictly less than upper bound (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.573455953742156d + "'", double6 == 6.573455953742156d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 53L + "'", long9 == 53L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.724547589087228d + "'", double13 == 14.724547589087228d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-181.93987645118537d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 69L, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0): standard deviation (-0.785)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5033155610912496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5234086996188485d + "'", double1 == 0.5234086996188485d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 3.1622776601683795E-5d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2553.1481114157705d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextBeta(0.2686379367523434d, 1.5574077246549023d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-34.451011348439d) + "'", double6 == (-34.451011348439d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22 + "'", int11 == 22);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.743412141135254E-5d + "'", double14 == 2.743412141135254E-5d);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-18.522474246984295d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException0.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5234086996188485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6877709597556378d + "'", double1 == 1.6877709597556378d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9225246702208428E61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.922524670220843E61d + "'", double1 == 1.922524670220843E61d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.log10((-5.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.special.Erf.erf(17.568997884802346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, objArray56, convergenceException58, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable47, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65, "", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable45, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, objArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.0E-9d, (java.lang.Number) 52L, false);
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, number83, (java.lang.Number) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.9225246702208428E61d, (java.lang.Number) (-4.002831361813725d), (java.lang.Number) (-130.87770577867906d));
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        double double12 = randomDataImpl1.nextChiSquare(14.569070339568102d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-62.6943467030188d) + "'", double6 == (-62.6943467030188d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 17.243622679557213d + "'", double12 == 17.243622679557213d);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.6308214017997043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0207362104730586d + "'", double1 == 1.0207362104730586d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        long long14 = randomDataImpl1.nextSecureLong((long) (byte) -1, (long) (short) 0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double21 = normalDistributionImpl18.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl18.reseedRandomGenerator((long) (short) 0);
//        double[] doubleArray25 = normalDistributionImpl18.sample(100);
//        double[] doubleArray27 = normalDistributionImpl18.sample((int) (byte) 10);
//        normalDistributionImpl18.reseedRandomGenerator(10L);
//        double double30 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        try {
//            double double33 = randomDataImpl1.nextWeibull(20.723265836369194d, (-0.9999999999999999d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-64.20474757245326d) + "'", double6 == (-64.20474757245326d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.021127442416575826d + "'", double21 == 0.021127442416575826d);
//        org.junit.Assert.assertNotNull(doubleArray25);
//        org.junit.Assert.assertNotNull(doubleArray27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-30.05787989495589d) + "'", double30 == (-30.05787989495589d));
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        try {
//            double double14 = randomDataImpl1.nextGaussian((double) '#', 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-64.70224496929596d) + "'", double6 == (-64.70224496929596d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(47.45540159179914d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.888788107628158d + "'", double1 == 6.888788107628158d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        try {
//            double double11 = randomDataImpl1.nextUniform((double) 52L, (-108.12275130559608d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (-108.123): lower bound (52) must be strictly less than upper bound (-108.123)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-59.12606933698988d) + "'", double6 == (-59.12606933698988d));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10.0d, objArray13, convergenceException15, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable4, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0d, objArray31, convergenceException33, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable22, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("hi!", objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable19, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray48 = outOfRangeException47.getArguments();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable42, objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, localizable19, objArray48);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(57.52854145469d, (double) (byte) 100, 21.643774567583453d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 100 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7237368419565787d + "'", double1 == 0.7237368419565787d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.atanh(47.45540159179914d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 81L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 81L + "'", long1 == 81L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException2.addSuppressed((java.lang.Throwable) outOfRangeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0d, objArray19, convergenceException21, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable10, objArray23);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException28, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable8, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException45.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10.0d, objArray58, convergenceException60, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable49, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable47, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable8, objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(19, "d37efa674a", objArray76);
        java.lang.Object[] objArray83 = null;
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException81, "org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0.907)", objArray83);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double8 = randomDataImpl1.nextChiSquare((double) '4');
//        randomDataImpl1.reSeed((long) (byte) -1);
//        try {
//            double double13 = randomDataImpl1.nextUniform(11.783870842074952d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 11.784 is larger than, or equal to, the maximum (0): lower bound (11.784) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15.043448824764342d) + "'", double6 == (-15.043448824764342d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 41.94933032778491d + "'", double8 == 41.94933032778491d);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.539827837277029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4316706162001703d + "'", double1 == 0.4316706162001703d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.2686379367523434d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0363006924050517d + "'", double1 == 1.0363006924050517d);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 10);
//        try {
//            int int14 = randomDataImpl1.nextHypergeometric(0, 100, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15.770583832389436d) + "'", double6 == (-15.770583832389436d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5111c10535" + "'", str10.equals("5111c10535"));
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray11);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray11);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, objArray27, convergenceException29, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable18, objArray31);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number37 = outOfRangeException36.getHi();
        java.lang.Number number38 = outOfRangeException36.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str43 = outOfRangeException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable44 = outOfRangeException42.getGeneralPattern();
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(number45, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray49 = numberIsTooLargeException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException36, localizable44, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException14, "", objArray49);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 363.25026563894824d + "'", number37.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.6005946583803949d + "'", number38.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str43.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 99L, (float) 16L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.sinh(58.64496087462543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4728309560445906E25d + "'", double1 == 1.4728309560445906E25d);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        try {
//            int int13 = randomDataImpl1.nextInt(12, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 12 is larger than, or equal to, the maximum (10): lower bound (12) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-8.079631759365009d) + "'", double6 == (-8.079631759365009d));
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0207362104730586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.770166228581069d + "'", double1 == 0.770166228581069d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.09927014223709542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException2.addSuppressed((java.lang.Throwable) outOfRangeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0d, objArray19, convergenceException21, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable10, objArray23);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException28, "", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable8, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException45.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10.0d, objArray58, convergenceException60, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable49, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable47, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable8, objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(19, "d37efa674a", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable82 = maxIterationsExceededException81.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNull(localizable82);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.special.Erf.erf(0.7685705204390633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7229290946355417d + "'", double1 == 0.7229290946355417d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        randomDataImpl1.reSeed((long) 0);
        int int9 = randomDataImpl1.nextZipf(12, 1.2924966677897853d);
        try {
            double double12 = randomDataImpl1.nextBeta((-100.712694703437d), 5.298342365610589d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.241");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        randomDataImpl1.reSeed(0L);
//        long long16 = randomDataImpl1.nextLong((long) 10, (long) 23);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-18.66501433709857d) + "'", double6 == (-18.66501433709857d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28 + "'", int11 == 28);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 20L + "'", long16 == 20L);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) 363.25026563894824d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray14);
        java.lang.String str18 = mathException17.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.MathException: " + "'", str18.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-181.93987645118537d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.175449884744881d) + "'", double1 == (-3.175449884744881d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            long long2 = randomDataImpl0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.2659145016620736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2690594256013401d + "'", double1 == 0.2690594256013401d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        long long1 = org.apache.commons.math.util.FastMath.abs(77L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 77L + "'", long1 == 77L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math.util.FastMath.max(100.0d, 113.14732877928753d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 113.14732877928753d + "'", double2 == 113.14732877928753d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0d, objArray56, convergenceException58, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable47, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65, "", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable45, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, objArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.0E-9d, (java.lang.Number) 52L, false);
        java.lang.Object[] objArray83 = numberIsTooSmallException82.getArguments();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = normalDistributionImpl12.density((double) (byte) -1);
//        try {
//            double double19 = normalDistributionImpl12.cumulativeProbability((double) 20L, (-47.47333749536576d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 17.937612579649d + "'", double6 == 17.937612579649d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 17.937612579649d + "'", double13 == 17.937612579649d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-56.22061104432526d) + "'", double14 == (-56.22061104432526d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.003989223337860822d + "'", double16 == 0.003989223337860822d);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.exp(124744.07957402238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray9 = outOfRangeException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable3, objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray9);
        java.lang.String str12 = maxIterationsExceededException11.toString();
        int int13 = maxIterationsExceededException11.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str12.equals("org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextBinomial(4, (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((-1L));
//        int int11 = randomDataImpl1.nextBinomial(12, 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 25.921041649022907d + "'", double6 == 25.921041649022907d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray15);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException20);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, 77L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 77L + "'", long2 == 77L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-142.47141063084348d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5579770166397535d, (java.lang.Number) 1, (java.lang.Number) (-0.16299078079570548d));
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.16299078079570548d) + "'", number4.equals((-0.16299078079570548d)));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(57.55504356934539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 174.5947010653523d + "'", double1 == 174.5947010653523d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        java.lang.String str5 = convergenceException4.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "convergence failed" + "'", str5.equals("convergence failed"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.0f, (java.lang.Number) 3.726369000956119d, false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        int int10 = randomDataImpl1.nextHypergeometric(10, (int) (short) 0, (int) (byte) 0);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", "{0}");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: {0}");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 138.1421354526583d + "'", double6 == 138.1421354526583d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 12, (java.lang.Number) 4.641588833612778d, false);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextInt((-1), 0);
//        try {
//            int int14 = randomDataImpl1.nextInt(35, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (35): lower bound (35) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 150.47362674496014d + "'", double6 == 150.47362674496014d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        try {
//            double double13 = randomDataImpl1.nextBeta(0.0d, (-108.12275130559608d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.722");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.83137204905896d + "'", double6 == 145.83137204905896d);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.9065898968108168d, Double.NaN);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.cumulativeProbability(0.5039893563146316d);
        double double8 = normalDistributionImpl3.density(61.574258689729206d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.019416865714155625d + "'", double4 == 0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7035022480356141d + "'", double6 == 0.7035022480356141d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 16L, (float) 71);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 71.0f + "'", float2 == 71.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.log(57.55504356934539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.052741769370394d + "'", double1 == 4.052741769370394d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 99L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 99.0f + "'", float1 == 99.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 20L, (-74.58291726701029d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-74.58291726701029d) + "'", double2 == (-74.58291726701029d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeedSecure((long) 10);
//        org.apache.commons.math.random.RandomGenerator randomGenerator11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator11);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double17 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        org.apache.commons.math.random.RandomGenerator randomGenerator18 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator18);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double24 = randomDataImpl19.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double25 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double27 = normalDistributionImpl23.density((double) (byte) -1);
//        double double28 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 107.62542891610572d + "'", double6 == 107.62542891610572d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 107.70561330707827d + "'", double17 == 107.70561330707827d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 107.70561330707827d + "'", double24 == 107.70561330707827d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-184.92705276475087d) + "'", double25 == (-184.92705276475087d));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.003989223337860822d + "'", double27 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-32.84170641907946d) + "'", double28 == (-32.84170641907946d));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 81L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.530486572925153E34d + "'", double1 == 7.530486572925153E34d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-7.0d), (-62.6943467030188d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.030400371166897d) + "'", double2 == (-3.030400371166897d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = maxIterationsExceededException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 1.6308214017997043d, (java.lang.Number) 2.1685525535511587d, true);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(number23, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, localizable18, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNull(localizable29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.8597790185857428d, number19, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100, false);
        java.lang.Object[] objArray27 = numberIsTooSmallException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable17, objArray27);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ');
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0d, objArray29, convergenceException31, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable20, objArray33);
        mathException17.addSuppressed((java.lang.Throwable) convergenceException34);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        float float2 = org.apache.commons.math.util.FastMath.min(16.0f, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0d, objArray11, convergenceException13, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("hi!", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17);
        java.lang.String str19 = convergenceException18.getPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0}" + "'", str19.equals("{0}"));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        try {
//            int int9 = randomDataImpl1.nextPascal((int) (byte) -1, (-1.5574077246549023d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-30.649292513871156d) + "'", double6 == (-30.649292513871156d));
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeedSecure((long) 10);
//        org.apache.commons.math.random.RandomGenerator randomGenerator11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator11);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double17 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        org.apache.commons.math.random.RandomGenerator randomGenerator18 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator18);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double24 = randomDataImpl19.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double25 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double27 = normalDistributionImpl23.density((double) (byte) -1);
//        double double28 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double31 = randomDataImpl1.nextCauchy(2.8421709430404007E-14d, 100.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-31.45045845372404d) + "'", double6 == (-31.45045845372404d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-31.37968648851352d) + "'", double17 == (-31.37968648851352d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-31.403275395537243d) + "'", double24 == (-31.403275395537243d));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-97.92378046101976d) + "'", double25 == (-97.92378046101976d));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.003989223337860822d + "'", double27 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 44.64514687179607d + "'", double28 == 44.64514687179607d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-163.37357057742253d) + "'", double31 == (-163.37357057742253d));
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35, 26.897608610330366d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.897608610330366d + "'", double2 == 26.897608610330366d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double2 = org.apache.commons.math.util.FastMath.min(8.924115048159364E7d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double4 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.cumulativeProbability((double) 20L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-173.89826506775142d) + "'", double4 == (-173.89826506775142d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.579259709439103d + "'", double6 == 0.579259709439103d);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeed((long) (-1));
//        double double10 = randomDataImpl1.nextT(0.4116673457546182d);
//        try {
//            int int13 = randomDataImpl1.nextSecureInt((int) (byte) 100, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-28.982530469044175d) + "'", double6 == (-28.982530469044175d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.575539243570034d) + "'", double10 == (-1.575539243570034d));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9065898968108168d + "'", number4.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        java.lang.Number number20 = outOfRangeException19.getHi();
        java.lang.Number number21 = outOfRangeException19.getLo();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException25.getGeneralPattern();
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(number28, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException19, localizable27, objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException35.getGeneralPattern();
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException34, localizable36, objArray37);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException33, localizable36, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 363.25026563894824d + "'", number20.equals(363.25026563894824d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.6005946583803949d + "'", number21.equals(0.6005946583803949d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.55567426575568d, (java.lang.Number) 1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        randomDataImpl1.reSeed(0L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-43.081586862544455d) + "'", double6 == (-43.081586862544455d));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 27 + "'", int11 == 27);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        java.lang.String str4 = outOfRangeException3.toString();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray6);
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(50.62604209536384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8835911218173482d + "'", double1 == 0.8835911218173482d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long long2 = org.apache.commons.math.util.FastMath.min(69L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 71);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4068.000345428845d + "'", double1 == 4068.000345428845d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-48.68536463578576d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2789.4659176859964d) + "'", double1 == (-2789.4659176859964d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.32584491663629733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33817251483510724d + "'", double1 == 0.33817251483510724d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.9065898968108168d, Double.NaN);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.019416865714155625d + "'", double4 == 0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9065898968108168d + "'", double5 == 0.9065898968108168d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.min(16.13242631516386d, 34.411539123298105d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.13242631516386d + "'", double2 == 16.13242631516386d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double8 = randomDataImpl1.nextChiSquare((double) '4');
//        try {
//            int int11 = randomDataImpl1.nextZipf((int) (byte) 10, (-18.66501433709857d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -18.665 is smaller than, or equal to, the minimum (0): exponent (-18.665)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-73.46773849177866d) + "'", double6 == (-73.46773849177866d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 56.01742912112881d + "'", double8 == 56.01742912112881d);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(79.68631081516308d, (-49.39645539193308d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.asin(61.574258689729206d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.17453292519943295d, number1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.8414709848078964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1189396031849521d) + "'", double1 == (-1.1189396031849521d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 77L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 77 + "'", int1 == 77);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double16 = normalDistributionImpl12.cumulativeProbability((-4.002831361813725d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-68.35683674763067d) + "'", double6 == (-68.35683674763067d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-68.38520399242948d) + "'", double13 == (-68.38520399242948d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 42.345147054658426d + "'", double14 == 42.345147054658426d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.4840352766869618d + "'", double16 == 0.4840352766869618d);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0f, number1, (java.lang.Number) 80.54517617338425d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double2 = org.apache.commons.math.util.FastMath.atan2(99.99999999999999d, (-62.6943467030188d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1307919709063006d + "'", double2 == 2.1307919709063006d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.atanh(17.243622679557213d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = maxIterationsExceededException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 1.6308214017997043d, (java.lang.Number) 2.1685525535511587d, true);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(number23, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, localizable18, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 71.0f, (java.lang.Number) (byte) -1, (java.lang.Number) 107.62542891610572d);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
        randomDataImpl1.reSeed((long) 0);
        double double8 = randomDataImpl1.nextT(80.54517617338426d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6183880143993078d + "'", double8 == 0.6183880143993078d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0d, objArray17, convergenceException19, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable8, objArray21);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (-18.522474246984295d), (java.lang.Number) (-108.12275130559608d), false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray50 = outOfRangeException49.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable44, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException52.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((-1), "", objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable73 = convergenceException72.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray79 = outOfRangeException78.getArguments();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable73, objArray79);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, localizable53, objArray79);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable6, objArray79);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 16.0f, 3.735545630309108E-74d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double2 = org.apache.commons.math.util.FastMath.max(0.2686379367523434d, 22.37994691446491d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.37994691446491d + "'", double2 == 22.37994691446491d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-173.89826506775142d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2553.1481114157705d, (java.lang.Number) (byte) 10, (java.lang.Number) (-18.522474246984295d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.tan((-68.35683674763067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9470343583194655d + "'", double1 == 0.9470343583194655d);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) (byte) 1);
//        int int6 = randomDataImpl1.nextSecureInt(0, (int) (byte) 100);
//        try {
//            double double9 = randomDataImpl1.nextF((-142.47141063084348d), 44.64514687179607d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -142.471 is smaller than, or equal to, the minimum (0): degrees of freedom (-142.471)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.2420554870858343d) + "'", double3 == (-0.2420554870858343d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.022558322423987094d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.338279899083843E-48d + "'", double2 == 9.338279899083843E-48d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.atanh(57.55504356934539d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.acos(87.58746384397638d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-58.99559785234423d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3380.198766790388d) + "'", double1 == (-3380.198766790388d));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double13 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double17 = normalDistributionImpl12.cumulativeProbability((-52.034448565839455d), 0.4116673457546182d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-21.401405244163836d) + "'", double6 == (-21.401405244163836d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-21.332485346320983d) + "'", double13 == (-21.332485346320983d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-17.84488834587571d) + "'", double14 == (-17.84488834587571d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.20023056282962837d + "'", double17 == 0.20023056282962837d);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 81L, (float) 71);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 71.0f + "'", float2 == 71.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 64L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15105023781094d + "'", double1 == 4.15105023781094d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
        double double6 = normalDistributionImpl3.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray10 = normalDistributionImpl3.sample(25);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021127442416575826d + "'", double6 == 0.021127442416575826d);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.special.Gamma.digamma(13.367294647091695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5549401854618305d + "'", double1 == 2.5549401854618305d);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        int int14 = randomDataImpl1.nextInt(0, 4);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 46.06429806939634d + "'", double6 == 46.06429806939634d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0d, objArray10, convergenceException12, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0d, objArray27, convergenceException29, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable18, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.17453292519943295d, (java.lang.Number) 10L, false);
        java.lang.Number number38 = numberIsTooSmallException37.getArgument();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.String str40 = mathIllegalArgumentException33.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.17453292519943295d + "'", number38.equals(0.17453292519943295d));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed" + "'", str40.equals("org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed"));
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextGaussian((double) ' ', (double) 52);
//        randomDataImpl1.reSeed(0L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double23 = normalDistributionImpl20.cumulativeProbability((double) (byte) 0, 5.298342365610589d);
//        normalDistributionImpl20.reseedRandomGenerator((long) (short) 0);
//        double double26 = normalDistributionImpl20.getMean();
//        double double28 = normalDistributionImpl20.density((double) (-1L));
//        double double29 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int int32 = randomDataImpl1.nextPascal(23, (-43.081586862544455d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -43.082 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 48.52530828676734d + "'", double6 == 48.52530828676734d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 69.47952873258393d + "'", double14 == 69.47952873258393d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.021127442416575826d + "'", double23 == 0.021127442416575826d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.003989223337860822d + "'", double28 == 0.003989223337860822d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.574258689729206d + "'", double29 == 61.574258689729206d);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.atan(26.897608610330366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.533635415541066d + "'", double1 == 1.533635415541066d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow((-7.696713848543018d), (-68.38520399242948d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.3332436050969099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1546616842594672d + "'", double1 == 1.1546616842594672d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) 363.25026563894824d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0d, objArray30, convergenceException32, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable21, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "{0}", objArray34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "", objArray39);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 21.643774567583453d, (java.lang.Number) (short) 100, true);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException45.addSuppressed((java.lang.Throwable) outOfRangeException49);
        org.apache.commons.math.exception.util.Localizable localizable51 = outOfRangeException49.getGeneralPattern();
        java.lang.String str52 = outOfRangeException49.toString();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable54 = convergenceException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable54, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException49.addSuppressed((java.lang.Throwable) outOfRangeException68);
        org.apache.commons.math.exception.util.Localizable localizable70 = outOfRangeException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException(localizable71, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray76 = outOfRangeException75.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException44, localizable70, objArray76);
        mathException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException44);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str52.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 69L);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 69L + "'", number2.equals(69L));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(4, "d37efa674a", objArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.3204824060079865E11d + "'", double1 == 5.3204824060079865E11d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 0, (java.lang.Number) 100L, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray10 = outOfRangeException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable4, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((-1), "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range", objArray10);
        java.lang.String str13 = maxIterationsExceededException12.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 1.6308214017997043d, (java.lang.Number) 2.1685525535511587d, true);
        java.lang.Throwable throwable31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10.0d, objArray58, convergenceException60, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable49, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(throwable31, localizable33, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException12, localizable26, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str13.equals("org.apache.commons.math.MaxIterationsExceededException: org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float1 = org.apache.commons.math.util.FastMath.abs(71.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 71.0f + "'", float1 == 71.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) (-21.401405244163836d), (java.lang.Number) 1.1546616842594672d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long1 = org.apache.commons.math.util.FastMath.abs(69L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 69L + "'", long1 == 69L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable2, objArray3);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 57.55504356934539d, (java.lang.Number) (-1L), (java.lang.Number) 5729.5779513082325d);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray18);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(number25, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Object[] objArray29 = numberIsTooLargeException28.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable10, objArray29);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, number31, (java.lang.Number) 205.10770177750956d, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "d37efa674a", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException11.getGeneralPattern();
        int int13 = maxIterationsExceededException11.getMaxIterations();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 47.45540159179914d, (java.lang.Number) 69.05051438273028d, true);
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException18.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException11, "", (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        int int11 = randomDataImpl1.nextSecureInt((int) (byte) 10, (int) '#');
//        double double14 = randomDataImpl1.nextUniform(0.0d, 4.641588833612778d);
//        try {
//            java.lang.String str16 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 127.84532674043409d + "'", double6 == 127.84532674043409d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.19366261863665196d + "'", double14 == 0.19366261863665196d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(number1, (java.lang.Number) 0.9065898968108168d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException8.addSuppressed((java.lang.Throwable) outOfRangeException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException12.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0d, objArray25, convergenceException27, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable16, objArray29);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) (short) 100, (java.lang.Number) 0.6005946583803949d, (java.lang.Number) 363.25026563894824d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34, "", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable14, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "f6def14de9f5ab4f4ca8479bf5d517f2", objArray43);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("{0}", objArray43);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.9065898968108168d + "'", number5.equals(0.9065898968108168d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.922524670220843E61d, (java.lang.Number) (byte) -1, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.922524670220843E61d + "'", number4.equals(1.922524670220843E61d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3877787807814457E-17d, 0.539827837277029d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.93880610818761E-10d + "'", double2 == 7.93880610818761E-10d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5234086996188485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.281159063192008d) + "'", double1 == (-0.281159063192008d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) Double.NaN, (java.lang.Number) 1.7453292519943295d);
        convergenceException0.addSuppressed((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.String str7 = outOfRangeException4.toString();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray17);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (short) 1, (java.lang.Number) (-169.0734029878853d), (java.lang.Number) (-1.0d));
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Number number25 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range" + "'", str7.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [�, 1.745] range"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.7453292519943295d + "'", number25.equals(1.7453292519943295d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.781665747525173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7816657475251736d + "'", double1 == 3.7816657475251736d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-32.84170641907946d), (-184.92705276475087d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.841706419079465d) + "'", double2 == (-32.841706419079465d));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.9065898968108168d, Double.NaN);
        double double5 = normalDistributionImpl3.cumulativeProbability(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5679267937879646d + "'", double5 == 0.5679267937879646d);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(1.0E-9d, Double.NaN);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString(35);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ffc04af18cb88091c472fe0ce949236de8a" + "'", str6.equals("ffc04af18cb88091c472fe0ce949236de8a"));
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100.0f, 205.10770177750956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3232137742567098E-16d + "'", double2 == 1.3232137742567098E-16d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.019416865714155625d, 0.9065898968108168d, Double.NaN);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.019416865714155625d + "'", double4 == 0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.019416865714155625d + "'", double5 == 0.019416865714155625d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5574077246549023d);
        java.lang.Class<?> wildcardClass2 = notStrictlyPositiveException1.getClass();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(objArray3);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        randomDataImpl1.reSeed(99L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution11 = null;
//        try {
//            int int12 = randomDataImpl1.nextInversionDeviate(integerDistribution11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 76.93170292353956d + "'", double6 == 76.93170292353956d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 52, (double) (-1.0f), (-62.6943467030188d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) 363.25026563894824d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray14);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0d, objArray30, convergenceException32, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable21, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "{0}", objArray34);
        java.lang.Throwable[] throwableArray38 = mathException17.getSuppressed();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 100L, (short) 10, 0L, "hi!", (byte) 10, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 10.0d, objArray53, convergenceException55, 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable44, objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException("hi!", objArray57);
        java.lang.Object[] objArray60 = mathException59.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40, "{0}", objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, "", objArray60);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 100.0d, 0.0d);
//        double double6 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl1.reSeedSecure((long) (byte) 0);
//        double double11 = randomDataImpl1.nextBeta((double) 1.0f, (double) 1);
//        java.lang.String str13 = randomDataImpl1.nextHexString(26);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 31.693742175909772d + "'", double6 == 31.693742175909772d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33665995534951054d + "'", double11 == 0.33665995534951054d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "c4c8d87665b9caedfd1b6ff750" + "'", str13.equals("c4c8d87665b9caedfd1b6ff750"));
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 1.9377047211159066E-18d, 0.539827837277029d);
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability((-32.277302845186895d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -32.277 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }
}

