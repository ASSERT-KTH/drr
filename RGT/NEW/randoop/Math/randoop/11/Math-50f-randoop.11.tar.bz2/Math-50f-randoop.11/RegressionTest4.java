import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 9.848857801796104d, 0.09711106517906329d, (double) (-981759551), 0.0d, objArray13);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray20);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException25 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray23);
        java.lang.Number number26 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number26, (java.lang.Number) 1.0d, 0, orderDirection29, false);
        java.lang.Number number32 = nonMonotonousSequenceException31.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError33 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException31);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext34 = mathInternalError33.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection39, false);
        java.lang.Throwable[] throwableArray42 = nonMonotonousSequenceException41.getSuppressed();
        exceptionContext34.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Object[]) throwableArray42);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) (short) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 106);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) (short) 0);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (int) (short) 0);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Number) bigInteger55, (java.lang.Number) 3628800L, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException65 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats59, (java.lang.Number) 10L, objArray64);
        org.apache.commons.math.exception.NotPositiveException notPositiveException67 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats59, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray68 = notPositiveException67.getSuppressed();
        exceptionContext34.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray68);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNotNull(exceptionContext34);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray68);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 10000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.729577951308232E11d + "'", double1 == 5.729577951308232E11d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1023), (double) 1, 3104.0d, 0.0d, objArray5);
        double double7 = noBracketingException6.getFLo();
        double double8 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3104.0d + "'", double7 == 3104.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1023.0d) + "'", double8 == (-1023.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "too many regressors ({0}) specified, only {1} in the model" + "'", str1.equals("too many regressors ({0}) specified, only {1} in the model"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-97));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray13 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray49);
        double double59 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray13, doubleArray42);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray72 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray65);
        double[][] doubleArray75 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray65, doubleArray75);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, doubleArray75);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.0d + "'", double14 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 20735.0d + "'", double59 == 20735.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.0d + "'", double73 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.7853981633974483d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "", localizedFormats13, localizedFormats14 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray15);
        double double17 = noBracketingException16.getFLo();
        double double18 = noBracketingException16.getFLo();
        double double19 = noBracketingException16.getLo();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) noBracketingException16);
        int int21 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str22 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < null)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < null)"));
        org.junit.Assert.assertNull(orderDirection23);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.4119627100860633d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4119627100860633d + "'", double2 == 0.4119627100860633d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getFunctionValueAccuracy();
        double double18 = regulaFalsiSolver3.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction20 = null;
        try {
            double double24 = regulaFalsiSolver3.solve((int) (byte) -1, univariateRealFunction20, 0.0d, 3.9889117920610055d, (double) 7.2057601E17f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-15d + "'", double17 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 92.13617560368711d, (double) (-1024.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount(1079083008);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.8128838741512321d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11, (java.lang.Number) 100.0d, 10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.632725553821903d);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: cannot compute 0-th root of unity, indefinite result" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: cannot compute 0-th root of unity, indefinite result"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 20735.0d, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-2L), objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 30, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, 2.718281828459045d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(1079083008, univariateRealFunction4, (double) 9.223372E18f, 5.73064017839119d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1401248639, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4355029767821175679L + "'", long2 == 4355029767821175679L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-2147483636L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.147483636E9d) + "'", double1 == (-2.147483636E9d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray13 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray35);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray59 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double[][] doubleArray62 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray52, doubleArray62);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, orderDirection46, doubleArray62);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 9747.916313026086d);
        try {
            double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.0d + "'", double14 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.0d + "'", double60 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1.0f));
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, 70.00001f, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 10L, objArray19);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (-0.4505495340698077d), objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) bigInteger8, objArray19);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 6.283185307179586d, 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Number) 10L, objArray36);
        org.apache.commons.math.exception.NotPositiveException notPositiveException39 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray40 = notPositiveException39.getSuppressed();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) notPositiveException39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) 1.110506744054915E14d, 1024, orderDirection42, false);
        int int45 = nonMonotonousSequenceException44.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1024 + "'", int45 == 1024);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-0.5440211108893698d), 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1114.1552351014293d) + "'", double2 == (-1114.1552351014293d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger6, false);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 106);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray32);
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger22, objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) (-0.4505495340698077d), objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger3, objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-23L), (int) 'a');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-46), (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-46.0d) + "'", double2 == (-46.0d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int int1 = org.apache.commons.math.util.FastMath.abs((-358450366));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 358450366 + "'", int1 == 358450366);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-44563605345380415L), (java.lang.Number) 3628814.4197382154d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getHi();
        double double13 = noBracketingException9.getLo();
        double double14 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection24, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (-9.3197095425E9d), 1, orderDirection24, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5430806348152437d, (java.lang.Number) 0.8836011904065779d, 0, orderDirection24, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger12, (java.lang.Number) 0.400704296007415d, 0, orderDirection24, false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.5282839739597524d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-358450366), 3628800.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.58450368E8f) + "'", float2 == (-3.58450368E8f));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10230.000000014888d, (java.lang.Number) 10001.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10001.0d + "'", number6.equals(10001.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 0.9998476951563913d, (-1.0d), (-9.319709542E9d), (double) 1076232282, (-0.39731803409122196d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.89210304749025E9d + "'", double6 == 8.89210304749025E9d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 9.999999974754094E-7d, (double) (-1023), 34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.000004f + "'", float1 == 52.000004f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(34.0d, (double) 90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (byte) 1);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 3628800L);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 10L, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) (-0.0f), objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3628800L, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10003.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.21074029199751d + "'", double1 == 9.21074029199751d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        double double6 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 11013.232874703393d, (java.lang.Number) 0.8623188722876839d, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8623188722876839d + "'", number5.equals(0.8623188722876839d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 11013.232874703393d + "'", number6.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8623188722876839d + "'", number7.equals(0.8623188722876839d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2758547353515625L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2758547353515657L + "'", long2 == 2758547353515657L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(18639419084L, 3104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14464189209184L + "'", long2 == 14464189209184L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (-2), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.23606797749979d + "'", double2 == 2.23606797749979d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 187L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 187L + "'", long2 == 187L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) bigInteger16, (java.lang.Number) 3628800L, false);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger16);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (-2147483646));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-2,147,483,646)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger10, false);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 106);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (short) 0);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 106);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) (short) 0);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (int) (short) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger33);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) bigInteger36, (java.lang.Number) 3628800L, false);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger36);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 358450366);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(90, 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.75363714284725d + "'", double2 == 14.75363714284725d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.1586256126509653d, (java.lang.Number) 4.746501045726147d, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 20735.0d, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) (-2L), objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray16);
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) 10L, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 10L, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray35);
        notStrictlyPositiveException22.addSuppressed((java.lang.Throwable) mathIllegalArgumentException37);
        java.lang.Throwable[] throwableArray39 = mathIllegalArgumentException37.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException40 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Number) 20735.0d, objArray35);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Number) (-2L), objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray35);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, number40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException48 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, (java.lang.Number) 10L, objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException55 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, (java.lang.Number) 10L, objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray54);
        notStrictlyPositiveException41.addSuppressed((java.lang.Throwable) mathIllegalArgumentException56);
        java.lang.Throwable[] throwableArray58 = mathIllegalArgumentException56.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException59 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray58);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        try {
            double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-0.035010977236495024d), (-1023.9999999999999d), (double) 4.7683716E-7f, (-9.319709542E9d), 0.0d, (double) 9.223373E18f, (double) 9.223373E18f, 0.8830442304498398d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.1446464333543916E18d + "'", double8 == 8.1446464333543916E18d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.98090125E9f, 3.51843721E14f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10L, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.958103478741511E26d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.141592653589793d, (double) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 341642573L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(2.3299273855E11d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.1920928E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray10);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) 'a');
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray27);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray10);
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray36 = new int[] {};
        int[] intArray37 = new int[] {};
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray37);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray41 = new int[] {};
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray46);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray51);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray50);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int[] intArray64 = org.apache.commons.math.util.MathUtils.copyOf(intArray63);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray63);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray63, (int) 'a');
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray63);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray63);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray46);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray46);
        int[] intArray73 = null;
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray73);
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, (int) '#');
        int[] intArray77 = new int[] {};
        int[] intArray78 = org.apache.commons.math.util.MathUtils.copyOf(intArray77);
        int[] intArray79 = new int[] {};
        int[] intArray80 = org.apache.commons.math.util.MathUtils.copyOf(intArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray79);
        int[] intArray82 = new int[] {};
        int[] intArray83 = org.apache.commons.math.util.MathUtils.copyOf(intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray82);
        int[] intArray86 = org.apache.commons.math.util.MathUtils.copyOf(intArray82, (int) ' ');
        int[] intArray88 = org.apache.commons.math.util.MathUtils.copyOf(intArray86, (int) ' ');
        try {
            int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray88);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 981759551, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51051496652L + "'", long2 == 51051496652L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = new float[] {};
        float[] floatArray19 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray21 = new float[] { (byte) 1 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray25 = new float[] {};
        float[] floatArray32 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray34 = new float[] { (byte) 1 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray32);
        float[] floatArray37 = new float[] {};
        float[] floatArray44 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray46 = new float[] { (byte) 1 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray37, floatArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray44);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray44);
        float[] floatArray57 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray59 = new float[] { (byte) 1 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(floatArray57, floatArray59);
        float[] floatArray61 = new float[] {};
        float[] floatArray68 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray70 = new float[] { (byte) 1 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(floatArray68, floatArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray61, floatArray68);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(floatArray57, floatArray61);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray61);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1565238004));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.48729816431393913d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4534346041897341d + "'", double1 == 0.4534346041897341d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0146664566373451d, (-0.4119627100860633d), (double) (-83462400L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 7.6293945E-6f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) ' ', 12.041199826559248d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.123599479677745d) + "'", double2 == (-4.123599479677745d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963267948966d, (java.lang.Number) 1.0E-15d, 97);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0E-15d + "'", number4.equals(1.0E-15d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.4119656981009763d, (double) 38.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2147483648L), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-111669149696L) + "'", long2 == (-111669149696L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-0.0f), objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3.51843721E14f, 20735.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100, 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3800 + "'", int2 == 3800);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, (int) (short) 10);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 40);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 3800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int5 = regulaFalsiSolver4.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution9);
        double double11 = regulaFalsiSolver4.getRelativeAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution15 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(358450366, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 52.952809179494906d, (double) 1.0E10f, 0.014559944337890235d, allowedSolution15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-14d + "'", double11 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution15 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution15.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection17, false);
        double[] doubleArray25 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[] doubleArray31 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection17, doubleArray32);
        double[] doubleArray39 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray46 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double[] doubleArray53 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray60 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray60);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray53);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray53);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray53);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1));
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (-1.0f));
        double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 101.0d + "'", double61 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.0303030303030303d + "'", double69 == 2.0303030303030303d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getStartValue();
        double double4 = regulaFalsiSolver1.getAbsoluteAccuracy();
        int int5 = regulaFalsiSolver1.getEvaluations();
        double double6 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (-358450367), 3.6288E9d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-2L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.9999999f) + "'", float1 == (-1.9999999f));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1665534083, (long) (-1565238004));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,565,238,004)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.07269325E9f);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        long long2 = org.apache.commons.math.util.MathUtils.pow(716100L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-9.3197097E9f), 1072693338, 40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 40, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-2), objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathInternalError7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection13, false);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray16);
        exceptionContext8.setValue("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [0.487, 0], values: [0, -1]", (java.lang.Object) 24.0d);
        java.lang.Object obj22 = exceptionContext8.getValue("org.apache.commons.math.exception.NoBracketingException: -1 is not a finite number");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 10L, objArray38);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray38);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray38);
        java.lang.Object[] objArray42 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray38);
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, 9.848857801796104d, 0.09711106517906329d, (double) (-981759551), 0.0d, objArray38);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException44 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 329L, objArray38);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray38);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (long) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1023L), (int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1023.0d) + "'", double3 == (-1023.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection17, false);
        double[] doubleArray25 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[] doubleArray31 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection17, doubleArray32);
        double[] doubleArray39 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray46 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39);
        double[][] doubleArray49 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray39, doubleArray49);
        double[] doubleArray56 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray63 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray39);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 101.0d + "'", double64 == 101.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 175.46509624423885d + "'", double65 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 1072693248, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException6 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 0, 30);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 100, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(35.0d, (double) 39481480091340L, (-1.0512497153941978d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double[] doubleArray0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection7, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = nonMonotonousSequenceException9.getContext();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        java.lang.String str13 = nonMonotonousSequenceException9.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number1, (java.lang.Number) (-9.3197095425E9d), (int) 'a', orderDirection14, true);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray36);
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray72 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double75 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray29, doubleArray58);
        double[] doubleArray81 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray88 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray81);
        double[][] doubleArray91 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray81, doubleArray91);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray58, doubleArray91);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection14, doubleArray91);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.0d + "'", double73 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 20735.0d + "'", double75 == 20735.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.0d + "'", double89 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1023.9999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16056393283891465d + "'", double1 == 0.16056393283891465d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger10, false);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 35);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 51051496652L, (float) (-83462400L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", localizedFormats10, localizedFormats11 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.0d), objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.298342441900717d, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 2758547353515625L, 0.46982219669862557d, 1.0E-14d, 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 537824L, (double) 70L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.4E-45f), (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int1 = org.apache.commons.math.util.FastMath.abs(37);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray21 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray23 = new float[] { (byte) 1 };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray21);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray14);
        float[] floatArray27 = new float[] {};
        float[] floatArray34 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray36 = new float[] { (byte) 1 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(floatArray34, floatArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray34);
        float[] floatArray39 = new float[] {};
        float[] floatArray46 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray48 = new float[] { (byte) 1 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray46, floatArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray39, floatArray46);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray34, floatArray46);
        float[] floatArray52 = new float[] {};
        float[] floatArray59 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray61 = new float[] { (byte) 1 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray52, floatArray59);
        float[] floatArray64 = new float[] {};
        float[] floatArray71 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray73 = new float[] { (byte) 1 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray71, floatArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray64, floatArray71);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray71);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(floatArray34, floatArray71);
        float[] floatArray79 = new float[] { 0 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray71, floatArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray71);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 315L, (double) 11L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [315, 11]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 10L, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10L, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException20 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (byte) 1, 2.99822295029797d, 100.00499987500625d, (double) 362880000L, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray34);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray34);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray34);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException38 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray34);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (-1.4558669573934826d), objArray34);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        java.lang.Throwable[] throwableArray9 = nullArgumentException8.getSuppressed();
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (byte) 1);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 1 + "'", number2.equals((byte) 1));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int int2 = org.apache.commons.math.util.FastMath.min(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.6929695075925542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02954789204335721d + "'", double1 == 0.02954789204335721d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.5063656411097587d), 34.99999999999999d, 52.00000000000001d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 34.99999999999999d + "'", double4 == 34.99999999999999d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        double double4 = regulaFalsiSolver2.getMax();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.8639419083999996E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8639419083E10d) + "'", double1 == (-1.8639419083E10d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7.6293945E-6f, 0.589615898275564d, (double) 9223372036854775807L, 981759551);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (-1023), 0.8101836031147954d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1023.0d + "'", double2 == 1023.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Float.NaN);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.09741807476623128d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMin();
        int int18 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 40, 0, 1076232192);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,076,232,192, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 10.0d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.08288831974674488d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08269927111300003d) + "'", double1 == (-0.08269927111300003d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-46));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5490606199531038d) + "'", double1 == (-1.5490606199531038d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 6.283185307179586d, 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray13 = notPositiveException12.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) notPositiveException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass16 = orderDirection15.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2758547353515657L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 6.0f, (double) 358450366);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 1076232203L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076232203L + "'", long2 == 1076232203L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.9075712110370514d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9075712110370514d + "'", double2 == 0.9075712110370514d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1401248639, (-1565238004));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 9468.356456209538d);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray41 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray48 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double[] doubleArray55 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray62 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray69 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray76 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray76);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69);
        double[] doubleArray84 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray91 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray84, doubleArray91);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray84);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray69);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray69);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray41);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2140242005 + "'", int35 == 2140242005);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 101.0d + "'", double49 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 101.0d + "'", double63 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 101.0d + "'", double77 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 101.0d + "'", double92 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 9747.916313026086d + "'", double96 == 9747.916313026086d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 9565.430912297914d + "'", double97 == 9565.430912297914d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        int int3 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.math.util.FastMath.max(1401248639, 981759551);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1401248639 + "'", int2 == 1401248639);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999092042625951d + "'", double1 == 0.9999092042625951d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1079083008);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1023), 3800);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 4.7683716E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000001137d + "'", double1 == 1.0000000000001137d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(9.21074029199751d, 0.013707783890401887d, 21.15557659395077d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.270227759920085E13d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 104.0d, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, 10230.488746878127d, (double) (-1.0f), 0.9913289158005998d, 3628800.0d, objArray20);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (short) 0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 4.584967478670572d, (java.lang.Number) bigInteger26, true);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0167994369962388d), (java.lang.Number) 1.1008953666826535d, false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 11, (float) 1072693248L, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-44563605345380415L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.24871388718602142d, 100.01499887516871d, (-1565238004));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 90);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 97, 10230.000000014887d, 3.141592653589793d, 1.7453292519943297E8d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 4853.89129293241d, 2.23606797749979d, (double) (-18639419085L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.688117141816135E43d, (java.lang.Number) (-101.04040404040403d), 38);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1023.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(5.6964865478977345d, (double) 90, (double) 9.223373E18f, 0.0d, 0.0d, (-1114.1552351014293d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 512.6837893107961d + "'", double6 == 512.6837893107961d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver1.getMin();
        double double6 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction12 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 106);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution18 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double19 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(35, univariateRealFunction12, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, 0.014559944337890235d, 62.26061319933956d, 0.01745417862959511d, allowedSolution18);
        try {
            double double20 = regulaFalsiSolver1.solve(0, univariateRealFunction8, (double) 4.0f, (double) 40, allowedSolution18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution18 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution18.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.014559944337890235d + "'", double19 == 0.014559944337890235d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.9998476951563913d);
        double double2 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.014559944337890235d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014559429911440295d + "'", double1 == 0.014559429911440295d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(9223372036854775807L, (long) (-981759551));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1));
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0102525138905933d + "'", double63 == 1.0102525138905933d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 341642573L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray10);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) 'a');
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray27);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray10);
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray36 = new int[] {};
        int[] intArray37 = new int[] {};
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray37);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray41 = new int[] {};
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray46);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray51);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray50);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int[] intArray64 = org.apache.commons.math.util.MathUtils.copyOf(intArray63);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray63);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray63, (int) 'a');
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray63);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray63);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray46);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray46);
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray74);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-46), (-1565238004));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,565,238,004)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        float[] floatArray6 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray8 = new float[] { (byte) 1 };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray8);
        float[] floatArray10 = new float[] {};
        float[] floatArray17 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray19 = new float[] { (byte) 1 };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray17, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray17);
        float[] floatArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray22);
        float[] floatArray24 = new float[] {};
        float[] floatArray31 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray33 = new float[] { (byte) 1 };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray31);
        float[] floatArray36 = new float[] {};
        float[] floatArray43 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray45 = new float[] { (byte) 1 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray36, floatArray43);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray43);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray43);
        float[] floatArray50 = new float[] {};
        float[] floatArray57 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray59 = new float[] { (byte) 1 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(floatArray57, floatArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray50, floatArray57);
        float[] floatArray62 = new float[] {};
        float[] floatArray69 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray71 = new float[] { (byte) 1 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(floatArray69, floatArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray62, floatArray69);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray57, floatArray69);
        float[] floatArray75 = new float[] {};
        float[] floatArray82 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray84 = new float[] { (byte) 1 };
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(floatArray82, floatArray84);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray75, floatArray82);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(floatArray69, floatArray75);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray75);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray43);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.957296094269961E11d, (java.lang.Number) 0, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(187.0f, (float) 38, (float) (-46));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 12.566370614359172d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = nonMonotonousSequenceException5.getContext();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0d + "'", number10.equals(1.0d));
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-35), (-1980901215L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,980,901,215)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) (short) -1);
        int int3 = regulaFalsiSolver2.getEvaluations();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 39481480091340L, 2.7585477E15f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(0);
        int int9 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1072693248, (-3.58450368E8f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.58450368E8f) + "'", float2 == (-3.58450368E8f));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 3104L, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3104.0d + "'", double2 == 3104.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-23L), (long) 1155530752);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 5506.223738269998d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 100, 0.0f, 1401248639);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.07269325E9f, (-46.0f), 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 2.7585477E15f, 8.8454160025231072E16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0975370071383839d + "'", double2 == 1.0975370071383839d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(10, (-1329415437));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (double) 1024L, (double) (-35), (double) 9.223373E18f);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-35.0d) + "'", double5 == (-35.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223373136366404E18d + "'", double6 == 9.223373136366404E18d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1565238004));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1565238004L + "'", long1 == 1565238004L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 341642573L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = new float[] {};
        float[] floatArray19 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray21 = new float[] { (byte) 1 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray25 = new float[] {};
        float[] floatArray32 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray34 = new float[] { (byte) 1 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray32);
        float[] floatArray37 = new float[] {};
        float[] floatArray44 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray46 = new float[] { (byte) 1 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray37, floatArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray44);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray44);
        float[] floatArray51 = null;
        float[] floatArray58 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray60 = new float[] { (byte) 1 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(floatArray51, floatArray58);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray7, floatArray51);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 14464189209184L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5244772533169565E11d + "'", double1 == 2.5244772533169565E11d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 3.58450368E8f, 1.5430806348d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.58450368E8d + "'", double2 == 3.58450368E8d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6.283185307179586d);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 10000000000L);
        mathInternalError4.addSuppressed((java.lang.Throwable) maxCountExceededException6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) 1.0d, 0, orderDirection10, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getPrevious();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        int int15 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 1.0E-6f, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) 10L, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 10L, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray35);
        java.lang.Object[] objArray38 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 11L, objArray38);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException12, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException52 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats46, (java.lang.Number) 10L, objArray51);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray51);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException54 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, (java.lang.Number) (-0.0f), objArray51);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException55 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray51);
        java.lang.Class<?> wildcardClass56 = objArray51.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray51);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1565238004L, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707962679308929d + "'", double2 == 1.5707962679308929d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.8342233605065102d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10L, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 10L, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray18);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 9223372036854775807L, objArray18);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray18);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray18);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException27 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) -1, (-981759551));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 10230);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 358450366);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18932.78547916286d + "'", double1 == 18932.78547916286d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        double double6 = regulaFalsiSolver0.getMax();
        int int7 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = null;
        try {
            double double14 = regulaFalsiSolver0.solve(90, univariateRealFunction9, 10.107875886857d, 0.014559429911440295d, (double) 3628800L, allowedSolution13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2147483646), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-0.037381141273430396d), (double) 14L, (-1.5490606199531038d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1980901215L, 5506.223738269998d, 981759551);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.08269927111300003d), 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '#');
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, 10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        try {
            int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 10L, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (byte) 1, 2.99822295029797d, 100.00499987500625d, (double) 362880000L, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, localizable9, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray42);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException44 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Number) 20735.0d, objArray42);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) (-2L), objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray42);
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, number47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException55 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, (java.lang.Number) 10L, objArray54);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException62 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats56, (java.lang.Number) 10L, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray61);
        notStrictlyPositiveException48.addSuppressed((java.lang.Throwable) mathIllegalArgumentException63);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) notStrictlyPositiveException48);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1980901217) + "'", int30 == (-1980901217));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger10, false);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, (java.lang.Number) 10L, objArray34);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Number) (-0.4505495340698077d), objArray34);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException37 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray34);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) bigInteger23, objArray34);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(bigInteger39);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10230.000000014888d, (java.lang.Number) 10001.0d, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 2.140242005E9d, (java.lang.Number) (byte) -1, false);
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 363.7393755555636d, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '#');
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray13);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray13);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray20);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int[] intArray24 = new int[] {};
        int[] intArray25 = new int[] {};
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray25);
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) 'a');
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray25);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray20);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-100.0f), 0.0d, 9.21074029199751d, 0.009710801264635796d, (double) 28, (double) 9.223372E18f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.5825441703193372E20d + "'", double6 == 2.5825441703193372E20d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(187.0f, 63, (-46));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -46, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 0, 35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        java.lang.String str4 = localizedFormats3.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Conversion Exception in Transformation: {0}" + "'", str4.equals("Conversion Exception in Transformation: {0}"));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.15920507027249187d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8528214527080135d + "'", double1 == 0.8528214527080135d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        float float2 = org.apache.commons.math.util.FastMath.min(9.223373E18f, (float) 4355029767821175679L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.35502977E18f + "'", float2 == 4.35502977E18f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        incrementor0.incrementCount();
        incrementor0.resetCount();
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray13 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.0d + "'", double14 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) (-46));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.9572960942883878E11d, 0.0d, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver3.solve((-2147483648), univariateRealFunction5, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathIllegalStateException16.getContext();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        int int19 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-0.037381141273430396d), 5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.656977757577177d + "'", double2 == 5.656977757577177d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.4657359027997265d, (java.lang.Number) 1.5706963567862324d, (-1329415437), orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.14510469346731042d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver8 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int15 = regulaFalsiSolver14.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution19 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double20 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction13, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution19);
        double double21 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction7, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver8, (double) 10.0f, 0.0d, (double) 35.0f, allowedSolution19);
        try {
            double double22 = regulaFalsiSolver1.solve(63, univariateRealFunction3, (-0.9171523356672744d), (-3.584492136767125E9d), allowedSolution19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution19 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution19.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (byte) 10, 1.2850972089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7168146928204138d + "'", double2 == 3.7168146928204138d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 4L, 1.09951163E12f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 22.180709777452588d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 39481480091340L, 1.0333147966386297E40d, (-58613.58244188321d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.9481480149953586E13d + "'", double3 == 3.9481480149953586E13d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '#');
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, 10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray18);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray22);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray26 = new int[] {};
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray28 = new int[] {};
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray28);
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray26);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray33);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        int int1 = org.apache.commons.math.util.FastMath.abs(106);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 106 + "'", int1 == 106);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.01745417862959511d, objArray1);
        java.lang.Class<?> wildcardClass3 = notFiniteNumberException2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-2147483648L), (float) 4L, (float) 981759551);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-127), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 127L + "'", long2 == 127L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2147483647, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0d + "'", number10.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 18639419084L, (float) 97, (float) 1024L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1023), (-111669149696L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-111,669,149,696)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-83462400L), (double) (short) 100, 5.166573983193148E39d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (-1023));
        org.apache.commons.math.exception.NotPositiveException notPositiveException5 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number6 = notPositiveException5.getMin();
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) notPositiveException5);
        java.lang.Number number8 = notPositiveException5.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 9565.430912297914d, 114.59155902616465d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.533571983992772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9212278213095213d + "'", double1 == 2.9212278213095213d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray66 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray73 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66);
        double[][] doubleArray76 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray66, doubleArray76);
        double[] doubleArray83 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray90 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-358450367) + "'", int59 == (-358450367));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 101.0d + "'", double74 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 101.0d + "'", double91 == 101.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 175.46509624423885d + "'", double92 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 34);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 106);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger23);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 100);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) bigInteger23, (java.lang.Number) 100.0f, false);
        boolean boolean34 = numberIsTooLargeException33.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(39.71440802747728d, (-72000.0d), 1.5122093305432393E42d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.232874703393d, 6.283185307179586d, (double) 52L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 9.848857801796104d, 0.09711106517906329d, (double) (-981759551), 0.0d, objArray13);
        java.lang.String str19 = noBracketingException18.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: unparseable real vector: \"9.849\"" + "'", str19.equals("org.apache.commons.math.exception.NoBracketingException: unparseable real vector: \"9.849\""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getHi();
        double double13 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.24871388718602142d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3) + "'", int1 == (-3));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.1608753909688045d), (java.lang.Number) 1.4327039495545584E20d, true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(37);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution7);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        try {
            double double12 = regulaFalsiSolver2.solve((-981759551), univariateRealFunction10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.9481480149953586E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0078125d + "'", double1 == 0.0078125d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.1058338518107955E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2048.0d + "'", double1 == 2048.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9075712110370514d, 18932.78547916286d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1255.8977222675155d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMax();
        double double4 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (short) 100, (float) 1076232203L, 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.14510469346731042d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4194304.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-0.39731803409122196d), (double) 100, (double) 70, 1.0873887412729094E25d, (-2.147483636E9d), 0.013707783890401887d, 31.384563552848054d, 174.96856860590705d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.611721188910365E26d + "'", double8 == 7.611721188910365E26d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = mathArithmeticException21.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = mathArithmeticException21.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertNotNull(exceptionContext23);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-9.3197097E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1076232192, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076232092L + "'", long2 == 1076232092L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.7910068511973d + "'", double1 == 11.7910068511973d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-1.3007446917685998E15d), 114.59155902616465d, 0.0d, 3.58351893845611d, (-0.8390715290764524d), (double) 1L, 2.220446049250313E-16d, 0.047442967903742035d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.4905436212477184E17d) + "'", double8 == (-1.4905436212477184E17d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, (int) (short) 10);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray12 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray14);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray12);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray19);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.400704296007415d, (double) (-358450366));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7922518279964784E8d) + "'", double2 == (-1.7922518279964784E8d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection8, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 4194304.0f, 0.01745417862959511d, 0.0d, 22.583313058969097d, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        int int7 = incrementor0.getCount();
        int int8 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-97), (-358450366));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -358,450,366, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), (int) '4');
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) (-0.4505495340698077d), objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger3, objArray14);
        org.apache.commons.math.exception.MathInternalError mathInternalError19 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notFiniteNumberException18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2140242005, (java.lang.Number) 10230.000000014888d, (-127));
        mathInternalError19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray50 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray57 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray71 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray64);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray64);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1));
        double double78 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray19, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.0d);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.0d + "'", double58 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 101.0d + "'", double72 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + (-101.04040404040404d) + "'", double78 == (-101.04040404040404d));
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(39481480091340L, (long) (-2147483646));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 2140242005, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0E-6f, (java.lang.Number) 1.0d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 6.283185307179586d, 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray13 = notPositiveException12.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) notPositiveException12);
        java.lang.String str15 = notPositiveException12.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotPositiveException: -0.037 method needs at least two previous points" + "'", str15.equals("org.apache.commons.math.exception.NotPositiveException: -0.037 method needs at least two previous points"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (-981759551), (float) 358450366);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.8175955E8f + "'", float2 == 9.8175955E8f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.140242005E9d, (double) 1155530752, (double) 7.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1980901215L, (-981759551));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray15);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22);
        double[] doubleArray37 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray44 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray37);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray37);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (-3.584492136767125E9d));
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 101.0d + "'", double45 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.01499887516871d + "'", double50 == 100.01499887516871d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int int2 = org.apache.commons.math.util.MathUtils.pow(40, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10230, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10230.0d + "'", double2 == 10230.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-3), (double) (short) 10, 9.999999974754094E-7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.46982219669862557d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray11 = new int[] {};
        int[] intArray12 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray12);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray11);
        try {
            int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (-46));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-981759551), 40);
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
        java.lang.Class<?> wildcardClass5 = dimensionMismatchException3.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 34);
        try {
            java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (-1024L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,024)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1155530752, 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(3104L, 14464189209184L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3104L + "'", long2 == 3104L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1023L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 6.283185307179586d);
        java.lang.Number number11 = notPositiveException10.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray13);
        exceptionContext6.setValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)", (java.lang.Object) objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray26);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 20735.0d, objArray26);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray26);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-18639419084L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray12);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        int[] intArray24 = new int[] {};
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray24);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray24);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray21);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 6.0000005f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999877116625145d + "'", double1 == 0.9999877116625145d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-1023), (float) 315L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray20);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException25 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException38 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray37);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException39 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray37);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats29, (org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray37);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException41 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray37);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException42 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Number) 0.009710801264635796d, objArray37);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException43 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) 1076232203L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.7082376834970003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.261460636515294d + "'", double1 == 1.261460636515294d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver1.getMin();
        int int6 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double12 = regulaFalsiSolver1.solve(1072693248, univariateRealFunction8, 0.0d, (double) 34, (double) 3.51843721E14f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.4327039495545584E20d, 1.7453292519943297E8d, (-0.5063656411097588d), 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,023");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        float float2 = org.apache.commons.math.util.FastMath.min((-1024.0f), 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1024.0f) + "'", float2 == (-1024.0f));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0975370071383839d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(39481480091340L, (long) 1665534083);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        long long2 = org.apache.commons.math.util.FastMath.min(341642573L, (long) (-1023));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1023L) + "'", long2 == (-1023L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 45);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray20 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray22 = new float[] { (byte) 1 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray22);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 0.0d, true);
        double[] doubleArray11 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray18 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray18);
        double[] doubleArray25 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray32 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25);
        double[] doubleArray40 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray47 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray40);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray57 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray64 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray64);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57);
        double[][] doubleArray67 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray57, doubleArray67);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection51, doubleArray67);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException70 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray67);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException71 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray67);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 101.0d + "'", double19 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 101.0d + "'", double33 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 101.0d + "'", double48 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 101.0d + "'", double65 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray20);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException24 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 11L, objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray23);
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.7082376834970003d, (double) 10.0f, 34.0d, (double) 10000000000L, objArray23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 342.0d, (java.lang.Number) 8.533571983992772d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 10L, objArray19);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (-0.4505495340698077d), objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) bigInteger8, objArray19);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException38 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray37);
        java.lang.Object[] objArray39 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray37);
        java.lang.Object[] objArray40 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException41 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 104.0d, objArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException42 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, 10230.488746878127d, (double) (-1.0f), 0.9913289158005998d, 3628800.0d, objArray40);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) (short) 0);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (int) (short) 0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 4.584967478670572d, (java.lang.Number) bigInteger46, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats51);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException63 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats57, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray62);
        java.lang.Object[] objArray64 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray62);
        java.lang.Object[] objArray65 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray62);
        org.apache.commons.math.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats51, 3.831008000716578E22d, 1.4210854715202004E-14d, (double) 45, 0.16056393283879805d, objArray65);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) bigInteger24, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray65);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(358450366, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 358450356 + "'", int2 == 358450356);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-127), (long) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-310133503) + "'", int2 == (-310133503));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 38, (-0.4119627100860633d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6.283185307179586d);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        java.lang.Number number7 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int2 = org.apache.commons.math.util.FastMath.min((-1980901217), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1980901217) + "'", int2 == (-1980901217));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.4455175430087551d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4455175430087551d + "'", double2 == 0.4455175430087551d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.2850972089d);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-35));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(20.793438378082765d, 1.5707962679308929d, (double) (-1024.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.66225540174341d + "'", double4 == 32.66225540174341d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-127), 52);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.14510469346731042d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14510469346731042d + "'", double1 == 0.14510469346731042d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1072693248);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 1.5698197646053373d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.01499887516871d + "'", double15 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 187.0f, (int) (byte) -1, (-46));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0975370071383839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04041917285495852d + "'", double1 == 0.04041917285495852d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.1752011936438014d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-3.58450368E8f), 1.261460636515294d, 24.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.16814528752542068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16894786513923227d + "'", double1 == 0.16894786513923227d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        java.lang.String str20 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "unparseable real vector: \"{0}\"" + "'", str20.equals("unparseable real vector: \"{0}\""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        double double2 = org.apache.commons.math.util.FastMath.scalb(52.952809179494906d, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 211.81123671797963d + "'", double2 == 211.81123671797963d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-2147483636L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 256.0f + "'", float1 == 256.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-310133503), 2.5825441703193372E20d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3628800L, (float) 5L, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        double double3 = regulaFalsiSolver2.getMax();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException7 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.48729816431393913d);
        java.lang.Throwable[] throwableArray8 = tooManyEvaluationsException7.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.4119656981009763d, 52.0d, 3.6267774588438875E24d, (-1.0512497153941978d), (java.lang.Object[]) throwableArray8);
        double double11 = noBracketingException10.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        int int7 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(2.2250738585072014E-308d, 8.463708561893364E50d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2250738585072014E-308d + "'", double2 == 2.2250738585072014E-308d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray45);
        double[] doubleArray47 = null;
        try {
            double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        double double1 = org.apache.commons.math.util.FastMath.cosh(143.99652773591453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7213429821350874E62d + "'", double1 == 1.7213429821350874E62d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.948148009134034E13d);
        double double2 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.656854249492381d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-18639419084L), (float) 45, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-981759551), 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 458753 + "'", int2 == 458753);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray45);
        try {
            double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.013707783890401887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013706925407731583d + "'", double1 == 0.013706925407731583d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        long long1 = org.apache.commons.math.util.FastMath.abs(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        int int6 = incrementor0.getMaximalCount();
        int int7 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1024L), 39.71440802747728d, 20.793438378082765d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve(10, univariateRealFunction5, 3.469446951953614E-18d, (double) 9.8175955E8f, 11013.232874703393d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.0195652940572162d, 10230.000000014888d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0195652940572162d + "'", double2 == 1.0195652940572162d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-2.0d), 1.0000038146972656d, (-310133503));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray11 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray11);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray8);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 2758547353515625L, (float) (-2L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-2.0f), (double) 28, (-0.4505495340698077d), 1255.8977222675155d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(6.0000005f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger10, false);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 106);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger26);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger26);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger26);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 341642467);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 63);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.8836011904065779d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.275238093010493d + "'", double2 == 28.275238093010493d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) (-1114.1552351014293d), (-46));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 127L, (float) 341642573L, 45);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 19784.578601884947d, (java.lang.Number) Float.POSITIVE_INFINITY, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + Float.POSITIVE_INFINITY + "'", number6.equals(Float.POSITIVE_INFINITY));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(39481480091340L, 3104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 18639419084L, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8639419084E10d + "'", double2 == 1.8639419084E10d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray12);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray12);
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats2 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray19);
        java.lang.String str21 = mathIllegalStateException20.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = mathIllegalStateException20.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: real format" + "'", str21.equals("org.apache.commons.math.exception.MathIllegalStateException: real format"));
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.551115123125783E-17d, 0.09711106517906329d, 358450356);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.POSITIVE_INFINITY, (double) (-46.0f), 11.7910068511973d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double2 = org.apache.commons.math.util.FastMath.scalb(5.298342441900717d, 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.102483004388943E10d + "'", double2 == 9.102483004388943E10d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(34, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1024.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 716100L, (-1.4050196873014067d), 52.00000000000001d, 0.047442967903742035d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount((-358450367));
        try {
            incrementor0.incrementCount(358450356);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-358,450,367) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMax();
        double double18 = regulaFalsiSolver3.getMin();
        double double19 = regulaFalsiSolver3.getAbsoluteAccuracy();
        int int20 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52L, (java.lang.Number) 2.140242005E9d, (-3));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.4210854715201903E-14d, (-0.037381141273430396d));
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4210854715201903E-14d + "'", double4 == 1.4210854715201903E-14d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1155530752);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-981759551), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        double double2 = org.apache.commons.math.util.FastMath.min(926048.202621805d, (double) 315L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 315.0d + "'", double2 == 315.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        long long2 = org.apache.commons.math.util.FastMath.min(716100L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (byte) 10, (double) 10230);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 1.5860134523134298E15d, (int) (byte) 0, orderDirection6, true);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) ' ');
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) ' ');
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray13);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray17 = new int[] {};
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray26);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray39);
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, (int) 'a');
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray39);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray39);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray22);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray49);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray48);
        int[] intArray53 = new int[] {};
        int[] intArray54 = org.apache.commons.math.util.MathUtils.copyOf(intArray53);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int[] intArray64 = org.apache.commons.math.util.MathUtils.copyOf(intArray63);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray63);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray62);
        int[] intArray67 = new int[] {};
        int[] intArray68 = new int[] {};
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray68);
        int[] intArray70 = new int[] {};
        int[] intArray71 = org.apache.commons.math.util.MathUtils.copyOf(intArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray70);
        int[] intArray74 = new int[] {};
        int[] intArray75 = new int[] {};
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray75);
        int[] intArray79 = org.apache.commons.math.util.MathUtils.copyOf(intArray75, (int) 'a');
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray75);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray75);
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray58);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray58);
        int[] intArray85 = null;
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray85);
        int[] intArray88 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, (int) '#');
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray88);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.7853981633974483d), (double) 18639419084L, 5.298492335617899d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int int2 = org.apache.commons.math.util.FastMath.max((-1980901217), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 10L, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException20 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10003.0d, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4994888620096063d, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 9.536743E-7f, (double) 1.09951163E12f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5565115857642013d, 2.9212278213095213d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.489563713633778d + "'", double2 == 0.489563713633778d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", localizedFormats10, localizedFormats11 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.0d), objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.298342441900717d, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException17 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        int int7 = incrementor0.getCount();
        int int8 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 40, 35.0d, 5.6964865478977345d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 8.8454160025231072E16d, 44.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.7453292519943297E8d, 1.4728051276747958d, 0.6931471805599453d, 1.0102525138905933d, (-0.9117339147869651d), (double) (-83462400L), 7.211102550927978d, 34.99999999999999d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.33148740960165E8d + "'", double8 == 3.33148740960165E8d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.7168146928204138d, 0.0d, 63);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-358450367) + "'", int59 == (-358450367));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1076232203L, (long) 63);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = regulaFalsiSolver0.solve(0, univariateRealFunction3, (double) 52L, (double) 32L, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        java.lang.Number number7 = maxCountExceededException6.getMax();
        java.lang.Number number8 = maxCountExceededException6.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10L + "'", number7.equals(10L));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10L + "'", number8.equals(10L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 45, 1.0975370071383839d, (-1.9999999999999998d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-100L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-100.0d) + "'", double1 == (-100.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(6.044629098073146E23d);
        double double2 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 10230, (-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -2,147,483,648, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1848836590513583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.270306328792301d + "'", double1 == 3.270306328792301d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) -1, 10230);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10230 + "'", int3 == 10230);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1076232203L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101.04040404040404d), (java.lang.Number) 6.0000005f, 97, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray20 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray22 = new float[] { (byte) 1 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray22);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray12 = new java.lang.Object[] { "", localizedFormats10, localizedFormats11 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.0d), objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.298342441900717d, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.9155040003582885E22d, (-0.3901379238959021d), (-0.5063656411097588d), 0.8836011904065779d, (double) 0.00390625f, (double) 1L, 5.551115123125783E-17d, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-7.473107539140779E21d) + "'", double8 == (-7.473107539140779E21d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.1920928E-7f, (double) 32L, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1023L));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException(number0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-9.3197095425E9d), (double) (-1024L), (-0.5440211108893698d), (double) 34, 1.4129651365067377d, 2.958103478741511E26d, 1.0333147966386297E40d, (-101.04040404040404d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0440654455329503E42d) + "'", double8 == (-1.0440654455329503E42d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1.0f));
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        double[] doubleArray42 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray49 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        double[][] doubleArray52 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, doubleArray52);
        double[] doubleArray59 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray66 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray66);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66, 3800);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 101.0d + "'", double50 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 101.0d + "'", double67 == 101.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 175.46509624423885d + "'", double68 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 143.99652773591453d + "'", double70 == 143.99652773591453d);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        double double1 = org.apache.commons.math.util.FastMath.log(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray15);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 9223372036854775807L, objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 90, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1079083008);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9251475365964139d), (double) 256.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        java.lang.Number number1 = null;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 106);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger9);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 100);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        double double1 = org.apache.commons.math.util.FastMath.log10(342.00000000000006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5340261060561353d + "'", double1 == 2.5340261060561353d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) 1072693248L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray63 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray70 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double double73 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray56);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray27);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 101.0d + "'", double71 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 20735.0d + "'", double73 == 20735.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 342.0d + "'", double74 == 342.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-46.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4321779448847783d) + "'", double1 == (-0.4321779448847783d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3841858E-7f, (float) 52L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-35));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException10.getContext();
        java.util.Set<java.lang.String> strSet12 = exceptionContext11.getKeys();
        java.util.Set<java.lang.String> strSet13 = exceptionContext11.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5430806348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 1665534083);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1665534082) + "'", int2 == (-1665534082));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 3047381646304L);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 3047381646304L + "'", number2.equals(3047381646304L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(1.957296094269961E11d, (double) (-1023), (double) (-2147483636L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount((-1980901217));
        try {
            incrementor0.incrementCount(6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1,980,901,217) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.16056393283879805d, 1.5663706143591722d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.056983663313455356d + "'", double2 == 0.056983663313455356d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        double double2 = org.apache.commons.math.util.FastMath.min(9.999999974754094E-7d, 2.688117141816135E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999974754094E-7d + "'", double2 == 9.999999974754094E-7d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9999877116625145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7182484254997905d + "'", double1 == 2.7182484254997905d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7.6293945E-6f, 0.0d, (double) 341642467);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.3440585709080678E43d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 127L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3800, (float) (-1665534082), (float) 14L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (byte) 0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray59 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double[] doubleArray67 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray74 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray74);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray67);
        double[] doubleArray82 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray89 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray82, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray82);
        double double92 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray52, doubleArray82);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double double94 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.0d + "'", double60 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 101.0d + "'", double75 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 101.0d + "'", double90 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 10003.0d + "'", double92 == 10003.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 100.01499887516871d + "'", double94 == 100.01499887516871d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.0f), objArray8);
        java.lang.Number number12 = maxCountExceededException11.getMax();
        java.lang.Number number13 = maxCountExceededException11.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-0.0f) + "'", number12.equals((-0.0f)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-0.0f) + "'", number13.equals((-0.0f)));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-2L), 2.147483636E9d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.46982219669862557d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-2), 362880000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.9073486328125E-6d, 2.2250738585072014E-308d, 0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        long long1 = org.apache.commons.math.util.FastMath.round(4.768371582031431E-7d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.140242005E9d, 1.7213429821350874E62d, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray35);
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10003.0d + "'", double45 == 10003.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.01499887516871d + "'", double61 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray42);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 1.5565115842075d);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray46);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 35, 981759551);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 106);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (short) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 106);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) (short) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (short) 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger32);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.7640532449337d + "'", double1 == 8.7640532449337d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.incrementCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        incrementor0.incrementCount();
        incrementor0.setMaximalCount(1079083008);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 11, (long) 2140242005);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2140242016L + "'", long2 == 2140242016L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.6559732987302917E20d, 2.718281828459045d, 4.34314575050763d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-2147483646), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 106);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (-1980901217));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,980,901,217)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0102525138905933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7904982316365984d + "'", double1 == 0.7904982316365984d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7.211102550927978d, (java.lang.Number) 2140242016L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.16056393283879805d, (double) 0.99999994f);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(5, univariateRealFunction5, 3200.0d, 1.8639419084E10d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray15);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 175.46509624423885d + "'", double31 == 175.46509624423885d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1079083008);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray72 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray65);
        double[] doubleArray80 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray87 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray80);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray58);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1980901217) + "'", int45 == (-1980901217));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.0d + "'", double73 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.0d + "'", double88 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 174.96856860590705d + "'", double91 == 174.96856860590705d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10L, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 9223372036854775807L, objArray14);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16.255619765854984d) + "'", double1 == (-16.255619765854984d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.2233715E18f, 70.00001f, 30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}

