import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.107875886857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.107875886857d + "'", double1 == 10.107875886857d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.5063656411097587d), 6.283185307179586d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0, 11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-101.04040404040403d), (-9.319709542E9d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        double double6 = regulaFalsiSolver0.getMax();
        double double7 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-6d + "'", double7 == 1.0E-6d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943297E8d + "'", double1 == 1.7453292519943297E8d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.util.Locale locale2 = null;
        try {
            java.lang.String str3 = localizedFormats0.getLocalizedString(locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot compute beta density at 1 when beta = %.3g" + "'", str1.equals("cannot compute beta density at 1 when beta = %.3g"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 39481480091340L, 0.33417732577148335d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.035010977236495024d) + "'", double2 == (-0.035010977236495024d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1752011936438014d, 3.58351893845611d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(45, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = 45");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.4E-45f), 45.0d, (-46));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), (int) 'a');
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.log(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 341642467);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46982219669862557d, 0.48729816431393913d);
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.5574077246549025d, 97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549025d + "'", double2 == 1.5574077246549025d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getStartValue();
        double double4 = regulaFalsiSolver1.getAbsoluteAccuracy();
        int int5 = regulaFalsiSolver1.getEvaluations();
        int int6 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.01745417862959511d, 44.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017454178629595113d + "'", double2 == 0.017454178629595113d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-97L), (float) 465985477100L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.tan(88.5808275421977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7082376834970003d + "'", double1 == 0.7082376834970003d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 9.2233715E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30, 10);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (short) 0);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger38, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection49, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (-9.3197095425E9d), 1, orderDirection49, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) (-35), 1072693248, orderDirection49, false);
        try {
            boolean boolean58 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30, orderDirection49, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-46));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9171523356672744d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0512497153941978d) + "'", double1 == (-1.0512497153941978d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) ' ');
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) ' ');
        int[] intArray12 = new int[] {};
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 341642467);
        java.lang.Throwable[] throwableArray3 = notPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray63 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray70 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double double73 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray56);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray27);
        java.math.BigInteger bigInteger79 = null;
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger79, (long) (short) 0);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException87 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) bigInteger83, (-1), orderDirection85, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-9.319709542E9d), (java.lang.Number) 1.9155040003582885E22d, (int) (short) 1, orderDirection85, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection85, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (35 < 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 101.0d + "'", double71 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 20735.0d + "'", double73 == 20735.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 342.0d + "'", double74 == 342.0d);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(6L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.99999994f, (float) 34, (float) 10000000000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 70);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 70L + "'", long1 == 70L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(2.3299273855E11d, (-6.000000001096488d), 1.2850972089d, 3628800.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean34 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection31, true, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.01499887516871d + "'", double30 == 100.01499887516871d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.5430806348152437d, 0.0d, 3.6267774588438875E24d, 2.99822295029797d, (double) (short) 1, (double) 35L, (double) 90, 1.5430806348d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0873887412729094E25d + "'", double8 == 1.0873887412729094E25d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection29, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 45);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getHi();
        double double13 = noBracketingException9.getLo();
        org.apache.commons.math.exception.MathInternalError mathInternalError14 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray5);
        java.lang.Object[] objArray7 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray5);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        float float2 = org.apache.commons.math.util.FastMath.max(97.00001f, 3.51843754E14f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.51843754E14f + "'", float2 == 3.51843754E14f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray11 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray11);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray8);
        int[] intArray16 = new int[] {};
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray17);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray13);
        double double18 = noBracketingException17.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(9.223372E18f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0195652940572162d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray72 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray65);
        double[] doubleArray80 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray87 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray80);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray58);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1980901217) + "'", int45 == (-1980901217));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.0d + "'", double73 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.0d + "'", double88 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 174.96856860590705d + "'", double91 == 174.96856860590705d);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.3431851641374776E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1023), (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 10L, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray16);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException20 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.sinh(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.166573983193148E39d + "'", double1 == 5.166573983193148E39d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.5574077246549023d, (double) 6L, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        long long1 = org.apache.commons.math.util.FastMath.abs(1980901215L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1980901215L + "'", long1 == 1980901215L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.0E-6f), (-127.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 362880000L, (float) (-1980901215L), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger5, false);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 341642467);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray21);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 20735.0d, objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (-2L), objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray21);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException26 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException27 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) bigInteger5, objArray21);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        org.apache.commons.math.util.MathUtils.checkFinite(0.8342233605065102d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.16056393283879805d, 1.0146664566373451d, 5.267831587699267d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double9 = regulaFalsiSolver0.solve(1079083008, univariateRealFunction5, (double) Float.POSITIVE_INFINITY, (double) 4.0f, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(2.140242005100442E9d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = localizedFormats0.getLocalizedString(locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = new float[] {};
        float[] floatArray19 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray21 = new float[] { (byte) 1 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray31 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray33 = new float[] { (byte) 1 };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray33);
        float[] floatArray35 = new float[] {};
        float[] floatArray42 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray44 = new float[] { (byte) 1 };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray42, floatArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray35, floatArray42);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray35);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray35);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.09741807476623128d, 0.0d, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 30, (float) 106);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(3.51843754E14f, (int) (byte) 1, 34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 34, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        long long2 = org.apache.commons.math.util.MathUtils.pow(14L, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 537824L + "'", long2 == 537824L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2147483647, (-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: overflow in subtraction: 2,147,483,647 - -2,147,483,648");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-127));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.7585477E15f + "'", float1 == 2.7585477E15f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8836011904065779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 4.34314575050763d, (-2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.6881171418161356E43d, 1.5430806348152437d, 0.0d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (-1023));
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        int int5 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray20);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray20);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray20);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException27 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Number) 10L, objArray36);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray36);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray36);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) int5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1023) + "'", int5 == (-1023));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 341642573L, (float) (-1565238004));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-97L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (null) exceeded: evaluations");
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException9.getContext();
        java.util.Set<java.lang.String> strSet11 = exceptionContext10.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        long long1 = org.apache.commons.math.util.FastMath.abs((-97L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection17, false);
        double[] doubleArray25 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[] doubleArray31 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection17, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 161700.0d, 24.0d, (double) (-97L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-1023L), 0.46982219669862557d, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1024L, 5.166573983193148E39d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(18639419084L, (-44563605345380415L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 537824L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.73064017839119d + "'", double1 == 5.73064017839119d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(5.73064017839119d, 3.6288E9d, (double) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 1.1752011936438014d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 0.0d, 10230.488746878127d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-97L), (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-100.0f) + "'", float3 == (-100.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 63, (long) 45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 315L + "'", long2 == 315L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1980901217), (-358450367));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = -358,450,367, n = -1,980,901,217");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 0);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.01499887516871d + "'", double30 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        float float1 = org.apache.commons.math.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 30.0f, (double) 97.00001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 63.500003814697266d + "'", double2 == 63.500003814697266d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 3.6267774588438875E24d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 10, 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 35.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 3.831008000716578E22d, 1.4210854715202004E-14d, (double) 45, 0.16056393283879805d, objArray14);
        double double16 = noBracketingException15.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.16056393283879805d + "'", double16 == 0.16056393283879805d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        float float2 = org.apache.commons.math.util.FastMath.min(3628800.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 35.0d, (double) (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1980901215L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(Double.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException3 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.48729816431393913d);
        java.lang.Throwable[] throwableArray4 = tooManyEvaluationsException3.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3047381646304L, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 10000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) 10, (double) 6, (double) (byte) 1);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 1.0000000000000002d, (double) (-1), 1.9073486328125E-6d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2147483646), (-35));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 0.99999994f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        int int7 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.incrementCount();
        incrementor0.incrementCount();
        incrementor0.setMaximalCount(1024);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        org.apache.commons.math.util.MathUtils.checkFinite(10003.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.4657359027997265d, (double) 45, (-1565238004));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 9.223373E18f, 10.107875886857d, 0.047442967903742035d, 1.0195652940572162d, 1.0000000000000002d, 4853.89129293241d, 0.09741807476623128d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 474.35585780738086d + "'", double8 == 474.35585780738086d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.0d, 0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.0E10d, 104.0d, 0.009710801264635796d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.990289198735365d + "'", double3 == 15.990289198735365d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0E-6f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.570698575084553d, 1.0120948455406895d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double2 = org.apache.commons.math.util.FastMath.max(129.12393363912722d, 3628800.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3628800.0d + "'", double2 == 3628800.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.signum(720.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1072693248, (-35));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-358450367));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-358,450,367)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(97.00000000000001d, 0.16814528752542068d, 1.1058338518107955E19d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, 6.691673596021348E41d, Double.NEGATIVE_INFINITY);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver3.solve((int) ' ', univariateRealFunction5, 3.831008000716578E22d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.MathUtils.sign(20.793438378082765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 9468.356456209538d);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray41 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray48 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray48);
        double[] doubleArray58 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray65 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray48, doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection72, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext75 = nonMonotonousSequenceException74.getContext();
        java.lang.Number number76 = nonMonotonousSequenceException74.getPrevious();
        int int77 = nonMonotonousSequenceException74.getIndex();
        java.lang.String str78 = nonMonotonousSequenceException74.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException74.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection79, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (35 < 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2140242005 + "'", int35 == 2140242005);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 101.0d + "'", double49 == 101.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 143.99652773591453d + "'", double51 == 143.99652773591453d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 101.0d + "'", double66 == 101.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 20735.0d + "'", double68 == 20735.0d);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (byte) 10 + "'", number76.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 6 + "'", int77 == 6);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)" + "'", str78.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)"));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(1.1058338518107955E19d, (-0.9171523356672744d), 1.1752011936438014d, 174.96856860590705d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0142181000482097E19d) + "'", double4 == (-1.0142181000482097E19d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(4.584967478670572d, (-0.8390715290764524d), 95.0d, 9747.916313026086d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 926048.202621805d + "'", double4 == 926048.202621805d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5574077246549025d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1665534083 + "'", int1 == 1665534083);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        int int7 = incrementor0.getCount();
        incrementor0.setMaximalCount(10230);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(11, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.asinh(100.01499887516871d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298492335617899d + "'", double1 == 5.298492335617899d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 6, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, 52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 6, (double) 'a', (double) 70.00001f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3104L, (-1.9999999f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (-358450367));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        java.lang.String str13 = noBracketingException9.toString();
        double double14 = noBracketingException9.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str13.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-2147483646), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147483636L) + "'", long2 == (-2147483636L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = new float[] {};
        float[] floatArray19 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray21 = new float[] { (byte) 1 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray25 = new float[] {};
        float[] floatArray32 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray34 = new float[] { (byte) 1 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray32);
        float[] floatArray37 = new float[] {};
        float[] floatArray44 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray46 = new float[] { (byte) 1 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray37, floatArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray44);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray44);
        float[] floatArray52 = new float[] { 0 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray44, floatArray52);
        float[] floatArray54 = new float[] {};
        float[] floatArray61 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray63 = new float[] { (byte) 1 };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(floatArray61, floatArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray54, floatArray61);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray44, floatArray54);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3.51843721E14f, (double) (-358450367));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 70L, (-0.08288831974674488d), (double) 35, 3.4657359027997265d, 101.0d, (double) 1.09951163E12f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.110506744054915E14d + "'", double6 == 1.110506744054915E14d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-358450366));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.58450368E8f + "'", float1 == 3.58450368E8f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(3.141592653589793d, 1.0120948455406895d, 4853.89129293241d, 0.0d);
        java.lang.Throwable[] throwableArray5 = noBracketingException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        try {
            org.apache.commons.math.util.MathUtils.checkFinite(Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotFiniteNumberException; message: � is not a finite number");
        } catch (org.apache.commons.math.exception.NotFiniteNumberException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-358450367), 1.6929695075925542d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.58450336E8f) + "'", float2 == (-3.58450336E8f));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 7.2057601E17f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6710818042072318d + "'", double1 == 0.6710818042072318d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray7);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray5);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (int) (byte) 100);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 2.7585477E15f, (double) 10.0f, 34.99999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2,758,547,704,119,296, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 4L, (double) 1.0E-6f, (-1.3007446917685998E15d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1.4E-45f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6.283185307179586d);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notPositiveException2.getMin();
        java.lang.String str5 = notPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotPositiveException: endpoints do not specify an interval: [6.283, 0]" + "'", str5.equals("org.apache.commons.math.exception.NotPositiveException: endpoints do not specify an interval: [6.283, 0]"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger10, false);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger15);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 106);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger26);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger26);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger26);
        try {
            java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (-35));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-35)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.3841858E-7f + "'", float1 == 2.3841858E-7f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 14L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2446066160948055d + "'", double1 == 7.2446066160948055d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 9.848857801796104d, 0.09711106517906329d, (double) (-981759551), 0.0d, objArray13);
        double double19 = noBracketingException18.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 9.848857801796104d + "'", double19 == 9.848857801796104d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-1.0512497153941978d), (double) 34);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.01745417862959511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray12);
        java.util.Set<java.lang.String> strSet14 = exceptionContext9.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray27);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 20735.0d, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException30 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) (-2L), objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray27);
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, number32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException40 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Number) 10L, objArray39);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException47 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Number) 10L, objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray46);
        notStrictlyPositiveException33.addSuppressed((java.lang.Throwable) mathIllegalArgumentException48);
        java.lang.Throwable[] throwableArray50 = mathIllegalArgumentException48.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException51 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray50);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536738616591883E-7d + "'", double1 == 9.536738616591883E-7d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 465985477100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.659854771E11d + "'", double1 == 4.659854771E11d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-97L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.14510469346731042d), 101.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.14510469346731042d) + "'", double2 == (-0.14510469346731042d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        int int11 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 106);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (short) 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (int) (short) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger19);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.9073486328125E-6d, (java.lang.Number) bigInteger3, 10);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.cos(161700.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6094156883605427d) + "'", double1 == (-0.6094156883605427d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, 6.691673596021348E41d, Double.NEGATIVE_INFINITY);
        double double4 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve((int) (short) 1, univariateRealFunction6, (double) 14L, 0.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10L, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 10L, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (byte) 1, 2.99822295029797d, 100.00499987500625d, (double) 362880000L, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, localizable9, objArray27);
        java.lang.Object[] objArray32 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (-2147483636L), 5.73064017839119d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.147483636E9d + "'", double2 == 2.147483636E9d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 92.13617560368711d, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (byte) 0);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46, (int) '#');
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1076232192, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076232203L + "'", long2 == 1076232203L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 100.0f);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray14);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.009710801264635796d, objArray14);
        notPositiveException1.addSuppressed((java.lang.Throwable) notFiniteNumberException19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-9.3197097E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-981759551), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (-2.0d), (double) 100.00001f, (double) 50.0f, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1058338518107955E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.4050196873014067d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1401248639 + "'", int1 == 1401248639);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.8639419084E10d, 7.2446066160948055d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8639419084E10d + "'", double2 == 1.8639419084E10d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray20);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray51);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, (int) (byte) 0);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.01499887516871d + "'", double30 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.01499887516871d + "'", double61 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.513155876994848d, (-58613.58244188321d), 1.4327039495545584E20d, 8.533571983992772d, 0.0d, (double) 1.0E-6f, (double) (-127), 2.958103478741511E26d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-3.7567912957408964E28d) + "'", double8 == (-3.7567912957408964E28d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 716100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 90, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 187L + "'", long2 == 187L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray10);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) 'a');
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray27);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray10);
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray36 = new int[] {};
        int[] intArray37 = new int[] {};
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray37);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray41 = new int[] {};
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray46);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray51);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray50);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int[] intArray64 = org.apache.commons.math.util.MathUtils.copyOf(intArray63);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray63);
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray63, (int) 'a');
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray63);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray63);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray46);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray46);
        int[] intArray73 = null;
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray73);
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, (int) '#');
        int[] intArray77 = new int[] {};
        int[] intArray78 = new int[] {};
        int[] intArray79 = org.apache.commons.math.util.MathUtils.copyOf(intArray78);
        int[] intArray80 = new int[] {};
        int[] intArray81 = org.apache.commons.math.util.MathUtils.copyOf(intArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray78, intArray80);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray80);
        int[] intArray84 = new int[] {};
        int[] intArray85 = new int[] {};
        int[] intArray86 = org.apache.commons.math.util.MathUtils.copyOf(intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray85);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray84);
        try {
            double double89 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray84);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, 28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 28, n = -1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 3104L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1102230246251565E-16d, 0.7938312476336207d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.398563016931731E-16d + "'", double2 == 1.398563016931731E-16d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        int int3 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1023.9999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 187L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 187.0f + "'", float2 == 187.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10230.000000014888d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10230.000000014887d + "'", double2 == 10230.000000014887d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.5282839739597524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.589615898275564d + "'", double1 == 0.589615898275564d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) ' ', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-0.4505495340698077d), objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException15 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (int) 'a', (-1023));
        java.lang.Throwable[] throwableArray16 = dimensionMismatchException15.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        org.apache.commons.math.exception.MathInternalError mathInternalError0 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Class<?> wildcardClass1 = mathInternalError0.getClass();
        java.lang.Throwable[] throwableArray2 = mathInternalError0.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        float float2 = org.apache.commons.math.util.FastMath.min(9.536743E-7f, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536743E-7f + "'", float2 == 9.536743E-7f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.0d, (double) 2140242005);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0701210025E9d + "'", double2 == 1.0701210025E9d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) 4.7683716E-7f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7938312476336207d, 8.8454160025231072E16d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-1.0512497153941978d), (-0.4505495340698077d), (double) 1.0E-6f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException24 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 10L, objArray23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (-0.4505495340698077d), objArray23);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray23);
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) mathArithmeticException26);
        java.lang.String str28 = mathArithmeticException26.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: Cannot normalize to NaN" + "'", str28.equals("org.apache.commons.math.exception.MathArithmeticException: Cannot normalize to NaN"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Float.NaN, (float) (-46), (-127));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4857159644818056E138d + "'", double1 == 1.4857159644818056E138d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0142181000482097E19d), 5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0142181000482097E19d) + "'", double2 == (-1.0142181000482097E19d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray4);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray9);
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray8);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray16);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray16);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray13);
        try {
            int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.6710818042072318d, 24.0d, 2.99822295029797d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [24, 2.998]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        try {
            double double21 = regulaFalsiSolver3.solve(3, univariateRealFunction19, 1.1058338518107955E19d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-15d + "'", double17 == 1.0E-15d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1401248639);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5663706143591722d);
        double double2 = regulaFalsiSolver1.getMin();
        double double3 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(14L, 315L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 329L + "'", long2 == 329L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-18639419084L), (double) 187L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8639419083999996E10d) + "'", double2 == (-1.8639419083999996E10d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, (double) (-35));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4E-45f) + "'", float2 == (-1.4E-45f));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 0L, 1.4857159644818056E138d, 0.4455175430087551d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.4119627100860633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3901379238959021d) + "'", double1 == (-0.3901379238959021d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1980901215L, (-0.15920507027249187d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.980901215E9d + "'", double2 == 1.980901215E9d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 106, (double) 63, 6.044629098073146E23d, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 9468.356456209538d);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray41 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray48 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray48);
        double[] doubleArray58 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray65 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray48, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray65);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray65);
        java.lang.Class<?> wildcardClass71 = doubleArray65.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2140242005 + "'", int35 == 2140242005);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 101.0d + "'", double49 == 101.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 143.99652773591453d + "'", double51 == 143.99652773591453d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 101.0d + "'", double66 == 101.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 20735.0d + "'", double68 == 20735.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 20358520L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5565115857642013d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.9668078739084828d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7685236247170785d) + "'", double1 == (-0.7685236247170785d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger5, false);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        try {
            java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (-1980901217));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,980,901,217)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0.0f, (double) 39481480091340L, 38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.0512497153941978d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0167994369962388d) + "'", double1 == (-1.0167994369962388d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1, 70);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) ' ', (float) 6, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        float float3 = org.apache.commons.math.util.MathUtils.round(1.1920929E-7f, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.1920929E-7f + "'", float3 == 1.1920929E-7f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int int2 = org.apache.commons.math.util.FastMath.max(45, 2140242005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2140242005 + "'", int2 == 2140242005);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.831008000716578E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.583313058969097d + "'", double1 == 22.583313058969097d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(90, 1076232192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076232282 + "'", int2 == 1076232282);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(1.1920929E-7f, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920928E-7f + "'", float2 == 1.1920928E-7f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-2), 20735.0d, 9.848857801796104d, 1.1752011936438014d);
        double double5 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.0d) + "'", double5 == (-2.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.6931471805599453d, (double) 100.0f, (double) 0.0f, 0.6931471805599453d);
        double double5 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 30.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 342.00000000000006d, (java.lang.Number) 0.047442967903742035d, true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106 + "'", int2 == 106);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1.4E-45f), (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-127.0d), 3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-3.7567912957408964E28d), 62.26061319933956d, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 3.51843754E14f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) ' ', (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getStartValue();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver0.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double11 = regulaFalsiSolver0.solve(1079083008, univariateRealFunction7, 1.1102230246251565E-16d, 0.0d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.16056393283879805d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.400704296007415d + "'", double1 == 0.400704296007415d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.7853981633974483d), (java.lang.Number) 1.4E-45f, false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2147483648), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147483648L) + "'", long2 == (-2147483648L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int2 = org.apache.commons.math.util.FastMath.max(1401248639, 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1401248639 + "'", int2 == 1401248639);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1072693248, (-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: overflow in subtraction: 1,072,693,248 - -2,147,483,648");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -2,147,483,648");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (byte) 1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) bigInteger4, (java.lang.Number) (-0.9171523356672744d), false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-981759551), (-981759551));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 981759551 + "'", int2 == 981759551);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        java.lang.String str13 = noBracketingException9.toString();
        double double14 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str13.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 143.99652773591453d, (double) (byte) 10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (-2.12489865774099891E18d), (double) 45, (-101.04040404040404d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013707783890401887d + "'", double1 == 0.013707783890401887d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.999999974754094E-7d + "'", double1 == 9.999999974754094E-7d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (-97), (-1329415437));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        java.lang.Number number2 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number2, (java.lang.Number) 1.0d, 0, orderDirection5, false);
        java.lang.Number number8 = nonMonotonousSequenceException7.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError9 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10L, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException19.getContext();
        java.util.Set<java.lang.String> strSet21 = exceptionContext20.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        exceptionContext20.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException7, localizable10, objArray23);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(0);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.33417732577148335d, (java.lang.Number) 1.0E10d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 34);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 106);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger23);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 100);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger23);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) bigInteger23, (java.lang.Number) 100.0f, false);
        java.lang.Number number34 = numberIsTooLargeException33.getMax();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100.0f + "'", number34.equals(100.0f));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray4);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        try {
            int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1.0f));
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        double[] doubleArray42 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray49 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        double[][] doubleArray52 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, doubleArray52);
        double[] doubleArray59 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray66 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray66);
        java.math.BigInteger bigInteger71 = null;
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger71, (long) (short) 0);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException77 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger75, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection86 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection86, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException90 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (-9.3197095425E9d), 1, orderDirection86, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException92 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) (-35), 1072693248, orderDirection86, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection86, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (35 <= 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 101.0d + "'", double50 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 101.0d + "'", double67 == 101.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 175.46509624423885d + "'", double68 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertTrue("'" + orderDirection86 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection86.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray7);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray5);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray19);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1L, (-58613.58244188321d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver2.solve(34, univariateRealFunction4, (double) 1.0E10f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5282839739597524d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-2), (double) 100.0f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve((-1023), univariateRealFunction4, (double) Float.NaN, 1.5574077246549025d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double double2 = org.apache.commons.math.util.FastMath.copySign(34.0d, 9747.916313026086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.0f), 1.1920929E-7f, 1401248639);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.resetCount();
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 38, 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 38.0f + "'", float2 == 38.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 95.0d, 0.0d, (double) (-23L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1076232282, number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 3.8146973E-6f, 32.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0000038146972656d + "'", double3 == 1.0000038146972656d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-2.270227759920085E13d), 3.6288E9d, (double) 40);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1240007591484375E9d + "'", double3 == 3.1240007591484375E9d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int2 = org.apache.commons.math.util.MathUtils.pow(90, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3628800L, (-23L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-83462400L) + "'", long2 == (-83462400L));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.017453292519943295d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.16056393283879805d, (double) 0.99999994f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver10 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5663706143591722d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver10, 720.0d, (double) 10.0f, (double) 10L, allowedSolution14);
        try {
            double double16 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction4, 15.990289198735365d, 92.13617560368711d, allowedSolution14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 720.0d + "'", double15 == 720.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray13 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray13);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray37 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray44 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray46);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 101.0d + "'", double14 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 101.0d + "'", double45 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 315L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 315.0f + "'", float1 == 315.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.8639419083999996E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(28, 90);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 90, n = 28");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1024L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5698197646053373d + "'", double1 == 1.5698197646053373d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, (-358450367));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-358,450,367)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1L, (-58613.58244188321d));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathIllegalStateException16.getContext();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) mathIllegalStateException16);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException20 = new org.apache.commons.math.exception.TooManyEvaluationsException(number19);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) tooManyEvaluationsException20);
        java.lang.Number number22 = tooManyEvaluationsException20.getMax();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(474.35585780738086d, 0.0d, 0.0d, (double) 7.2057601E17f, 926048.202621805d, 9.139598282174859E44d, 3.9889117920610055d, (double) 9.223373E18f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.463708561893364E50d + "'", double8 == 8.463708561893364E50d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10L, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException19.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray27);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException29 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Number) 10L, objArray35);
        exceptionContext20.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray35);
        exceptionContext9.setValue("cannot compute beta density at 1 when beta = %.3g", (java.lang.Object) exceptionContext20);
        java.util.Set<java.lang.String> strSet39 = exceptionContext20.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(strSet39);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8101836031147954d, 0.9913289158005998d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (-3.7567912957408964E28d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.7567912957408964E28d) + "'", double2 == (-3.7567912957408964E28d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (short) 0, (-127));
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-127) + "'", int4 == (-127));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 70.00001f, 2.573416701630061E34d, 23.648544480750406d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 100.0f);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2147483636L), 1024);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 70L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6917246496340396E41d + "'", double1 == 6.6917246496340396E41d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 38);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.330906425536431d + "'", double1 == 4.330906425536431d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) 0, 0.7082376834970003d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(10.107875886857d, 1.285097208938469d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.6964865478977345d + "'", double2 == 5.6964865478977345d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 6.0f, (double) 3628800L, 0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (byte) 1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) tooManyEvaluationsException1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 341642573L, (-9.319709542E9d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009999999991584142d + "'", double1 == 0.009999999991584142d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 2L, 0.400704296007415d, (-1980901217));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger5, false);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (byte) 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = maxCountExceededException6.getContext();
        java.lang.Object obj9 = exceptionContext7.getValue("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        long long1 = org.apache.commons.math.util.FastMath.round(1.570698575084553d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection18, false);
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException20.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Object[]) throwableArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.18503986326152d + "'", double1 == 2.18503986326152d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483646), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483646) + "'", int2 == (-2147483646));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) -1, (-83462400L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1079083008, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079083008E9d + "'", double2 == 1.079083008E9d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) ' ', Float.POSITIVE_INFINITY, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-18639419085L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18639419085L + "'", long2 == 18639419085L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.09951163E12f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.041199826559248d + "'", double1 == 12.041199826559248d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str1.equals("{0} is larger than, or equal to, the maximum ({1})"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int1 = org.apache.commons.math.util.FastMath.round(Float.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3047381646304L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        double double5 = regulaFalsiSolver0.getRelativeAccuracy();
        double double6 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-6d + "'", double6 == 1.0E-6d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-127), 2147483647);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 341642573L, (-1329415437));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(174.96856860590705d, 0.0d, (double) (-46.0f));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-22.180709776986927d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray15);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22);
        double[] doubleArray37 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray44 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray37);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray37);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (-3.584492136767125E9d));
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 101.0d + "'", double45 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1980901217) + "'", int50 == (-1980901217));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 10L, 0.9075712110370514d, 6.283185307179586d, (double) 100L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = mathArithmeticException21.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        java.lang.String str24 = localizedFormats23.getSourceString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException33 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Number) 10L, objArray32);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException34 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) (-0.4505495340698077d), objArray32);
        exceptionContext22.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "cannot compute beta density at 1 when beta = %.3g" + "'", str24.equals("cannot compute beta density at 1 when beta = %.3g"));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(97, (int) 'a');
        int int3 = dimensionMismatchException2.getDimension();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException2.getContext();
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger16, false);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (short) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger24);
        exceptionContext4.setValue("cannot compute beta density at 1 when beta = %.3g", (java.lang.Object) bigInteger24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 2.0d, 0.0d, 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 2140242005, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2140242005L + "'", long2 == 2140242005L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.5860134523134298E15d, 6.283185307179586d, (-1.1752011936438014d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-1980901217));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        float float3 = org.apache.commons.math.util.MathUtils.round((-1.0f), (int) '#', 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 9468.356456209538d);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray41 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray48 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray48);
        double[] doubleArray58 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray65 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray65);
        double[] doubleArray72 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray79 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray72, doubleArray79);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray72);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray72);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray72);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (-1));
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2140242005 + "'", int35 == 2140242005);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 101.0d + "'", double49 == 101.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 143.99652773591453d + "'", double51 == 143.99652773591453d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 101.0d + "'", double66 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 101.0d + "'", double80 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1565238004));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1023L), (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.6929695075925542d, 1.5574077246549023d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 20735.0d, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-2L), objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) 10L, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) 10L, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray29);
        notStrictlyPositiveException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException31);
        java.lang.Throwable[] throwableArray33 = mathIllegalArgumentException31.getSuppressed();
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double double1 = org.apache.commons.math.util.FastMath.asin(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-9.3197095425E9d), 0.5097826470286081d, 2.140242005E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 0, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-100L), 3.51843754E14f, 1076232192);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "", localizedFormats8, localizedFormats9 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.0d), objArray10);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int2 = org.apache.commons.math.util.FastMath.min(3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 14L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4994888620096063d + "'", double1 == 1.4994888620096063d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 104.0d, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 10230.488746878127d, (double) (-1.0f), 0.9913289158005998d, 3628800.0d, objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (java.lang.Number) 10L, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray27);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray27);
        java.lang.Object[] objArray31 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray31);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double[] doubleArray66 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray73 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66);
        double[] doubleArray83 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray90 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray83);
        double[][] doubleArray93 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray83, doubleArray93);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray77, doubleArray93);
        try {
            double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-358450367) + "'", int59 == (-358450367));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 101.0d + "'", double74 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 100.01499887516871d + "'", double76 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 101.0d + "'", double91 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathInternalError7.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection13, false);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 106);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger26);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) bigInteger29, (java.lang.Number) 3628800L, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException39 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 10L, objArray38);
        org.apache.commons.math.exception.NotPositiveException notPositiveException41 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray42 = notPositiveException41.getSuppressed();
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray42);
        java.lang.Object[] objArray44 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray42);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10L, objArray24);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray24);
        exceptionContext9.setValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < null)", (java.lang.Object) 32L);
        java.lang.Object obj31 = exceptionContext9.getValue("cannot compute beta density at 1 when beta = %.3g");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5097826470286081d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4119656981009763d + "'", double1 == 0.4119656981009763d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathInternalError7.getContext();
        float[] floatArray10 = new float[] {};
        float[] floatArray17 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray19 = new float[] { (byte) 1 };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray17, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray17);
        exceptionContext8.setValue("Conversion Exception in Transformation: {0}", (java.lang.Object) floatArray17);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 6L, 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution7);
        double double9 = regulaFalsiSolver2.getRelativeAccuracy();
        double double10 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-14d + "'", double9 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.4260624389053682d, (double) (-1024.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0009929946746d + "'", double2 == 1024.0009929946746d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (byte) 0);
        double[] doubleArray52 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray59 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray52);
        double[] doubleArray69 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray76 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray76);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray69);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray69);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.0d + "'", double60 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.01499887516871d + "'", double62 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 101.0d + "'", double77 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.9998476951563913d, objArray2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = maxCountExceededException3.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20735.0d, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = maxCountExceededException9.getContext();
        java.lang.Object obj12 = exceptionContext10.getValue("cannot access {0} method in percentile implementation {1}");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException9.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        exceptionContext10.setValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not decreasing (10 < 34)", (java.lang.Object) localizedFormats12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(716100L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 716101L + "'", long2 == 716101L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(4194304.0d, 3.948148009134034E13d, 0.0d, (double) 3628800.0f, 1.0195652940572162d, (-0.08288831974674488d), (double) (-1024L), 1.9073486328125E-6d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.6559732987302917E20d + "'", double8 == 1.6559732987302917E20d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-0.4119627100860633d), (double) 1.1920928E-7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4119627100860633d + "'", double2 == 0.4119627100860633d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 35.0d);
        java.lang.Throwable[] throwableArray2 = tooManyEvaluationsException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-18639419085L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) ' ', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4657359027997265d + "'", double2 == 3.4657359027997265d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-358450366));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-358,450,366)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        double double2 = org.apache.commons.math.util.FastMath.pow(10230.488746878127d, (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 4.7683716E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.768371582031431E-7d + "'", double1 == 4.768371582031431E-7d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 2.140242005100442E9d, 0.0d, (double) 9.223373E18f, 40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray33 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray40 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray48);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray33);
        double[] doubleArray66 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray73 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66);
        double[] doubleArray81 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray88 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray81);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 0.589615898275564d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.0d + "'", double41 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 101.0d + "'", double74 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.0d + "'", double89 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 100.01499887516871d + "'", double92 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1058338518107955E19d, (double) (-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        org.apache.commons.math.util.MathUtils.checkFinite(3.3431851641374776E20d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5063656411097587d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39731803409122196d) + "'", double1 == (-0.39731803409122196d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        double double6 = regulaFalsiSolver0.getMax();
        double double7 = regulaFalsiSolver0.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-14d + "'", double7 == 1.0E-14d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 2, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, 1980901215L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8698165080591833d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.0E-15d, (-3.7567912957408964E28d), 0.0d, 40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1980901215L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.98090125E9f + "'", float1 == 1.98090125E9f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1072693248, 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693338 + "'", int2 == 1072693338);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 10000000000L, 1.3440585709080678E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 9.536738616591883E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, (int) 'a');
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray20);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray20);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray30);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray30);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray30);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(720.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.566370614359172d + "'", double1 == 12.566370614359172d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(0);
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20735.0d, objArray7);
        org.apache.commons.math.exception.NotPositiveException notPositiveException11 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.3007446917685998E15d));
        boolean boolean12 = notPositiveException11.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (short) 1, 1.5663706143591722d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(30, (-358450367));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-127));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(19784.578601884947d, (double) 28, (double) 4.7683716E-7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        int int4 = regulaFalsiSolver0.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver0.solve(1072693248, univariateRealFunction6, 161700.0d, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(90, (-1565238004));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMax();
        double double18 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-15d + "'", double18 == 1.0E-15d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException64 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection62, false);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection62, true, false);
        double[] doubleArray73 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray80 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray73, doubleArray80);
        double[] doubleArray87 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray94 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray87, doubleArray94);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray87);
        try {
            double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 101.0d + "'", double81 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 101.0d + "'", double95 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7685236247170785d), 1.0146664566373451d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 329L, (float) 465985477100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 329.0f + "'", float2 == 329.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.009710801264635796d, (double) 187.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [187, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 39481480091340L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray7);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray5);
        int[] intArray13 = new int[] { 4, 10230 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray18 = new int[] {};
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray18);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray18);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray22);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray30);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray30);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray35);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) 'a');
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray35);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray35);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray43);
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray42);
        int[] intArray47 = new int[] {};
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray49);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray47);
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray47);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray47);
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray47);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.848857801796104d, 4194304.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.8639419083999996E10d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, 63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 63, n = 10");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver0.solve(10, univariateRealFunction4, 0.0d, 4.755250792540576E198d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-2.0f), 5.656854249492381d, (double) 32L);
        double double4 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10L, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (-0.0f), objArray11);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        java.lang.Class<?> wildcardClass16 = objArray11.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 38.0f, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.Number number0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException(number0, objArray1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5663706143591722d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 1.98090125E9f, (double) 7.6293945E-6f, 1.5663706143591722d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        double[][] doubleArray61 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray51, doubleArray61);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection45, doubleArray61);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        java.lang.Class<?> wildcardClass65 = doubleArray12.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (-2));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 2.3299273855E11d, 129.12393363912722d, 1.1848836590513583d, 10230);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(92.13617560368711d, (-0.7685236247170785d), (double) 3.58450368E8f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [92.136, -0.769]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.8752288940032076d, 39.71440802747728d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 39.72405103447847d + "'", double2 == 39.72405103447847d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 329L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0E-15d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long2 = org.apache.commons.math.util.FastMath.max(362880000L, (long) 2140242005);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2140242005L + "'", long2 == 2140242005L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        exceptionContext0.setValue("hi!", (java.lang.Object) localizedFormats2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) Float.NaN);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3628814.4197382154d, 8.463708561893364E50d, 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        float float2 = org.apache.commons.math.util.FastMath.scalb(3.8146973E-6f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.00390625f + "'", float2 == 0.00390625f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) (-1), (double) (-35));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 10L, (double) (-9.3197097E9f), (-1980901217));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray5);
        double double7 = noBracketingException6.getHi();
        double double8 = noBracketingException6.getLo();
        java.lang.String str9 = noBracketingException6.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray17);
        noBracketingException6.addSuppressed((java.lang.Throwable) mathIllegalStateException20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: -1 is not a finite number" + "'", str9.equals("org.apache.commons.math.exception.NoBracketingException: -1 is not a finite number"));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-0.32162240316253093d), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2147483646));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.FastMath.floor(9.139598282174859E44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.139598282174859E44d + "'", double1 == 9.139598282174859E44d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1023L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1023.0f + "'", float1 == 1023.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10L, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (-0.0f), objArray11);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        java.lang.Class<?> wildcardClass16 = objArray11.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-9.3197095425E9d), (java.lang.Number) 50.0f, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException4);
        boolean boolean8 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean9 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 50.0f + "'", number5.equals(50.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-9.3197095425E9d) + "'", number6.equals((-9.3197095425E9d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.0E-15d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray15 = new java.lang.Object[] { "", localizedFormats13, localizedFormats14 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray15);
        double double17 = noBracketingException16.getFLo();
        double double18 = noBracketingException16.getFLo();
        double double19 = noBracketingException16.getLo();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) noBracketingException16);
        int int21 = nonMonotonousSequenceException5.getIndex();
        boolean boolean22 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1980901217) + "'", int15 == (-1980901217));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.3841858E-7f, (java.lang.Number) bigInteger8, 6);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(720.0d, (double) (-100L), 0.0d, (-3.7567912957408964E28d), 2.220446049250313E-16d, 21.15557659395077d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-72000.0d) + "'", double6 == (-72000.0d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int int1 = org.apache.commons.math.util.MathUtils.hash(6.044629098073146E23d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1155530752 + "'", int1 == 1155530752);
    }
}

