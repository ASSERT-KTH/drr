import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.48729816431393913d, (double) 0L, 0.0d, (double) (byte) -1);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693248L + "'", long2 == 1072693248L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1072693248, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20358520L + "'", long2 == 20358520L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-2.270227759920085E13d), (-2.5663706143591725d), (double) (-0.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        java.util.Locale locale2 = null;
        try {
            java.lang.String str3 = localizedFormats0.getLocalizedString(locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 97, 6.691673596021348E41d, 21.15557659395077d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 35);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9913289158005998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8752288940032076d + "'", double1 == 0.8752288940032076d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray33 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray40 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray48);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.0d + "'", double41 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10L, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.4505495340698077d), objArray7);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(9.223372E18f, (double) (-4.6598547E11f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.2233715E18f + "'", float2 == 9.2233715E18f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.0817069768229715d, 0.0d, 19784.578601884947d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9171523356672744d) + "'", double1 == (-0.9171523356672744d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        try {
            double double21 = regulaFalsiSolver3.solve(1072693248, univariateRealFunction18, 5.216385381925387d, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-981759551), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 35, n = -981,759,551");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        try {
            double double3 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) 10, (double) 6, (double) (byte) 1);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver3.solve((int) (short) 100, univariateRealFunction5, (double) (-1.0E-6f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 100.0f, 3.1622776601683795d, (-0.9117339147869651d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray6);
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray11);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray10);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray10);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7853981633974483d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(45.0d, (int) 'a', (-1329415437));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 97, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.00001f + "'", float2 == 97.00001f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 10, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-2.270227759920085E13d), (double) (-358450367), 1.2850972089d, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1023));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.48729816431393913d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8836011904065779d + "'", double1 == 0.8836011904065779d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 2140242005, (float) 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0E-6f, (java.lang.Number) 1.0d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.FastMath.abs(3104L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3104L + "'", long1 == 3104L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.4728051276747958d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.107875886857d + "'", double2 == 10.107875886857d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 10, 45);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.51843721E14f + "'", float2 == 3.51843721E14f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1024, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024L + "'", long2 == 1024L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 70);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079083008 + "'", int1 == 1079083008);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection34, false);
        double[] doubleArray42 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[] doubleArray48 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[][] doubleArray49 = new double[][] { doubleArray42, doubleArray48 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, orderDirection34, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection34, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.01499887516871d + "'", double15 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.513155876994848d, 0.0d, (double) (byte) 100, 0.8698165080591833d, (double) 3628800L, 3.948148009134034E13d, (double) (-2L), (-0.037381141273430396d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4327039495545584E20d + "'", double8 == 1.4327039495545584E20d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0E-6f), 1.2089258196146292E24d, (double) (short) 1, 6.691673596021348E41d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.floor(3104.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3104.0d + "'", double1 == 3104.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, (-358450367));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-358450366) + "'", int2 == (-358450366));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-981759551), 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-6.000000001096488d), (double) (-1329415437), (double) 6L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException(localizable0, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) bigInteger8, (-1), orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-9.319709542E9d), (java.lang.Number) 1.9155040003582885E22d, (int) (short) 1, orderDirection10, true);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.9155040003582885E22d + "'", number15.equals(1.9155040003582885E22d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (short) 1, 161700.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(45);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 129.12393363912722d + "'", double1 == 129.12393363912722d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0195652940572162d, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0195652940572162d + "'", double2 == 1.0195652940572162d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.0000005f, (float) (byte) 100, (-1023));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 97L, (float) 32L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, 100.00499987500625d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 97.0d, 1.4260624389053682d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.cos(5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8101836031147954d + "'", double1 == 0.8101836031147954d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray10);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray22);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) 'a');
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray27);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray27);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray10);
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray10);
        int[] intArray36 = null;
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray36);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-58613.58244188321d), 9747.916313026086d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4853.89129293241d, (double) 35L, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.4E-45f, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.0120948455406895d, 0.0d, (double) 4194304.0f, (double) (-0.0f), (-0.5309649148733797d), (-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4455175430087551d + "'", double6 == 0.4455175430087551d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, 6.691673596021348E41d, Double.NEGATIVE_INFINITY);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((-1329415437), univariateRealFunction6, (double) 9.2233715E18f, 143.99652773591453d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-127), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -127");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.9073486328125E-6d, 1.1752011936438014d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-18639419085L), (float) (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-127.0f) + "'", float2 == (-127.0f));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9572960942883878E11d + "'", double1 == 1.9572960942883878E11d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((-0.9117339147869651d), (double) (-2));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4558669573934826d) + "'", double2 == (-1.4558669573934826d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065104d + "'", double1 == 0.8342233605065104d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 52, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 3.831008000716578E22d, (double) (-358450367));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray13);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 9.848857801796104d, 0.09711106517906329d, (double) (-981759551), 0.0d, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) (-0.4119627100860633d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long2 = org.apache.commons.math.util.MathUtils.pow(97L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380415L) + "'", long2 == (-44563605345380415L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -2");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        float float2 = org.apache.commons.math.util.MathUtils.round(97.00001f, 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.00001f + "'", float2 == 97.00001f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 1.09951163E12f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40 + "'", int1 == 40);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-981759551));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-981759551) + "'", int2 == (-981759551));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-2), (double) 100.0f);
        double double3 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-127.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.4210854715202004E-14d, (double) 1L, 720.0d);
        double double4 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.15920507027249187d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1), (double) 34, 3.58351893845611d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMax();
        double double18 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double19 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.FastMath.copySign(97.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-97L), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (short) 0, 10230);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-127.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-127.0d) + "'", double1 == (-127.0d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4194304.0f, 0.16056393283879805d, 40);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        long long1 = org.apache.commons.math.util.FastMath.round(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(20.793438378082765d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 11013.232874703393d, 3.948148009134034E13d, (double) 1072693248L, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, number1, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: ∞ is larger than the maximum (null)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: ∞ is larger than the maximum (null)"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        java.lang.String str13 = noBracketingException9.toString();
        java.lang.String str14 = noBracketingException9.toString();
        double double15 = noBracketingException9.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str13.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str14.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.9075712110370514d, 342.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [342, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) (-1), 4853.89129293241d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 39481480091340L, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.9481478E13f + "'", float2 == 3.9481478E13f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1024, (-9.319709542E9d), (double) 1024L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,024, -9,319,709,542]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-358450367), (double) 106);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.58450336E8f) + "'", float2 == (-3.58450336E8f));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10L, objArray24);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray24);
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = localizedFormats10.getLocalizedString(locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 45, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.948148009134034E13d + "'", double2 == 3.948148009134034E13d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        long long1 = org.apache.commons.math.util.FastMath.round(4.755250792540576E198d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        long long2 = org.apache.commons.math.util.FastMath.max(362880000L, (long) (-35));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 362880000L + "'", long2 == 362880000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.9171523356672744d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1608753909688045d) + "'", double1 == (-1.1608753909688045d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 34.99999999999999d, (java.lang.Number) (-1024.0f), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1024.0f) + "'", number5.equals((-1024.0f)));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1079083008, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray63 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray70 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double double73 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray56);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray27);
        double[] doubleArray80 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray87 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray87);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray80);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray80);
        try {
            double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 101.0d + "'", double71 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 20735.0d + "'", double73 == 20735.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 342.0d + "'", double74 == 342.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 101.0d + "'", double88 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 100.01499887516871d + "'", double90 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 20735.0d, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-2L), objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats16);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException20 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (int) (short) 10, (int) (byte) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) 10L, objArray29);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray29);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray29);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray33);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray33);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException36 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 3.1622776601683795d, objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 40);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 161700.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long long2 = org.apache.commons.math.util.FastMath.min(20358520L, (long) 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-4.6598547E11f), (double) 0, (double) 1.0f, 1.0817069768229715d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray50 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray57 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray71 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray64);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray64);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1));
        double double78 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray19, doubleArray77);
        double[] doubleArray84 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray91 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray84, doubleArray91);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray84);
        double[][] doubleArray94 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray84, doubleArray94);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.0d + "'", double58 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 101.0d + "'", double72 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + (-101.04040404040404d) + "'", double78 == (-101.04040404040404d));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 101.0d + "'", double92 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray94);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4129651365067377d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.asinh(20735.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.632725553821903d + "'", double1 == 10.632725553821903d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double2 = org.apache.commons.math.util.FastMath.max(2.140242005E9d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.140242005E9d + "'", double2 == 2.140242005E9d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.46982219669862557d, 175.46509624423885d, (-2.270227759920085E13d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [175.465, -22,702,277,599,200.85]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.00499987500625d, (java.lang.Number) 1072693248L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1920929E-7f, (float) 39481480091340L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-2.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9999999999999998d) + "'", double1 == (-1.9999999999999998d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 70);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.515438670919167E30d + "'", double1 == 2.515438670919167E30d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1980901215L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1980901215L + "'", long1 == 1980901215L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 18639419084L, (-1023.9999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [18,639,419,084, -1,024]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 341642467, (long) 106);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 341642573L + "'", long2 == 341642573L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.3299273855E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3299273855E11d + "'", double1 == 2.3299273855E11d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 97.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929695075925542d + "'", double1 == 1.6929695075925542d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (null) exceeded: evaluations" + "'", str2.equals("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (null) exceeded: evaluations"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(52, 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.384563552848054d + "'", double2 == 31.384563552848054d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.util.MathUtils.checkFinite(0.014559944337890235d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, 3.51843721E14f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.51843721E14f + "'", float2 == 3.51843721E14f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.3007446917685998E15d), (double) 3, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 10000000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(18639419084L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.cosh(39.71440802747728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.8454160025231072E16d + "'", double1 == 8.8454160025231072E16d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 363.7393755555636d, (double) 34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.4129651365067377d, (-1.1752011936438014d), 10001.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection17, false);
        double[] doubleArray25 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[] doubleArray31 = new double[] { 3628800.0d, 39.71440802747728d, 35.0d, 0.9913289158005998d, 2.6881171418161356E43d };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection17, doubleArray32);
        double[] doubleArray39 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray46 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39);
        double[][] doubleArray49 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray39, doubleArray49);
        double[] doubleArray56 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray63 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray39);
        double[] doubleArray68 = new double[] { 21.15557659395077d };
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 101.0d + "'", double47 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 101.0d + "'", double64 == 101.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 175.46509624423885d + "'", double65 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (-35));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) bigInteger20, (-1), orderDirection22, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) 10, (double) 6, (double) (byte) 1);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.1752011936438014d, (double) 10230, (double) 97, 0.0d, 2.688117141816135E43d, 34.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.139598282174859E44d + "'", double6 == 9.139598282174859E44d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 10L, 0.0d, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray51 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray58 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        double[][] doubleArray61 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray51, doubleArray61);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection45, doubleArray61);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        double[] doubleArray67 = new double[] { 0.8830442304498398d, (-127) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection74, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (-9.3197095425E9d), 1, orderDirection74, true);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection74, true, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection74, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0 <= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 101.0d + "'", double59 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.48729816431393913d, (double) 50.0f, 1.0E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 97, 0.48729816431393913d, 0.0d, 1.3440585709080678E43d);
        double double5 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3440585709080678E43d + "'", double5 == 1.3440585709080678E43d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.4210854715202004E-14d, 3.831008000716578E22d, (double) 1072693248, (double) (-1980901215L), (double) 70.00001f, 1.0E10d, 62.26061319933956d, (double) 35);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.12489865774099891E18d) + "'", double8 == (-2.12489865774099891E18d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1024L), 39.71440802747728d, 20.793438378082765d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1024.0d) + "'", double4 == (-1024.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 11L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076232192 + "'", int1 == 1076232192);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(92.13617560368711d, (double) 6.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [92.136, 6]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.141592653589793d, (java.lang.Number) 6.691673596021348E41d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6.691673596021348E41d + "'", number5.equals(6.691673596021348E41d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.MathUtils.log(20.793438378082765d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int1 = org.apache.commons.math.util.FastMath.round(97.00001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.4728051276747958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16814528752542068d + "'", double1 == 0.16814528752542068d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray21 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray23 = new float[] { (byte) 1 };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray21);
        float[] floatArray26 = new float[] {};
        float[] floatArray33 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray35 = new float[] { (byte) 1 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray26, floatArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray33);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray33);
        float[] floatArray40 = new float[] {};
        float[] floatArray47 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray49 = new float[] { (byte) 1 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray40, floatArray47);
        float[] floatArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray40, floatArray52);
        float[] floatArray54 = new float[] {};
        float[] floatArray61 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray63 = new float[] { (byte) 1 };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(floatArray61, floatArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray54, floatArray61);
        float[] floatArray66 = new float[] {};
        float[] floatArray73 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray75 = new float[] { (byte) 1 };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(floatArray73, floatArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray66, floatArray73);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(floatArray61, floatArray73);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(floatArray40, floatArray73);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray33, floatArray40);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 0, (double) (-2L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = noBracketingException9.getContext();
        double double13 = noBracketingException9.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-1023), (float) 100, 34);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1076232192, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076232192 + "'", int2 == 1076232192);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.math.util.FastMath.min((-2), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3.9481478E13f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10L, objArray24);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray24);
        java.util.Set<java.lang.String> strSet27 = exceptionContext9.getKeys();
        exceptionContext9.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: ∞ is larger than the maximum (null)", (java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(strSet27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float1 = org.apache.commons.math.util.FastMath.abs(3.51843721E14f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.51843721E14f + "'", float1 == 3.51843721E14f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1024.0d), (double) 1L, 1.285097208938469d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-358450367), (float) (byte) 0, (float) (-358450367));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 5L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.7683716E-7f + "'", float1 == 4.7683716E-7f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 106);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3104L, (long) (-981759551));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3047381646304L + "'", long2 == 3047381646304L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 9.223372E18f, (double) 362880000L, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.397318034091222d) + "'", double1 == (-0.397318034091222d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 101.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), (-1023), 341642467);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = new float[] {};
        float[] floatArray19 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray21 = new float[] { (byte) 1 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray25 = new float[] {};
        float[] floatArray32 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray34 = new float[] { (byte) 1 };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray32);
        float[] floatArray37 = new float[] {};
        float[] floatArray44 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray46 = new float[] { (byte) 1 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray37, floatArray44);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray44);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray44);
        float[] floatArray51 = new float[] {};
        float[] floatArray58 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray60 = new float[] { (byte) 1 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray58);
        float[] floatArray63 = null;
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray63);
        float[] floatArray65 = new float[] {};
        float[] floatArray72 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray74 = new float[] { (byte) 1 };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(floatArray72, floatArray74);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray65, floatArray72);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(floatArray63, floatArray65);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray65);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 10230, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3628814.4197382154d + "'", double2 == 3628814.4197382154d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-0.0f), (double) (short) 10, (double) Float.NaN);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-101.04040404040404d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-101.04040404040403d) + "'", double1 == (-101.04040404040403d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 341642467);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1565238004) + "'", int1 == (-1565238004));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray17 = new java.lang.Object[] { "", localizedFormats15, localizedFormats16 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray17);
        double double19 = noBracketingException18.getFLo();
        double double20 = noBracketingException18.getFLo();
        double double21 = noBracketingException18.getLo();
        java.lang.String str22 = noBracketingException18.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) noBracketingException18);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str22.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.4455175430087551d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1008953666826535d + "'", double1 == 1.1008953666826535d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1024, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-0.397318034091222d), (double) (-1.0f), (double) 11L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [-0.397, -1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (short) 100, (-1023), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(20358520L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (-0.15920507027249187d), Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-2.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(97, (int) 'a');
        java.lang.Throwable throwable3 = null;
        try {
            dimensionMismatchException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 10L, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray16);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray16);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray16);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException23 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076232192);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 4194304.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4194304.0d + "'", double2 == 4194304.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        try {
            double double22 = regulaFalsiSolver3.solve((int) (byte) 1, univariateRealFunction18, 0.9998476951563913d, (double) '4', 92.13617560368711d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8698165080591833d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1848836590513583d + "'", double1 == 1.1848836590513583d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(101.0d, 0.0d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.8454160025231072E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        java.util.Set<java.lang.String> strSet2 = exceptionContext1.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = localizedFormats0.getLocalizedString(locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            boolean boolean4 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection1.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray1, (int) 'a');
        int[] intArray6 = null;
        try {
            int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double10 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction5, (double) 'a', (double) (-1980901217), 1.5707963267948966d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.1586256126509653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33417732577148335d + "'", double1 == 0.33417732577148335d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.1920929E-7f, 10.107875886857d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.14510469346731042d) + "'", double2 == (-0.14510469346731042d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 0.014559944337890235d, (double) 70, 363.7393755555636d, (double) 106, objArray14);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver1.solve(0, univariateRealFunction6, (double) 2140242005, (double) (-1.0f), (double) 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int1 = org.apache.commons.math.util.FastMath.round(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.5063656411097587d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5282839739597524d) + "'", double1 == (-0.5282839739597524d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0E-6f), 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0E-6f) + "'", float2 == (-1.0E-6f));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int1 = org.apache.commons.math.util.FastMath.abs(341642467);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 341642467 + "'", int1 == 341642467);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(Float.NaN, (float) (-18639419084L), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 70L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(3, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.48729816431393913d, (double) 0L, 0.0d, (double) (byte) -1);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.8830442304498398d, (double) 10000000000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.1848836590513583d, (double) 3104L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483646) + "'", int2 == (-2147483646));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.FastMath.max((-1980901217), (-358450367));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-358450367) + "'", int2 == (-358450367));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.0d + "'", double1 == 24.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double2 = org.apache.commons.math.util.FastMath.min(3104.0d, (-101.04040404040404d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-101.04040404040404d) + "'", double2 == (-101.04040404040404d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger8);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 100);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 1);
        try {
            java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.9998476951563913d, objArray2);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number4, (java.lang.Number) 3628800L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray21 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray23 = new float[] { (byte) 1 };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray21);
        float[] floatArray26 = new float[] {};
        float[] floatArray33 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray35 = new float[] { (byte) 1 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray26, floatArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray33);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray33);
        float[] floatArray40 = null;
        float[] floatArray47 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray49 = new float[] { (byte) 1 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray40, floatArray47);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray47);
        float[] floatArray53 = new float[] {};
        float[] floatArray60 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray62 = new float[] { (byte) 1 };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(floatArray60, floatArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray53, floatArray60);
        float[] floatArray65 = null;
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray53, floatArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray65);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.FastMath.sin(104.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.32162240316253093d) + "'", double1 == (-0.32162240316253093d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (short) 10, 34.99999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(97, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.958103478741511E26d + "'", double2 == 2.958103478741511E26d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.513155876994848d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(129.12393363912722d, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 362880000L, 10.0d, 1.4327039495545584E20d, 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.6288E9d + "'", double4 == 3.6288E9d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 20735.0d, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-2L), objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException24 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 10L, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 10L, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray30);
        notStrictlyPositiveException17.addSuppressed((java.lang.Throwable) mathIllegalArgumentException32);
        java.lang.Throwable[] throwableArray34 = mathIllegalArgumentException32.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException35 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray36 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.9036922050915098d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915097d) + "'", double1 == (-0.9036922050915097d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.1752011936438014d, (-0.32162240316253093d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.175, -0.322]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1024);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 10L, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10L, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 9223372036854775807L, objArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) tooManyEvaluationsException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.4558669573934826d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) (short) -1);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.4260624389053682d, 10230.488746878127d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4260624389053682d + "'", double2 == 1.4260624389053682d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        double double6 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-6d + "'", double6 == 1.0E-6d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        try {
            org.apache.commons.math.util.MathUtils.checkFinite((double) Float.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotFiniteNumberException; message: -∞ is not a finite number");
        } catch (org.apache.commons.math.exception.NotFiniteNumberException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(10, 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        float float1 = org.apache.commons.math.util.FastMath.abs(97.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.00001f + "'", float1 == 97.00001f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01745417862959511d + "'", double1 == 0.01745417862959511d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.1752011936438014d), 0.0d, 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 10, (float) 1072693248L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        java.lang.Object[] objArray4 = null;
        java.lang.Object[] objArray5 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.3431851641374776E20d, objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1024, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1565238004));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.2850972089d, (double) 70.00001f, (double) (byte) -1, 4.657009507803836d, (double) 3, 1.2089258196146292E24d, (double) (-97L), 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.6267774588438875E24d + "'", double8 == 3.6267774588438875E24d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(3.51843721E14f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.51843754E14f + "'", float1 == 3.51843754E14f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(70.00001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.0120948455406895d, (double) 3628800L, (double) 39481480091340L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount(35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = maxCountExceededException6.getContext();
        java.util.Set<java.lang.String> strSet8 = exceptionContext7.getKeys();
        java.util.Set<java.lang.String> strSet9 = exceptionContext7.getKeys();
        java.util.Set<java.lang.String> strSet10 = exceptionContext7.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-0.0f));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.0000005f, (float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 70L, 97);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9036922050915098d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9668078739084828d) + "'", double1 == (-0.9668078739084828d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(35, (-358450366));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.5309649148733797d), 0.0d, 0.2969118560322386d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 3628800L, (float) 34, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        float float2 = org.apache.commons.math.util.FastMath.scalb(3.51843754E14f, 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.2057601E17f + "'", float2 == 7.2057601E17f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.NaN, 2.99822295029797d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.09951163E12f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.FastMath.atan(10003.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706963567862324d + "'", double1 == 1.5706963567862324d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.0d, (double) 100L, (double) 2140242005);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 95.0d + "'", double3 == 95.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 4.755250792540576E198d, (double) 3047381646304L, (double) (-0.0f), (-1.9999999999999998d), (-0.08288831974674488d), 0.7853981633974483d, (-1.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.4050196873014067d) + "'", double8 == (-1.4050196873014067d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getStartValue();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double11 = regulaFalsiSolver0.solve((-1980901217), univariateRealFunction6, 1.285097208938469d, 0.0d, 3628800.0d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), (-35));
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 70.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5565115857642013d + "'", double1 == 1.5565115857642013d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (-2L), (double) (-1023L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [-2, -1,023]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double2 = org.apache.commons.math.util.FastMath.pow(10003.0d, 10001.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(9.223372E18f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 63 + "'", int1 == 63);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 32, n = 1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.0d, (double) 3.51843754E14f, (-6.000000001096488d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1980901217) + "'", int31 == (-1980901217));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMax();
        double double18 = regulaFalsiSolver3.getAbsoluteAccuracy();
        int int19 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double2 = org.apache.commons.math.util.MathUtils.log(129.12393363912722d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8128838741512321d + "'", double2 == 0.8128838741512321d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray32);
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
        java.lang.Object[] objArray35 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, 3.831008000716578E22d, 1.4210854715202004E-14d, (double) 45, 0.16056393283879805d, objArray35);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: exponent ({0})");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 34, 3104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3104L + "'", long2 == 3104L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.8639419084E10d, 106);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5122093305432393E42d + "'", double2 == 1.5122093305432393E42d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 2.1586256126509653d, (double) 34, (double) (-1024.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(orderDirection9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) ' ');
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray15);
        java.lang.Class<?> wildcardClass18 = intArray15.getClass();
        try {
            double double19 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5663706143591722d);
        double double2 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(0, univariateRealFunction4, 1.5430806348152437d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.4210854715202004E-14d, (double) 1L, 720.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = null;
        try {
            double double10 = regulaFalsiSolver3.solve((int) (short) 1, univariateRealFunction5, 0.0d, (double) 9.2233715E18f, 3.948148009134034E13d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (int) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger11, (java.lang.Number) 3628800L, false);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4194304.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '#', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1024, number1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2140242005);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(11L, (long) 34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-23L) + "'", long2 == (-23L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-1024L), 31.999999999999993d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) -1, 0.09711106517906329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0000000000000002d, 1.4327039495545584E20d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.979809054835857E-21d + "'", double2 == 6.979809054835857E-21d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.515438670919167E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5154386709191672E30d + "'", double1 == 2.5154386709191672E30d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        long long2 = org.apache.commons.math.util.FastMath.min((-100L), (long) 1076232192);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1024.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-44563605345380415L), (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.0E-14d, (double) (short) 10, 5.656854249492381d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.34314575050763d + "'", double3 == 4.34314575050763d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3628800L, (float) (-18639419084L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3628800.0f + "'", float2 == 3628800.0f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        float float1 = org.apache.commons.math.util.MathUtils.sign(50.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.log(31.999999999999993d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 341642573L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.533571983992772d + "'", double1 == 8.533571983992772d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 34, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-2.0f), 5.656854249492381d, (double) 32L);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        float float2 = org.apache.commons.math.util.FastMath.min(9.223373E18f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8128838741512321d, (double) 0.0f, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1329415437), (java.lang.Number) 100.00499987500625d, true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) '4', (double) ' ');
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver3.solve((-2), univariateRealFunction5, (double) (-1.0f), 0.6931471805599453d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-18639419084L), (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.3197097E9f) + "'", float2 == (-9.3197097E9f));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 97, 720.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1072693248L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.24871388718602142d, 1.0195652940572162d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6341395906216188d + "'", double2 == 0.6341395906216188d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 341642467, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.0d, (double) 1079083008, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,079,083,008, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 97.00001f, (double) (-1024.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0471478989860294d + "'", double2 == 3.0471478989860294d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.log10(9747.916313026086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9889117920610055d + "'", double1 == 3.9889117920610055d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-127), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray38 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray45 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray45);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray38);
        double[][] doubleArray48 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray48);
        double[] doubleArray55 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray62 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55);
        double[] doubleArray70 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray77 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray70);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray70);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 101.0d + "'", double46 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 101.0d + "'", double63 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 101.0d + "'", double78 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 2.0d + "'", double80 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0E-6f, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-127), (float) 10L, (float) 3047381646304L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6.283185307179586d);
        java.lang.Number number3 = notPositiveException2.getMin();
        java.lang.Number number4 = notPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.283185307179586d + "'", number4.equals(6.283185307179586d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1752011936438014d, (double) (byte) 0, 10003.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver3.solve((-1329415437), univariateRealFunction5, (double) (-9.3197097E9f), (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-358450367));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.746501045726147d + "'", double1 == 4.746501045726147d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.FastMath.log10((-2.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5282839739597525d) + "'", double1 == (-0.5282839739597525d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (short) -1);
        double[] doubleArray54 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray61 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray61);
        double[] doubleArray68 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray75 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray68, doubleArray75);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray68);
        double[] doubleArray83 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray90 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double91 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray83);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray68);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (byte) 0);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray95);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 101.0d + "'", double62 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 101.0d + "'", double76 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 101.0d + "'", double91 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 1.0102525138905933d + "'", double97 == 1.0102525138905933d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        float float2 = org.apache.commons.math.util.FastMath.min(3.51843754E14f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math.util.MathUtils.checkFinite((double) (-18639419085L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unsupported expansion mode {0}, supported modes are {1} ({2}) and {3} ({4})" + "'", str1.equals("unsupported expansion mode {0}, supported modes are {1} ({2}) and {3} ({4})"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 18639419084L, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.2089258196146292E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2089258196146292E24d + "'", double1 == 1.2089258196146292E24d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.33417732577148335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (byte) 10, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.07269325E9f, (float) 4, 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3628814.4197382154d, 1.9572960942883878E11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.957296094269961E11d + "'", double2 == 1.957296094269961E11d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) 10, (double) 6, (double) (byte) 1);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve((int) '4', univariateRealFunction6, (double) 3.8146973E-6f, (double) 20358520L, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-127.0d), 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.181843386368E12d) + "'", double2 == (-2.181843386368E12d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 1079083008, 63);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.957296094269961E11d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger7, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1023.9999999999999d), (java.lang.Number) 1.0333147966386297E40d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int1 = org.apache.commons.math.util.FastMath.abs(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double2 = org.apache.commons.math.util.FastMath.hypot(20735.0d, (double) 2140242005);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.140242005100442E9d + "'", double2 == 2.140242005100442E9d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-35));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.979809054835857E-21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10L, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math.util.MathUtils.checkFinite((double) (-358450367));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 34);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 106);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger23);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 100);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger23);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (byte) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.0d, 92.13617560368711d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.09951163E12f, 9747.916313026086d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1076232192);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.037381141273430396d));
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException11 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 1, (-127));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 3628800L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 2758547353515625L, (double) 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.09711106517906329d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-4.6598547E11f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 38 + "'", int1 == 38);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.141592653589793d, (-0.4505495340698077d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-358450366), (long) 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(0);
        int int9 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.5663706143591722d, (-9.319709542E9d), (double) (-358450367), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int2 = org.apache.commons.math.util.FastMath.max(2, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.755250792540576E198d, (double) 1.07269325E9f, 2.5154386709191672E30d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-46) + "'", int1 == (-46));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4.7683716E-7f, (double) (short) 100, 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(orderDirection8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-2147483646));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.180709776986927d) + "'", double1 == (-22.180709776986927d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray15);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22);
        double[] doubleArray37 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray44 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray37);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray37);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 101.0d + "'", double45 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 3, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(2.5154386709191672E30d, 10230.488746878127d, (-0.037381141273430396d), 0.0d, 0.0d, (double) 3628800.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.573416701630061E34d + "'", double6 == 2.573416701630061E34d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 97L);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException23 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray22);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 10L, objArray30);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray30);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 4.755250792540576E198d, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray30);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-1.0d), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.09711106517906329d, 161700.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(6.979809054835857E-21d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-3.584492136767125E9d), (double) 52.0f, 0.0d, 1072693248);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray21 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray23 = new float[] { (byte) 1 };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray21);
        float[] floatArray26 = new float[] {};
        float[] floatArray33 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray35 = new float[] { (byte) 1 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray26, floatArray33);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray33);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray33);
        float[] floatArray40 = null;
        float[] floatArray47 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray49 = new float[] { (byte) 1 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray40, floatArray47);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray47);
        float[] floatArray59 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray61 = new float[] { (byte) 1 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray61);
        float[] floatArray63 = new float[] {};
        float[] floatArray70 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray72 = new float[] { (byte) 1 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(floatArray70, floatArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray63, floatArray70);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray63);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray63);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double2 = org.apache.commons.math.util.FastMath.max(3104.0d, (-1023.9999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3104.0d + "'", double2 == 3104.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.FastMath.abs(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-2147483646));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 20735.0d, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-2L), objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) 10L, objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) 10L, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray29);
        notStrictlyPositiveException16.addSuppressed((java.lang.Throwable) mathIllegalArgumentException31);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = notStrictlyPositiveException16.getContext();
        java.lang.Throwable[] throwableArray34 = notStrictlyPositiveException16.getSuppressed();
        boolean boolean35 = notStrictlyPositiveException16.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        int int2 = org.apache.commons.math.util.FastMath.min((-2), 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray3);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray7);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray15);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, (int) 'a');
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray20);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray20);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, 10230);
        int[] intArray29 = new int[] {};
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray29);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray34);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray38);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray46);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray51);
        int[] intArray55 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, (int) 'a');
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray51);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray51);
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray34);
        try {
            double double59 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(6.283185307179586d, 0.46982219669862557d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [6.283, 0.47]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.4260624389053682d, 0.8101836031147954d, (double) 0L, 10230);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8752288940032076d, 1.5430806348152437d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 70, (long) 10230);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 716100L + "'", long2 == 716100L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1.4E-45f, 0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 3.948148009134034E13d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = mathIllegalStateException12.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.6931471805599453d, (double) 100.0f, (double) 0.0f, 0.6931471805599453d);
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.141592653589793d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        exceptionContext6.setValue("cannot compute beta density at 1 when beta = %.3g", (java.lang.Object) localizedFormats8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        exceptionContext6.setValue("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded", (java.lang.Object) localizedFormats11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.5808275421977d + "'", double1 == 88.5808275421977d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 3628800L, (double) 3047381646304L, 10.107875886857d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1058338518107955E19d + "'", double4 == 1.1058338518107955E19d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2758547353515625L, (java.lang.Number) 50.0f, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 3628800L, (float) (-127), (float) 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0817069768229715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7938312476336207d + "'", double1 == 0.7938312476336207d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (byte) 10, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.952809179494906d + "'", double2 == 52.952809179494906d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 40, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 2147483647, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        long long2 = org.apache.commons.math.util.FastMath.min((-18639419084L), 70L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18639419084L) + "'", long2 == (-18639419084L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(100);
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(0);
        int int9 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.09711106517906329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09741807476623128d + "'", double1 == 0.09741807476623128d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 39481480091340L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1.0E-6f), (double) 35.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.00499987500625d, (java.lang.Number) (-1980901217), true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10L, objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray17);
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 100.00499987500625d, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.0E-6d, (double) (-18639419085L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.math.util.FastMath.max((-358450366), (-127));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-127) + "'", int2 == (-127));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9998476951563913d, (java.lang.Number) (-2L), (-981759551));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 100, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10L, objArray7);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray7);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) (-0.7853981633974483d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException26 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 10L, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray25);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray25);
        java.lang.Object[] objArray29 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray25);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray25);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException32 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray25);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException33 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 10000000000L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0E10f + "'", float2 == 1.0E10f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1980901215L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1255.8977222675155d + "'", double1 == 1255.8977222675155d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 18639419084L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.648544480750406d + "'", double1 == 23.648544480750406d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-46), (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-46.0f) + "'", float2 == (-46.0f));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-35), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10230);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570698575084553d + "'", double1 == 1.570698575084553d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 3, n = 1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963267948966d, (java.lang.Number) 1.0E-15d, 97);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0E-15d + "'", number4.equals(1.0E-15d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 6.283185307179586d, 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-0.037381141273430396d));
        java.lang.Throwable[] throwableArray13 = notPositiveException12.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) notPositiveException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        int int16 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException11 = new org.apache.commons.math.exception.DimensionMismatchException(97, (int) 'a');
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) dimensionMismatchException11);
        int int13 = dimensionMismatchException11.getDimension();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.0195652940572162d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5097826470286081d + "'", double2 == 0.5097826470286081d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-46));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-358450367) + "'", int59 == (-358450367));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, (-1.4558669573934826d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4E-45f) + "'", float2 == (-1.4E-45f));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 97, (float) '#', (float) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException(localizable1, objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 90, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException(number15);
        java.lang.String str17 = maxCountExceededException16.toString();
        java.lang.Number number18 = maxCountExceededException16.getMax();
        java.lang.Number number19 = maxCountExceededException16.getMax();
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) maxCountExceededException16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded" + "'", str17.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded"));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 9468.356456209538d);
        double[] doubleArray37 = new double[] { 0.8830442304498398d, (-127) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (-9.3197095425E9d), 1, orderDirection44, true);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection44, true, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection44, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0.01 <= 0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long long2 = org.apache.commons.math.util.FastMath.min(32L, (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (-0.0f), (float) (-97L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

