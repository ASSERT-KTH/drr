import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        int int3 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray1, (int) 'a');
        int[] intArray6 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray8);
        int[] intArray11 = new int[] {};
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray11);
        try {
            int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((-0.8390715290764524d), 9468.356456209538d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 34.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.cos(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 6, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 10, (int) (byte) 0);
        int int5 = dimensionMismatchException4.getDimension();
        int int6 = dimensionMismatchException4.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.util.MathUtils.checkFinite(3628800.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) ' ', 2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.5063656411097587d), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 10000000000L, (float) 2, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 'a', (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3104L + "'", long2 == 3104L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution7);
        double double9 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        try {
            double double13 = regulaFalsiSolver2.solve(0, univariateRealFunction11, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-15d + "'", double9 == 1.0E-15d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(10230, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 35, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1.09951163E12f, 161700.0d, 3.1622776601683795d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,099,511,627,776, 161,700]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1072693248);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0f, (float) 465985477100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver12 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction17 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver18 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int19 = regulaFalsiSolver18.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution23 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double24 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction17, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver18, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution23);
        double double25 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver12, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution23);
        try {
            double double26 = regulaFalsiSolver2.solve(6, univariateRealFunction5, (double) (-2), (double) 1072693248, 0.0d, allowedSolution23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution23 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution23.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 32.0d + "'", double25 == 32.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(39.71440802747728d, 1.5663706143591722d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [39.714, 1.566]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 465985477100L, (double) 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (byte) 1, 0.7853981633974483d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, 0.785]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-9.3197095425E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.319709542E9d) + "'", double1 == (-9.319709542E9d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(10003.0d, (-9.3197095425E9d), (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float float2 = org.apache.commons.math.util.FastMath.copySign(100.0f, (float) 18639419084L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1024, 0.0d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9223372036854775807L, (int) '#', (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -127, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(39.71440802747728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) '#', 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        double[] doubleArray17 = new double[] { 3104.0d, 0.7853981633974483d };
        double[][] doubleArray18 = new double[][] { doubleArray17 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection14, doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 52.0f, (double) 10000000000L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 465985477100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3299273855E11d + "'", double2 == 2.3299273855E11d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        java.lang.Object obj11 = exceptionContext9.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10L, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray24);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray24);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray24);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) Double.NEGATIVE_INFINITY, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray24);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) "", (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double2 = org.apache.commons.math.util.FastMath.copySign(10003.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10003.0d + "'", double2 == 10003.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.log((-9.319709542E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) (short) 10, univariateRealFunction4, 0.0d, Double.POSITIVE_INFINITY, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) 1, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-2.5663706143591725d), (double) 10.0f, 0.8342233605065102d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(10.0d, 100.01499887516871d, (double) (-358450367), 3628800.0d, 0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.3007446917685998E15d) + "'", double6 == (-1.3007446917685998E15d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        java.lang.String str13 = noBracketingException9.toString();
        double double14 = noBracketingException9.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str13.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-1.3007446917685998E15d), (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.MathInternalError mathInternalError8 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1023), (int) (short) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5430806348152437d, 10230, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        int int4 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray2);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray1);
        try {
            int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-9.319709542E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9073486328125E-6d + "'", double1 == 1.9073486328125E-6d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 100, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 362880000L + "'", long2 == 362880000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.017453292519943295d, (double) (short) -1, (double) (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.017, -1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            boolean boolean48 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection45, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly decreasing (35 <= 97)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) (short) -1, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.08288831974674488d) + "'", double2 == (-0.08288831974674488d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.9075712110370514d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9075712110370514d + "'", double2 == 0.9075712110370514d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.1752011936438014d, 0.0d, Double.POSITIVE_INFINITY, (double) 18639419084L, 101.0d, 1.9155040003582885E22d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1024.0f), (int) '#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1024.0d) + "'", double3 == (-1024.0d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 6L, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.285097208938469d + "'", double2 == 1.285097208938469d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10003.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 0, (-2));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 32.0d, 1.0E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) (-1023));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1023L) + "'", long2 == (-1023L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 0, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 3104L, 0.6931471805599453d, 11013.232874703393d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver8 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int9 = regulaFalsiSolver8.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double14 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction7, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver8, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution13);
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) 10.0f, 0.0d, (double) 35.0f, allowedSolution13);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction17 = null;
        try {
            double double21 = regulaFalsiSolver2.solve((-1023), univariateRealFunction17, 32.0d, 0.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution13 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution13.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, 2.718281828459045d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver2.solve((int) (short) 0, univariateRealFunction4, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.util.MathUtils.checkFinite(100.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1023L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-58613.58244188321d) + "'", double1 == (-58613.58244188321d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 3104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver8 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int9 = regulaFalsiSolver8.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double14 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction7, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver8, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution13);
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) 10.0f, 0.0d, (double) 35.0f, allowedSolution13);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction17 = null;
        try {
            double double19 = regulaFalsiSolver2.solve((int) (byte) 0, univariateRealFunction17, (-2.5663706143591725d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution13 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution13.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1023L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 10L, 1.0E-14d, 720.0d, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-2), 1072693248);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, (int) (short) 10);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray8);
        try {
            int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46982219669862557d, 0.48729816431393913d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double9 = regulaFalsiSolver2.solve((-127), univariateRealFunction4, 0.0d, 0.0d, (double) (byte) -1, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 9223372036854775807L, (-127));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math.util.MathUtils.copyOf(intArray0);
        int[] intArray2 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray2);
        double double4 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
        int[] intArray5 = new int[] {};
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray9);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 0, 18639419084L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) 'a', (-1023));
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        int int5 = dimensionMismatchException3.getDimension();
        int int6 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1023) + "'", int5 == (-1023));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1023) + "'", int6 == (-1023));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) Float.NEGATIVE_INFINITY, (double) (-2), 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray36 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray43 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray50 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray57 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50);
        double[] doubleArray65 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray72 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray65);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        try {
            double double76 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray30, doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 101.0d + "'", double44 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.0d + "'", double58 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.0d + "'", double73 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray15);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext18 = mathIllegalStateException17.getContext();
        java.util.Set<java.lang.String> strSet19 = exceptionContext18.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        exceptionContext18.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException5, localizable8, objArray21);
        int int24 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, (double) 10.0f);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver17 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int18 = regulaFalsiSolver17.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution22 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double23 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction16, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver17, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution22);
        double double24 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, (double) 10.0f, 0.0d, (double) 35.0f, allowedSolution22);
        try {
            double double25 = regulaFalsiSolver2.solve((int) (short) -1, univariateRealFunction5, 1.285097208938469d, (double) 97, (double) 97, allowedSolution22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution22 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution22.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(161700.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection45, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 35)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution23 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double24 = regulaFalsiSolver3.solve(106, univariateRealFunction19, 0.0d, 1.1752011936438014d, 2.718281828459045d, allowedSolution23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution23 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution23.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.5707963267948966d, 0.0d, (double) '#', 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 10000000000L);
        java.lang.String str2 = maxCountExceededException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (10,000,000,000) exceeded" + "'", str2.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (10,000,000,000) exceeded"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, number1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715201903E-14d + "'", double1 == 1.4210854715201903E-14d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(6, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger6, false);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger11);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 106);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (short) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger22);
        try {
            java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 9223372036854775807L, (float) 10230);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.223372E18f + "'", float2 == 9.223372E18f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.acosh(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.216385381925387d + "'", double1 == 5.216385381925387d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46982219669862557d, 0.48729816431393913d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((-127), univariateRealFunction4, (double) 97, 97.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray29 = null;
        try {
            double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(Double.POSITIVE_INFINITY, 10003.0d, (double) (-1.0f));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -127");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1023), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -1,023");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 1, 50.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 1.09951163E12f, (double) 9.223372E18f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1072693248, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100, (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09711106517906329d + "'", double2 == 0.09711106517906329d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 0.0d, (-0.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5574077246549023d, (double) 9.223372E18f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray21 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray28 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray28);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray35);
        double[] doubleArray50 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray57 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray71 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray64);
        double double74 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray28, doubleArray57);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        try {
            double double76 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.01499887516871d + "'", double15 == 100.01499887516871d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 101.0d + "'", double29 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.0d + "'", double58 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 101.0d + "'", double72 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 20735.0d + "'", double74 == 20735.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-358450367) + "'", int75 == (-358450367));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        float float2 = org.apache.commons.math.util.FastMath.scalb(0.99999994f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 52.0d, 0.0d, 1.285097208938469d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3628800.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 10L, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray19);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (byte) 1, 2.99822295029797d, 100.00499987500625d, (double) 362880000L, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) Double.NEGATIVE_INFINITY, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(101.0d, (-0.5309649148733797d), 1.4210854715201903E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "lower endpoint ({0}) must be less than or equal to upper endpoint ({1})" + "'", str1.equals("lower endpoint ({0}) must be less than or equal to upper endpoint ({1})"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 100.01499887516871d, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) 10, (double) 6, (double) (byte) 1);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        float float2 = org.apache.commons.math.util.FastMath.scalb(Float.NaN, 10230);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (int) 'a', (-1023));
        java.lang.Throwable[] throwableArray6 = dimensionMismatchException5.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-1.1752011936438014d), (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.3299273855E11d, (int) (byte) 100, 1024);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.657009507803836d + "'", double1 == 4.657009507803836d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        float float2 = org.apache.commons.math.util.FastMath.copySign(1.0E-6f, (float) (-18639419084L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0E-6f) + "'", float2 == (-1.0E-6f));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35L, 6.691673596021348E41d, (-358450367));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 10, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.MathUtils.round(9.848857801796104d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.848857801796104d + "'", double2 == 9.848857801796104d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray34);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection49, false);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection49, false, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection49, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 35.0f, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.037381141273430396d) + "'", double2 == (-0.037381141273430396d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.acos(100.01499887516871d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        double[] doubleArray49 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray56 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray71 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray64);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray81 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray88 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray81);
        double[][] doubleArray91 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray81, doubleArray91);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray42, orderDirection75, doubleArray91);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection75, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 101.0d + "'", double57 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 101.0d + "'", double72 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 101.0d + "'", double89 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4210854715202004E-14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.017453292519943295d, (double) 10230);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10230.000000014888d + "'", double2 == 10230.000000014888d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10001.0d, number1, (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double8 = regulaFalsiSolver1.solve(10230, univariateRealFunction6, 5.656854249492381d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-0.0f), (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9998476951563913d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10230);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4728051276747958d + "'", double1 == 1.4728051276747958d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-2));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5309649148733797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4119627100860633d) + "'", double1 == (-0.4119627100860633d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray16 = null;
        try {
            double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.01499887516871d + "'", double15 == 100.01499887516871d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), (double) (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (byte) -1, false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        float float1 = org.apache.commons.math.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.5430806348152437d, (-58613.58244188321d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.543, -58,613.582]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(39.71440802747728d, (double) 97L, (double) (-1023L), (double) 0, 1.5574077246549023d, (double) 10230);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 19784.578601884947d + "'", double6 == 19784.578601884947d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.0E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.000000001096488d) + "'", double1 == (-6.000000001096488d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9468.356456209538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 2L, 9.848857801796104d, 1.5574077246549025d, (double) 3104L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4853.89129293241d + "'", double4 == 4853.89129293241d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0E-6f), (java.lang.Number) 100.0d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0E-6f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0E-6f + "'", number6.equals(1.0E-6f));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 18639419084L, (float) 35, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) Float.NEGATIVE_INFINITY, 10001.0d, (double) (-2L), 1.5574077246549025d);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray16);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10L, objArray24);
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray24);
        java.util.Set<java.lang.String> strSet27 = exceptionContext9.getKeys();
        java.lang.Class<?> wildcardClass28 = strSet27.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(strSet27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.216385381925387d, 9.848857801796104d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.141592653589793d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-127), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-127.0f) + "'", float2 == (-127.0f));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.cos(34.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915098d) + "'", double1 == (-0.9036922050915098d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(35L, (long) 10230);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 6L, 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0000005f + "'", float2 == 6.0000005f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(orderDirection8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray50 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray57 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray64 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray71 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray64);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray64);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray64);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1));
        double double78 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray19, doubleArray77);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) double78);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 101.0d + "'", double58 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 101.0d + "'", double72 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + (-101.04040404040404d) + "'", double78 == (-101.04040404040404d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 10230, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10230.488746878127d + "'", double2 == 10230.488746878127d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.util.MathUtils.checkFinite((double) (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-0.0f), objArray9);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) bigInteger19, (-1), orderDirection21, true);
        nullArgumentException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (-2L), (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.0f) + "'", float2 == (-2.0f));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(18639419084L, (-1023L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-1024.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection16, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.01499887516871d + "'", double15 == 100.01499887516871d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 100L, (double) (-127), (double) 3104L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.0d + "'", double3 == 44.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 0L, 0.0d, (double) ' ', 161700.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(342.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 342.00000000000006d + "'", double1 == 342.00000000000006d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 35.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 35);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 20735.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 10, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.0d + "'", double2 == 45.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) -1, 18639419084L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18639419085L) + "'", long2 == (-18639419085L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = 97");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1072693248);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.793438378082765d + "'", double1 == 20.793438378082765d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[] doubleArray20 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray27 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20);
        double[] doubleArray35 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray42 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray5, doubleArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 101.0d + "'", double28 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.0d + "'", double43 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 10003.0d + "'", double45 == 10003.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 0, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-97L) + "'", long2 == (-97L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 4853.89129293241d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 4853.89129293241d + "'", number2.equals(4853.89129293241d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0E-6f), (float) 6, (float) (-1023L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, (double) 6L, (double) '#', (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.044629098073146E23d, (double) 1.09951163E12f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.688117141816135E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        long long1 = org.apache.commons.math.util.FastMath.abs(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getHi();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) 0.0d, true);
        noBracketingException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 100, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1024.0d), (double) (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1023.9999999999999d) + "'", double2 == (-1023.9999999999999d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-9.3197095425E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        long long1 = org.apache.commons.math.util.FastMath.abs(465985477100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 465985477100L + "'", long1 == 465985477100L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(101.0d, 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 4.657009507803836d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double2 = org.apache.commons.math.util.FastMath.max(10230.488746878127d, 1.5430806348d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10230.488746878127d + "'", double2 == 10230.488746878127d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException(number0);
        java.lang.String str2 = maxCountExceededException1.toString();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        java.lang.Number number4 = maxCountExceededException1.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded" + "'", str2.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded"));
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1L, (-0.5063656411097587d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(2, 1024);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,024, n = 2");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 2, (-6.000000001096488d), (double) Float.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2, -6]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1.0E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = regulaFalsiSolver1.solve((int) (short) 1, univariateRealFunction5, 0.7853981633974483d, (double) 100.0f, 3.948148009134034E13d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long1 = org.apache.commons.math.util.FastMath.round(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 39481480091340L + "'", long1 == 39481480091340L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) (-1023), 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9155040003582885E22d + "'", double2 == 1.9155040003582885E22d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot access {0} method in percentile implementation {1}" + "'", str1.equals("cannot access {0} method in percentile implementation {1}"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.2089258196146292E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.513155876994848d + "'", double1 == 0.513155876994848d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) -1, (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int12 = regulaFalsiSolver11.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution16 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double17 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution16);
        try {
            double double18 = regulaFalsiSolver1.solve((-2), univariateRealFunction6, (double) 9223372036854775807L, 34.99999999999999d, allowedSolution16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution16 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution16.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        float float3 = org.apache.commons.math.util.MathUtils.round(35.0f, (-1980901217), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(3.1622776601683795d, 0.0d, (double) (-1.0f), 0.0d, Double.NaN, 1.5430806348d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-6.000000001096488d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-18639419085L), (java.lang.Number) 1.5574077246549023d, 100);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (byte) 1, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(11013.232874703393d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5506.223738269998d + "'", double2 == 5506.223738269998d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 35.0f, 2.718281828459045d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) '#', univariateRealFunction4, (double) 9.223372E18f, 0.513155876994848d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4210854715201903E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.00000000000001d + "'", double2 == 52.00000000000001d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2140242005);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.140242005E9d + "'", double1 == 2.140242005E9d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10230, 10230.488746878127d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.exception.MathInternalError mathInternalError0 = new org.apache.commons.math.exception.MathInternalError();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathInternalError0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 5L, (float) 3104L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 'a', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.755250792540576E198d + "'", double2 == 4.755250792540576E198d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.cos((-9.319709542E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24871388718602142d + "'", double1 == 0.24871388718602142d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (double) '#');
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 39481480091340L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.999999999999993d + "'", double1 == 31.999999999999993d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-1L), (double) 35.0f, (double) 1072693248);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1072693248, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07269325E9f + "'", float2 == 1.07269325E9f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        java.lang.Number number12 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 1.0d, 0, orderDirection15, false);
        noBracketingException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        double double19 = noBracketingException9.getLo();
        double double20 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1980901217), (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1980901215L) + "'", long2 == (-1980901215L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(35L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4129651365067377d + "'", double1 == 1.4129651365067377d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-127));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1024.0d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(100.0d, (double) ' ', 10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3200.0d + "'", double4 == 3200.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 18639419084L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8639419084E10d + "'", double1 == 1.8639419084E10d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '#', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.46982219669862557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0817069768229715d + "'", double1 == 1.0817069768229715d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.util.MathUtils.checkFinite(5506.223738269998d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1024, (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.15920507027249187d) + "'", double2 == (-0.15920507027249187d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger5, false);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 106);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (short) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger21);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) bigInteger5, (java.lang.Number) bigInteger21, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 1.5663706143591722d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100, (-58613.58244188321d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(97, 2140242005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getStartValue();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(Double.NEGATIVE_INFINITY, 0.0d, 0.24871388718602142d, (double) 35);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double2 = org.apache.commons.math.util.FastMath.scalb(52.0d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 104.0d + "'", double2 == 104.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = noBracketingException9.getContext();
        java.lang.String str13 = noBracketingException9.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence" + "'", str13.equals("org.apache.commons.math.exception.NoBracketingException: none of the 0 start points lead to convergence"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray9 = new float[] { (byte) 1 };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray12);
        float[] floatArray14 = null;
        float[] floatArray21 = new float[] { (byte) 100, (-1), 35, (byte) 100, (-1023), (byte) -1 };
        float[] floatArray23 = new float[] { (byte) 1 };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray21);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray21);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        float float2 = org.apache.commons.math.util.FastMath.max(1.4E-45f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long1 = org.apache.commons.math.util.FastMath.round((-1023.9999999999999d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1024L) + "'", long1 == (-1024L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(106, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (byte) 10, 1, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1L), 6, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 10L, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        exceptionContext9.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray12);
        java.lang.Object obj15 = exceptionContext9.getValue("cannot compute beta density at 1 when beta = %.3g");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.0d, 0.7853981633974483d, 20735.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2969118560322386d + "'", double3 == 0.2969118560322386d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1024L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024L + "'", long1 == 1024L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2140242005, (java.lang.Number) Double.POSITIVE_INFINITY, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.46982219669862557d, 2.99822295029797d, (double) Float.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2.998, -∞]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.cos(100.01499887516871d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8698165080591833d + "'", double1 == 0.8698165080591833d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NEGATIVE_INFINITY, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.3007446917685998E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.270227759920085E13d) + "'", double1 == (-2.270227759920085E13d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10L, (double) 0.0f, 5506.223738269998d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3431851641374776E20d + "'", double1 == 3.3431851641374776E20d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (byte) 100, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int1 = org.apache.commons.math.util.FastMath.round(1.09951163E12f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 2147483647, (float) 34, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 2, (-127.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int12 = regulaFalsiSolver11.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution16 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double17 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution16);
        double double18 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution16);
        double double19 = regulaFalsiSolver5.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution23 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double24 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(35, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 3.948148009134034E13d, (double) (byte) 0, (double) 3628800L, allowedSolution23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution16 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution16.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 32.0d + "'", double18 == 32.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution23 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution23.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "", localizedFormats6, localizedFormats7 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 100, (double) (-1L), (double) 10.0f, objArray8);
        double double10 = noBracketingException9.getFLo();
        double double11 = noBracketingException9.getFLo();
        double double12 = noBracketingException9.getLo();
        double double13 = noBracketingException9.getHi();
        double double14 = noBracketingException9.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathIllegalStateException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342441900717d + "'", double1 == 5.298342441900717d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 465985477100L, (float) (-1980901215L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.6598547E11f) + "'", float2 == (-4.6598547E11f));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 20735.0d, objArray7);
        java.lang.Number number10 = maxCountExceededException9.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 20735.0d + "'", number10.equals(20735.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1024, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1024L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution7);
        double double9 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        try {
            double double15 = regulaFalsiSolver2.solve((int) (byte) 100, univariateRealFunction11, (double) (-18639419084L), (-2.5663706143591725d), 34.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-15d + "'", double9 == 1.0E-15d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 39481480091340L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 45 + "'", int1 == 45);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716578E22d + "'", double1 == 3.831008000716578E22d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) ' ', 6.283185307179586d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-2.0f), 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.9999999f) + "'", float2 == (-1.9999999f));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, (-1023L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,023)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4260624389053682d + "'", double1 == 1.4260624389053682d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int5 = regulaFalsiSolver4.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution9);
        double double11 = regulaFalsiSolver4.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution15 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 20735.0d, (double) 2147483647, (double) (-1023L), allowedSolution15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-15d + "'", double11 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution15 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution15.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5574077246549025d, (double) (-1.0E-6f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549025d + "'", double2 == 1.5574077246549025d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 106);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106 + "'", int2 == 106);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray8);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException10 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.8623188722876839d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.0d), (double) (-2.0f), (-127));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2), 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int1 = org.apache.commons.math.util.MathUtils.hash(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 341642467 + "'", int1 == 341642467);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray33 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray40 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray48);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34.0d, (java.lang.Number) (byte) 10, 6, orderDirection63, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection63, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.0d + "'", double41 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount(10230);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 1.0E-15d, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 465985477100L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 0, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.MathUtils.sign(9747.916313026086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 465985477100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray33 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray40 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray48);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection60, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 101.0d + "'", double41 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5574077246549025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0120948455406895d + "'", double1 == 1.0120948455406895d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int1 = org.apache.commons.math.util.MathUtils.sign(34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.1752011936438014d, 5.298342441900717d, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1586256126509653d + "'", double3 == 2.1586256126509653d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 97, 0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 0.8698165080591833d, 1.0d, 2.6881171418161356E43d, (double) 1L, 101.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.6881171418161356E43d + "'", double6 == 2.6881171418161356E43d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1), 45.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-127.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 70);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5565115842075d + "'", double1 == 1.5565115842075d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        long long2 = org.apache.commons.math.util.FastMath.min(1024L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos(20735.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8830442304498398d + "'", double1 == 0.8830442304498398d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2758547353515625L + "'", long2 == 2758547353515625L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.9998476951563913d, objArray2);
        java.lang.Number number4 = maxCountExceededException3.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.9998476951563913d + "'", number4.equals(0.9998476951563913d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 106);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0333147966386297E40d, (java.lang.Number) bigInteger5, false);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger10);
        try {
            java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-2L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-2)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 3628800L, (double) (-0.0f), (double) 1072693248, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.047442967903742035d + "'", double1 == 0.047442967903742035d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.755250792540576E198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 10230.488746878127d);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        double[] doubleArray48 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray55 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray12, doubleArray41);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 50.0f);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41, 35);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 101.0d + "'", double56 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20735.0d + "'", double58 == 20735.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-1023));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1023), 45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 45, n = -1,023");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5663706143591722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0195652940572162d + "'", double1 == 1.0195652940572162d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 465985477100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 2140242005);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2140242005 + "'", int2 == 2140242005);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10L, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (short) 10, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 18639419084L, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1023), (double) 1, 3104.0d, 0.0d, objArray5);
        double double7 = noBracketingException6.getFLo();
        double double8 = noBracketingException6.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3104.0d + "'", double7 == 3104.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double2 = org.apache.commons.math.util.FastMath.max(97.0d, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 465985477100L, 2.718281828459045d, (-358450367));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1023), 9.848857801796104d, 2.1586256126509653d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        long long1 = org.apache.commons.math.util.FastMath.abs(18639419084L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 18639419084L + "'", long1 == 18639419084L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1.3007446917685998E15d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.8146973E-6f, Float.POSITIVE_INFINITY, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0E-6f, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0E-6f + "'", float2 == 1.0E-6f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, objArray5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException24 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 10L, objArray23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (-0.4505495340698077d), objArray23);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray23);
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) mathArithmeticException26);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext28 = mathArithmeticException26.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext29 = mathArithmeticException26.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(exceptionContext28);
        org.junit.Assert.assertNotNull(exceptionContext29);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 2140242005, (int) (short) 100, 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 100L, 0.46982219669862557d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(100.0d, 0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6.283185307179586d);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notPositiveException2.getMin();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = notPositiveException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((-1.0E-6f), 10, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -1,023, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5663706143591722d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray19 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray26 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray26);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double[] doubleArray34 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray41 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray34);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray19);
        double[] doubleArray45 = null;
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.0d + "'", double27 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 101.0d + "'", double42 == 101.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014559944337890235d + "'", double1 == 0.014559944337890235d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.0333147966386297E40d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) -1, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, (double) (-1.0f), 1.5707963267948966d, 3.141592653589793d, allowedSolution14);
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) ' ', (double) (-1023), (double) 50.0f, allowedSolution14);
        double double17 = regulaFalsiSolver3.getMax();
        double double18 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction20 = null;
        try {
            double double24 = regulaFalsiSolver3.solve(100, univariateRealFunction20, (double) 1024L, 143.99652773591453d, (double) (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-18639419084L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 39481480091340L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4194304.0f + "'", float1 == 4194304.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1024);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1024 + "'", number2.equals(1024));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 70);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 70.00001f + "'", float1 == 70.00001f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.09711106517906329d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009710801264635796d + "'", double2 == 0.009710801264635796d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.223373E18f + "'", float1 == 9.223373E18f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1024.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16056393283879805d + "'", double1 == 0.16056393283879805d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.285097208938469d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2850972089d + "'", double2 == 1.2850972089d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.014559944337890235d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0146664566373451d + "'", double1 == 1.0146664566373451d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (short) -1, (double) '4', (double) 100, 0.0d, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-0.0f), objArray6);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1329415437) + "'", int2 == (-1329415437));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.00001f + "'", float1 == 97.00001f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10L, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (-0.4505495340698077d), objArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathArithmeticException11.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray5 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray12 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5);
        double[][] doubleArray15 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, doubleArray15);
        double[] doubleArray22 = new double[] { (-1.0f), (-1L), 1, 2.2250738585072014E-308d, 100 };
        double[] doubleArray29 = new double[] { 100L, '#', 97, 10L, (byte) 1, 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 101.0d + "'", double30 == 101.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 175.46509624423885d + "'", double31 == 175.46509624423885d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 143.99652773591453d + "'", double32 == 143.99652773591453d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 35L, (float) (-1L), 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-58613.58244188321d), (double) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 106);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) bigInteger7);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 100);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (byte) 1);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException16 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9117339147869651d), 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.009710801264635796d, 9.848857801796104d, 2140242005);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) Float.NaN, (double) (short) 1);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 10.0d, (double) 465985477100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 2.2250738585072014E-308d, (byte) -1, (-1) };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 10L, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-0.0f), objArray10);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        java.lang.Class<?> wildcardClass15 = objArray10.getClass();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (byte) 0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve((-1), univariateRealFunction3, 0.9075712110370514d, 1.4129651365067377d, (double) 1.09951163E12f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.232874703393d, 34.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-358450367), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-981759551) + "'", int2 == (-981759551));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0d, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathInternalError7.getContext();
        java.lang.Object obj10 = exceptionContext8.getValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (1 < null)");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        exceptionContext8.setValue("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (null) exceeded", (java.lang.Object) localizedFormats12);
        java.lang.Object obj15 = exceptionContext8.getValue("");
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0146664566373451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00632330348276421d + "'", double1 == 0.00632330348276421d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0E-6f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }
}

