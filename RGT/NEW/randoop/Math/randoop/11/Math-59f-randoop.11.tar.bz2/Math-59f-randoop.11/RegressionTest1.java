import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.09247351917780995d, (java.lang.Number) 16, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.1102230246251565E-16d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Object[] objArray8 = numberIsTooSmallException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 1.1102230246251565E-16d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException11);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getTwo();
        boolean boolean11 = dfp2.unequal(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11);
        java.lang.Object[] objArray14 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathRuntimeException11.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp14 = dfp2.divide(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlagsBits(10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getPi();
        boolean boolean28 = dfp3.unequal(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.rint();
        int int30 = dfp27.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double double2 = org.apache.commons.math.util.FastMath.min(1.140187487400072d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251565E-16d + "'", double2 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
//        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
//        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
//        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
//        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
//        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
//        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) -1 };
//        mersenneTwister12.nextBytes(byteArray17);
//        boolean boolean19 = dfp10.equals((java.lang.Object) mersenneTwister12);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister();
//        mersenneTwister20.setSeed((long) ' ');
//        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
//        int int24 = mersenneTwister23.nextInt();
//        mersenneTwister23.setSeed((int) ' ');
//        byte[] byteArray28 = new byte[] { (byte) 10 };
//        mersenneTwister23.nextBytes(byteArray28);
//        mersenneTwister20.nextBytes(byteArray28);
//        mersenneTwister12.nextBytes(byteArray28);
//        float float32 = mersenneTwister12.nextFloat();
//        int[] intArray35 = new int[] { (-515693678), (-32767) };
//        mersenneTwister12.setSeed(intArray35);
//        org.junit.Assert.assertNotNull(dfp3);
//        org.junit.Assert.assertNotNull(dfp5);
//        org.junit.Assert.assertNotNull(dfpArray6);
//        org.junit.Assert.assertNotNull(dfp8);
//        org.junit.Assert.assertNotNull(dfp10);
//        org.junit.Assert.assertNotNull(byteArray17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1422236599) + "'", int24 == (-1422236599));
//        org.junit.Assert.assertNotNull(byteArray28);
//        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.96464646f + "'", float32 == 0.96464646f);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) ' ');
        boolean boolean3 = mersenneTwister0.nextBoolean();
        long long4 = mersenneTwister0.nextLong();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3774039988963962337L) + "'", long4 == (-3774039988963962337L));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 4684399888325504639L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.6844E18f + "'", float2 == 4.6844E18f);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K((int) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.getTwo();
        int int10 = dfp3.log10();
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp3.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.8284271247461903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9930373454058692d + "'", double1 == 0.9930373454058692d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97.0f);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) ' ');
        mersenneTwister0.setSeed((int) (byte) 1);
        boolean boolean5 = mersenneTwister0.nextBoolean();
        boolean boolean6 = mersenneTwister0.nextBoolean();
        double double7 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7203245003902519d + "'", double7 == 0.7203245003902519d);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.newInstance((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp7.nextAfter(dfp15);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((int) ' ');
//        byte[] byteArray5 = new byte[] { (byte) 10 };
//        mersenneTwister0.nextBytes(byteArray5);
//        mersenneTwister0.setSeed(256222763);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 969290971 + "'", int1 == 969290971);
//        org.junit.Assert.assertNotNull(byteArray5);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.233403117511217d + "'", double1 == 1.233403117511217d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField10.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField10.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField23 = dfp22.getField();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.remainder(dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getPi();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp50.remainder(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp50.add(dfp60);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp37.dotrap((int) (short) -1, "hi!", dfp46, dfp61);
        boolean boolean63 = dfp34.lessThan(dfp46);
        java.lang.Class<?> wildcardClass64 = dfp34.getClass();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField66.getPi();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField66.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField66.getPi();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp34.multiply(dfp71);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField23.newDfp(dfp74);
        boolean boolean76 = dfp8.greaterThan(dfp75);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField78.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray83 = dfpField78.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField78.getE();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField78.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp86 = dfp75.nextAfter(dfp85);
        org.apache.commons.math.dfp.Dfp dfp87 = org.apache.commons.math.dfp.DfpField.computeExp(dfp3, dfp75);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfpField23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfpArray83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        int int7 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.01745417873758517d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) -1 };
        mersenneTwister12.nextBytes(byteArray17);
        boolean boolean19 = dfp10.equals((java.lang.Object) mersenneTwister12);
        int int20 = mersenneTwister12.nextInt();
        double double21 = mersenneTwister12.nextDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-319902279) + "'", int20 == (-319902279));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9646465565646098d + "'", double21 == 0.9646465565646098d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1209601498, (long) 2142770048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2142770048L + "'", long2 == 2142770048L);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (-1000663195));
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.getSqr3Reciprocal();
        dfpField12.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField12.getESplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField12.getLn5();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp10.newInstance(dfp21);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField19.getOne();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.multiply(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.remainder(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.getPi();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp32.add(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.getPi();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp32.nextAfter(dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp53.remainder(dfp57);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getPi();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp53.add(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField70.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.remainder(dfp72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField75.getPi();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp68.add(dfp78);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField81.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField81.getPi();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp68.nextAfter(dfp84);
        org.apache.commons.math.dfp.Dfp dfp86 = org.apache.commons.math.dfp.DfpField.computeLn(dfp48, dfp53, dfp68);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp28.nextAfter(dfp48);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        int int5 = dfp2.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        float float2 = mersenneTwister0.nextFloat();
//        long long3 = mersenneTwister0.nextLong();
//        int int4 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-680518512) + "'", int1 == (-680518512));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.75520134f + "'", float2 == 0.75520134f);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-7245641222710537859L) + "'", long3 == (-7245641222710537859L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1841453901 + "'", int4 == 1841453901);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance("2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.newInstance((byte) -1, (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp2.dotrap(32, "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100", dfp52, dfp63);
        java.lang.String str65 = dfp64.toString();
        java.lang.Class<?> wildcardClass66 = dfp64.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3." + "'", str65.equals("3."));
        org.junit.Assert.assertNotNull(wildcardClass66);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp12);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        float float2 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed(0);
//        double double5 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1381063899) + "'", int1 == (-1381063899));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.75667346f + "'", float2 == 0.75667346f);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5488135008937807d + "'", double5 == 0.5488135008937807d);
//    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((-1.6529620192770991E7d));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.remainder(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getPi();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp42.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp29.dotrap((int) (short) -1, "hi!", dfp38, dfp53);
        boolean boolean55 = dfp26.lessThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField8.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField1.newDfp(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getE();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp60.remainder(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getE();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getE();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp70.remainder(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp76.getTwo();
        boolean boolean78 = dfp66.greaterThan(dfp76);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField80.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField80.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray87 = dfpField80.getESplit();
        boolean boolean88 = dfp66.equals((java.lang.Object) dfpField80);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp26.multiply(dfp66);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp66.power10((-32767));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfpArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp91);
    }
}

