import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test003");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.029714058710677338d + "'", double0 == 0.029714058710677338d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.rint(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.acosh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.693147180044656d + "'", double1 == 10.693147180044656d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2626272556789118d + "'", double2 == 1.2626272556789118d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8144772166995121d + "'", double1 == 0.8144772166995121d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.Throwable throwable12 = null;
        try {
            mathRuntimeException9.addSuppressed(throwable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32760);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32760 + "'", int1 == 32760);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5039722448044603d) + "'", double1 == (-0.5039722448044603d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13962634015954636d + "'", double1 == 0.13962634015954636d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 'a', 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.5039722448044603d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6041261502626034d + "'", double1 == 0.6041261502626034d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5430806348152437d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.543080634815244d + "'", double2 == 1.543080634815244d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32760, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.5039722448044603d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-28.87548261902951d) + "'", double1 == (-28.87548261902951d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01745417873758517d) + "'", double1 == (-0.01745417873758517d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable3, localizable4, localizable5, objArray11);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathRuntimeException13.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException9.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-28.87548261902951d), (-28.87548261902951d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.356194490192345d) + "'", double2 == (-2.356194490192345d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5882505055324818d + "'", double1 == 1.5882505055324818d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.0f, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6981152095798223d) + "'", double1 == (-0.6981152095798223d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 1, (-0.01745417873758517d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, (-947077474));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8284271247461903d + "'", double1 == 2.8284271247461903d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable4, localizable5, localizable6, objArray12);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, localizable2, localizable3, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray12);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.718281828459045d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException9.toString();
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException(throwable13, localizable14, localizable15, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathRuntimeException22.getSpecificPattern();
        mathRuntimeException9.addSuppressed((java.lang.Throwable) mathRuntimeException22);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32768);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.140692632779267d + "'", double1 == 22.140692632779267d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 100, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01d + "'", double2 == 0.01d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int2 = org.apache.commons.math.util.FastMath.max(32760, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32760 + "'", int2 == 32760);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8144772166995121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1401874874000717d + "'", double1 == 1.1401874874000717d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-479536588), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.79536588E8d) + "'", double2 == (-4.79536588E8d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathRuntimeException11.getGeneralPattern();
        java.lang.String str14 = mathRuntimeException11.toString();
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException(throwable15, localizable16, localizable17, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathRuntimeException24.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException24);
        mathRuntimeException11.addSuppressed((java.lang.Throwable) mathRuntimeException26);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable25);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-479536588), (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707961245162751d) + "'", double2 == (-1.5707961245162751d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable4, localizable5, localizable6, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathRuntimeException13.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException13);
        java.lang.String str16 = mathRuntimeException15.toString();
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) mathRuntimeException15);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.acos((-4.79536588E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.13962634015954636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13962634015954636d + "'", double1 == 0.13962634015954636d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.8390715290764524d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10.693147180044656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4590029591006584d + "'", double1 == 2.4590029591006584d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1401874874000717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.140187487400072d + "'", double1 == 1.140187487400072d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 0);
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 3, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1401874874000717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 65.32793088164983d + "'", double1 == 65.32793088164983d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5882505055324818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.287052202148914d) + "'", double1 == (-57.287052202148914d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-479536588));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) ' ');
        double double3 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6392501115114819d + "'", double3 == 0.6392501115114819d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1704955946762781470L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1704955946762781470L + "'", long1 == 1704955946762781470L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.730165733925067d + "'", double1 == 1.730165733925067d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp28 = dfp24.newInstance(dfp27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int2 = org.apache.commons.math.util.FastMath.max(8, 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32768 + "'", int2 == 32768);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField8.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable6, (java.lang.Object[]) dfpArray13);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.140187487400072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.056976270677128626d + "'", double1 == 0.056976270677128626d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getPi();
        boolean boolean28 = dfp3.unequal(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp3.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfpField29);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-947077474));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.remainder(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        boolean boolean20 = dfp8.greaterThan(dfp18);
        double[] doubleArray21 = dfp18.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        long long1 = org.apache.commons.math.util.FastMath.round(2.4590029591006584d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.258096538021482d + "'", double1 == 3.258096538021482d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 10);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 16, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.rint();
        int int28 = dfp5.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        boolean boolean6 = dfp2.equals((java.lang.Object) 0.9863813f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-947077474));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6529620192770991E7d) + "'", double1 == (-1.6529620192770991E7d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        java.lang.String str9 = dfp7.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166" + "'", str9.equals("2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        int int51 = dfp49.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 25 + "'", int51 == 25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getPi();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.remainder(dfp13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10((int) (short) 100);
        java.lang.String str7 = dfp6.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100" + "'", str7.equals("1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-515693678));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-515693678L) + "'", long1 == (-515693678L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), (double) 25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25.0d + "'", double2 == 25.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5403023058681398d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6462253643711198d + "'", double2 == 2.6462253643711198d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.903487550036129d + "'", double1 == 9.903487550036129d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((int) ' ');
//        byte[] byteArray5 = new byte[] { (byte) 10 };
//        mersenneTwister0.nextBytes(byteArray5);
//        double double7 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2142770064 + "'", int1 == 2142770064);
//        org.junit.Assert.assertNotNull(byteArray5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05965650637017417d + "'", double7 == 0.05965650637017417d);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, (-479536588));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-479536588) + "'", int2 == (-479536588));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09247351917780995d + "'", double1 == 0.09247351917780995d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 3);
        int int11 = dfp7.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2L, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9999999999999998d + "'", double2 == 1.9999999999999998d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4210854715202004E-14d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        boolean boolean19 = dfp18.isNaN();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.negate();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.floor();
        int int23 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(0.8144772166995121d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 35.0f, 2.6462253643711198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12188.54943981122d + "'", double2 == 12188.54943981122d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(100L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (-1000663195));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1000663195) + "'", int2 == (-1000663195));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5401476965874874d) + "'", double2 == (-1.5401476965874874d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.newInstance((-947077474));
        org.apache.commons.math.dfp.Dfp dfp30 = dfp5.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 8, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 8 + "'", number6.equals(8));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        boolean boolean19 = dfp18.isNaN();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.negate();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.floor();
        int int23 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp15.nextAfter(dfp18);
        boolean boolean25 = dfp18.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1000663195));
        mersenneTwister1.setSeed((long) 35);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1000663195));
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.ulp(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-188017526));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.8801752E8f) + "'", float2 == (-1.8801752E8f));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-57.287052202148914d), (java.lang.Number) (-1.0f), false);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
//        mersenneTwister6.setSeed((long) ' ');
//        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister();
//        int int10 = mersenneTwister9.nextInt();
//        mersenneTwister9.setSeed((int) ' ');
//        byte[] byteArray14 = new byte[] { (byte) 10 };
//        mersenneTwister9.nextBytes(byteArray14);
//        mersenneTwister6.nextBytes(byteArray14);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { byteArray14 };
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable5, objArray17);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1378534813) + "'", int10 == (-1378534813));
//        org.junit.Assert.assertNotNull(byteArray14);
//        org.junit.Assert.assertNotNull(objArray17);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1.0d) + "'", number2.equals((-1.0d)));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp29.rint();
        int int35 = dfp29.classify();
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp24, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.remainder(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.getPi();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp45.add(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getPi();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp45.nextAfter(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.getPi();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getPi();
        boolean boolean70 = dfp45.unequal(dfp69);
        boolean boolean71 = dfp39.unequal(dfp69);
        int int72 = dfp39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp36.add(dfp39);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 25 + "'", int72 == 25);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.remainder(dfp5);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2142770064);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2142770048 + "'", int1 == 2142770048);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.divide(dfp10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.1401874874000717d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) ' ');
        boolean boolean3 = mersenneTwister0.nextBoolean();
        byte[] byteArray4 = null;
        try {
            mersenneTwister0.nextBytes(byteArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long2 = org.apache.commons.math.util.FastMath.min(4684399888325504639L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField5.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField5.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField5.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField5.getOne();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.ceil();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        boolean boolean17 = dfp14.equals((java.lang.Object) roundingMode16);
        dfpField1.setRoundingMode(roundingMode16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.029714058710677338d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.029714058710677338d + "'", double2 == 0.029714058710677338d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.log1p(12188.54943981122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.408334260332932d + "'", double1 == 9.408334260332932d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp2.dotrap(32, "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100", dfp52, dfp63);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp2.newInstance((-0.017453292519943295d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp8, dfp16);
        int int22 = dfp16.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 25 + "'", int22 == 25);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6392501115114819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.62633344287516d + "'", double1 == 36.62633344287516d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-515693678), 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.15693664E8f) + "'", float2 == (-5.15693664E8f));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.acos((-2.356194490192345d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp28.dotrap((int) (short) -1, "hi!", dfp37, dfp52);
        boolean boolean54 = dfp25.lessThan(dfp37);
        java.lang.Class<?> wildcardClass55 = dfp25.getClass();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp25.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField14.newDfp(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField14.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp10.multiply(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp10.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp49.newInstance((-319902279));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1378534813));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.405997134021433E7d) + "'", double1 == (-2.405997134021433E7d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 8, true);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number9 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 8 + "'", number7.equals(8));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.5430806348152437d + "'", number9.equals(1.5430806348152437d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.apache.commons.math.util.FastMath.max((-1704955946762781470L), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray10);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2015653705132565776L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException5);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 8, true);
        java.lang.Class<?> wildcardClass13 = numberIsTooSmallException12.getClass();
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Number number15 = numberIsTooSmallException12.getMin();
        boolean boolean16 = numberIsTooSmallException12.getBoundIsAllowed();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 8 + "'", number15.equals(8));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(25);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, (double) (-32767));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9, localizable11, localizable12, objArray14);
        java.lang.Throwable[] throwableArray16 = mathRuntimeException9.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1378534813));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.93944526f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.remainder(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.remainder(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.getTwo();
        int int22 = dfp15.log10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.remainder(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getPi();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField40.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp49.remainder(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getPi();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp49.add(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp36.dotrap((int) (short) -1, "hi!", dfp45, dfp60);
        boolean boolean62 = dfp33.lessThan(dfp45);
        java.lang.Class<?> wildcardClass63 = dfp33.getClass();
        boolean boolean64 = dfp15.lessThan(dfp33);
        try {
            org.apache.commons.math.dfp.Dfp dfp65 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp11, dfp33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        boolean boolean51 = dfp10.isNaN();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp10.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.apache.commons.math.util.FastMath.max((-479536588), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.09247351917780995d, (java.lang.Number) 16, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1523459874));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1523459840) + "'", int1 == (-1523459840));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.rint(12188.54943981122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12189.0d + "'", double1 == 12189.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1000663195));
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) -1 };
        mersenneTwister3.nextBytes(byteArray8);
        mersenneTwister1.nextBytes(byteArray8);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.divide((int) 'a');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.27632259394013d + "'", double1 == 2.27632259394013d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.newInstance((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-479536588));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7132039919073366d) + "'", double1 == (-0.7132039919073366d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.678982327128295d + "'", double1 == 4.678982327128295d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 3, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) -1, (byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1235773094) + "'", int1 == (-1235773094));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.140187487400072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4037977922081113d + "'", double1 == 1.4037977922081113d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2, (java.lang.Number) (-0.7853981633974483d), true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 2142770048);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.543080634815244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1555698629817919d + "'", double1 == 1.1555698629817919d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits(32);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        double double2 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3720162056618914244L) + "'", long1 == (-3720162056618914244L));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1667021869024767d) + "'", double2 == (-1.1667021869024767d));
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        int int27 = dfp26.classify();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.remainder(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.remainder(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp33.dotrap((int) (short) 0, "hi!", dfp39, dfp52);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getE();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp57.rint();
        int int63 = dfp57.classify();
        org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.Dfp.copysign(dfp52, dfp57);
        boolean boolean65 = dfp26.equals((java.lang.Object) dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp26.power10((int) (byte) 3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.5707961245162751d), number1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(0.13962634015954636d);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.remainder(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) -1);
        boolean boolean21 = dfp8.unequal(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 1.1555698629817919d, true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int[] intArray1 = new int[] { 8 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (-1));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((int) ' ');
//        byte[] byteArray5 = new byte[] { (byte) 10 };
//        mersenneTwister0.nextBytes(byteArray5);
//        int int7 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-216888467) + "'", int1 == (-216888467));
//        org.junit.Assert.assertNotNull(byteArray5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 256222763 + "'", int7 == 256222763);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.38418579101567E-7d + "'", double1 == 2.38418579101567E-7d);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        double double2 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 56584645 + "'", int1 == 56584645);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6180826483777593d + "'", double2 == 0.6180826483777593d);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1378534813));
        mersenneTwister1.setSeed(1704955946762781470L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9, localizable11, localizable12, objArray14);
        java.lang.Throwable[] throwableArray16 = mathRuntimeException15.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException15.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.140187487400072d, number2, false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-875851759));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 875851759L + "'", long1 == 875851759L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField3.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) dfpArray10);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 291435766);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 291435766L + "'", long1 == 291435766L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
        int int3 = mersenneTwister1.nextInt(4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits(2142770048);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        int int4 = dfp3.classify();
        int int5 = dfp3.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(25);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-875851759), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-875851759L) + "'", long2 == (-875851759L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.38418579101567E-7d, 1.1401874874000717d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.091047145634099E-7d + "'", double2 == 2.091047145634099E-7d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2396109578603927d + "'", double1 == 2.2396109578603927d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1235773094));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp10.multiply(dfp47);
        java.lang.String str49 = dfp47.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117" + "'", str49.equals("3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6180826483777593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.48113309522711345d) + "'", double1 == (-0.48113309522711345d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) -1 };
        mersenneTwister12.nextBytes(byteArray17);
        boolean boolean19 = dfp10.equals((java.lang.Object) mersenneTwister12);
        mersenneTwister12.setSeed((-515693678));
        double double22 = mersenneTwister12.nextDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.21767491276146878d + "'", double22 == 0.21767491276146878d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(0.13962634015954636d);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.remainder(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance((byte) -1);
        boolean boolean21 = dfp8.unequal(dfp20);
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = dfp8.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField2.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray8);
        java.lang.Class<?> wildcardClass10 = mathIllegalArgumentException9.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathRuntimeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathRuntimeException11.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-1.6529620192770991E7d));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.09247351917780995d, (java.lang.Number) 16, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Throwable throwable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable8, localizable9, localizable10, objArray16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable5, (java.lang.Object[]) throwableArray18);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.remainder(dfp8);
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        int int5 = dfp4.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-947077474), (long) 2142770048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2142770048L + "'", long2 == 2142770048L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp11.dotrap((int) (short) 0, "hi!", dfp17, dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp5.add(dfp32);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.expm1(32760.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((int) ' ');
//        mersenneTwister0.setSeed((-479536588));
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 261401790 + "'", int1 == 261401790);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-3720162056618914244L));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((-1.6529620192770991E7d));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.remainder(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getPi();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp42.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp29.dotrap((int) (short) -1, "hi!", dfp38, dfp53);
        boolean boolean55 = dfp26.lessThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField8.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField1.newDfp(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getE();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp60.remainder(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getE();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getE();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp70.remainder(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp76.getTwo();
        boolean boolean78 = dfp66.greaterThan(dfp76);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField80.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField80.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray87 = dfpField80.getESplit();
        boolean boolean88 = dfp66.equals((java.lang.Object) dfpField80);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp26.multiply(dfp66);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp66.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfpArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        int int4 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-3720162056618914244L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.log10((-4.79536588E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.543080634815244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 8, true);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException(throwable5, localizable6, localizable7, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathRuntimeException14.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException14);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathRuntimeException14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException14);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathRuntimeException18.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = mathRuntimeException18.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNull(localizable19);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.remainder(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.getPi();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp54.add(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp65.rint();
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField68.getE();
        boolean boolean70 = dfp69.isNaN();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp69.getOne();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp69.negate();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp69.floor();
        int int74 = dfp69.log10();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp66.nextAfter(dfp69);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp50.add(dfp75);
        java.lang.String str77 = dfp50.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "0." + "'", str77.equals("0."));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 8, true);
        java.lang.Class<?> wildcardClass5 = numberIsTooSmallException4.getClass();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getSpecificPattern();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32760);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        int int10 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 56584645);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.544395397174984d + "'", double1 == 18.544395397174984d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.atan((-28.87548261902951d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5361787059786256d) + "'", double1 == (-1.5361787059786256d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.1102230246251565E-16d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-515693678L), number2, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField3.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField3.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField3.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField3.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField3.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField3.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField3.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField3.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) dfpArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray15);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-515693678), (float) (-515693678L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.15693664E8f) + "'", float2 == (-5.15693664E8f));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math.util.FastMath.min(0.09247351917780995d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09247351917780995d + "'", double2 == 0.09247351917780995d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField2.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField2.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField2.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField2.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException15.getGeneralPattern();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp8, dfp16);
        int int22 = dfp16.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1000663195), (java.lang.Number) 2, false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode12);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.2396109578603927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.239610957860393d + "'", double1 == 2.239610957860393d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 25 + "'", int6 == 25);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        boolean boolean8 = dfp6.equals((java.lang.Object) 3.4657359027997265d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.power10K((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0f, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.295779276891516d + "'", double1 == 57.295779276891516d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 25, (java.lang.Number) 9.903487550036129d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 12189.0d, (java.lang.Number) 0.056976270677128626d, true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1378534813), (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3785348129999998E9d) + "'", double2 == (-1.3785348129999998E9d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp2.dotrap(32, "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100", dfp52, dfp63);
        java.lang.String str65 = dfp64.toString();
        boolean boolean66 = dfp64.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "3." + "'", str65.equals("3."));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1378534813), (float) (-4));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.37853478E9f) + "'", float2 == (-1.37853478E9f));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 291435766);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.464542848817878d + "'", double1 == 8.464542848817878d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.acosh(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.043958477050381d + "'", double1 == 7.043958477050381d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 10);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int[] intArray6 = new int[] { ' ', 100, (-1523459840), 10, 32, 4 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double9 = mersenneTwister8.nextDouble();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.47983498856904383d + "'", double9 == 0.47983498856904383d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(100);
        double double2 = mersenneTwister1.nextGaussian();
        try {
            int int4 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5401476965874874d) + "'", double2 == (-1.5401476965874874d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.power10K((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        mersenneTwister0.setSeed((long) ' ');
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        int int4 = mersenneTwister3.nextInt();
//        mersenneTwister3.setSeed((int) ' ');
//        byte[] byteArray8 = new byte[] { (byte) 10 };
//        mersenneTwister3.nextBytes(byteArray8);
//        mersenneTwister0.nextBytes(byteArray8);
//        int[] intArray15 = new int[] { (-875851759), (-1378534813), 35, (-188017526) };
//        mersenneTwister0.setSeed(intArray15);
//        float float17 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1039621277 + "'", int4 == 1039621277);
//        org.junit.Assert.assertNotNull(byteArray8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.35264862f + "'", float17 == 0.35264862f);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.903487550036129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4701628865780936d + "'", double1 == 1.4701628865780936d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp2.dotrap(32, "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100", dfp52, dfp63);
        int int65 = dfp64.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        double double11 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.ceil();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.newInstance(18.544395397174984d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.power10((-875851759));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.remainder(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.remainder(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.dotrap((int) (short) 0, "hi!", dfp11, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.rint();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.newInstance("3.");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        int int51 = dfp49.log10();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        boolean boolean55 = dfp54.isNaN();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.getOne();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.negate();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp60.rint();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getE();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeLn(dfp57, dfp60, dfp68);
        boolean boolean74 = dfp49.greaterThan(dfp57);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-4) + "'", int51 == (-4));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        boolean boolean8 = dfp7.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.negate();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.divide(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.remainder(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.rint();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp40, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.remainder(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.getPi();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp52.add(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp48.subtract(dfp62);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.remainder(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getPi();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp12.add(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.rint();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.ceil();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.newDfp(dfp27);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.apache.commons.math.util.FastMath.round(3.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.5707961245162751d), number1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((-1.6529620192770991E7d));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField8.getPiSplit();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.remainder(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getPi();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp42.add(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp29.dotrap((int) (short) -1, "hi!", dfp38, dfp53);
        boolean boolean55 = dfp26.lessThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField8.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField1.newDfp(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getE();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField64.getE();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp60.remainder(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getE();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp70.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getE();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp70.remainder(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp76.getTwo();
        boolean boolean78 = dfp66.greaterThan(dfp76);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField80.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField80.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField80.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray87 = dfpField80.getESplit();
        boolean boolean88 = dfp66.equals((java.lang.Object) dfpField80);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp26.multiply(dfp66);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp26.newInstance(261401790);
        org.apache.commons.math.dfp.Dfp dfp92 = dfp91.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfpArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.util.FastMath.min(2.091047145634099E-7d, (-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.remainder(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp2.dotrap(32, "1.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e100", dfp52, dfp63);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.getOne();
        boolean boolean66 = dfp63.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.01745417873758517d), (java.lang.Number) (-1L), false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10K((int) (byte) 0);
        double double9 = dfp8.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((long) 'a');
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) -1 };
        mersenneTwister12.nextBytes(byteArray17);
        boolean boolean19 = dfp10.equals((java.lang.Object) mersenneTwister12);
        int[] intArray26 = new int[] { ' ', 100, (-1523459840), 10, 32, 4 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister(intArray26);
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray26);
        mersenneTwister12.setSeed(intArray26);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getLn2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn5();
        boolean boolean30 = dfp24.greaterThan(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp24.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp((-1.6529620192770991E7d));
        org.apache.commons.math.dfp.Dfp dfp39 = dfp14.dotrap((int) (byte) 3, "org.apache.commons.math.exception.MathRuntimeException: ", dfp31, dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField41.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField41.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField41.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField41.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp38.remainder(dfp50);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        boolean boolean8 = dfp7.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.negate();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.divide(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.remainder(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.rint();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp40, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.getPi();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.nextAfter(dfp55);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6108652381980153d + "'", double1 == 0.6108652381980153d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp8, dfp16);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.remainder(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.getPi();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField39.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.remainder(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.getPi();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp48.add(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp35.dotrap((int) (short) -1, "hi!", dfp44, dfp59);
        boolean boolean61 = dfp32.lessThan(dfp44);
        java.lang.Class<?> wildcardClass62 = dfp32.getClass();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.getPi();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getPi();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp32.multiply(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp72 = org.apache.commons.math.dfp.DfpField.computeLn(dfp16, dfp32, dfp71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        java.lang.Class<?> wildcardClass18 = dfp17.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1425465430742778d) + "'", double1 == (-0.1425465430742778d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        int int8 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getZero();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp14);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int[] intArray6 = new int[] { ' ', 100, (-1523459840), 10, 32, 4 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long9 = mersenneTwister8.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8851393200003593745L + "'", long9 == 8851393200003593745L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        boolean boolean3 = dfp2.isNaN();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        boolean boolean8 = dfp7.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.negate();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.divide(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField13.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp28.remainder(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.rint();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getLn5();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp24, dfp40, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp24.add(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField57 = dfp24.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpField57);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getTwo();
        boolean boolean22 = dfp13.unequal(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp10.subtract(dfp21);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8556343548213666d + "'", double1 == 0.8556343548213666d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits(2142770048);
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1000663195));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2996288155981073d + "'", double1 == 1.2996288155981073d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.0d, (double) 0.77001727f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.705290192444123d + "'", double2 == 1.705290192444123d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) 874442466);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.floor(16.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        double double10 = dfp9.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7320508075688772d + "'", double10 == 1.7320508075688772d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-947077474));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13725516750384548d) + "'", double1 == (-0.13725516750384548d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance((byte) 3, (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits(2142770048);
        int int16 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        int int36 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4037977922081113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8708801475835817d + "'", double1 == 0.8708801475835817d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 256222763);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getTwo();
        boolean boolean14 = dfp7.greaterThan(dfp13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        double double16 = dfp14.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        boolean boolean28 = dfp27.isNaN();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.getOne();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        boolean boolean33 = dfp32.isNaN();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.getOne();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.negate();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.divide(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField38.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField38.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField38.getOne();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField38.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField38.getTwo();
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.DfpField.computeExp(dfp32, dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp53.remainder(dfp57);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.getPi();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp53.add(dfp63);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp64.rint();
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.getPi();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.getLn5();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeLn(dfp49, dfp65, dfp72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField75.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField75.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp49.add(dfp80);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp24.divide(dfp80);
        boolean boolean83 = dfp14.greaterThan(dfp82);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 13.141592653589793d + "'", double16 == 13.141592653589793d);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6041261502626034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5399791353757237d + "'", double1 == 0.5399791353757237d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.remainder(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp15.add(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp2.dotrap((int) (short) -1, "hi!", dfp11, dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp2.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2626272556789118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5346958487132123d + "'", double1 == 2.5346958487132123d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int2 = org.apache.commons.math.util.FastMath.max(1039621277, (-1523459840));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1039621277 + "'", int2 == 1039621277);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getTwo();
        boolean boolean11 = dfp2.unequal(dfp10);
        int int12 = dfp2.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfp2.newInstance(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        int int5 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        float float2 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed((-4));
//        double double5 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 260672403 + "'", int1 == 260672403);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.7750113f + "'", float2 == 0.7750113f);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7852939526844751d + "'", double5 == 0.7852939526844751d);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (-1000663195));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.4590029591006584d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.459002959100659d + "'", double1 == 2.459002959100659d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 0, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.remainder(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.add(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp28.dotrap((int) (short) -1, "hi!", dfp37, dfp52);
        boolean boolean54 = dfp25.lessThan(dfp37);
        java.lang.Class<?> wildcardClass55 = dfp25.getClass();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp25.multiply(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField14.newDfp(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField72.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp70.remainder(dfp74);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp70.getTwo();
        boolean boolean77 = dfp70.isNaN();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp66.divide(dfp70);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 7.043958477050381d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 260672403, (long) 56584645);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56584645L + "'", long2 == 56584645L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp3.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getPi();
        boolean boolean28 = dfp3.unequal(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp3.newInstance("3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2015653705132565776L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException5);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException6);
        boolean boolean8 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray9 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(2.6462253643711198d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        float float2 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed((-4));
//        int int5 = mersenneTwister0.nextInt();
//        boolean boolean6 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2010734638) + "'", int1 == (-2010734638));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.36769676f + "'", float2 == 0.36769676f);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-922155416) + "'", int5 == (-922155416));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField42.getPi();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp10.multiply(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.remainder(dfp56);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp56.newInstance((byte) 3);
        boolean boolean60 = dfp47.unequal(dfp56);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp56.newInstance((long) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dfp62);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        dfpField1.setIEEEFlags((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.5707961245162751d), number1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable5, objArray6);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-875851759L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.String str13 = mathRuntimeException11.toString();
        java.lang.Object[] objArray14 = mathRuntimeException11.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField2.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField2.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField2.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField2.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField2.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField2.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField2.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray14);
        java.lang.Object[] objArray16 = mathIllegalArgumentException15.getArguments();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.sqrt();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        boolean boolean11 = dfp2.greaterThan(dfp10);
        java.lang.String str12 = dfp10.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166" + "'", str12.equals("2.718281828459045235360287471352662497757247093699959574966967627724076630353547594571382178525166"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 0, (byte) 10);
        int int14 = dfp10.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray12);
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException(throwable14, localizable15, localizable16, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathRuntimeException23.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException23);
        java.lang.String str26 = mathRuntimeException25.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException25);
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) mathRuntimeException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException(throwable33, localizable34, localizable35, objArray41);
        java.lang.Throwable[] throwableArray43 = mathRuntimeException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, (java.lang.Object[]) throwableArray43);
        java.lang.Throwable[] throwableArray45 = mathIllegalArgumentException44.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException13, localizable29, localizable30, (java.lang.Object[]) throwableArray45);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str26.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10((int) (byte) -1);
        boolean boolean10 = dfp7.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed((long) ' ');
        mersenneTwister0.setSeed((int) (byte) 1);
        mersenneTwister0.setSeed((int) (byte) 3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10((-479536588));
        org.apache.commons.math.dfp.Dfp dfp14 = dfp2.divide(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getLn5Split();
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp13.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException9);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException(throwable16, localizable17, localizable18, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathRuntimeException25.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException25);
        java.lang.Throwable[] throwableArray28 = mathRuntimeException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11, localizable13, localizable14, (java.lang.Object[]) throwableArray28);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.remainder(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp3.add(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.rint();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField19.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField19.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField19.getOne();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.multiply(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.multiply((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, 2142770048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 875851759L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.75851759E8d + "'", double1 == 8.75851759E8d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 56584645);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 987588.3613221468d + "'", double1 == 987588.3613221468d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.1102230246251565E-16d, (java.lang.Number) (byte) 10, false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long1 = org.apache.commons.math.util.FastMath.round(2.5346958487132123d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        float float2 = mersenneTwister0.nextFloat();
//        long long3 = mersenneTwister0.nextLong();
//        double double4 = mersenneTwister0.nextDouble();
//        mersenneTwister0.setSeed(0L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 277375297 + "'", int1 == 277375297);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.23099053f + "'", float2 == 0.23099053f);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6114707401041644525L + "'", long3 == 6114707401041644525L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6518050402163496d + "'", double4 == 0.6518050402163496d);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp8.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getPi();
        boolean boolean33 = dfp8.unequal(dfp32);
        boolean boolean34 = dfp2.unequal(dfp32);
        int int35 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp2.floor();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp36.add(dfp43);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 25 + "'", int35 == 25);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32760, (long) (-1523459874));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32760L + "'", long2 == 32760L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        dfpField1.setIEEEFlags((-875851759));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10((-479536588));
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getPi();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp26.add(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp13.dotrap((int) (short) -1, "hi!", dfp22, dfp37);
        boolean boolean39 = dfp10.lessThan(dfp22);
        java.lang.Class<?> wildcardClass40 = dfp10.getClass();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp44.remainder(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp10.newInstance(dfp49);
        boolean boolean51 = dfp10.isNaN();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp10.divide(16);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        long long1 = org.apache.commons.math.util.FastMath.round(52.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        dfpField1.setIEEEFlagsBits((-1));
        int int12 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 25 + "'", int12 == 25);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.remainder(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp(10L);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.remainder(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp10.dotrap((int) (short) 0, "hi!", dfp16, dfp29);
        int int32 = dfp31.classify();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((double) 0L);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (byte) -1);
        boolean boolean43 = dfp31.greaterThan(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp4.remainder(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { '4', (byte) 10, 10.0f, 1.5430806348152437d, (-1) };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, localizable2, localizable3, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10);
        java.lang.Throwable[] throwableArray13 = mathRuntimeException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray13);
        java.lang.String str15 = mathIllegalArgumentException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException14.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str15.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }
}

