import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 35);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 31);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 320);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.48537739999097d, (java.lang.Number) 320, 320);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.7755575615628914E-17d, (double) 8407224849895527215L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5404595870571008d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 35);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 31);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 35);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 31);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger27);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 35);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) (short) 0);
        java.math.BigInteger bigInteger40 = null;
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 0L);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 35);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger42);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1528444544, 9312L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9929358262223082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7818535714945634d + "'", double1 == 0.7818535714945634d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.1645021403133892d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0135610169218996d + "'", double1 == 1.0135610169218996d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 3921225L, (double) 30.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number6, (int) (byte) 100, orderDirection8, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (-0.6153354142503362d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-959457161), (-1958073980));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        int int2 = org.apache.commons.math.util.FastMath.max((-32), 782483503);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 782483503 + "'", int2 == 782483503);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 105864422900L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 105864422900L + "'", long1 == 105864422900L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 5, 1950, 1083068416);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 195);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-30L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-30L) + "'", long2 == (-30L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 959457152, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 128, 3, 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 128.001f + "'", float3 == 128.001f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1528444544);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1L), (long) 1077870590);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1077870591L) + "'", long2 == (-1077870591L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 320);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-96), 1077936169);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936073 + "'", int2 == 1077936073);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.152059189427843E-21d, 157.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.10487365421592865d) + "'", double2 == (-0.10487365421592865d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 35);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 35);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 31);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (short) 1);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 35);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) bigInteger24, (int) (byte) 0);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) (-32.0d), 1, orderDirection39, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 81.55795945611504d, (java.lang.Number) bigInteger20, 2, orderDirection39, true);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.18422578237157E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double1 = org.apache.commons.math.util.FastMath.abs(2783.520592342062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2783.520592342062d + "'", double1 == 2783.520592342062d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 2117288458);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2117288457) + "'", int2 == (-2117288457));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        long long1 = org.apache.commons.math.util.MathUtils.sign(93530307328229772L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.4999961800229868d, 1072693249, (-1073741824));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-17L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.4673785725277835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.892752432011608d + "'", double1 == 0.892752432011608d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 100, (-1077870560));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1077870460) + "'", int2 == (-1077870460));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) 9.59457152E8d, (int) (byte) -1);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 9.59457152E8d + "'", number12.equals(9.59457152E8d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.742245718635205E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.585170926665248E13d + "'", double1 == 5.585170926665248E13d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8519509564645355958L, (float) 95);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.0f + "'", float2 == 95.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) 9.59457152E8d, (int) (byte) -1);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException16.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        int int20 = nonMonotonousSequenceException16.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (959,457,152 >= 1)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (959,457,152 >= 1)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 97, 6.000000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.329720049290034E11d + "'", double2 == 8.329720049290034E11d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5656417332723562d + "'", number5.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.5656417332723562d + "'", number6.equals(1.5656417332723562d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        long long2 = org.apache.commons.math.util.FastMath.min((-959389121L), (long) 923521);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-959389121L) + "'", long2 == (-959389121L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5340482110486216705L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.5449077018110318d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9983342860140444d + "'", double1 == 0.9983342860140444d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.4893565216418789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5113517370832934d + "'", double1 == 0.5113517370832934d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 499570044731244740L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.719142124895571E15d + "'", double1 == 8.719142124895571E15d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double double1 = org.apache.commons.math.util.FastMath.tanh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999930253396107d + "'", double1 == 0.9999930253396107d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611506d + "'", double1 == 81.55795945611506d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-7L), 320L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 313L + "'", long2 == 313L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 779659312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 9700L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9700.0d + "'", double2 == 9700.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-2117288457));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        long long2 = org.apache.commons.math.util.FastMath.min((-1601518777690678937L), (long) (-1077870460));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1601518777690678937L) + "'", long2 == (-1601518777690678937L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 2.301298902307295d, 1077936073, orderDirection3, true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1077936190);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07793619E9d + "'", double1 == 1.07793619E9d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 10000000000L, 3.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5169658075432558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1077936190);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07793613E9f + "'", float1 == 1.07793613E9f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray9 = new double[] { 32 };
        double[] doubleArray15 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray30);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray39);
        double[] doubleArray47 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray47);
        double[] doubleArray52 = new double[] { 32 };
        double[] doubleArray58 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray30);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (byte) 0);
        try {
            double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 0.6716289980804335d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.51368066089312d + "'", double48 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-959457121) + "'", int49 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 117.64158883361279d + "'", double60 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.5880029862840195d, 157.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.202781477127244E-37d + "'", double2 == 6.202781477127244E-37d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.025651134010854d + "'", double1 == 10.025651134010854d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 'a', (-1077870460));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.281182334612965E41d + "'", double2 == 5.281182334612965E41d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 35);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 31);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.lang.Class<?> wildcardClass17 = bigInteger16.getClass();
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 2L);
        java.lang.Class<?> wildcardClass20 = bigInteger16.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 3, 1077936158);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.221225472E9d + "'", double2 == 3.221225472E9d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1579239825 + "'", int2 == 1579239825);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1077936158);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 316898364);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-96));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9700L, 1078034432, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.695010982077783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.648202069967204d + "'", double1 == 1.648202069967204d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (long) (-53));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.605170185988091d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7236894193081453d + "'", double1 == 1.7236894193081453d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(9.594571200000008E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.4972843599777016E10d + "'", double1 == 5.4972843599777016E10d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-959457156));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.46232633135477d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2117298158), (-18));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) 5044);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5044L + "'", long2 == 5044L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.964889726830815d + "'", double1 == 18.964889726830815d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger8, (java.lang.Number) 9.59457152E8d, (int) (byte) -1);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str13 = nonMonotonousSequenceException11.toString();
        java.lang.Number number14 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 9.59457152E8d + "'", number12.equals(9.59457152E8d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (959,457,152 >= 1)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (959,457,152 >= 1)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 9.59457152E8d + "'", number14.equals(9.59457152E8d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.5449077018110318d, (double) 8519509564645355905L, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.8750399924480483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2995716621760823d) + "'", double1 == (-0.2995716621760823d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int[] intArray2 = new int[] { (short) 1, (byte) 1 };
        int[] intArray5 = new int[] { (short) 1, 32 };
        int[] intArray12 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray17 = new int[] { (short) 1, (byte) 1 };
        int[] intArray20 = new int[] { (short) 1, 32 };
        int[] intArray27 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray20);
        int[] intArray33 = new int[] { (short) 1, (byte) 1 };
        int[] intArray36 = new int[] { (short) 1, 32 };
        int[] intArray43 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray36);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray36);
        int[] intArray49 = new int[] { (short) 1, (byte) 1 };
        int[] intArray52 = new int[] { (short) 1, 32 };
        int[] intArray59 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray52);
        int[] intArray64 = new int[] { (short) 1, (byte) 1 };
        int[] intArray67 = new int[] { (short) 1, 32 };
        int[] intArray74 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray67);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray67);
        int[] intArray80 = new int[] { (short) 1, (byte) 1 };
        int[] intArray83 = new int[] { (short) 1, 32 };
        int[] intArray90 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray83, intArray90);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray83);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray83);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray83);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 118.43141475132347d + "'", double13 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 118.43141475132347d + "'", double28 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.43141475132347d + "'", double44 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 118.43141475132347d + "'", double60 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 118.43141475132347d + "'", double75 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 31 + "'", int76 == 31);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 118.43141475132347d + "'", double91 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 31 + "'", int92 == 31);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1079508992, 21.49155243011387d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0795089919999998E9d + "'", double2 == 1.0795089919999998E9d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1958073980));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1958073984) + "'", int1 == (-1958073984));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray21);
        int[] intArray34 = new int[] { (short) 1, (byte) 1 };
        int[] intArray37 = new int[] { (short) 1, 32 };
        int[] intArray44 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        int[] intArray49 = new int[] { (short) 1, (byte) 1 };
        int[] intArray52 = new int[] { (short) 1, 32 };
        int[] intArray59 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray52);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray52);
        int[] intArray65 = new int[] { (short) 1, (byte) 1 };
        int[] intArray68 = new int[] { (short) 1, 32 };
        int[] intArray75 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray68);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray68);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray37);
        try {
            double double80 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 118.43141475132347d + "'", double45 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 118.43141475132347d + "'", double60 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 118.43141475132347d + "'", double76 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 31 + "'", int77 == 31);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-959457156), (-84268852));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.7236894193081453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.220446049250313E-16d, 14.100656565716712d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.57471110575726E-17d + "'", double2 == 1.57471110575726E-17d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(37, (-1077870592));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1077870555) + "'", int2 == (-1077870555));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-1.5574077246549023d));
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (-0.004451584879506875d));
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray30);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-959457121) + "'", int32 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.51368066089312d + "'", double36 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1077870592), (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07787059E9f) + "'", float2 == (-1.07787059E9f));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37060834919179914d + "'", double1 == 0.37060834919179914d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 35);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 31);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 35);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 1);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 31);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 35);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 1);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 31);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger36);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 96);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger37);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double1 = org.apache.commons.math.util.FastMath.sinh(25.298221281347036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.851185804540105E10d + "'", double1 == 4.851185804540105E10d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1564967006);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-936.1946107697584d), 2.2584572434425354E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray21);
        int[] intArray34 = new int[] { (short) 1, (byte) 1 };
        int[] intArray37 = new int[] { (short) 1, 32 };
        int[] intArray44 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray37);
        int[] intArray50 = new int[] { (short) 1, 32 };
        int[] intArray57 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray57);
        java.lang.Class<?> wildcardClass59 = intArray50.getClass();
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray50);
        int[] intArray63 = new int[] { (short) 1, (byte) 1 };
        int[] intArray66 = new int[] { (short) 1, 32 };
        int[] intArray73 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray66);
        int[] intArray78 = new int[] { (short) 1, (byte) 1 };
        int[] intArray81 = new int[] { (short) 1, 32 };
        int[] intArray88 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray88);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray81);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray81);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray66);
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 118.43141475132347d + "'", double45 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 118.43141475132347d + "'", double58 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 118.43141475132347d + "'", double74 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 31 + "'", int75 == 31);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 118.43141475132347d + "'", double89 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 31 + "'", int90 == 31);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        float float2 = org.apache.commons.math.util.MathUtils.round(97.0f, (-1073741824));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = null;
        double[] doubleArray10 = new double[] { 32 };
        double[] doubleArray16 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        double[] doubleArray24 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray31);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray40);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray48);
        double[] doubleArray58 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray65 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray58);
        double[] doubleArray70 = new double[] { 32 };
        double[] doubleArray76 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-959457121) + "'", int7 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.51368066089312d + "'", double25 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-959457121) + "'", int50 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.51368066089312d + "'", double59 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 100.51368066089312d + "'", double66 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1077870590, (-1958073984));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-880203394) + "'", int2 == (-880203394));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int[] intArray2 = new int[] { (short) 1, (byte) 1 };
        int[] intArray5 = new int[] { (short) 1, 32 };
        int[] intArray12 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray17 = new int[] { (short) 1, (byte) 1 };
        int[] intArray20 = new int[] { (short) 1, 32 };
        int[] intArray27 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray20);
        int[] intArray33 = new int[] { (short) 1, (byte) 1 };
        int[] intArray36 = new int[] { (short) 1, 32 };
        int[] intArray43 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray36);
        int[] intArray48 = new int[] { (short) 1, (byte) 1 };
        int[] intArray51 = new int[] { (short) 1, 32 };
        int[] intArray58 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray51);
        int[] intArray64 = new int[] { (short) 1, 32 };
        int[] intArray71 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray71);
        int[] intArray76 = new int[] { (short) 1, 32 };
        int[] intArray83 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray83);
        int int85 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray83);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray83);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 118.43141475132347d + "'", double13 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 118.43141475132347d + "'", double28 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.43141475132347d + "'", double44 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 118.43141475132347d + "'", double59 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 31 + "'", int60 == 31);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 118.43141475132347d + "'", double72 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 195 + "'", int73 == 195);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 118.43141475132347d + "'", double84 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 195 + "'", int85 == 195);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 118.43141475132347d + "'", double86 == 118.43141475132347d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(5044L, (long) 899659405);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 899664449L + "'", long2 == 899664449L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray10 = null;
        double[] doubleArray12 = new double[] { 32 };
        double[] doubleArray18 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray12);
        double[] doubleArray26 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray33 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray33);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray33);
        double[] doubleArray42 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray42);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 2.2584572434425354E-8d);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.51368066089312d + "'", double27 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.51368066089312d + "'", double34 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.51368066089312d + "'", double43 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-959457121) + "'", int47 == (-959457121));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 22.0d + "'", double48 == 22.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10, 9.46232633135477d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 4.605170185988092d);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 2.537297501373361d, (int) ' ');
        java.lang.String str60 = nonMonotonousSequenceException59.toString();
        boolean boolean61 = nonMonotonousSequenceException59.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = nonMonotonousSequenceException59.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection62, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (4.225 > -0.042)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)" + "'", str60.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertEquals((float) number5, Float.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.52107990906477d, number1, (int) (byte) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1.07793613E9f, (-32));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 65L, (java.lang.Number) (-9.0d), 52);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double2 = org.apache.commons.math.util.FastMath.min(4.899897107843787d, 1.5697653993250724d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5697653993250724d + "'", double2 == 1.5697653993250724d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1077936190);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.605170185988091d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.lang.Number number11 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number11, (int) (byte) 100, orderDirection13, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.1645021403133892d), (java.lang.Number) 32833.43466651029d, 1077936127, orderDirection13, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger4, (java.lang.Number) 1.0456934E11f, 3, orderDirection13, true);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 1950);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1077936169L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(970, 1528444544);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1072693248);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.4914338285155067d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.07787059E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) (-1077870592L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07787059E9f) + "'", float2 == (-1.07787059E9f));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1025.362768916376d + "'", double1 == 1025.362768916376d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(9728.0d, (double) 2117288458);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1172884593645165E9d + "'", double2 == 2.1172884593645165E9d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1958073980), 132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.142219984546603E-13d + "'", number5.equals(8.142219984546603E-13d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertEquals((float) number13, Float.NaN, 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 35);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 31);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger16);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 35);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 1);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 31);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 35);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 1);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 31);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger37);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 96);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger38);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) '#');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.04569339904E11d, (java.lang.Number) bigInteger16, (-1));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.1752011936438014d, 320, (-9));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.34197069E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1341970688) + "'", int1 == (-1341970688));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-96L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5395564933646284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 8519509564645355958L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(5.0541415591887455d, (-1.77148690890803072E17d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.7654192526714155d, (double) 636L, 1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        double double1 = org.apache.commons.math.util.FastMath.log(0.3980417532092065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9211983716392924d) + "'", double1 == (-0.9211983716392924d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) (-938.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-936.1946107697584d) + "'", double2 == (-936.1946107697584d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double2 = org.apache.commons.math.util.MathUtils.round(32.48537739999097d, 195);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.48537739999097d + "'", double2 == 32.48537739999097d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double double1 = org.apache.commons.math.util.FastMath.cosh(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1814400.000000139d + "'", double1 == 1814400.000000139d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 95.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.683261714736121d + "'", double1 == 0.683261714736121d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-2117298158));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5995022633598608d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.717158461011042d, (double) (-1.34197069E9f), (-0.4159265358979311d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        double double2 = org.apache.commons.math.util.MathUtils.log(Double.POSITIVE_INFINITY, 1.3564341684929225E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-35) + "'", int2 == (-35));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int[] intArray2 = new int[] { (short) 1, (byte) 1 };
        int[] intArray5 = new int[] { (short) 1, 32 };
        int[] intArray12 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray17 = new int[] { (short) 1, (byte) 1 };
        int[] intArray20 = new int[] { (short) 1, 32 };
        int[] intArray27 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray20);
        int[] intArray33 = new int[] { (short) 1, (byte) 1 };
        int[] intArray36 = new int[] { (short) 1, 32 };
        int[] intArray43 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray36);
        int[] intArray48 = new int[] { (short) 1, (byte) 1 };
        int[] intArray51 = new int[] { (short) 1, 32 };
        int[] intArray58 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray51);
        int[] intArray64 = new int[] { (short) 1, (byte) 1 };
        int[] intArray67 = new int[] { (short) 1, 32 };
        int[] intArray74 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray67);
        int[] intArray79 = new int[] { (short) 1, (byte) 1 };
        int[] intArray82 = new int[] { (short) 1, 32 };
        int[] intArray89 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray82, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray79, intArray82);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray82);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray64);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray51);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 118.43141475132347d + "'", double13 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 118.43141475132347d + "'", double28 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.43141475132347d + "'", double44 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 118.43141475132347d + "'", double59 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 31 + "'", int60 == 31);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 118.43141475132347d + "'", double75 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 31 + "'", int76 == 31);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 118.43141475132347d + "'", double90 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 31 + "'", int91 == 31);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 31 + "'", int92 == 31);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 31.0d + "'", double93 == 31.0d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2117298158));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 2.537297501373361d, (int) ' ');
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) 7.211102550927978d, (int) (byte) 1, orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, 195, orderDirection12, true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number1, (int) (byte) 100, orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(104.99999999999999d, 18.924652662709544d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.03540569948578d + "'", double2 == 17.03540569948578d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1579239825);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        long long2 = org.apache.commons.math.util.FastMath.max(926957372L, (long) (-2117298158));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 926957372L + "'", long2 == 926957372L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1077936153L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1077936153L + "'", long1 == 1077936153L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        float float2 = org.apache.commons.math.util.FastMath.min(3.16898368E8f, (float) 2400);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2400.0f + "'", float2 == 2400.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 35, (long) 113236097);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7068277824408411683L + "'", long2 == 7068277824408411683L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 131L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1077870590);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07787059E9f + "'", float1 == 1.07787059E9f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, 636L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 636L + "'", long2 == 636L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(195);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1.0456934E11f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.1269280110429725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12692801104297252d + "'", double1 == 0.12692801104297252d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-2117298158));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2117298158L) + "'", long2 == (-2117298158L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-84269204L), 0.1258574822126553d, (double) (-27889441555L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.441451060972311E152d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

