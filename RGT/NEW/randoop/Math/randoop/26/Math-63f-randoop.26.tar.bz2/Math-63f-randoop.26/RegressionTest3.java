import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6038627545958068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5044083343577858d) + "'", double1 == (-0.5044083343577858d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-959457161));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 959457152, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.59457152E8d + "'", double2 == 9.59457152E8d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-32), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-959457121), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-959457156) + "'", int2 == (-959457156));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 636L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 636.0000000000001d + "'", double1 == 636.0000000000001d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number4, (int) (byte) 100, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.110352820159525d), (java.lang.Number) 2.718281828459045d, 782483503, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1.07269331E9f, (int) (byte) 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1077936127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.491461236846263d + "'", double1 == 21.491461236846263d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-959457156), (-1601518777690678937L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(96, (-32));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-9.59457121E8d), 0.8731205525192183d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963258848814d) + "'", double2 == (-1.5707963258848814d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(959457152, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.521079909064771d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-53));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.6088731523847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03806762534314909d) + "'", double1 == (-0.03806762534314909d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.acosh(143375.65657007025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.566370614359172d + "'", double1 == 12.566370614359172d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        double[] doubleArray25 = null;
        double[] doubleArray27 = new double[] { 32 };
        double[] doubleArray33 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray27);
        double[] doubleArray41 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray48);
        double[] doubleArray57 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray57);
        double[] doubleArray65 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray65);
        double[] doubleArray74 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray81 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double[] doubleArray88 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray88);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray81);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (-1.5574077246549023d));
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray93);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.51368066089312d + "'", double42 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.51368066089312d + "'", double58 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 100.51368066089312d + "'", double66 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-959457121) + "'", int67 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.51368066089312d + "'", double75 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 100.51368066089312d + "'", double82 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 100.51368066089312d + "'", double89 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 101.4288144262889d + "'", double95 == 101.4288144262889d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 22.0d + "'", double96 == 22.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1528444522L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.528444522E9d + "'", double1 == 1.528444522E9d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0826224784739814E-8d + "'", double37 == 2.0826224784739814E-8d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 938L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int[] intArray2 = new int[] { (short) 1, 32 };
        int[] intArray9 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray9);
        int[] intArray13 = new int[] { (short) 1, (byte) 1 };
        int[] intArray16 = new int[] { (short) 1, 32 };
        int[] intArray23 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray16);
        int[] intArray28 = new int[] { (short) 1, (byte) 1 };
        int[] intArray31 = new int[] { (short) 1, 32 };
        int[] intArray38 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray31);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray31);
        int[] intArray44 = new int[] { (short) 1, (byte) 1 };
        int[] intArray47 = new int[] { (short) 1, 32 };
        int[] intArray54 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray59 = new int[] { (short) 1, (byte) 1 };
        int[] intArray62 = new int[] { (short) 1, 32 };
        int[] intArray69 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray62);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray62);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray47);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray31);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 118.43141475132347d + "'", double10 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 118.43141475132347d + "'", double24 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 118.43141475132347d + "'", double39 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 118.43141475132347d + "'", double55 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 31 + "'", int56 == 31);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 118.43141475132347d + "'", double70 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9442157056960555d, number1, 32);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4098018484275194d, (-0.9999999999999873d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999873d) + "'", double2 == (-0.9999999999999873d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-899659405), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 899659405 + "'", int2 == 899659405);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray44 = null;
        double[] doubleArray46 = new double[] { 32 };
        double[] doubleArray52 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray46);
        double[] doubleArray60 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray67);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray76);
        double[] doubleArray84 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray84);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray84);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray67);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 5.521079909064771d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.51368066089312d + "'", double61 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 100.51368066089312d + "'", double85 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-959457121) + "'", int86 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-1.5574077246549023d));
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (-0.004451584879506875d));
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray30);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray37 = null;
        double[] doubleArray39 = new double[] { 32 };
        double[] doubleArray45 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        double[] doubleArray53 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray60 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray60);
        double[] doubleArray69 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray69);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray60);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 2.0734669172813818d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-959457121) + "'", int32 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.51368066089312d + "'", double36 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.51368066089312d + "'", double54 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.51368066089312d + "'", double61 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 100.51368066089312d + "'", double70 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0038848218538872d), (double) 1639552224827244288L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.003884821853887d) + "'", double2 == (-1.003884821853887d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5340482110486216705L, (float) 14524424832624L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.45244249E13f + "'", float2 == 1.45244249E13f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int17 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        java.lang.String str23 = nonMonotonousSequenceException21.toString();
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException21.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException21.getArgument();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.5656417332723562d + "'", number25.equals(1.5656417332723562d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int[] intArray2 = new int[] { (short) 1, 32 };
        int[] intArray9 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray9);
        int[] intArray13 = new int[] { (short) 1, (byte) 1 };
        int[] intArray16 = new int[] { (short) 1, 32 };
        int[] intArray23 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray16);
        int[] intArray28 = new int[] { (short) 1, (byte) 1 };
        int[] intArray31 = new int[] { (short) 1, 32 };
        int[] intArray38 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray31);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray31);
        int[] intArray44 = new int[] { (short) 1, 32 };
        int[] intArray51 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray51);
        int[] intArray55 = null;
        try {
            int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 118.43141475132347d + "'", double10 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 118.43141475132347d + "'", double24 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 118.43141475132347d + "'", double39 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 118.43141475132347d + "'", double52 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 195 + "'", int53 == 195);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8860927126647652d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.000000001E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        java.lang.Class<?> wildcardClass37 = doubleArray23.getClass();
        double[] doubleArray43 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray57 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (-1.5574077246549023d));
        double[] doubleArray68 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (-0.004451584879506875d));
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray68);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        java.lang.Class<?> wildcardClass75 = doubleArray50.getClass();
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray50);
        double[] doubleArray77 = null;
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.51368066089312d + "'", double44 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.51368066089312d + "'", double51 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.51368066089312d + "'", double58 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 100.51368066089312d + "'", double69 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-959457121) + "'", int70 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 100.51368066089312d + "'", double74 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-30L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.343237290762231E12d + "'", double1 == 5.343237290762231E12d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection10, false);
        double[] doubleArray18 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray25 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (-1.5574077246549023d));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1077936159 + "'", int9 == 1077936159);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.51368066089312d + "'", double19 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.51368066089312d + "'", double26 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 9700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int2 = org.apache.commons.math.util.FastMath.max(95, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long2 = org.apache.commons.math.util.FastMath.max(105L, 1528444521L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1528444521L + "'", long2 == 1528444521L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(970, 40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 163.95593656835138d + "'", double2 == 163.95593656835138d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.5697302291177695d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1621843080939258d) + "'", double1 == (-1.1621843080939258d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(95, (-1073741824));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.4280228873417884d), (-0.41592653589793116d), 157.05398348363875d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.NEGATIVE_INFINITY, (float) 1072693249);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1564967006, 1077870592);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 923521L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 923521 + "'", int1 == 923521);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-53L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39592515018183416d) + "'", double1 == (-0.39592515018183416d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2117298158), 9700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2117288458) + "'", int2 == (-2117288458));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 8407224849895527163L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5214788145349561d) + "'", double1 == (-0.5214788145349561d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.004451584879506d, (java.lang.Number) 0.9679652519378836d, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-3394226340030730831L), (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6.000000000000001d, 96.26705125297137d, 0.5958054171689086d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1104154720, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-18L), 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.atanh(104.99999999999999d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35, (float) 1639552224827244288L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.63955216E18f + "'", float2 == 1.63955216E18f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5656417332723562d + "'", number5.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 35);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 5340482110486216705L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 183579396L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 35);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 35);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 31);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger29);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 1);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 35);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) bigInteger38, (int) (byte) 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger38);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 52L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger38);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger38);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 0L);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) 35);
        java.math.BigInteger bigInteger55 = null;
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, (long) 35);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 1);
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 31);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger61);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (int) (short) 1);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger66, (int) '#');
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, (long) 1077936127);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.18043044929109792d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19897601471198592d) + "'", double1 == (-0.19897601471198592d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1077870592L), (long) 1077936127);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0000000000000002E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(195, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1950 + "'", int2 == 1950);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1077870592, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077870590 + "'", int2 == 1077870590);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-1.5574077246549023d));
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-358115560) + "'", int25 == (-358115560));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.3980417532092065d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0802700897118174d + "'", double1 == 1.0802700897118174d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        try {
            double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 1.1368683772161603E-13d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-9.0d), (double) Float.NEGATIVE_INFINITY, 32.48537739999097d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray3 = new double[] { 32 };
        double[] doubleArray9 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray17 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray24 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray24);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection29, false);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.51368066089312d + "'", double18 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.51368066089312d + "'", double25 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.7755575615628914E-17d, (double) 5340482110486216705L, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1341970657), (long) 1564967006);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2100139801225142942L) + "'", long2 == (-2100139801225142942L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1958073010));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 8519509564645355905L, 2.3674242326753027E12d, 1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-959457152L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.59457152E8d + "'", double1 == 9.59457152E8d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.3980417532092065d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3980417532092065d + "'", double1 == 0.3980417532092065d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2400, (float) (-32L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-32.0f) + "'", float2 == (-32.0f));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException8.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number13 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 8.142219984546603E-13d + "'", number12.equals(8.142219984546603E-13d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.5868506970919094d + "'", number13.equals(1.5868506970919094d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-27889441555L), 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-27889441557L) + "'", long2 == (-27889441557L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 31);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 35);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 1);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 31);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 35);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 1);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 31);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger28);
        try {
            java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1.0456934E11f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267853335d + "'", double1 == 1.5707963267853335d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.3012989023072956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.043637531419156d + "'", double1 == 5.043637531419156d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6292692974562307d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 8.142219984546603E-13d + "'", number4.equals(8.142219984546603E-13d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.15580649996954174d), 970, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.FastMath.log10(96.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9822712330395684d + "'", double1 == 1.9822712330395684d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = null;
        double[] doubleArray10 = new double[] { 32 };
        double[] doubleArray16 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray10);
        double[] doubleArray24 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray31);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray40);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray48);
        double[] doubleArray58 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray65 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray72 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray72);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-959457121) + "'", int7 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.51368066089312d + "'", double25 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-959457121) + "'", int50 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.51368066089312d + "'", double59 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 100.51368066089312d + "'", double66 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 100.51368066089312d + "'", double73 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-959457121) + "'", int76 == (-959457121));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 97, (long) (-1958073010));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-189933081970L) + "'", long2 == (-189933081970L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        long long2 = org.apache.commons.math.util.FastMath.max((-959389121L), (long) (-959457152));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-959389121L) + "'", long2 == (-959389121L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.abs((-2.303834612632515d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.303834612632515d + "'", double1 == 2.303834612632515d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-32));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        double[] doubleArray55 = new double[] { 32 };
        double[] doubleArray61 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray61);
        java.lang.Class<?> wildcardClass63 = doubleArray55.getClass();
        double[] doubleArray69 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray76);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray69);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 100.51368066089312d + "'", double70 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 22.0d + "'", double79 == 22.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.1258574822126553d, number1, 782483503);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1528444521);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-96L), 320);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-32L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-959457156));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.atanh(21.491461236846263d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.4966250612127736d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6085811217073325d + "'", double1 == 0.6085811217073325d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.691673596021348E41d, (-0.4966250612127736d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 97, 96L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9312L + "'", long2 == 9312L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-84268852), 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 926957372L + "'", long2 == 926957372L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6716289980804335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6716289980804335d + "'", double1 == 0.6716289980804335d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection3, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean10 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection20, false);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        boolean boolean24 = nonMonotonousSequenceException9.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException9.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-959457161L), (long) 128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-959457033L) + "'", long2 == (-959457033L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.cos(7.211102550927978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5995022633598608d + "'", double1 == 0.5995022633598608d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.9E-324d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.4221817809573358E-5d, 677.1919921296093d, (double) (-358115560));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 8519509564645355905L, 1.7422457186352053E41d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.5195095646453555E18d + "'", double2 == 8.5195095646453555E18d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray43 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray57 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (-1.5574077246549023d));
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray50);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-959457121) + "'", int37 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.51368066089312d + "'", double44 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.51368066089312d + "'", double51 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.51368066089312d + "'", double58 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.141592653589793d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2889783497123428d) + "'", double1 == (-1.2889783497123428d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.3108872417680944E-30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3108872417680944E-30d + "'", double1 == 6.3108872417680944E-30d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1528444521, (double) 113236097, 1024.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 104569339904L, 8.5195095646453555E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7179163197164597d + "'", double2 == 1.7179163197164597d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(8.356652224460968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.029289973437858d + "'", double1 == 2.029289973437858d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5325618802906484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6300561810314924d) + "'", double1 == (-0.6300561810314924d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) 'a', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double2 = org.apache.commons.math.util.FastMath.max(1.7736920295129484E80d, (double) (-959457121));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7736920295129484E80d + "'", double2 == 1.7736920295129484E80d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.rint(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 52.0f, (double) 10000000000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.abs(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.74607629780772d + "'", double1 == 155.74607629780772d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.561773448904622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2787522617753226d + "'", double1 == 2.2787522617753226d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(113236097);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.6666666666666667d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-53L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7575857620481944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8596064876872624d + "'", double1 == 0.8596064876872624d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.220446049250313E-16d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1077936158L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1077936127);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-6955610928549199872L), (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.9556117E18f) + "'", float2 == (-6.9556117E18f));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.384185791015625E-7d, (double) (-84268852));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.8750399924480483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean18 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1.07374182E9f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0737418239999999E9d) + "'", double2 == (-1.0737418239999999E9d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.283585074390262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.29157638854253204d + "'", double1 == 0.29157638854253204d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1072693248, (float) (-1341970657));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.34197069E9f) + "'", float2 == (-1.34197069E9f));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double2 = org.apache.commons.math.util.FastMath.max(32.69314718055995d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.69314718055995d + "'", double2 == 32.69314718055995d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray15 = null;
        double[] doubleArray17 = new double[] { 32 };
        double[] doubleArray23 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        double[] doubleArray47 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray47);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 2.2584572434425354E-8d);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray38);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.51368066089312d + "'", double39 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.51368066089312d + "'", double48 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-959457121) + "'", int55 == (-959457121));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (-2117298158));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9470582131168938d + "'", double1 == 0.9470582131168938d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long1 = org.apache.commons.math.util.FastMath.round(320.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 320L + "'", long1 == 320L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.043637531419156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.9076487131773585d) + "'", double1 == (-2.9076487131773585d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        float float2 = org.apache.commons.math.util.FastMath.max(132.0f, (float) 1077870590);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07787059E9f + "'", float2 == 1.07787059E9f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double2 = org.apache.commons.math.util.FastMath.max(32.0d, (double) 1104154720);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.10415472E9d + "'", double2 == 1.10415472E9d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9442157056960555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54.099574886350624d + "'", double1 == 54.099574886350624d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int2 = org.apache.commons.math.util.MathUtils.pow(128, 8519509564645355958L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 8.4072249E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.57562311679104d + "'", double1 == 43.57562311679104d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.asinh(54.099574886350624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.684058916087224d + "'", double1 == 4.684058916087224d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException10.getSuppressed();
        int int14 = nonMonotonousSequenceException10.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1077936158, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2, (long) (-1958073980));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, 8519509564645355958L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1), 32);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1) + "'", number4.equals((-1)));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5L, (long) 128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 640L + "'", long2 == 640L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 316898364);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(113236097, (-316898364));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray44 = null;
        double[] doubleArray46 = new double[] { 32 };
        double[] doubleArray52 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray46);
        double[] doubleArray60 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray67);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray76);
        double[] doubleArray84 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray84);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray84);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray67);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 635.8048168533758d);
        java.lang.Class<?> wildcardClass91 = doubleArray90.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.51368066089312d + "'", double61 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 100.51368066089312d + "'", double85 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-959457121) + "'", int86 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(wildcardClass91);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-959389121L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(9700.000000000002d, 0.9999877116507956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9700.0d + "'", double2 == 9700.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 31);
        java.lang.Class<?> wildcardClass10 = bigInteger7.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0f, (java.lang.Number) (-1), 0, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.110352820159525d), (java.lang.Number) bigInteger7, 1078034432, orderDirection15, true);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 37);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 9223372036854775807L);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.MathUtils.sign(14.100656565716712d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.rint(96.30685281944007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.0d + "'", double1 == 96.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(113236097, 68000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113304097 + "'", int2 == 113304097);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 8519509564645355958L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.5195098E18f + "'", float2 == 8.5195098E18f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray35 = null;
        double[] doubleArray37 = new double[] { 32 };
        double[] doubleArray43 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray37);
        double[] doubleArray51 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray58 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray58);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray67);
        double[] doubleArray75 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray75);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray75);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, 1.078034432E9d);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (-32));
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-959457121) + "'", int34 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 100.51368066089312d + "'", double52 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.51368066089312d + "'", double59 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 100.51368066089312d + "'", double76 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-959457121) + "'", int77 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-959457121) + "'", int85 == (-959457121));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 35);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 37);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 35);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 35);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 1);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 31);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger26);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (short) 1);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 35);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) bigInteger35, (int) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger35);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-1.5574077246549023d));
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (-0.004451584879506875d));
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray30);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-959457121) + "'", int32 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.51368066089312d + "'", double36 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.51368066089312d + "'", double37 == 100.51368066089312d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 35);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 5340482110486216705L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 183579396L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 8519509564645355958L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 35);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7575857620481944d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.123796173748747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 128, 95, 320);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int2 = org.apache.commons.math.util.FastMath.min((-959457156), 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-959457156) + "'", int2 == (-959457156));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-32.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-32L) + "'", long1 == (-32L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(5L, (long) 1077936158);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1077936153L) + "'", long2 == (-1077936153L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8596064876872624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9508234735066673d + "'", double1 == 0.9508234735066673d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10.0f, 1.0000000002582699E10d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int[] intArray2 = new int[] { (short) 1, 32 };
        int[] intArray9 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray9);
        int[] intArray13 = new int[] { (short) 1, (byte) 1 };
        int[] intArray16 = new int[] { (short) 1, 32 };
        int[] intArray23 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray16);
        int[] intArray28 = new int[] { (short) 1, 32 };
        int[] intArray35 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray28);
        int[] intArray40 = new int[] { (short) 1, (byte) 1 };
        int[] intArray43 = new int[] { (short) 1, 32 };
        int[] intArray50 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray43);
        int[] intArray55 = new int[] { (short) 1, (byte) 1 };
        int[] intArray58 = new int[] { (short) 1, 32 };
        int[] intArray65 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray58);
        int[] intArray71 = new int[] { (short) 1, (byte) 1 };
        int[] intArray74 = new int[] { (short) 1, 32 };
        int[] intArray81 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray74);
        int[] intArray87 = new int[] { (short) 1, 32 };
        int[] intArray94 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray94);
        java.lang.Class<?> wildcardClass96 = intArray87.getClass();
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray87);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray43);
        int int99 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray13);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 118.43141475132347d + "'", double10 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 118.43141475132347d + "'", double24 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 118.43141475132347d + "'", double36 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 31.0d + "'", double37 == 31.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 118.43141475132347d + "'", double51 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 118.43141475132347d + "'", double66 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 31 + "'", int67 == 31);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 118.43141475132347d + "'", double82 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 118.43141475132347d + "'", double95 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(wildcardClass96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 31 + "'", int98 == 31);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 31 + "'", int99 == 31);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (-96));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-96L) + "'", long2 == (-96L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 35);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 31);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 96);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 35);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.6153354142503362d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6153354142503362d + "'", double1 == 0.6153354142503362d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int2 = org.apache.commons.math.util.FastMath.min(1077936158, (-1408344889));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1408344889) + "'", int2 == (-1408344889));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 35);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 35);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 1);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 31);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger18);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) '#');
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-959457033L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08638811633366007d) + "'", double1 == (-0.08638811633366007d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = null;
        double[] doubleArray11 = new double[] { 32 };
        double[] doubleArray17 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray11);
        double[] doubleArray25 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray32);
        double[] doubleArray41 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray41);
        double[] doubleArray49 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray49);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray49);
        double[] doubleArray59 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray66 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray75 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (-0.004451584879506875d));
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray66);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.51368066089312d + "'", double7 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-959457121) + "'", int8 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.51368066089312d + "'", double26 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.51368066089312d + "'", double42 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.51368066089312d + "'", double50 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-959457121) + "'", int51 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.51368066089312d + "'", double60 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 100.51368066089312d + "'", double67 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 100.51368066089312d + "'", double69 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 100.51368066089312d + "'", double76 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-959457121) + "'", int77 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.00408402282524d + "'", double80 == 100.00408402282524d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-53), (-959457033L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(35, 84268852);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.FastMath.min((-959457152), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-959457152) + "'", int2 == (-959457152));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1077936127, (long) (-959457161));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double1 = org.apache.commons.math.util.FastMath.log(104.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.653960350157523d + "'", double1 == 4.653960350157523d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2400, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        int int21 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertEquals((float) number20, Float.NaN, 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.008982293606624373d, 0.0d, 1.5868506970919094d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9999474044075106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2842576305252932E-5d) + "'", double1 == (-2.2842576305252932E-5d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.63955216E18f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9470582131168938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8434383360376223d + "'", double1 == 0.8434383360376223d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 14524424912896L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 14524424912896L + "'", long1 == 14524424912896L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.42240075499703494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00737228393760815d + "'", double1 == 0.00737228393760815d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (-18));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-18) + "'", int2 == (-18));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1958073980));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 779659312 + "'", int1 == 779659312);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, (float) (-959457033L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.5945702E8f) + "'", float2 == (-9.5945702E8f));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-899659405), (-899659405));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1077870590, 926957372L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 499570044731244740L + "'", long2 == 499570044731244740L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 938L, (float) (-1073741824));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07374182E9f) + "'", float2 == (-1.07374182E9f));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.sinh(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1814399.9999998633d + "'", double1 == 1814399.9999998633d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', 8519509564645355958L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8519509564645355958L + "'", long2 == 8519509564645355958L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 10.0f, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int[] intArray2 = new int[] { (short) 1, 32 };
        int[] intArray9 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray9);
        int[] intArray13 = new int[] { (short) 1, (byte) 1 };
        int[] intArray16 = new int[] { (short) 1, 32 };
        int[] intArray23 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray16);
        int[] intArray28 = new int[] { (short) 1, 32 };
        int[] intArray35 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray28);
        int[] intArray40 = new int[] { (short) 1, (byte) 1 };
        int[] intArray43 = new int[] { (short) 1, 32 };
        int[] intArray50 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray43);
        int[] intArray55 = new int[] { (short) 1, (byte) 1 };
        int[] intArray58 = new int[] { (short) 1, 32 };
        int[] intArray65 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray58);
        int[] intArray71 = new int[] { (short) 1, (byte) 1 };
        int[] intArray74 = new int[] { (short) 1, 32 };
        int[] intArray81 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray81);
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        double double84 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray74);
        int int85 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray43);
        try {
            int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 118.43141475132347d + "'", double10 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 118.43141475132347d + "'", double24 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 118.43141475132347d + "'", double36 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 31.0d + "'", double37 == 31.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 118.43141475132347d + "'", double51 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 118.43141475132347d + "'", double66 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 31 + "'", int67 == 31);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 118.43141475132347d + "'", double82 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 31 + "'", int85 == 31);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 6.9556112E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.5449077018110318d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.332679798366996d + "'", double1 == 17.332679798366996d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.009022755461861152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009022510625963674d + "'", double1 == 0.009022510625963674d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1L, 9312L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9313L + "'", long2 == 9313L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.41592653589793116d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7464582855744399d) + "'", double1 == (-0.7464582855744399d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2, 0.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray9 = new double[] { 32 };
        double[] doubleArray15 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray30);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray39);
        double[] doubleArray47 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray47);
        double[] doubleArray52 = new double[] { 32 };
        double[] doubleArray58 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray30);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray74 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray81 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (-1.5574077246549023d));
        double[] doubleArray92 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray92);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray92);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray92, (-0.004451584879506875d));
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray92);
        double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray74);
        int int99 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.51368066089312d + "'", double48 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-959457121) + "'", int49 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 117.64158883361279d + "'", double60 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.51368066089312d + "'", double75 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 100.51368066089312d + "'", double82 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 100.51368066089312d + "'", double93 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-959457121) + "'", int94 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + (-959457121) + "'", int99 == (-959457121));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-37.232096219594695d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.390331886173928E15d) + "'", double1 == (-7.390331886173928E15d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) 782483503);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0f, (java.lang.Number) (-1), 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 118.43141475132347d, (int) 'a', orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9470582131168938d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 31);
        java.lang.Class<?> wildcardClass10 = bigInteger7.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0f, (java.lang.Number) (-1), 0, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.110352820159525d), (java.lang.Number) bigInteger7, 1078034432, orderDirection15, true);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 37);
        java.lang.Class<?> wildcardClass22 = bigInteger21.getClass();
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.4221817811941835E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-4.7080055079815875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.561773448904622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9406997721269098d + "'", double1 == 0.9406997721269098d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1073741824));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (-938L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long2 = org.apache.commons.math.util.MathUtils.pow(926957372L, 113304097);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.19897601471198592d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.400485867329769d) + "'", double1 == (-11.400485867329769d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5669767943827975d, (-4.9E-324d), 37);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(132, (-899659405));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1077870592, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1161805013098430464L + "'", long2 == 1161805013098430464L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException16.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-96), (java.lang.Number) 0.5157837238723002d, 97, orderDirection22, true);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-2.117298158E9d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray15 = null;
        double[] doubleArray17 = new double[] { 32 };
        double[] doubleArray23 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.51368066089312d + "'", double39 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.sinh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.6300561810314924d), 1.451863517420987d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.451863517420987d + "'", double2 == 1.451863517420987d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(320);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(923521, (-32));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.6094379124341003d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6094379124341d + "'", double2 == 1.6094379124341d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 0, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(30.48232336227865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.482323362278652d + "'", double1 == 30.482323362278652d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1077936158L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107793615800L + "'", long2 == 107793615800L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getArgument();
        boolean boolean12 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.5656417332723562d + "'", number11.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 30.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4771212547196624d + "'", double1 == 1.4771212547196624d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray9 = new double[] { 32 };
        double[] doubleArray15 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray9);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray30);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray39);
        double[] doubleArray47 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray47);
        double[] doubleArray52 = new double[] { 32 };
        double[] doubleArray58 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray30);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray74 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray81 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray74);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray67);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean90 = nonMonotonousSequenceException89.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException94 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection95 = nonMonotonousSequenceException94.getDirection();
        nonMonotonousSequenceException89.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException94);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection97 = nonMonotonousSequenceException94.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection97, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.51368066089312d + "'", double48 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-959457121) + "'", int49 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 117.64158883361279d + "'", double60 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.51368066089312d + "'", double75 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 100.51368066089312d + "'", double82 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + orderDirection95 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection95.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection97 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection97.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        long long1 = org.apache.commons.math.util.FastMath.round(20.681878183512982d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21L + "'", long1 == 21L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-3.141592653589793d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9801475222605264d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4914338285155067d + "'", double1 == 1.4914338285155067d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 9223372036854775807L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 2.537297501373361d, (int) ' ');
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1958073010L, (long) 67900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, (-17L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7L) + "'", long2 == (-7L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 899659405, (-84268852));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1.45244249E13f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.301298902307295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1077936158, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936190 + "'", int2 == 1077936190);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.005251634398522539d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000137898636212d + "'", double1 == 1.0000137898636212d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertEquals((float) number5, Float.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(117.64158883361279d, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 117.64158883361277d + "'", double2 == 117.64158883361277d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 345.3794070622669d + "'", double1 == 345.3794070622669d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1102230246251565E-16d, (double) (-1341970657));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251564E-16d + "'", double2 == 1.1102230246251564E-16d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9700, (-1408344889));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1408354589 + "'", int2 == 1408354589);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(970, 1077936159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, (-959457161));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 95);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5443.099053742821d + "'", double1 == 5443.099053742821d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.123796173748747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.388251238710856d + "'", double1 == 11.388251238710856d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 100, (long) (-2117288458));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 105864422900L + "'", long2 == 105864422900L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(439465857, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.605170185988092d, 21.491461236846263d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.605170185988093d + "'", double2 == 4.605170185988093d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6292692974562308d, (java.lang.Number) 100.0d, (-1958073980));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 439465857, (long) 84268852);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.9E-324d, (double) 1072693249, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.ulp(20.798253257700395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2117288458));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2117288458 + "'", int1 == 2117288458);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.Number number0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 35);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 5340482110486216705L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        int int16 = nonMonotonousSequenceException14.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection23, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) (-32.0d), 1, orderDirection23, false);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException27.getSuppressed();
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) bigInteger9, (-1341970657), orderDirection30, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-31L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32.0d) + "'", double1 == (-32.0d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 970L, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection37, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 31, 54.099574886350624d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.808765932405644E80d + "'", double2 == 4.808765932405644E80d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8508150646900634d) + "'", double1 == (-0.8508150646900634d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 5044);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9850737044270655d) + "'", double1 == (-0.9850737044270655d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.4280228873417884d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4159265358979311d) + "'", double1 == (-0.4159265358979311d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) 9.46232633135477d, (-959457152));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -959,457,153 and -959,457,152 are not strictly increasing (9.462 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -959,457,153 and -959,457,152 are not strictly increasing (9.462 >= 0)"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 923521L, (double) 1528444521L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(67900, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67900 + "'", int2 == 67900);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0000000005d + "'", double1 == 3628800.0000000005d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.4615540935313574d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { 32 };
        double[] doubleArray42 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray36);
        double[] doubleArray50 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray57 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray57);
        double[] doubleArray66 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray66);
        double[] doubleArray74 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray74);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray74);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 22.0d + "'", double25 == 22.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-959457121) + "'", int33 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.51368066089312d + "'", double51 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 100.51368066089312d + "'", double58 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 100.51368066089312d + "'", double67 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.51368066089312d + "'", double75 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-959457121) + "'", int76 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        int int8 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.5656417332723562d + "'", number7.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(970);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2511337694649084753L, 10.004451584879506d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5113376946490849E18d + "'", double2 == 2.5113376946490849E18d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.152059189427843E-21d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.log10(11.388251238710856d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0564570396465183d + "'", double1 == 1.0564570396465183d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52L, (double) (-31L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1161805013098430464L, 1078034432);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 636L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 636L + "'", long1 == 636L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 35L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2511337694649084753L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.4159265358979311d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 9312L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9312.0d + "'", double1 == 9312.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1752011936438014d, (double) (-30L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1024392999135477d + "'", double2 == 3.1024392999135477d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1073741824));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double2 = org.apache.commons.math.util.MathUtils.log((-9.594571209999999E8d), (double) 0.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3724.225668350351d, 40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.094829426813056E15d + "'", double2 == 4.094829426813056E15d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 938L, (-2.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1365651183618914E-6d + "'", double2 == 1.1365651183618914E-6d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.073741824E9d + "'", double1 == 1.073741824E9d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.29157638854253204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0428104105417055d + "'", double1 == 1.0428104105417055d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1.0f), (double) 4, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        java.lang.Number number19 = nonMonotonousSequenceException16.getArgument();
        java.lang.String str20 = nonMonotonousSequenceException16.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 2.537297501373361d, (int) ' ');
        java.lang.String str25 = nonMonotonousSequenceException24.toString();
        boolean boolean26 = nonMonotonousSequenceException24.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException24.getDirection();
        java.lang.Number number28 = nonMonotonousSequenceException24.getArgument();
        java.lang.Number number29 = nonMonotonousSequenceException24.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean34 = nonMonotonousSequenceException33.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = nonMonotonousSequenceException38.getDirection();
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection44, false);
        nonMonotonousSequenceException33.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        java.lang.Throwable[] throwableArray48 = nonMonotonousSequenceException33.getSuppressed();
        java.lang.Throwable[] throwableArray49 = nonMonotonousSequenceException33.getSuppressed();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 12.566370614359172d + "'", number18.equals(12.566370614359172d));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 12.566370614359172d + "'", number19.equals(12.566370614359172d));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (0.648 < 12.566)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not decreasing (0.648 < 12.566)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2.537 >= 32)"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 32.0d + "'", number28.equals(32.0d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 2.537297501373361d + "'", number29.equals(2.537297501373361d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-3.1415926535897927d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.548739357257743d) + "'", double1 == (-11.548739357257743d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1161805013098430464L, (java.lang.Number) 5.0d, 132);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.4807900619344254d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(65L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.31349432818165834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2726910120387088d + "'", double1 == 0.2726910120387088d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.log(2783.520592342062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.931471805599453d + "'", double1 == 7.931471805599453d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        long long2 = org.apache.commons.math.util.MathUtils.pow(9313L, 131L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2270195707738683103L) + "'", long2 == (-2270195707738683103L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 21L, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.0d + "'", double2 == 21.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-316898364), 128);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-2117298158), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.11729818E9f) + "'", float2 == (-2.11729818E9f));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1077870592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-84268852), 352L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-84269204L) + "'", long2 == (-84269204L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.8695649970375994d), 95, (-959457152));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(320.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7477272994091158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5583162578599312d + "'", double1 == 0.5583162578599312d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double1 = org.apache.commons.math.util.FastMath.acos(35.00000000000001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray16 = null;
        double[] doubleArray18 = new double[] { 32 };
        double[] doubleArray24 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray18);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray39);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray48);
        double[] doubleArray56 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray56);
        double[] doubleArray61 = new double[] { 32 };
        double[] doubleArray67 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray39);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray83 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double[] doubleArray90 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray83);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray76);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 0L);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.51368066089312d + "'", double15 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 100.51368066089312d + "'", double57 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-959457121) + "'", int58 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 117.64158883361279d + "'", double69 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 100.51368066089312d + "'", double84 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 100.51368066089312d + "'", double91 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 117.64158883361279d + "'", double95 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 100.51368066089312d + "'", double98 == 100.51368066089312d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 316898364);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.574091665291576d + "'", double1 == 19.574091665291576d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 52.0f, (-2.2842576305252932E-5d), 1814399.9999998633d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9880316240928618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.685942321433315d + "'", double1 == 1.685942321433315d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray15 = null;
        double[] doubleArray17 = new double[] { 32 };
        double[] doubleArray23 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray17);
        double[] doubleArray31 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray38 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray38);
        double[] doubleArray47 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray47);
        double[] doubleArray55 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray55);
        double[] doubleArray60 = new double[] { 32 };
        double[] doubleArray66 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray66);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 4.605170185988092d);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, 4.9E-324d);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray70);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.51368066089312d + "'", double32 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.51368066089312d + "'", double39 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.51368066089312d + "'", double48 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 100.51368066089312d + "'", double56 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-959457121) + "'", int57 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 117.64158883361279d + "'", double68 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.27439769376085554d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004789143216006031d + "'", double1 == 0.004789143216006031d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.605170185988093d, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 9700, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0f, (java.lang.Number) (-1), 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(6.000000000000001d, 0.5958054171689084d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(19.574091665291576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.695010982077783d + "'", double1 == 2.695010982077783d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass6 = throwableArray5.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 9700);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9700L + "'", long1 == 9700L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 5044);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6995216443485196d) + "'", double1 == (-0.6995216443485196d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4673785725277835d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4673785725277835d + "'", double2 == 0.4673785725277835d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 84268852, 320, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-18));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-936.1946107697584d), (double) 65L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.83185307179588d + "'", double2 == 62.83185307179588d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7477272994091158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.030503595801677816d + "'", double1 == 0.030503595801677816d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 970L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083068416 + "'", int1 == 1083068416);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 67900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570781599254397d + "'", double1 == 1.570781599254397d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2511337694649084753L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.51133761E18f + "'", float1 == 2.51133761E18f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-17L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0802700897118174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0260710880830497d + "'", double1 == 1.0260710880830497d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 0, 5340482110486216705L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5340482110486216705L) + "'", long2 == (-5340482110486216705L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1958073980), (double) 1077936169L, (double) (-32));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-53));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 84268852);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 35);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 35);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 1);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 31);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 1);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 320);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.717158461011042d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.717158461011042d + "'", double2 == 0.717158461011042d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        long long2 = org.apache.commons.math.util.MathUtils.pow(96L, (long) 779659312);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 105864422900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4730.604909026036d + "'", double1 == 4730.604909026036d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray22);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-1.5574077246549023d));
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (-0.004451584879506875d));
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray47 = null;
        double[] doubleArray49 = new double[] { 32 };
        double[] doubleArray55 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray49);
        double[] doubleArray63 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray70 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray70);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray70);
        double[] doubleArray79 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray70, doubleArray79);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray70);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.51368066089312d + "'", double30 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 100.51368066089312d + "'", double46 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.51368066089312d + "'", double64 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 100.51368066089312d + "'", double71 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.51368066089312d + "'", double80 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-959457121) + "'", int83 == (-959457121));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 22.0d + "'", double84 == 22.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1083068416);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, 1073741824);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int int1 = org.apache.commons.math.util.FastMath.round(97.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2400, (-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-21600) + "'", int2 == (-21600));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1528444544, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444544 + "'", int2 == 1528444544);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int2 = org.apache.commons.math.util.FastMath.max(5044, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5044 + "'", int2 == 5044);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection10, false);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray14 = null;
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1077936159 + "'", int9 == 1077936159);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1077936159 + "'", int13 == 1077936159);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 640L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.298221281347036d + "'", double1 == 25.298221281347036d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-27889441557L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-2270195707738683103L), (-2100139801225142942L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        long long2 = org.apache.commons.math.util.FastMath.max(352L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 352L + "'", long2 == 352L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 37, (float) (-6955610928549199872L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.9556112E18f) + "'", float2 == (-6.9556112E18f));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-959457121) + "'", int15 == (-959457121));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1077936127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.077936127E9d + "'", double1 == 1.077936127E9d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5044, (long) (-84268852));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5044L + "'", long2 == 5044L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7867071229411882d + "'", double1 == 0.7867071229411882d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int2 = org.apache.commons.math.util.FastMath.min(5, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double1 = org.apache.commons.math.util.FastMath.floor(157.05398348363875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 157.0d + "'", double1 == 157.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 10L, (double) (-899659405));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.996594050225387E8d) + "'", double2 == (-8.996594050225387E8d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.2743976937608556d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.27439769376085554d + "'", double2 == 0.27439769376085554d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3921225L + "'", long2 == 3921225L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) ' ', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4657359027997265d + "'", double2 == 3.4657359027997265d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.log(21.491461236846263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0676557044733714d + "'", double1 == 3.0676557044733714d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double1 = org.apache.commons.math.util.FastMath.abs(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(32, 1077870592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1077870560) + "'", int2 == (-1077870560));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0428104105417055d, (double) (-132L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int1 = org.apache.commons.math.util.FastMath.abs(1072693249);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693249 + "'", int1 == 1072693249);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 3.16898368E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.16898368E8d + "'", double1 == 3.16898368E8d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5747679041177876E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012548975671813966d + "'", double1 == 0.012548975671813966d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5404595870571008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.493335778182202d + "'", double1 == 0.493335778182202d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1077936159 + "'", int10 == 1077936159);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-959457156));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-3.141592653589793d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.7654192526714155d, 923521);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.49873003762933E-39d) + "'", double2 == (-4.49873003762933E-39d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-358115560), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5868506970919094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 899659405);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        long long1 = org.apache.commons.math.util.FastMath.abs(99L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-959457156), (-1408344889));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.5656417332723562d + "'", number6.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 5.0f, 1.5395564933646284d, (double) (-1601504253265766041L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.571446062633583E49d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.633160768136789E52d + "'", double2 == 2.633160768136789E52d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, (-2117288458));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 68000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.211102550927978d, 2.3674242326753027E12d, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1408354589, 1077936159);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.029289973437858d, (-32), 1528444521);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1077936153L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 120L + "'", long1 == 120L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(96, (-1408344889));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-959457152L), (double) 6.9556112E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.594571519999999E8d) + "'", double2 == (-9.594571519999999E8d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(79350.35618327367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1384.9249780283667d + "'", double1 == 1384.9249780283667d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        long long2 = org.apache.commons.math.util.FastMath.min(131L, (long) 316898364);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 131L + "'", long2 == 131L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int1 = org.apache.commons.math.util.MathUtils.sign(439465857);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 65L, (java.lang.Number) (-9.0d), 52);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-9.0d) + "'", number12.equals((-9.0d)));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        long long1 = org.apache.commons.math.util.FastMath.abs(636L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 636L + "'", long1 == 636L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.0E10f, (double) 1079508992);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998E9d + "'", double2 == 9.999999999999998E9d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 970, 970);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 970.0d + "'", double2 == 970.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1077870592, (long) (-2117288458));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2117288458L) + "'", long2 == (-2117288458L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5840734641020688d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        int int1 = org.apache.commons.math.util.FastMath.abs(84268852);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 84268852 + "'", int1 == 84268852);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1083068416, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1083068416L + "'", long2 == 1083068416L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0f, (java.lang.Number) (-1), 0, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 32.0f + "'", number7.equals(32.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1077870592L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1077870592) + "'", int1 == (-1077870592));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 1077936169L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 132, (java.lang.Number) (-0.39592515018183416d), 4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) (-32.0d), 1, orderDirection6, false);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-938L), 1072693249);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1876.0d) + "'", double2 == (-1876.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.Number number1 = null;
        double[] doubleArray4 = new double[] { 32 };
        double[] doubleArray10 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray13 = null;
        double[] doubleArray15 = new double[] { 32 };
        double[] doubleArray21 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray15);
        double[] doubleArray29 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray36 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray36);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean46 = nonMonotonousSequenceException45.getStrict();
        java.lang.Throwable[] throwableArray47 = nonMonotonousSequenceException45.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException45.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection48, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.1269280110429725d, number1, (int) (short) 100, orderDirection48, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.51368066089312d + "'", double30 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.51368066089312d + "'", double37 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.0260710880830497d, 68000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0260710880830497d + "'", double2 == 1.0260710880830497d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1341970657));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        double double2 = org.apache.commons.math.util.MathUtils.log(8.18422578237157E22d, (double) 316898364);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37100896028471564d + "'", double2 == 0.37100896028471564d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-6955610928549199872L), 30.482323362278652d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4524424832623713E13d, 1.7736920295129484E80d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7736920295129484E80d + "'", double2 == 1.7736920295129484E80d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1365651183618914E-6d, 5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1575360452631182E-7d + "'", double2 == 2.1575360452631182E-7d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5656417332723562d + "'", number5.equals(1.5656417332723562d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.5656417332723562d + "'", number6.equals(1.5656417332723562d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1413478768163254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1836271799968414d + "'", double1 == 2.1836271799968414d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.29157638854253204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.537297501373361d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double1 = org.apache.commons.math.util.FastMath.atan(14.100656565716712d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4999961800229868d + "'", double1 == 1.4999961800229868d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5325618802906484d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4893565216418789d + "'", double1 == 0.4893565216418789d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-81007559613L), 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray22);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-1.5574077246549023d));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray22);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.51368066089312d + "'", double30 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(8407224849895527215L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) (-32.0d), 1, orderDirection12, false);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException3.getDirection();
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 35);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 1);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 31);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger28, (java.lang.Number) 9.59457152E8d, (int) (byte) -1);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 779659312, (-32));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        double[] doubleArray37 = null;
        double[] doubleArray39 = new double[] { 32 };
        double[] doubleArray45 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        double[] doubleArray53 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray60 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray60);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 1.0564570396465183d);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.51368066089312d + "'", double54 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.51368066089312d + "'", double61 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.9742053508708637d + "'", double66 == 0.9742053508708637d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 12.566370614359172d, (java.lang.Number) 0.6483383454571674d, (int) 'a', orderDirection14, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertEquals((float) number20, Float.NaN, 0);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9700L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

