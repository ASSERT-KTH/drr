import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100.0f, (double) 8407224849895527163L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.46232633135477d + "'", double2 == 9.46232633135477d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1408344889), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-959457152), (-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-959457161) + "'", int2 == (-959457161));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-32.0d), (-57.29577951308232d), 2.3674242326753027E12d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.asinh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1077936159, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 635.8048168533758d + "'", double2 == 635.8048168533758d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 0, (-32.0d), (double) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9880316240928618d, 2.4221817809573358E-5d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 0, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.641588833612779d, 117.64158883361279d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5557.690612768985d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1958073010) + "'", int1 == (-1958073010));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(30.48232336227865d, 0.9880316240928618d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 0L, (-959457161), (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.5430806348152437d, 52);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 52.0f, 10.004451584879506d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(10, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.15580649996954174d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(10000000000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 9700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(35, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 183579396L + "'", long2 == 183579396L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray3 = new double[] { 32 };
        double[] doubleArray9 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray3);
        double[] doubleArray17 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray24 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray24);
        double[] doubleArray33 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 2.2584572434425354E-8d);
        try {
            double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.51368066089312d + "'", double18 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.51368066089312d + "'", double25 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.51368066089312d + "'", double34 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.8421709430404007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.log10(118.43141475132347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0734669172813818d + "'", double1 == 2.0734669172813818d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 132, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0f + "'", float1 == 5.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) -1, (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 2.2584572434425354E-8d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection43, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) (-32.0d), 1, orderDirection43, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection43, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long2 = org.apache.commons.math.util.FastMath.min(183579396L, 105L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 105L + "'", long2 == 105L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.8421709430404007E-14d, (double) (-32), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.64158883361278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6666666666666667d + "'", double1 == 0.6666666666666667d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int[] intArray2 = new int[] { (short) 1, 32 };
        int[] intArray9 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray9);
        int[] intArray11 = null;
        try {
            int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 118.43141475132347d + "'", double10 == 118.43141475132347d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        float float1 = org.apache.commons.math.util.FastMath.abs(31.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 31.0f + "'", float1 == 31.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5840734641020688d, (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 320, 65L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 320L + "'", long2 == 320L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 4.605170185988092d);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-84268852) + "'", int56 == (-84268852));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.2584572434425354E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2584572434425347E-8d + "'", double1 == 2.2584572434425347E-8d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int2 = org.apache.commons.math.util.FastMath.min((-96), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-96) + "'", int2 == (-96));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-959457152));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021443E41d + "'", double1 == 6.691673596021443E41d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 5340482110486216705L, 970, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.0541415591887455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5169658075432558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009022755461861152d + "'", double1 == 0.009022755461861152d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-959457152));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertEquals((float) number12, Float.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-959457152));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.sin((-28.754080141118614d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4615540935313574d + "'", double1 == 0.4615540935313574d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 0, 132L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-132L) + "'", long2 == (-132L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.015572818255850338d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1078034432, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray21);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 2.537297501373361d, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 31.0f, 4.15912713462618d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.min(677.1919921296093d, (-0.5514266812416906d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5514266812416906d) + "'", double2 == (-0.5514266812416906d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (byte) 10, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.503599627370496E16d + "'", double2 == 4.503599627370496E16d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.tanh(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.MathUtils.log(30.48232336227865d, 5.52107990906477d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 1, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.8020393306553872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8020393306553872d + "'", double1 == 2.8020393306553872d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-959457152), 31, 1077936159);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.util.FastMath.min(1.537122012015815E12d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (-132L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.rint(104.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.142219984546603E-13d + "'", number5.equals(8.142219984546603E-13d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 31.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.0d + "'", double1 == 31.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.atan(2783.520592342062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5704370695435836d + "'", double1 == 1.5704370695435836d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5669767943827975d, 0.0d, 4.503599627370496E16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.9442157056960555d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.6313083693369503E35d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1408344889));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-6955610928549199872L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1958073010), 11.993498045565198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.993498045565198d + "'", double2 == 11.993498045565198d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long1 = org.apache.commons.math.util.FastMath.abs(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 32L, 3.141592653589793d, (double) (-1.40834483E9f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int int1 = org.apache.commons.math.util.FastMath.round(32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6806126648574351d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6292692974562307d + "'", double1 == 0.6292692974562307d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray7);
        double[] doubleArray10 = new double[] { (-0.004451584879506875d) };
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray18 = null;
        double[] doubleArray20 = new double[] { 32 };
        double[] doubleArray26 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray26);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray20);
        double[] doubleArray34 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray41 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray41);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray41);
        double[] doubleArray50 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray50);
        double[] doubleArray58 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray58);
        double[] doubleArray63 = new double[] { 32 };
        double[] doubleArray69 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray41);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray16);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.51368066089312d + "'", double35 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.51368066089312d + "'", double42 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.51368066089312d + "'", double51 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.51368066089312d + "'", double59 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-959457121) + "'", int60 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 117.64158883361279d + "'", double71 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 10.004451584879506d + "'", double73 == 10.004451584879506d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6292692974562307d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6292692974562308d + "'", double2 == 0.6292692974562308d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1078034432, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 1, 6.691673596021443E41d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 183579396L, (-959457152));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 970);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 31, 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8519509564645355905L + "'", long2 == 8519509564645355905L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1077936159, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936169 + "'", int2 == 1077936169);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.004451584879506875d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1645021403133892d) + "'", double1 == (-0.1645021403133892d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 320L, 0.1353352832366127d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-9));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.0d) + "'", double1 == (-9.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-32.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999873d) + "'", double1 == (-0.9999999999999873d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, (int) (short) 1, 970);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-32));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1077936159, 1077936159);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5340482110486216705L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1, 1077936158);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.267884728309446d, (java.lang.Number) 5.0f, (-959457121));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.4673785725277835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.451845708858593d + "'", double1 == 0.451845708858593d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.7477272994091158d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.506431593288552E9d + "'", double2 == 7.506431593288552E9d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1078034432);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078034432E9d + "'", double1 == 1.078034432E9d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(96, (-6955610928549199872L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray16 = null;
        double[] doubleArray18 = new double[] { 32 };
        double[] doubleArray24 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray18);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray39);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray48);
        double[] doubleArray56 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray56);
        double[] doubleArray61 = new double[] { 32 };
        double[] doubleArray67 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray39);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray83 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double[] doubleArray90 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray83);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray76);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.51368066089312d + "'", double15 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 100.51368066089312d + "'", double57 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-959457121) + "'", int58 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 117.64158883361279d + "'", double69 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 100.51368066089312d + "'", double84 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 100.51368066089312d + "'", double91 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 117.64158883361279d + "'", double95 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 5.0541415591887455d + "'", double96 == 5.0541415591887455d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.15912713462618d, (int) (short) 100, (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.apache.commons.math.util.MathUtils.pow(320, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 104569339904L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(5, (-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 4.605170185988093d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) ' ', (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-938L) + "'", long2 == (-938L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int[] intArray33 = new int[] { (short) 1, (byte) 1 };
        int[] intArray36 = new int[] { (short) 1, 32 };
        int[] intArray43 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray36);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray36);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray18);
        try {
            int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 118.43141475132347d + "'", double44 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 31 + "'", int47 == 31);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-9));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(8407224849895527163L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8407224849895527215L + "'", long2 == 8407224849895527215L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 1077936158);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(32, (-96));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, (-959457121));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '#', (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.571446062633583E49d + "'", double2 == 2.571446062633583E49d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-32));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1078034432);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.49155243011387d + "'", double1 == 21.49155243011387d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.0734669172813818d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.356652224460968d + "'", double2 == 8.356652224460968d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 0.0f, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.pow((-3.110352820159525d), (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.77148690890803072E17d) + "'", double2 == (-1.77148690890803072E17d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1077936159, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077936159L + "'", long2 == 1077936159L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-96), (java.lang.Number) 0.5157837238723002d, 97, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.5157837238723002d + "'", number6.equals(0.5157837238723002d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.FastMath.abs((-84268852));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 84268852 + "'", int1 == 84268852);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int[] intArray2 = new int[] { (short) 1, (byte) 1 };
        int[] intArray5 = new int[] { (short) 1, 32 };
        int[] intArray12 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray17 = new int[] { (short) 1, (byte) 1 };
        int[] intArray20 = new int[] { (short) 1, 32 };
        int[] intArray27 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int[] intArray32 = new int[] { (short) 1, (byte) 1 };
        int[] intArray35 = new int[] { (short) 1, 32 };
        int[] intArray42 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray35);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray35);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray17);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 118.43141475132347d + "'", double13 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 118.43141475132347d + "'", double28 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 118.43141475132347d + "'", double43 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 31 + "'", int44 == 31);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4524424832623713E13d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 14524424832624L + "'", long1 == 14524424832624L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-959457152));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.571446062633583E49d, (double) Float.NaN, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.41592653589793116d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.3674242326753027E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3564341684929225E14d + "'", double1 == 1.3564341684929225E14d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5430806348152437d, 2.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(32.48537739999097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.699594494347029d + "'", double1 == 5.699594494347029d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-2.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1073741824) + "'", int1 == (-1073741824));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int1 = org.apache.commons.math.util.FastMath.abs(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(6.3108872417680944E-30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.pow(183579396L, (long) 1077936169);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(96);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) ' ', 320L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 352L + "'", long2 == 352L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 5340482110486216705L);
        java.math.BigInteger bigInteger7 = null;
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5656417332723562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.785745122547596d + "'", double1 == 3.785745122547596d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1077936159);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.356652224460968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.35665222446097d + "'", double1 == 8.35665222446097d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8407224849895527163L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.4072249E18f + "'", float1 == 8.4072249E18f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(320, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6666666666666667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.717158461011042d + "'", double1 == 0.717158461011042d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 8407224849895527163L, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int2 = org.apache.commons.math.util.MathUtils.pow(31, 183579396L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 439465857 + "'", int2 == 439465857);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-959457152));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.5945715E8f + "'", float1 == 9.5945715E8f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10000000000L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0E10f + "'", float1 == 1.0E10f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97, (-12.089257168133964d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1077936159, (-32));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936127 + "'", int2 == 1077936127);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) (-938L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-936.1946107697584d) + "'", double2 == (-936.1946107697584d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 320L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(35, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (-32));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        long long1 = org.apache.commons.math.util.FastMath.abs(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(6.691673596021348E41d, 0.9880316240928618d, (double) 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 14524424832624L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.009022755461861152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5747679041177876E-4d + "'", double1 == 1.5747679041177876E-4d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3186545890560927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31349432818165834d + "'", double1 == 0.31349432818165834d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 22.0d + "'", double25 == 22.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-938L), 1077936158);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray21);
        int[] intArray34 = new int[] { (short) 1, (byte) 1 };
        int[] intArray37 = new int[] { (short) 1, 32 };
        int[] intArray44 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray37);
        int[] intArray50 = new int[] { (short) 1, 32 };
        int[] intArray57 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray57);
        java.lang.Class<?> wildcardClass59 = intArray50.getClass();
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray50);
        int[] intArray63 = new int[] { (short) 1, 32 };
        int[] intArray70 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray70);
        java.lang.Class<?> wildcardClass72 = intArray63.getClass();
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray63);
        try {
            int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 118.43141475132347d + "'", double45 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 118.43141475132347d + "'", double58 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 118.43141475132347d + "'", double71 == 118.43141475132347d);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5840734641020688d, (-0.004451584879506875d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.004451584879506875d) + "'", double2 == (-0.004451584879506875d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-959457152));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3628800.0d, 35.00000000000001d, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) '4', (-9));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 5.0541415591887455d + "'", double54 == 5.0541415591887455d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1077936159, 352L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(9.59457152E8d, (double) 31, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) -1, 1077936159L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077936158L + "'", long2 == 1077936158L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(10.004451584879506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1547543309026267d + "'", double1 == 2.1547543309026267d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5707963267948966d), number1, 320, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 5, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 96, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 2.303834612632515d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-959457161));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 959457161L + "'", long1 == 959457161L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 320L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9999999999999873d), (double) 0, 132.00000000000003d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-6955610928549199872L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.util.MathUtils.log(194.0d, (double) (-959457152));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number6, (int) (byte) 100, orderDirection8, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (� >= 1.566)"));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.5656417332723562d + "'", number12.equals(1.5656417332723562d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6292692974562308d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2585385949124617d + "'", double2 == 1.2585385949124617d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 1, 1077936169, (int) (short) 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 8.4072249E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3980417532092065d) + "'", double1 == (-0.3980417532092065d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1078034432, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.4046102750019673d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.exp(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 8519509564645355905L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.009171805590283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5325618802906484d + "'", double1 == 0.5325618802906484d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.7477272994091158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24247366994544117d + "'", double1 == 0.24247366994544117d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8529129374230334d, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8529129374230334d + "'", double2 == 0.8529129374230334d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.5514266812416906d), (double) 65L, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double2 = org.apache.commons.math.util.FastMath.min(12.566370614359172d, 0.6367115264373017d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6367115264373017d + "'", double2 == 0.6367115264373017d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double[] doubleArray5 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray19 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray12);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (-1.5574077246549023d));
        double[] doubleArray30 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (-0.004451584879506875d));
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray30);
        double[] doubleArray36 = null;
        double[] doubleArray38 = new double[] { 32 };
        double[] doubleArray44 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray38);
        double[] doubleArray52 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray59 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray59);
        double[] doubleArray68 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray68);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray76);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.51368066089312d + "'", double6 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.51368066089312d + "'", double13 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.51368066089312d + "'", double20 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.51368066089312d + "'", double31 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-959457121) + "'", int32 == (-959457121));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 100.51368066089312d + "'", double53 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.51368066089312d + "'", double60 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 100.51368066089312d + "'", double69 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-959457121) + "'", int78 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(9700, 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 9.5945715E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.59457152E8d + "'", double1 == 9.59457152E8d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.MathUtils.pow(35, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-96));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-95.99999999999999d) + "'", double1 == (-95.99999999999999d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-32), (long) (-959457161));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-938L), 0.0d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 14524424832624L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.45244249E13f + "'", float2 == 1.45244249E13f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-32));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5585053606381855d) + "'", double1 == (-0.5585053606381855d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 9.5945715E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.594571520000001E8d + "'", double1 == 9.594571520000001E8d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 35);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 31);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) '#');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-938L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        double[] doubleArray14 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray16 = null;
        double[] doubleArray18 = new double[] { 32 };
        double[] doubleArray24 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray18);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray39 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray39);
        double[] doubleArray48 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray48);
        double[] doubleArray56 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray56);
        double[] doubleArray61 = new double[] { 32 };
        double[] doubleArray67 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray67);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray39);
        double[] doubleArray76 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray83 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double[] doubleArray90 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray83, doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray83);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray76);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray14);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection97 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection97, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not decreasing (-1 < 4.642)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.51368066089312d + "'", double15 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.51368066089312d + "'", double40 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.51368066089312d + "'", double49 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 100.51368066089312d + "'", double57 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-959457121) + "'", int58 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 117.64158883361279d + "'", double69 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 100.51368066089312d + "'", double77 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 100.51368066089312d + "'", double84 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 100.51368066089312d + "'", double91 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 117.64158883361279d + "'", double95 == 117.64158883361279d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 5.0541415591887455d + "'", double96 == 5.0541415591887455d);
        org.junit.Assert.assertTrue("'" + orderDirection97 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection97.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1528444521, 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2511337694649084753L + "'", long2 == 2511337694649084753L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0E10d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10000000000L + "'", long1 == 10000000000L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(35.00000000000001d, 0.0d, (double) (-938L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 5340482110486216705L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.12184760565226d + "'", double1 == 43.12184760565226d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.785745122547596d, 2.0734669172813818d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        java.lang.Number number45 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1, number45, (int) (byte) 100, orderDirection47, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection47, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 32, 195);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-959457121));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.5514266812416906d), 104.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.005251634398522539d) + "'", double2 == (-0.005251634398522539d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.MathUtils.sign(9.594571520000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.4221817809573358E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4221817811941835E-5d + "'", double1 == 2.4221817811941835E-5d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1226168683560893E57d + "'", double1 == 2.1226168683560893E57d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6483383454571674d, (-0.9835877454343449d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32833.43466651029d + "'", double1 == 32833.43466651029d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.8020393306553872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4098018484275194d + "'", double1 == 1.4098018484275194d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray32 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray40 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray40);
        double[] doubleArray45 = new double[] { 32 };
        double[] doubleArray51 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 4.605170185988092d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (4.225 >= -0.042)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.51368066089312d + "'", double33 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.51368066089312d + "'", double41 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-959457121) + "'", int42 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 117.64158883361279d + "'", double53 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        long long1 = org.apache.commons.math.util.FastMath.abs((-938L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 938L + "'", long1 == 938L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-959457121), 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.acosh(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 157.05398348363875d + "'", double1 == 157.05398348363875d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection3, false);
        java.lang.Throwable throwable6 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.acos(9.46232633135477d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.717158461011042d, 677.1919921296093d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 970);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 970L + "'", long1 == 970L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 439465857);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.642925139495128d + "'", double1 == 8.642925139495128d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 938L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5697302291177695d + "'", double1 == 1.5697302291177695d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100, (double) (-84268852), 1.4098018484275194d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1078034432, (long) 439465857);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-959457152), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-959457152L) + "'", long2 == (-959457152L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1077936169, (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-71302844527667943L) + "'", long2 == (-71302844527667943L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.74607629780772d + "'", double1 == 155.74607629780772d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-959457121));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 959457121L + "'", long1 == 959457121L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 31, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31L) + "'", long2 == (-31L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-53));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 8407224849895527163L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int int2 = org.apache.commons.math.util.FastMath.max(970, 1077936127);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936127 + "'", int2 == 1077936127);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1958073010), 2L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-316898364) + "'", int2 == (-316898364));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 2.1547543309026267d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1547543309026267d + "'", double2 == 2.1547543309026267d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-316898364));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.16898368E8f + "'", float1 == 3.16898368E8f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-6955610928549199872L), 970, 439465857);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1528444521, (-1073741824), (-84268852));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.2584572434425354E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-53), 0.0d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1958073010));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.95807296E9f) + "'", float2 == (-1.95807296E9f));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.24247366994544117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27439769376085554d + "'", double1 == 0.27439769376085554d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-4.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (-0.004451584879506875d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.004451584879506875d) + "'", double2 == (-0.004451584879506875d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.2584572434425354E-8d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2584572434425354E-8d + "'", double2 == 2.2584572434425354E-8d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.27439769376085554d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2L, (-84268852), (-32));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        double[] doubleArray27 = null;
        double[] doubleArray29 = new double[] { 32 };
        double[] doubleArray35 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray29);
        double[] doubleArray43 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray50 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray50);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray50);
        double[] doubleArray59 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray59);
        double[] doubleArray67 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray67);
        double[] doubleArray72 = new double[] { 32 };
        double[] doubleArray78 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray78);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 4.605170185988092d);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, 4.9E-324d);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.51368066089312d + "'", double44 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.51368066089312d + "'", double51 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.51368066089312d + "'", double60 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.51368066089312d + "'", double68 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-959457121) + "'", int69 == (-959457121));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 117.64158883361279d + "'", double80 == 117.64158883361279d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 96.26705125297137d + "'", double85 == 96.26705125297137d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.sin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1408344889), 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1601518777690678937L) + "'", long2 == (-1601518777690678937L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.31349432818165834d, (-9.5945712E8d), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, 2.301298902307295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.301298902307295d + "'", double2 == 2.301298902307295d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        long long1 = org.apache.commons.math.util.FastMath.abs(970L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 970L + "'", long1 == 970L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.6948892444103338E28d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 104569339904L, 6.691673596021443E41d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.21273601220948d) + "'", double1 == (-48.21273601220948d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 32 };
        double[] doubleArray8 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        double[] doubleArray16 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray23 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray23);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray23);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.51368066089312d + "'", double17 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.51368066089312d + "'", double24 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.571446062633583E49d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4733300663443743E51d + "'", double1 == 1.4733300663443743E51d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.642925139495128d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1077936159L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8813535100851107E7d + "'", double1 == 1.8813535100851107E7d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0820658028826817d) + "'", double1 == (-1.0820658028826817d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-84268852), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.142219984546603E-13d, (java.lang.Number) 1.5868506970919094d, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.142219984546603E-13d + "'", number5.equals(8.142219984546603E-13d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.587 >= 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.587 >= 0)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.587 >= 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.587 >= 0)"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double2 = org.apache.commons.math.util.FastMath.max((double) Float.NaN, 0.6292692974562307d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-959457152), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 959457152 + "'", int2 == 959457152);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9126365759632116d + "'", double1 == 0.9126365759632116d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int1 = org.apache.commons.math.util.FastMath.abs(1077936158);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077936158 + "'", int1 == 1077936158);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 5, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3394226340030730831L) + "'", long2 == (-3394226340030730831L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        long long1 = org.apache.commons.math.util.MathUtils.sign(938L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-132L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.303834612632515d) + "'", double1 == (-2.303834612632515d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.FastMath.log10(132.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.12057393120585d + "'", double1 == 2.12057393120585d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.1353352832366127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1269280110429725d + "'", double1 == 0.1269280110429725d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.5574077246549023d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.141592653589793d) + "'", double2 == (-2.141592653589793d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-53), 132L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53L) + "'", long2 == (-53L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(8.065817517094494E67d, 1077936169);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7736920295129484E80d + "'", double2 == 1.7736920295129484E80d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1077936159L, (-96), 132);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5169658075432558d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-959457161));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2L, (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long1 = org.apache.commons.math.util.FastMath.round(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.691673596021443E41d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray1 = new double[] { 32 };
        double[] doubleArray7 = new double[] { (-1), (short) -1, 4.641588833612779d, 1.0000000000000002d, (-1L) };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray7);
        java.lang.Class<?> wildcardClass9 = doubleArray1.getClass();
        double[] doubleArray15 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray22 = new double[] { 10L, (short) 100, (-1L), 1.0f, (-1.0d) };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.51368066089312d + "'", double16 == 100.51368066089312d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.51368066089312d + "'", double23 == 100.51368066089312d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 22.0d + "'", double25 == 22.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 32.0d + "'", double26 == 32.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (float) 65L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, 1077936158L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-32), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-32.0f) + "'", float2 == (-32.0f));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.41592653589793116d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4280228873417884d) + "'", double1 == (-0.4280228873417884d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.5449077018110318d, 195, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.signum(96.26705125297137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.signum(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-959457161), (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592653589793d) + "'", double2 == (-3.141592653589793d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 183579396L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 40, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.3012989023072956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1943159977894011d + "'", double1 == 1.1943159977894011d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5704370695435836d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5656417332723562d, (java.lang.Number) Float.NaN, 97);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) -1, (java.lang.Number) 2.0734669172813818d, (int) '#', orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.9996621509623059d, 2.12057393120585d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 132, (-31L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-6955610928549199872L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, (-53));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int[] intArray2 = new int[] { (short) 1, (byte) 1 };
        int[] intArray5 = new int[] { (short) 1, 32 };
        int[] intArray12 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray17 = new int[] { (short) 1, (byte) 1 };
        int[] intArray20 = new int[] { (short) 1, 32 };
        int[] intArray27 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray20);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray20);
        int[] intArray33 = new int[] { (short) 1, 32 };
        int[] intArray40 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray40);
        int[] intArray45 = new int[] { (short) 1, (byte) 1 };
        int[] intArray48 = new int[] { (short) 1, 32 };
        int[] intArray55 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray48);
        int[] intArray60 = new int[] { (short) 1, (byte) 1 };
        int[] intArray63 = new int[] { (short) 1, 32 };
        int[] intArray70 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray63);
        int[] intArray75 = new int[] { (short) 1, (byte) 1 };
        int[] intArray78 = new int[] { (short) 1, 32 };
        int[] intArray85 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray78, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray78);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray78);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray60);
        try {
            int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 118.43141475132347d + "'", double13 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 118.43141475132347d + "'", double28 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 118.43141475132347d + "'", double41 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 195 + "'", int42 == 195);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 118.43141475132347d + "'", double56 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 118.43141475132347d + "'", double71 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 31 + "'", int72 == 31);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 118.43141475132347d + "'", double86 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 31 + "'", int87 == 31);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 31 + "'", int88 == 31);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 31 + "'", int89 == 31);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.ceil(194.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 194.0d + "'", double1 == 194.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-37.232096219594695d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 100.51368066089312d, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.00000000000001d + "'", double1 == 96.00000000000001d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1528444521);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1528444544 + "'", int1 == 1528444544);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 100, (long) 1528444544);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-95.99999999999999d), (-3.110352820159525d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.603184505581172d) + "'", double2 == (-1.603184505581172d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = org.apache.commons.math.util.FastMath.min((-316898364), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-316898364) + "'", int2 == (-316898364));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.31349432818165834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 40, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-6955610928549199872L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 31);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4098018484275194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0951438644736284d + "'", double1 == 3.0951438644736284d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 96.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3724.225668350351d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-899659405) + "'", int1 == (-899659405));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(32, 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-936.1946107697584d), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(43.12184760565226d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.121847605652256d + "'", double2 == 43.121847605652256d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.009022755461861152d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5958054171689086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6316866363323128d + "'", double1 == 0.6316866363323128d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 10, (-71302844527667943L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-959457121), 1.4524424832623713E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.594571209999999E8d) + "'", double2 == (-9.594571209999999E8d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 32L, 0.5157837238723002d, 6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.9E-324d, 11.993498045565198d, (double) (-9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.605170185988093d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.1415926535897927d) + "'", double1 == (-3.1415926535897927d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.835438933818835d + "'", double1 == 1.835438933818835d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int2 = org.apache.commons.math.util.FastMath.min((-1408344889), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1408344889) + "'", int2 == (-1408344889));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        long long2 = org.apache.commons.math.util.FastMath.max((-6955610928549199872L), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.52107990906477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8750399924480483d + "'", double1 == 1.8750399924480483d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double2 = org.apache.commons.math.util.FastMath.pow(Double.NaN, 6.691673596021443E41d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.log(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int2 = org.apache.commons.math.util.FastMath.min((-53), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) -1, (long) 1077936169);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, 104569339904L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104569339904L + "'", long2 == 104569339904L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2511337694649084753L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { (short) 1, (byte) 1 };
        int[] intArray6 = new int[] { (short) 1, 32 };
        int[] intArray13 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray6);
        int[] intArray18 = new int[] { (short) 1, (byte) 1 };
        int[] intArray21 = new int[] { (short) 1, 32 };
        int[] intArray28 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray21);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray21);
        int[] intArray34 = new int[] { (short) 1, (byte) 1 };
        int[] intArray37 = new int[] { (short) 1, 32 };
        int[] intArray44 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        int[] intArray49 = new int[] { (short) 1, (byte) 1 };
        int[] intArray52 = new int[] { (short) 1, 32 };
        int[] intArray59 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray52);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray52);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray37);
        int[] intArray66 = new int[] { (short) 1, (byte) 1 };
        int[] intArray69 = new int[] { (short) 1, 32 };
        int[] intArray76 = new int[] { (short) 100, 'a', (byte) 0, (short) 100, (short) 100, 100 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray76);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray69);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray69);
        try {
            int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 118.43141475132347d + "'", double14 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 118.43141475132347d + "'", double29 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 118.43141475132347d + "'", double45 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 118.43141475132347d + "'", double60 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 118.43141475132347d + "'", double77 == 118.43141475132347d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 31 + "'", int78 == 31);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-96));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-96) + "'", int1 == (-96));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5256198019480952d + "'", double1 == 0.5256198019480952d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5, 183579396L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 183579396L + "'", long2 == 183579396L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(117.64158883361279d, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.57095826455913d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1961646473490529d + "'", double1 == 0.1961646473490529d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.8750399924480483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.594571520000001E8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2117298158) + "'", int1 == (-2117298158));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1077936169, (long) (-9));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 938L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 938.0f + "'", float1 == 938.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 9700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-96), 132);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 14524424832624L, (float) (-938L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-938.0f) + "'", float2 == (-938.0f));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-316898364));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int2 = org.apache.commons.math.util.FastMath.min(1077936158, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 970L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(9700, 1078034432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 5, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int1 = org.apache.commons.math.util.FastMath.abs(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, 1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5559594203007321d) + "'", double2 == (-0.5559594203007321d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1528444544, (-2117298158));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 100, 11.993498045565198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.539472934348473d + "'", double2 == 0.539472934348473d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, (-316898364));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 316898364 + "'", int2 == 316898364);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-9.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9998765901959134d) + "'", double1 == (-0.9998765901959134d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 5340482110486216705L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 1077936158L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000000000002d, 96.26705125297137d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-4.0d), 0.9126365759632116d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 9700);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9700.000000000002d + "'", double1 == 9700.000000000002d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 8.4072249E18f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.59457152E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.1547543309026267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5513303581418868d) + "'", double1 == (-0.5513303581418868d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 320);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double2 = org.apache.commons.math.util.FastMath.atan2(105.0d, (-4.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6088731523847d + "'", double2 == 1.6088731523847d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693249 + "'", int1 == 1072693249);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1528444544, (-28.754080141118614d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-28.754080141118614d) + "'", double2 == (-28.754080141118614d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 10, 8407224849895527215L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-9.5945712E8d), 0.0d, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1408344889), (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 31);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 96L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 938L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-9), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1958073010), 1077936127);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 938L, (float) 959457161L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.5945715E8f + "'", float2 == 9.5945715E8f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int2 = org.apache.commons.math.util.MathUtils.pow(959457152, 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5697653993250724d + "'", double1 == 1.5697653993250724d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-53), 96);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 320);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 320 + "'", int2 == 320);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.52107990906477d, number1, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNull(number4);
    }
}

